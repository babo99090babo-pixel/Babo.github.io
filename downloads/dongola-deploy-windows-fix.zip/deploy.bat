@echo off
chcp 65001 >nul
title Dongola Engineering - publish site
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is not installed. Install it from https://nodejs.org then run this file again.
  echo.
  pause
  exit /b 1
)

echo.
echo This publishes the site, the Firestore security rules and indexes to the project dongola-eng.
echo First configure adminAccess/roster using docs\ADMIN-ACCOUNTS-AR.md. Old owner access will be removed.
echo Read docs\GUIDE-AR.md section "publishing" first. Results data must be migrated from the admin panel after publishing.
echo.
set /p CONFIRM=Type PUBLISH to continue:
if /i not "%CONFIRM%"=="PUBLISH" (
  echo Cancelled.
  pause
  exit /b 1
)

echo.
echo Step 1 of 4: installing tools (first time only)...
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed

echo.
echo Step 2 of 4: building pages and checking files...
call npm run build
if errorlevel 1 goto failed
call npm run check
if errorlevel 1 goto failed

echo.
echo Step 3 of 4: sign in to Google (a browser window opens the first time).
call npx firebase login
if errorlevel 1 goto failed

echo.
echo Step 4 of 4: publishing rules, indexes and the site...
call npx firebase deploy --only firestore:rules,firestore:indexes,hosting --project dongola-eng
if errorlevel 1 goto failed

echo.
echo Done. The site is at: https://dongola-eng.web.app
echo Next: open admin.html, sign in with a verified email in adminAccess/roster, and run "results import" for old results.
echo.
pause
exit /b 0

:failed
echo.
echo Publishing stopped because of an error. Nothing after the failed step was published.
pause
exit /b 1
