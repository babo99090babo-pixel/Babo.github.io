@echo off
chcp 65001 >nul
setlocal
title Dongola Engineering - initialize administrators
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 20 or newer, then run this file again.
  pause
  exit /b 1
)

echo Initial administrator list for Firebase project dongola-eng:
echo Dean: babo99090babo@gmail.com
echo Control director: chat99090chat@gmail.com
echo Faculty registrar: oneplus99090@gmail.com
echo All three accounts will have full administrator permissions.
echo Read docs\ADMIN-ACCOUNTS-AR.md before running this setup.
echo This requires trusted Application Default Credentials for dongola-eng.
echo Existing lists will not be overwritten. This command does not publish the site.
echo.

call npm ci --no-audit --no-fund
if errorlevel 1 goto failed

call npm run admins:init -- --project dongola-eng --emails "babo99090babo@gmail.com,chat99090chat@gmail.com,oneplus99090@gmail.com"
if errorlevel 1 goto failed

echo.
echo Initial list saved. Follow docs\ADMIN-ACCOUNTS-AR.md to enable sign-in and publish.
echo Future administrator changes are made from the website administration panel.
pause
exit /b 0

:failed
echo.
echo Setup stopped. Check the error above; an existing administrator list is preserved.
pause
exit /b 1
