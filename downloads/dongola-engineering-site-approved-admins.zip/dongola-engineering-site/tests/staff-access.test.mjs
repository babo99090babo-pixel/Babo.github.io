import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { adminEmails, resolveStaffRole } from '../public/js/staff-access.js';

describe('قائمة الإداريين الشخصية', () => {
  test('تقبل البريد الشخصي وتوحّد الأحرف وتترك المقاعد الفارغة', () => {
    assert.deepEqual(adminEmails([' First@Gmail.com ', '', 'second@outlook.com'], 'first@gmail.com'), ['first@gmail.com', 'second@outlook.com']);
  });
  test('تمنع التكرار بعد التوحيد وتجاوز ثلاثة وإزالة المدير الحالي', () => {
    assert.throws(() => adminEmails(['a@gmail.com', ' A@gmail.com ']));
    assert.throws(() => adminEmails(['a@b.com', 'b@b.com', 'c@b.com', 'd@b.com']));
    assert.throws(() => adminEmails(['replacement@gmail.com'], 'current@gmail.com'));
    assert.throws(() => adminEmails(['', ' ']));
  });
  test('ترفض العناوين التي تكسر مسار الوثيقة أو تحتوي فراغًا أو تتجاوز الحد', () => {
    for (const email of ['a/b@gmail.com', 'a b@gmail.com', 'a@@gmail.com', 'a@example', 'a'.repeat(250) + '@gmail.com']) {
      assert.throws(() => adminEmails([email]), email);
    }
  });
});

const snapshot = data => ({ exists: () => data !== null, data: () => data });
function backend({ roster = null, staff = null, rosterError = 'permission-denied' } = {}) {
  const reads = [];
  return { reads, db: {}, F: {
    doc: (_db, collection, id) => `${collection}/${id}`,
    async getDocFromServer(path) {
      reads.push(path);
      if (path === 'adminAccess/roster') {
        if (rosterError) throw Object.assign(new Error(rosterError), { code: rosterError });
        return snapshot(roster);
      }
      return snapshot(staff);
    }
  } };
}
const user = { email: 'personal@gmail.com', emailVerified: true };
describe('حل الدور دون مالك ثابت أو صلاحية من الذاكرة المحلية', () => {
  test('لا يستعلم ولا يمنح دورًا لبريد غير موثّق', async () => {
    const fb = backend({ roster: { emails: [user.email] }, rosterError: null });
    assert.equal(await resolveStaffRole(fb, { ...user, emailVerified: false }), null);
    assert.deepEqual(fb.reads, []);
  });
  test('يمنح الإدارة من القائمة على الخادم فقط', async () => {
    const fb = backend({ roster: { emails: [user.email] }, rosterError: null });
    assert.equal(await resolveStaffRole(fb, { ...user, email: 'PERSONAL@gmail.com' }), 'admin');
    assert.deepEqual(fb.reads, ['adminAccess/roster']);
  });
  test('رفض القائمة الخاصة يسمح بقراءة دور الموظف نفسه', async () => {
    const fb = backend({ staff: { role: 'results', active: true } });
    assert.equal(await resolveStaffRole(fb, user), 'results');
    assert.deepEqual(fb.reads, ['adminAccess/roster', 'staff/personal@gmail.com']);
  });
  test('يرفض سجل admin قديم والموظف المعطل والبريد المالك القديم', async () => {
    for (const staff of [null, { role: 'admin', active: true }, { role: 'editor', active: false }]) {
      assert.equal(await resolveStaffRole(backend({ staff }), { ...user, email: 'babo99090babo@gmail.com' }), null);
    }
  });
  test('خطأ اتصال الخادم لا يتحول إلى دور بديل قديم', async () => {
    const fb = backend({ rosterError: 'unavailable', staff: { role: 'editor', active: true } });
    await assert.rejects(() => resolveStaffRole(fb, user), { code: 'unavailable' });
    assert.deepEqual(fb.reads, ['adminAccess/roster']);
  });
});
