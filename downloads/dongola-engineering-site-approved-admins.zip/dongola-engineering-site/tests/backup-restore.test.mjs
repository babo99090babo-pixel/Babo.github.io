// اختبار النسخ الاحتياطي والاستعادة على المحاكي ببيانات وهمية.
// التشغيل: npm run test:backup
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { backupPayload, restoreAll, encrypt, decrypt } from '../tools/lib/firestore-backup.mjs';

const PROJECT = 'demo-dongola';
process.env.FIRESTORE_EMULATOR_HOST ||= '127.0.0.1:8080';
initializeApp({ projectId: PROJECT });
const db = getFirestore();

async function wipe() {
  const res = await fetch(`http://${process.env.FIRESTORE_EMULATOR_HOST}/emulator/v1/projects/${PROJECT}/databases/(default)/documents`, { method: 'DELETE' });
  assert.equal(res.ok, true);
}

test('نسخة كاملة ثم مسح ثم استعادة تعيد البيانات كما كانت', async () => {
  await wipe();
  const when = Timestamp.fromDate(new Date('2026-05-01T10:00:00Z'));
  const fixtures = {
    'adminAccess/roster': { emails: ['admin@test.local', 'admin2@test.local', 'admin3@test.local'], updatedBy: 'x', updatedAt: when },
    'staff/editor@test.local': { role: 'editor', active: true, name: 'وهمي', assignedBy: 'x', assignedAt: when },
    'batches/fake-b1': { year: '2025/2026', round: 1, subjects: [{ name: 'مادة وهمية', hours: 3 }], published: true },
    'results/fake-b1__F-1': { batchId: 'fake-b1', seatNo: 'F-1', name: 'طالب وهمي', grades: ['A', null], semesterGPA: 3.5, published: true },
    'public/news/items/fake-n1': { title: 'خبر وهمي', date: '2026-01-01', attachments: [{ title: 'ملف', url: 'files/x.pdf' }], _updatedAt: when },
    'drafts/news/items/fake-n1': { title: 'خبر وهمي', _status: 'published', _updatedAt: when },
    'audit/a1': { area: 'content', action: 'publish', summary: 'وهمي', at: when }
  };
  for (const [p, d] of Object.entries(fixtures)) await db.doc(p).set(d);

  const payload = await backupPayload(db, PROJECT);
  assert.equal(payload.count, Object.keys(fixtures).length);

  // التشفير يعيد النص نفسه، ويرفض عبارة مرور خاطئة
  const json = JSON.stringify(payload);
  const enc = encrypt(json, 'عبارة-تجريبية-طويلة');
  assert.notEqual(enc.includes('طالب وهمي'), true);
  assert.equal(decrypt(enc, 'عبارة-تجريبية-طويلة'), json);
  assert.throws(() => decrypt(enc, 'خطأ'));

  await wipe();
  assert.equal((await db.doc('results/fake-b1__F-1').get()).exists, false);

  const r = await restoreAll(db, JSON.parse(decrypt(enc, 'عبارة-تجريبية-طويلة')));
  assert.equal(r.written, Object.keys(fixtures).length);
  for (const [p, d] of Object.entries(fixtures)) {
    const snap = await db.doc(p).get();
    assert.equal(snap.exists, true, p);
    assert.deepEqual(snap.data(), d, p);
  }
});

test('الاستعادة الجزئية تكتب المجموعات المحددة فقط، والمعاينة لا تكتب شيئًا', async () => {
  await wipe();
  await db.doc('results/fake-b1__F-2').set({ batchId: 'fake-b1', seatNo: 'F-2', name: 'وهمي', grades: [], published: false });
  await db.doc('public/news/items/fake-n2').set({ title: 'وهمي' });
  const payload = await backupPayload(db, PROJECT);
  await wipe();
  const dry = await restoreAll(db, payload, { dryRun: true });
  assert.equal(dry.written, 0);
  assert.equal((await db.doc('results/fake-b1__F-2').get()).exists, false);
  await restoreAll(db, payload, { only: ['results'] });
  assert.equal((await db.doc('results/fake-b1__F-2').get()).exists, true);
  assert.equal((await db.doc('public/news/items/fake-n2').get()).exists, false);
});

test('يرفض ملفًا ليس نسخة احتياطية', async () => {
  await assert.rejects(() => restoreAll(db, { format: 'other', docs: {} }));
});
