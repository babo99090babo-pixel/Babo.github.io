// اختبارات وحدات لا تحتاج المحاكي: العرض الآمن، التحقق من المدخلات، قراءة الملف القديم، حساب المعدل.
// التشغيل: npm run test:unit
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import vm from 'node:vm';
import { parseLegacyResults } from '../public/js/admin/legacy-parse.js';
import { autoRow, classify, normSeat, normalizeBatch, parseGpa } from '../public/js/admin/results-logic.js';
import { activationCode, toJsonValue } from '../public/js/admin/util.js';

const sandbox = { window: {}, location: { hostname: 'test', search: '', origin: 'https://example.test' }, URLSearchParams, sessionStorage: { getItem: () => null, setItem() {} }, Intl };
sandbox.globalThis = sandbox.window;
for (const f of ['site-config.js', 'cms-schema.js', 'cms-render.js']) {
  vm.runInNewContext(readFileSync(new URL('../public/js/' + f, import.meta.url), 'utf8'), sandbox);
}
const S = sandbox.window.CMS_SCHEMA;
const R = sandbox.window.CMSRender;

describe('العرض الآمن للنصوص', () => {
  test('يهرّب HTML ولا ينفذ أي وسم', () => {
    const html = R.markdown('<script>alert(1)</script> <img src=x onerror=alert(2)>');
    assert.ok(!html.includes('<script'));
    assert.ok(!html.includes('<img'));
    assert.ok(html.includes('&lt;script&gt;'));
  });
  test('يرفض الروابط الخطرة ويقبل الآمنة', () => {
    for (const bad of ['javascript:alert(1)', 'JaVaScRiPt:alert(1)', 'data:text/html,x', 'vbscript:x', '//evil.example/x']) {
      assert.ok(!R.markdown(`[اضغط](${bad})`).includes('<a'), bad);
    }
    assert.ok(R.markdown('[الموقع](https://example.com)').includes('href="https://example.com"'));
    assert.ok(R.markdown('[ملف](files/a.pdf)', '../').includes('href="../files/a.pdf"'));
    assert.ok(R.markdown('[بريد](mailto:a@b.c)').includes('href="mailto:a@b.c"'));
    assert.equal(R.safeHref('java\tscript:alert(1)'), '');
  });
  test('يحوّل العناوين والقوائم والجداول', () => {
    const html = R.markdown('## عنوان\n\n- أ\n- ب\n\n1. أول\n\n| أ | ب |\n|---|---|\n| ١ | ٢ |\n\n**غامق**');
    assert.match(html, /<h2>عنوان<\/h2>/);
    assert.match(html, /<ul><li>أ<\/li><li>ب<\/li><\/ul>/);
    assert.match(html, /<ol><li>أول<\/li><\/ol>/);
    assert.match(html, /<th scope="col">أ<\/th>/);
    assert.match(html, /<strong>غامق<\/strong>/);
  });
  test('الروابط الخارجية تفتح بأمان في نافذة جديدة', () => {
    const html = R.markdown('https://example.com/x');
    assert.match(html, /rel="noopener noreferrer"/);
  });
  test('البطاقات تهرّب العناوين', () => {
    const html = R.card('news', { id: 'n1', title: '<b>x</b>', summary: '"><svg onload=1>', date: '2026-01-01' }, '');
    assert.ok(!html.includes('<b>x'));
    assert.ok(!html.includes('<svg'));
  });
  test('تاريخ عربي', () => {
    assert.match(R.fmtDate('2026-09-01'), /٢٠٢٦/);
    assert.equal(R.fmtDate('غير صالح'), '');
  });
});

describe('التحقق من المدخلات', () => {
  test('المسودة تحتاج العنوان فقط، والنشر يحتاج الحقول المطلوبة', () => {
    const d = S.clean('news', { title: 'خبر' });
    assert.equal(S.validate('news', d, 'draft').length, 0);
    const keys = S.validate('news', d, 'publish').map(e => e.key);
    assert.ok(keys.includes('category') && keys.includes('date') && keys.includes('summary'));
    assert.ok(S.validate('news', S.clean('news', {}), 'draft').some(e => e.key === 'title'));
  });
  test('يرفض بريدًا أو رابطًا أو تاريخًا غير صالح', () => {
    const errs = S.validate('faculty', S.clean('faculty', { title: 'س', email: 'not-an-email', photo: 'javascript:x' }), 'draft');
    assert.ok(errs.some(e => e.key === 'email'));
    assert.ok(errs.some(e => e.key === 'photo'));
    assert.ok(S.validate('services', S.clean('services', { title: 'خ', url: 'http://insecure.example' }), 'draft').some(e => e.key === 'url'));
    assert.ok(S.validate('calendar', S.clean('calendar', { title: 'م', startDate: '2026-13-45' }), 'draft').some(e => e.key === 'startDate'));
  });
  test('يرفض أنواع الملفات غير المسموحة', () => {
    const errs = S.validate('documents', S.clean('documents', { title: 'ن', attachments: [{ title: 'برنامج', url: 'files/setup.exe' }] }), 'draft');
    assert.ok(errs.some(e => e.key === 'attachments'));
    assert.equal(S.validate('documents', S.clean('documents', { title: 'ن', attachments: [{ title: 'لائحة', url: 'files/rules.pdf' }] }), 'draft').length, 0);
  });
  test('موافقة عضو هيئة التدريس واعتماد الصفحات شرط للنشر', () => {
    const member = S.clean('faculty', { title: 'د. س', academicTitle: 'محاضر', department: 'civil', specialization: 'إنشاءات' });
    assert.ok(S.validate('faculty', member, 'publish').some(e => e.key === 'consent'));
    assert.equal(S.validate('faculty', { ...member, consent: true }, 'publish').length, 0);
    const page = S.clean('pages', { title: 'الرؤية', body: 'نص' });
    assert.ok(S.validate('pages', page, 'publish').some(e => e.key === 'approvedBy'));
  });
  test('النموذج يحتاج طريقة الاستخدام، والتقويم يرفض نهاية قبل البداية', () => {
    const form = S.clean('documents', { title: 'نموذج', kind: 'form', purpose: 'و', attachments: [{ title: 'م', url: 'files/a.pdf' }] });
    assert.ok(S.validate('documents', form, 'publish').some(e => e.key === 'howToUse'));
    const cal = S.clean('calendar', { title: 'م', academicYear: '2026/2027', category: 'الدراسة', startDate: '2026-11-10', endDate: '2026-11-01' });
    assert.ok(S.validate('calendar', cal, 'publish').some(e => e.key === 'endDate'));
  });
  test('أسماء طلاب المشاريع تحتاج موافقتهم', () => {
    const p = S.clean('projects', { title: 'م', academicYear: '2025/2026', department: 'civil', summary: 'م', students: 'طالب أ\nطالب ب' });
    assert.deepEqual([...p.students], ['طالب أ', 'طالب ب']);
    assert.ok(S.validate('projects', p, 'publish').some(e => e.key === 'studentsConsent'));
  });
  test('الأرقام غير الموثقة تظهر تنبيهًا', () => {
    const w = S.warnings('settings', S.clean('settings', { title: 'إعدادات', facts: [{ value: '20', label: 'عضو', verified: false }] }));
    assert.ok(w.some(x => x.includes('غير موثَّق')));
  });
  test('التنظيف يحذف الصفوف الفارغة ويحوّل الأرقام', () => {
    const d = S.clean('departments', { title: 'ق', courses: [{ name: 'مقرر', hours: '3' }, { name: '', hours: '' }] });
    assert.equal(d.courses.length, 1);
    assert.equal(d.courses[0].hours, 3);
  });
});

describe('قراءة ملف النتائج القديم دون تنفيذه', () => {
  test('يقرأ الصيغة القديمة مع التعليقات والفواصل الزائدة والعلامات المفردة', () => {
    const text = `/* رأس */\nconst RESULTS_DATA = [\n // تعليق\n { id: "b1", round: 1, subjects: [{ name: 'م', hours: 3 },], students: [ { name: "وهمي", seatNo: "21-05", grades: ["A", null], semesterGPA: 3.5, ok: true } ], },\n];\n`;
    const data = parseLegacyResults(text);
    assert.equal(data.length, 1);
    assert.equal(data[0].students[0].seatNo, '21-05');
    assert.equal(data[0].students[0].grades[1], null);
  });
  test('يرفض أي شيفرة قابلة للتنفيذ', () => {
    assert.throws(() => parseLegacyResults('const RESULTS_DATA = [ alert(1) ];'));
    assert.throws(() => parseLegacyResults('const RESULTS_DATA = [ { a: fetch("x") } ];'));
    assert.throws(() => parseLegacyResults('const RESULTS_DATA = [ { __proto__: { admin: true } } ];'));
    assert.throws(() => parseLegacyResults('var x = 1;'));
  });
  test('ملف النتائج الأصلي (إن وُجد في المجلد الخاص) يُقرأ كاملًا دون عرض بياناته', { skip: !process.env.PRIVATE_RESULTS_FILE || !existsSync(process.env.PRIVATE_RESULTS_FILE || '') }, () => {
    const data = parseLegacyResults(readFileSync(process.env.PRIVATE_RESULTS_FILE, 'utf8'));
    const batches = data.map(normalizeBatch);
    const students = batches.reduce((n, b) => n + b.students.length, 0);
    const invalid = batches.flatMap(b => b.students.filter(s => !/^[0-9A-Za-z-]{1,20}$/.test(s.seatNo))).length;
    console.log(`  (الملف الأصلي: ${batches.length} دفعات، ${students} سجل طالب، أرقام جلوس غير صالحة: ${invalid})`);
    assert.ok(batches.length > 0 && students > 0);
    assert.equal(invalid, 0);
  });
});

describe('حساب المعدلات والتقديرات', () => {
  const batch = { semester: 'الفصل الدراسي الأول', subjects: [{ hours: 3 }, { hours: 2 }] };
  test('يحسب المعدل الفصلي والتقدير', () => {
    const st = { grades: ['A', 'B'], cumulativeGPA: null, status: '' };
    autoRow(st, batch);
    assert.equal(st.semesterGPA, 3.6);
    assert.equal(st.cumulativeGPA, 3.6);
    assert.equal(st.status, 'نجاح');
    assert.equal(st.classification, 'ممتاز');
  });
  test('الرسوب في مادة يعني ملحقًا دون معدل', () => {
    const st = { grades: ['F', 'F'], status: '' };
    autoRow(st, batch);
    assert.equal(st.status, 'ملحق');
    assert.equal(st.notes, 'ملحق/2');
    assert.equal(st.semesterGPA, null);
  });
  test('حدود التقديرات', () => {
    assert.equal(classify(3.5), 'ممتاز');
    assert.equal(classify(3.0), 'جيد جداً');
    assert.equal(classify(2.5), 'جيد');
    assert.equal(classify(2.49), 'مقبول');
    assert.equal(classify(null), null);
  });
  test('توحيد رقم الجلوس والمعدل المكتوب بالأرقام العربية', () => {
    assert.equal(normSeat(' ٢١-٠٥ '), '21-05');
    assert.equal(normSeat('t–1003'), 'T-1003');
    assert.equal(parseGpa('٣٫٢٥'.replace('٫', '.')), 3.25);
    assert.equal(parseGpa('3,5'), 3.5);
  });
});

describe('رموز التفعيل والنسخ', () => {
  test('الرمز ١٢ خانة من أحرف وأرقام غير ملتبسة، ولا يتكرر', () => {
    const seen = new Set();
    for (let i = 0; i < 2000; i++) {
      const c = activationCode();
      assert.match(c, /^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/);
      seen.add(c);
    }
    assert.equal(seen.size, 2000);
  });
  test('تحويل الوقت في النسخ الاحتياطية', () => {
    const ts = { seconds: 1, nanoseconds: 0, toDate: () => new Date(1000) };
    assert.deepEqual(toJsonValue({ a: ts, b: [ts] }), { a: { __ts: '1970-01-01T00:00:01.000Z' }, b: [{ __ts: '1970-01-01T00:00:01.000Z' }] });
  });
});
