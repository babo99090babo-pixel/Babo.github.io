// اختبارات قواعد Firestore على المحاكي ببيانات وهمية فقط.
// التشغيل: npm run test:rules
import { test, before, after, beforeEach, describe } from 'node:test';
import { readFileSync } from 'node:fs';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import {
  doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, getDocs,
  writeBatch, serverTimestamp, addDoc, setLogLevel
} from 'firebase/firestore';

// الرفض المتوقع في الاختبارات يملأ السجل برسائل PERMISSION_DENIED؛ نخفيها
setLogLevel('silent');

const PROJECT = 'demo-dongola';
let env;

const USERS = {
  owner: { uid: 'u-owner', email: 'babo99090babo@gmail.com' },
  admin: { uid: 'u-admin', email: 'admin@test.local' },
  admin2: { uid: 'u-admin2', email: 'admin2@test.local' },
  admin3: { uid: 'u-admin3', email: 'admin3@test.local' },
  replacement: { uid: 'u-replacement', email: 'replacement@gmail.com' },
  legacyAdmin: { uid: 'u-legacy', email: 'legacy@test.local' },
  editor: { uid: 'u-editor', email: 'editor@test.local' },
  news: { uid: 'u-news', email: 'news@test.local' },
  results: { uid: 'u-results', email: 'results@test.local' },
  inactive: { uid: 'u-inactive', email: 'inactive@test.local' },
  s1: { uid: 'u-s1', email: 's1@test.local' },
  s2: { uid: 'u-s2', email: 's2@test.local' },
  s3: { uid: 'u-s3', email: 's3@test.local' },
  s4: { uid: 'u-s4', email: 's4@test.local' }
};

function db(name, verified = true) {
  if (!name) return env.unauthenticatedContext().firestore();
  const u = USERS[name];
  return env.authenticatedContext(u.uid, { email: u.email, email_verified: verified }).firestore();
}

const meta = uid => ({ _updatedBy: uid, _updatedAt: serverTimestamp() });

async function seed() {
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    const staff = (role, active = true) => ({ role, active, name: 'تجريبي', assignedBy: 'seed', assignedAt: new Date() });
    await setDoc(doc(d, 'adminAccess/roster'), {
      emails: [USERS.admin.email, USERS.admin2.email, USERS.admin3.email],
      updatedBy: 'seed', updatedAt: new Date()
    });
    // سجل admin قديم لا يمنح صلاحية بعد الانتقال إلى القائمة الجديدة.
    await setDoc(doc(d, 'staff/legacy@test.local'), staff('admin'));
    await setDoc(doc(d, 'staff/editor@test.local'), staff('editor'));
    await setDoc(doc(d, 'staff/news@test.local'), staff('news'));
    await setDoc(doc(d, 'staff/results@test.local'), staff('results'));
    await setDoc(doc(d, 'staff/inactive@test.local'), staff('admin', false));

    await setDoc(doc(d, 'public/news/items/n1'), { title: 'خبر تجريبي', date: '2026-01-01' });
    await setDoc(doc(d, 'drafts/news/items/n2'), { title: 'مسودة تجريبية', _status: 'draft' });

    const subjects = [{ name: 'مادة أ', hours: 3 }];
    await setDoc(doc(d, 'batches/b-test'), { year: '2025/2026', round: 1, subjects, published: true, semester: 'الفصل الدراسي الأول', specialization: 'هندسة مدنية' });
    const result = (seatNo, published = true) => ({
      batchId: 'b-test', seatNo, name: 'طالب تجريبي ' + seatNo, grades: ['A'], published,
      year: '2025/2026', round: 1, subjects
    });
    await setDoc(doc(d, 'results/b-test__T-001'), result('T-001'));
    await setDoc(doc(d, 'results/b-test__T-002'), result('T-002'));
    await setDoc(doc(d, 'results/b-hidden__T-001'), { ...result('T-001', false), batchId: 'b-hidden' });

    // s1 مرتبط بـ T-001، و s2 مرتبط بـ T-002
    await setDoc(doc(d, 'studentLinks/u-s1'), { seatNo: 'T-001', code: 'AAAA-AAAA-AAA1', email: 's1@test.local', linkedAt: new Date() });
    await setDoc(doc(d, 'studentLinks/u-s2'), { seatNo: 'T-002', code: 'AAAA-AAAA-AAA2', email: 's2@test.local', linkedAt: new Date() });
    await setDoc(doc(d, 'seatClaims/T-001'), { uid: 'u-s1', claimedAt: new Date() });
    await setDoc(doc(d, 'seatClaims/T-002'), { uid: 'u-s2', claimedAt: new Date() });

    await setDoc(doc(d, 'activationCodes/AAAA-AAAA-AAA1'), { seatNo: 'T-001', usedBy: 'u-s1', usedAt: new Date() });
    await setDoc(doc(d, 'activationCodes/CCCC-CCCC-CCC3'), { seatNo: 'T-003', usedBy: null, usedAt: null });
    // رمز ثانٍ صالح لرقم جلوس مرتبط مسبقًا (لاختبار منع الربط المزدوج)
    await setDoc(doc(d, 'activationCodes/DDDD-DDDD-DDD1'), { seatNo: 'T-001', usedBy: null, usedAt: null });
    await setDoc(doc(d, 'audit/a1'), { area: 'content', action: 'publish', target: 'news/n1', summary: 'x', by: 'u-editor', email: 'editor@test.local', role: 'editor', at: new Date() });
    await setDoc(doc(d, 'audit/a2'), { area: 'results', action: 'save', target: 'batches/b-test', summary: 'x', by: 'u-results', email: 'results@test.local', role: 'results', at: new Date() });
  });
}

// عملية الربط كما ينفّذها المتصفح: ربط + تعليم الرمز + حجز رقم الجلوس
function linkBatch(fs, u, seatNo, code) {
  const b = writeBatch(fs);
  b.set(doc(fs, 'studentLinks/' + u.uid), { seatNo, code, email: u.email, linkedAt: serverTimestamp() });
  b.update(doc(fs, 'activationCodes/' + code), { usedBy: u.uid, usedAt: serverTimestamp() });
  b.set(doc(fs, 'seatClaims/' + seatNo), { uid: u.uid, claimedAt: serverTimestamp() });
  return b.commit();
}

before(async () => {
  env = await initializeTestEnvironment({
    projectId: PROJECT,
    firestore: { rules: readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8') }
  });
});
after(async () => { await env.cleanup(); });
beforeEach(async () => { await env.clearFirestore(); await seed(); });

describe('الزائر غير المسجّل', () => {
  test('يقرأ المحتوى المنشور', async () => {
    await assertSucceeds(getDoc(doc(db(), 'public/news/items/n1')));
    await assertSucceeds(getDocs(collection(db(), 'public/news/items')));
  });
  test('لا يقرأ المسودات', async () => {
    await assertFails(getDoc(doc(db(), 'drafts/news/items/n2')));
  });
  test('لا يكتب المحتوى', async () => {
    await assertFails(setDoc(doc(db(), 'public/news/items/x'), { title: 'x' }));
  });
  test('لا يقرأ النتائج ولا الدفعات', async () => {
    await assertFails(getDoc(doc(db(), 'results/b-test__T-001')));
    await assertFails(getDocs(collection(db(), 'results')));
    await assertFails(getDoc(doc(db(), 'batches/b-test')));
  });
  test('لا يقرأ الصلاحيات أو الرموز أو السجل', async () => {
    await assertFails(getDoc(doc(db(), 'staff/admin@test.local')));
    await assertFails(getDoc(doc(db(), 'activationCodes/CCCC-CCCC-CCC3')));
    await assertFails(getDocs(collection(db(), 'audit')));
  });
  test('نوع محتوى غير معروف مغلق', async () => {
    await assertFails(getDocs(collection(db(), 'public/secret/items')));
  });
});

describe('الطالب', () => {
  test('يقرأ نتيجته المنشورة', async () => {
    await assertSucceeds(getDoc(doc(db('s1'), 'results/b-test__T-001')));
  });
  test('يستعلم عن نتائجه برقم جلوسه', async () => {
    const q = query(collection(db('s1'), 'results'), where('seatNo', '==', 'T-001'), where('published', '==', true));
    const snap = await assertSucceeds(getDocs(q));
    if (snap.size !== 1) throw new Error('توقعنا نتيجة واحدة منشورة، وجدنا ' + snap.size);
  });
  test('لا يقرأ نتيجة طالب آخر', async () => {
    await assertFails(getDoc(doc(db('s1'), 'results/b-test__T-002')));
    await assertFails(getDocs(query(collection(db('s1'), 'results'), where('seatNo', '==', 'T-002'), where('published', '==', true))));
  });
  test('لا يسرد كل النتائج', async () => {
    await assertFails(getDocs(collection(db('s1'), 'results')));
    await assertFails(getDocs(query(collection(db('s1'), 'results'), where('published', '==', true))));
  });
  test('لا يقرأ نتيجته قبل نشرها', async () => {
    await assertFails(getDoc(doc(db('s1'), 'results/b-hidden__T-001')));
    await assertFails(getDocs(query(collection(db('s1'), 'results'), where('seatNo', '==', 'T-001'))));
  });
  test('لا يقرأ النتائج إذا لم يوثّق بريده', async () => {
    await assertFails(getDoc(doc(db('s1', false), 'results/b-test__T-001')));
  });
  test('لا يعدّل النتائج', async () => {
    await assertFails(updateDoc(doc(db('s1'), 'results/b-test__T-001'), { grades: ['A'] }));
    await assertFails(setDoc(doc(db('s1'), 'results/b-test__T-009'), { batchId: 'b-test', seatNo: 'T-009', name: 'x', grades: [], published: true }));
  });
  test('لا يمنح نفسه دورًا إداريًا', async () => {
    await assertFails(setDoc(doc(db('s1'), 'staff/s1@test.local'), { role: 'admin', active: true, assignedBy: 'u-s1', assignedAt: serverTimestamp() }));
  });
  test('لا يغيّر رقم الجلوس المرتبط بحسابه', async () => {
    await assertFails(updateDoc(doc(db('s1'), 'studentLinks/u-s1'), { seatNo: 'T-002' }));
    await assertFails(deleteDoc(doc(db('s1'), 'studentLinks/u-s1')));
  });
  test('يقرأ ربطه فقط', async () => {
    await assertSucceeds(getDoc(doc(db('s1'), 'studentLinks/u-s1')));
    await assertFails(getDoc(doc(db('s1'), 'studentLinks/u-s2')));
  });
  test('لا يقرأ رموز التفعيل', async () => {
    await assertFails(getDoc(doc(db('s3'), 'activationCodes/CCCC-CCCC-CCC3')));
    await assertFails(getDocs(collection(db('s3'), 'activationCodes')));
  });
  test('لا يكتب في سجل التغييرات', async () => {
    await assertFails(addDoc(collection(db('s1'), 'audit'), { area: 'content', action: 'x', target: 'x', summary: 'x', by: 'u-s1', email: 's1@test.local', role: 'none', at: serverTimestamp() }));
  });
});

describe('ربط الحساب برقم الجلوس', () => {
  test('ينجح برمز صحيح لمرة واحدة، ثم يرى نتيجته', async () => {
    await assertSucceeds(linkBatch(db('s3'), USERS.s3, 'T-003', 'CCCC-CCCC-CCC3'));
    await env.withSecurityRulesDisabled(async ctx => {
      await setDoc(doc(ctx.firestore(), 'results/b-test__T-003'), { batchId: 'b-test', seatNo: 'T-003', name: 'طالب تجريبي', grades: ['B'], published: true });
    });
    await assertSucceeds(getDoc(doc(db('s3'), 'results/b-test__T-003')));
    await assertFails(getDoc(doc(db('s3'), 'results/b-test__T-001')));
  });
  test('يفشل برقم جلوس لا يطابق الرمز', async () => {
    await assertFails(linkBatch(db('s3'), USERS.s3, 'T-002', 'CCCC-CCCC-CCC3'));
  });
  test('يفشل برمز غير موجود', async () => {
    await assertFails(linkBatch(db('s3'), USERS.s3, 'T-003', 'ZZZZ-ZZZZ-ZZZ9'));
  });
  test('يفشل برمز مستخدم', async () => {
    await assertFails(linkBatch(db('s4'), USERS.s4, 'T-001', 'AAAA-AAAA-AAA1'));
  });
  test('يفشل لرقم جلوس مرتبط بحساب آخر حتى برمز صالح', async () => {
    await assertFails(linkBatch(db('s4'), USERS.s4, 'T-001', 'DDDD-DDDD-DDD1'));
  });
  test('يفشل لبريد غير موثّق', async () => {
    await assertFails(linkBatch(db('s3', false), USERS.s3, 'T-003', 'CCCC-CCCC-CCC3'));
  });
  test('يفشل إن حاول ربط حساب آخر', async () => {
    const fs = db('s3');
    const b = writeBatch(fs);
    b.set(doc(fs, 'studentLinks/u-s4'), { seatNo: 'T-003', code: 'CCCC-CCCC-CCC3', email: USERS.s3.email, linkedAt: serverTimestamp() });
    b.update(doc(fs, 'activationCodes/CCCC-CCCC-CCC3'), { usedBy: 'u-s4', usedAt: serverTimestamp() });
    b.set(doc(fs, 'seatClaims/T-003'), { uid: 'u-s4', claimedAt: serverTimestamp() });
    await assertFails(b.commit());
  });
  test('لا يعلّم الرمز مستخدمًا دون إنشاء ربط', async () => {
    await assertFails(updateDoc(doc(db('s3'), 'activationCodes/CCCC-CCCC-CCC3'), { usedBy: 'u-s3', usedAt: serverTimestamp() }));
  });
  test('لا يربط حسابًا مرتبطًا مسبقًا مرة ثانية', async () => {
    await assertFails(linkBatch(db('s1'), USERS.s1, 'T-003', 'CCCC-CCCC-CCC3'));
  });
});

describe('محرر المحتوى', () => {
  test('ينشئ المسودات وينشر المحتوى', async () => {
    const fs = db('editor');
    await assertSucceeds(setDoc(doc(fs, 'drafts/departments/items/civil'), { title: 'الهندسة المدنية', _status: 'draft', ...meta(USERS.editor.uid) }));
    await assertSucceeds(setDoc(doc(fs, 'public/departments/items/civil'), { title: 'الهندسة المدنية', ...meta(USERS.editor.uid) }));
    await assertSucceeds(getDoc(doc(fs, 'drafts/news/items/n2')));
  });
  test('يُرفض المحتوى غير الصالح', async () => {
    const fs = db('editor');
    await assertFails(setDoc(doc(fs, 'public/news/items/bad'), { title: '', ...meta(USERS.editor.uid) }));
    await assertFails(setDoc(doc(fs, 'public/news/items/Bad_ID'), { title: 'x', ...meta(USERS.editor.uid) }));
    await assertFails(setDoc(doc(fs, 'public/news/items/ok'), { title: 'x', _updatedBy: 'someone-else', _updatedAt: serverTimestamp() }));
  });
  test('لا يقرأ النتائج ولا يعدّلها', async () => {
    const fs = db('editor');
    await assertFails(getDoc(doc(fs, 'results/b-test__T-001')));
    await assertFails(updateDoc(doc(fs, 'results/b-test__T-001'), { grades: ['F'] }));
    await assertFails(setDoc(doc(fs, 'batches/b-new'), { year: '2026', round: 1, subjects: [], published: false }));
    await assertFails(getDocs(collection(fs, 'activationCodes')));
  });
  test('لا يمنح الصلاحيات', async () => {
    await assertFails(setDoc(doc(db('editor'), 'staff/editor@test.local'), { role: 'admin', active: true, assignedBy: 'u-editor', assignedAt: serverTimestamp() }));
  });
  test('يسجّل في السجل باسمه فقط، ولا يعدّل السجل', async () => {
    const fs = db('editor');
    const entry = { area: 'content', action: 'publish', target: 'news/n1', summary: 'نشر', by: 'u-editor', email: 'editor@test.local', role: 'editor', at: serverTimestamp() };
    await assertSucceeds(addDoc(collection(fs, 'audit'), entry));
    await assertFails(addDoc(collection(fs, 'audit'), { ...entry, by: 'u-admin' }));
    await assertFails(addDoc(collection(fs, 'audit'), { ...entry, role: 'admin' }));
    await assertFails(updateDoc(doc(fs, 'audit/a1'), { summary: 'تعديل' }));
    await assertFails(deleteDoc(doc(fs, 'audit/a1')));
    await assertFails(getDocs(collection(fs, 'audit')));
  });
  test('حساب محرر بلا بريد موثّق لا يملك صلاحية', async () => {
    await assertFails(setDoc(doc(db('editor', false), 'public/news/items/x1'), { title: 'x', ...meta(USERS.editor.uid) }));
  });
});

describe('قراءة الدور', () => {
  test('كل موظف يقرأ وثيقة دوره فقط', async () => {
    await assertSucceeds(getDoc(doc(db('editor'), 'staff/editor@test.local')));
    await assertFails(getDoc(doc(db('editor'), 'staff/admin@test.local')));
    await assertFails(getDocs(collection(db('editor'), 'staff')));
    await assertFails(getDoc(doc(db('editor', false), 'staff/editor@test.local')));
  });
});

describe('محرر الأخبار', () => {
  test('لا يقرأ مسودات الأنواع الأخرى ولا يكتبها', async () => {
    const fs = db('news');
    await assertSucceeds(getDoc(doc(fs, 'drafts/news/items/n2')));
    await assertFails(getDocs(collection(fs, 'drafts/departments/items')));
    await assertFails(setDoc(doc(fs, 'drafts/faculty/items/x'), { title: 'x', _status: 'draft', ...meta(USERS.news.uid) }));
  });
  test('ينشر الأخبار فقط', async () => {
    const fs = db('news');
    await assertSucceeds(setDoc(doc(fs, 'public/news/items/x2'), { title: 'خبر', ...meta(USERS.news.uid) }));
    await assertFails(setDoc(doc(fs, 'public/departments/items/civil'), { title: 'قسم', ...meta(USERS.news.uid) }));
    await assertFails(setDoc(doc(fs, 'public/settings/items/site'), { title: 'إعدادات', ...meta(USERS.news.uid) }));
    await assertFails(getDoc(doc(fs, 'results/b-test__T-001')));
  });
});

describe('مسؤول النتائج', () => {
  test('يقرأ ويعدّل النتائج والدفعات', async () => {
    const fs = db('results');
    await assertSucceeds(getDocs(collection(fs, 'results')));
    await assertSucceeds(updateDoc(doc(fs, 'results/b-test__T-001'), { grades: ['B'] }));
    await assertSucceeds(setDoc(doc(fs, 'batches/b-new'), { year: '2026/2027', round: 1, subjects: [], published: false }));
    await assertSucceeds(setDoc(doc(fs, 'results/b-new__T-010'), { batchId: 'b-new', seatNo: 'T-010', name: 'طالب تجريبي', grades: [], published: false }));
  });
  test('يرفض معرّف نتيجة لا يطابق الدفعة ورقم الجلوس', async () => {
    await assertFails(setDoc(doc(db('results'), 'results/other-id'), { batchId: 'b-new', seatNo: 'T-010', name: 'x', grades: [], published: false }));
  });
  test('لا يخزّن بيانات الطلاب داخل وثيقة الدفعة', async () => {
    await assertFails(setDoc(doc(db('results'), 'batches/b-bad'), { year: '2026', round: 1, subjects: [], published: false, students: [] }));
  });
  test('يدير رموز التفعيل والربط', async () => {
    const fs = db('results');
    await assertSucceeds(setDoc(doc(fs, 'activationCodes/EEEE-EEEE-EEE5'), { seatNo: 'T-005', usedBy: null, usedAt: null, createdBy: 'u-results', createdAt: serverTimestamp() }));
    await assertFails(setDoc(doc(fs, 'activationCodes/short'), { seatNo: 'T-005', usedBy: null }));
    await assertSucceeds(getDocs(collection(fs, 'studentLinks')));
    await assertSucceeds(deleteDoc(doc(fs, 'studentLinks/u-s2')));
    await assertSucceeds(deleteDoc(doc(fs, 'seatClaims/T-002')));
  });
  test('لا يعدّل المحتوى العام ولا الصلاحيات', async () => {
    const fs = db('results');
    await assertFails(setDoc(doc(fs, 'public/news/items/x3'), { title: 'x', ...meta(USERS.results.uid) }));
    await assertFails(setDoc(doc(fs, 'staff/results@test.local'), { role: 'admin', active: true, assignedBy: 'u-results', assignedAt: serverTimestamp() }));
  });
  test('يقرأ سجل النتائج فقط', async () => {
    const fs = db('results');
    await assertSucceeds(getDocs(query(collection(fs, 'audit'), where('area', '==', 'results'))));
    await assertFails(getDocs(collection(fs, 'audit')));
  });
});

describe('المدير', () => {
  test('يمنح الأدوار ويقرأ السجل', async () => {
    const fs = db('admin');
    await assertSucceeds(setDoc(doc(fs, 'staff/new@test.local'), { role: 'editor', active: true, name: 'جديد', assignedBy: 'u-admin', assignedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(fs, 'staff/Upper@test.local'), { role: 'editor', active: true, assignedBy: 'u-admin', assignedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(fs, 'staff/x@test.local'), { role: 'superuser', active: true, assignedBy: 'u-admin', assignedAt: serverTimestamp() }));
    await assertSucceeds(getDocs(collection(fs, 'audit')));
    await assertSucceeds(getDocs(collection(fs, 'results')));
  });
  test('لا يبقى للبريد الثابت القديم أي امتياز تلقائي', async () => {
    await assertFails(getDocs(collection(db('owner'), 'staff')));
    await assertFails(getDocs(collection(db('owner', false), 'staff')));
    await assertFails(setDoc(doc(db('owner'), 'public/news/items/old-owner'), { title: 'x', ...meta(USERS.owner.uid) }));
  });
  test('الحساب المعطّل لا يملك صلاحية', async () => {
    await assertFails(getDocs(collection(db('inactive'), 'staff')));
    await assertFails(setDoc(doc(db('inactive'), 'public/news/items/x4'), { title: 'x', ...meta(USERS.inactive.uid) }));
  });
});

const roster = (emails, actor = USERS.admin.uid) => ({ emails, updatedBy: actor, updatedAt: serverTimestamp() });

describe('المديرون الثلاثة القابلون للاستبدال', () => {
  test('كل مدير في القائمة الموثّقة يملك الصلاحية، وغير الموثّق لا', async () => {
    for (const name of ['admin', 'admin2', 'admin3']) {
      await assertSucceeds(getDocs(collection(db(name), 'staff')));
      await assertSucceeds(getDoc(doc(db(name), 'adminAccess/roster')));
      await assertFails(getDocs(collection(db(name, false), 'staff')));
      await assertFails(getDoc(doc(db(name, false), 'adminAccess/roster')));
    }
  });
  test('يطابق البريد الموثّق دون حساسية لحالة الأحرف', async () => {
    const fs = env.authenticatedContext(USERS.admin.uid, {
      email: 'ADMIN@TEST.LOCAL', email_verified: true
    }).firestore();
    await assertSucceeds(getDoc(doc(fs, 'adminAccess/roster')));
    await assertSucceeds(getDocs(collection(fs, 'results')));
  });
  test('عناوين المديرين لا تُكشف للزائر أو الطالب أو الموظف أو البريد القديم', async () => {
    for (const name of [undefined, 's1', 'editor', 'results', 'owner', 'legacyAdmin']) {
      await assertFails(getDoc(doc(db(name), 'adminAccess/roster')));
      await assertFails(getDocs(collection(db(name), 'adminAccess')));
    }
    await assertFails(getDocs(collection(db('admin'), 'adminAccess')));
  });
  test('استبدال مدير يلغي وصوله فورًا ويمنح البريد الجديد الصلاحية', async () => {
    const oldDb = db('admin2');
    const newDb = db('replacement');
    await assertSucceeds(getDocs(collection(oldDb, 'results')));
    await assertFails(getDocs(collection(newDb, 'results')));
    await assertSucceeds(setDoc(doc(db('admin'), 'adminAccess/roster'),
      roster([USERS.admin.email, USERS.replacement.email, USERS.admin3.email])));
    await assertFails(getDocs(collection(oldDb, 'results')));
    await assertFails(getDoc(doc(oldDb, 'adminAccess/roster')));
    await assertFails(setDoc(doc(oldDb, 'adminAccess/roster'),
      roster([USERS.admin.email, USERS.admin2.email], USERS.admin2.uid)));
    await assertFails(setDoc(doc(oldDb, 'public/news/items/revoked'), { title: 'x', ...meta(USERS.admin2.uid) }));
    await assertSucceeds(getDocs(collection(newDb, 'results')));
    await assertSucceeds(getDoc(doc(newDb, 'adminAccess/roster')));
    await assertSucceeds(setDoc(doc(newDb, 'public/news/items/replacement'), { title: 'x', ...meta(USERS.replacement.uid) }));
  });
  test('البريد الجديد غير الموثّق لا يكتسب صلاحية حتى لو أُضيف للقائمة', async () => {
    await assertSucceeds(setDoc(doc(db('admin'), 'adminAccess/roster'),
      roster([USERS.admin.email, USERS.replacement.email])));
    await assertFails(getDocs(collection(db('replacement', false), 'results')));
    await assertFails(setDoc(doc(db('replacement', false), 'adminAccess/roster'),
      roster([USERS.replacement.email], USERS.replacement.uid)));
  });
  test('غير المدير لا يستطيع ترقية نفسه أو استبدال القائمة', async () => {
    for (const name of ['s1', 'editor', 'results', 'legacyAdmin', 'owner']) {
      await assertFails(setDoc(doc(db(name), 'adminAccess/roster'), roster([USERS[name].email], USERS[name].uid)));
    }
    await assertFails(setDoc(doc(db('admin', false), 'adminAccess/roster'), roster([USERS.admin.email])));
  });
  test('سجل staff القديم بدور admin لا يمنح أي صلاحية', async () => {
    await assertFails(getDocs(collection(db('legacyAdmin'), 'staff')));
    await assertFails(getDocs(collection(db('legacyAdmin'), 'results')));
    await assertFails(setDoc(doc(db('legacyAdmin'), 'public/news/items/legacy'), { title: 'x', ...meta(USERS.legacyAdmin.uid) }));
    await assertFails(setDoc(doc(db('admin'), 'staff/fourth@test.local'), {
      role: 'admin', active: true, name: 'x', assignedBy: USERS.admin.uid, assignedAt: serverTimestamp()
    }));
  });
  test('لا يستطيع المدير إزالة نفسه أو حذف آخر مدير أو الوثيقة', async () => {
    await assertFails(setDoc(doc(db('admin'), 'adminAccess/roster'), roster([USERS.admin2.email, USERS.admin3.email])));
    await assertFails(deleteDoc(doc(db('admin'), 'adminAccess/roster')));
    await assertSucceeds(setDoc(doc(db('admin'), 'adminAccess/roster'), roster([USERS.admin.email])));
    await assertFails(setDoc(doc(db('admin'), 'adminAccess/roster'), roster([])));
    await assertFails(setDoc(doc(db('admin'), 'adminAccess/roster'), roster([USERS.replacement.email])));
  });
  test('يرفض تجاوز ثلاثة مديرين والتكرار والبريد غير الصحيح أو غير الموحّد', async () => {
    const invalid = [
      [USERS.admin.email, USERS.admin2.email, USERS.admin3.email, USERS.replacement.email],
      [USERS.admin.email, USERS.admin.email],
      [USERS.admin.email, 'UPPER@gmail.com'],
      [USERS.admin.email, 'not-an-email'],
      [USERS.admin.email, 'with space@gmail.com'],
      [USERS.admin.email, 'slash/name@gmail.com'],
      [USERS.admin.email, 'line\nbreak@gmail.com'],
      [USERS.admin.email, 'name@example'],
      [USERS.admin.email, 'name@@example.com'],
      [USERS.admin.email, 'x'.repeat(250) + '@gmail.com'],
      [USERS.admin.email, 42],
      USERS.admin.email
    ];
    for (const emails of invalid) {
      await assertFails(setDoc(doc(db('admin'), 'adminAccess/roster'), roster(emails)));
    }
  });
  test('يرفض تزوير صاحب التعديل أو توقيته أو إضافة حقول غير معروفة', async () => {
    const ref = doc(db('admin'), 'adminAccess/roster');
    await assertFails(setDoc(ref, roster([USERS.admin.email], USERS.admin2.uid)));
    await assertFails(setDoc(ref, { ...roster([USERS.admin.email]), updatedAt: new Date('2020-01-01') }));
    await assertFails(setDoc(ref, { ...roster([USERS.admin.email]), owner: USERS.admin.email }));
    await assertFails(setDoc(ref, { emails: [USERS.admin.email] }));
  });
  test('تهيئة القائمة تتطلب خادمًا موثوقًا ولا يُسمح بها من المتصفح', async () => {
    await env.withSecurityRulesDisabled(async ctx => {
      await deleteDoc(doc(ctx.firestore(), 'adminAccess/roster'));
    });
    for (const name of ['admin', 'owner', 's1']) {
      await assertFails(setDoc(doc(db(name), 'adminAccess/roster'), roster([USERS[name].email], USERS[name].uid)));
    }
    await assertFails(setDoc(doc(db('admin'), 'adminAccess/other'), roster([USERS.admin.email])));
  });
});
