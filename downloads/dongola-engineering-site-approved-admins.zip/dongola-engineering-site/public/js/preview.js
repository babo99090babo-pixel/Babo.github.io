/* معاينة المحتوى قبل نشره: تستقبل البيانات من نافذة لوحة الإدارة (نفس الموقع فقط) */
(function () {
  'use strict';
  const R = window.CMSRender;
  const S = window.CMS_SCHEMA;
  const root = document.querySelector('[data-preview]');
  const esc = R.esc;

  function settingsPreview(d) {
    const facts = (d.facts || []).map(x => `<li>${esc(x.value)} — ${esc(x.label)} ${x.verified ? '<span class="news-tag">يظهر</span>' : '<span class="news-tag">مخفي: غير موثَّق</span>'}</li>`).join('');
    return `<dl class="fact-list">${[['العنوان', d.address], ['الهاتف', d.phone], ['البريد', d.email], ['ساعات العمل', d.workingHours], ['فيسبوك', d.facebook]].filter(x => x[1]).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>` +
      (facts ? `<h2 class="block-title">الكلية في أرقام</h2><ul class="check-list">${facts}</ul>` : '') +
      (d.deanMessage ? `<h2 class="block-title">كلمة العميد ${d.deanVerified ? '' : '(مخفية: غير معتمدة)'}</h2><blockquote class="prose">${esc(d.deanMessage)}</blockquote><p>${esc(d.deanName || '')} — ${esc(d.deanTitle || '')}</p>` : '');
  }

  function render(p) {
    const T = S.TYPES[p.type];
    if (!T || !p.data) return;
    const d = p.data;
    document.title = 'معاينة: ' + (d.title || '') + ' — كلية الهندسة';
    document.querySelector('.page-head h1').textContent = d.title || '(بدون عنوان)';
    document.querySelector('[data-preview-type]').textContent = 'النوع: ' + T.label;
    let main;
    if (p.type === 'faculty') main = R.member(d, '');
    else if (p.type === 'departments') main = R.department(d, '', null);
    else if (p.type === 'pages') main = R.page(d, '');
    else if (p.type === 'settings') main = settingsPreview(d);
    else main = R.detail(p.type, d, '');
    const noCard = ['pages', 'settings', 'departments'].includes(p.type);
    const cardHtml = noCard ? '' : R.card(p.type, Object.assign({ id: p.id }, d), '');
    const wrapCls = p.type === 'faculty' ? 'people-grid' : p.type === 'gallery' ? 'gallery-grid' : 'card-grid';
    root.innerHTML = `<section class="content-block"><h2 class="block-title">الصفحة</h2>${main}</section>` +
      (cardHtml ? `<section class="content-block"><h2 class="block-title">كيف يظهر في القوائم</h2>${p.type === 'calendar' ? `<ul class="timeline">${cardHtml}</ul>` : `<div class="${wrapCls}">${cardHtml}</div>`}</section>` : '');
    // الروابط في المعاينة لا تنقل إلى صفحات أخرى
    root.querySelectorAll('a[href]').forEach(a => {
      if (!/^(https?:|mailto:|tel:)/.test(a.getAttribute('href'))) a.addEventListener('click', e => e.preventDefault());
    });
  }

  let received = false;
  window.addEventListener('message', e => {
    if (e.origin !== location.origin || !e.data || e.data.kind !== 'cms-preview') return;
    received = true;
    render(e.data.payload);
  });
  if (window.opener) {
    try { window.opener.postMessage('cms-preview-ready', location.origin); } catch (err) { /* */ }
  }
  // إن لم تصل البيانات من النافذة الأصلية نقرأ آخر معاينة محفوظة في هذا المتصفح (خلال ٣٠ دقيقة)
  setTimeout(() => {
    if (received) return;
    try {
      const saved = JSON.parse(localStorage.getItem('cms-preview') || 'null');
      if (saved && Date.now() - saved.at < 30 * 60 * 1000) render(saved);
    } catch (err) { /* التخزين غير متاح */ }
  }, 600);
})();
