/* ============================================================
   بوابة النتائج — يرى كل طالب نتيجته فقط بعد تسجيل الدخول.
   الحماية الفعلية في firestore.rules: الخادم يرفض أي قراءة لنتيجة
   لا يملكها الحساب، مهما عُدِّل في هذه الصفحة.
   ============================================================ */
import { firebaseReady, explainError } from './firebase-init.js';
import { resolveStaffRole } from './staff-access.js';

const $ = id => document.getElementById(id);
const portal = $('portal');
const states = Array.from(portal.querySelectorAll('[data-state]'));
const accountBar = portal.querySelector('.portal-account');
const resultArea = $('resultArea');
const resultCard = $('resultCard');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

const SEMESTERS = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر'].map(s => 'الفصل الدراسي ' + s);
const CODE_RE = /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/;
const SEAT_RE = /^[0-9A-Za-z-]{1,20}$/;

const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const toLatinDigits = v => String(v).replace(/[٠-٩]/g, d => d.charCodeAt(0) - 0x0660).replace(/[۰-۹]/g, d => d.charCodeAt(0) - 0x06F0);
export const normSeat = v => toLatinDigits(v).replace(/[\s‏‎]/g, '').replace(/[‐-―]/g, '-').toUpperCase();
export function normCode(v) {
  const raw = toLatinDigits(v).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
  return raw.replace(/(.{4})(?=.)/g, '$1-');
}

function show(name, focus) {
  states.forEach(s => { s.hidden = s.dataset.state !== name; });
  const active = states.find(s => s.dataset.state === name);
  if (focus && active) {
    const target = active.querySelector('input, button, a');
    if (target) target.focus({ preventScroll: true });
  }
}
function setMsg(id, text, ok) {
  const el = $(id);
  el.textContent = text || '';
  el.classList.toggle('is-ok', !!ok);
}
function busy(form, on) {
  form.querySelectorAll('button, input').forEach(el => { el.disabled = on; });
  form.setAttribute('aria-busy', String(on));
}

/* ---------- عرض بطاقة النتيجة ---------- */
const ROUND_LABELS = { 1: 'الدور الأول', 2: 'الدور الثاني' };
const roundLabel = r => ROUND_LABELS[r] || ('الدور ' + r);
const GRADE_COLORS = {
  A: { bg: '#D1FAE5', text: '#065F46', border: '#6EE7B7' },
  B: { bg: '#DBEAFE', text: '#1E40AF', border: '#93C5FD' },
  C: { bg: '#FEF3C7', text: '#92400E', border: '#FCD34D' },
  D: { bg: '#FFEDD5', text: '#9A3412', border: '#FDBA74' },
  F: { bg: '#FEE2E2', text: '#991B1B', border: '#FCA5A5' },
  'ك': { bg: '#F3F4F6', text: '#4B5563', border: '#D1D5DB' }
};
const STATUS_STYLES = {
  'نجاح': { bg: '#D1FAE5', text: '#065F46', icon: '✓' },
  'ملحق': { bg: '#FEF3C7', text: '#92400E', icon: '⟳' },
  'إعادة تقييم': { bg: '#DBEAFE', text: '#1E40AF', icon: '↻' },
  'إعادة': { bg: '#FEE2E2', text: '#991B1B', icon: '✕' }
};
function newestFirst(a, b) {
  return String(b.year).localeCompare(String(a.year)) || (b.round - a.round) || (SEMESTERS.indexOf(b.semester) - SEMESTERS.indexOf(a.semester));
}

let results = [];
let currentIndex = 0;

function gpaCircle(value, label, color) {
  const pct = Math.max(0, Math.min(100, value / 4 * 100));
  return `<div class="rc-gpa-card"><div class="gpa-circle" style="--gpa-color:${color}"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="gpa-track" cx="50" cy="50" r="42"/><circle class="gpa-fill" cx="50" cy="50" r="42" style="stroke-dasharray:${(pct * 2.64).toFixed(1)} 264"/></svg><div class="gpa-value">${Number(value).toFixed(2)}</div></div><div class="gpa-label">${label}</div></div>`;
}

function displayResult(index, scroll) {
  currentIndex = index;
  const r = results[index];
  const status = STATUS_STYLES[r.status] || STATUS_STYLES['ملحق'];
  const switchHtml = results.length > 1 ? '<div class="rc-switch" role="group" aria-label="اختيار النتيجة">' + results.map((x, i) =>
    `<button type="button" data-i="${i}" aria-pressed="${i === index}">${esc(x.year)} · ${esc(roundLabel(x.round))} · ${esc(x.semester)}</button>`).join('') + '</div>' : '';
  const subjects = r.subjects || [];
  const grades = subjects.map((s, i) => {
    const g = (r.grades || [])[i];
    const c = GRADE_COLORS[g] || GRADE_COLORS['ك'];
    return `<tr class="grade-row" style="animation-delay:${i * 0.05}s"><td class="subj-name">${esc(s.name)}</td><td class="subj-hours">${esc(s.hours)}</td><td><span class="grade-badge" style="background:${c.bg};color:${c.text};border:1.5px solid ${c.border}">${esc(g || '—')}</span></td></tr>`;
  }).join('');
  const cg = r.cumulativeGPA;
  const color = cg >= 3.5 ? '#10B981' : cg >= 2.7 ? '#3B82F6' : cg >= 2.0 ? '#F59E0B' : '#EF4444';
  const gpa = (r.semesterGPA != null && cg != null) ? `<div class="rc-gpa-section">${gpaCircle(cg, 'المعدل التراكمي', color)}${gpaCircle(r.semesterGPA, 'المعدل الفصلي', color)}` +
    (r.classification ? `<div class="rc-gpa-card rc-classification"><div class="classification-text">${esc(r.classification)}</div><div class="gpa-label">التقدير</div></div>` : '') + '</div>' : '';

  resultCard.innerHTML = switchHtml + `
    <div class="result-card fadeInUp">
      <div class="rc-header">
        <div class="rc-status-badge" style="background:${status.bg};color:${status.text}"><span class="rc-status-icon" aria-hidden="true">${status.icon}</span> ${esc(r.notes || r.status)}</div>
        <button type="button" class="rc-print-btn" data-print><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg><span>طباعة</span></button>
      </div>
      <div class="rc-info">
        <div class="rc-avatar" aria-hidden="true"><svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="rc-details"><h2 class="rc-name">${esc(r.name)}</h2>
          <div class="rc-meta">
            <span class="rc-meta-item"><strong>رقم الجلوس:</strong> <span dir="ltr">${esc(r.seatNo)}</span></span>
            <span class="rc-meta-item"><strong>الفصل:</strong> ${esc(r.semester)}</span>
            <span class="rc-meta-item"><strong>التخصص:</strong> ${esc(r.specialization)}</span>
            <span class="rc-meta-item"><strong>العام:</strong> ${esc(r.year)}</span>
            <span class="rc-meta-item"><span class="rc-round-tag">${esc(roundLabel(r.round))}</span></span>
          </div></div>
      </div>
      ${gpa}
      <div class="rc-grades"><h3 class="rc-section-title">درجات المواد</h3>
        <div class="table-wrap"><table class="grades-table"><thead><tr><th scope="col">المادة</th><th scope="col">الساعات</th><th scope="col">الدرجة</th></tr></thead><tbody>${grades}</tbody></table></div></div>
      <div class="rc-footer"><span>جامعة دنقلا — كلية الهندسة</span><span>نتيجة امتحانات ${esc(roundLabel(r.round))}${r.session ? ' — ' + esc(r.session) : ''} — العام الدراسي ${esc(r.year)}</span></div>
      <p class="rc-disclaimer">للاطلاع فقط. الوثيقة الرسمية تصدر من الكلية.</p>
    </div>`;
  resultArea.hidden = false;
  if (scroll) {
    resultArea.scrollIntoView({ behavior: reducedMotion.matches ? 'auto' : 'smooth', block: 'start' });
    resultCard.focus({ preventScroll: true });
    if (r.status === 'نجاح' && !reducedMotion.matches) setTimeout(fireConfetti, 400);
  }
}

resultCard.addEventListener('click', e => {
  const sw = e.target.closest('.rc-switch button');
  if (sw) {
    displayResult(+sw.dataset.i, false);
    const sel = resultCard.querySelector('.rc-switch button[aria-pressed="true"]');
    if (sel) sel.focus({ preventScroll: true });
    return;
  }
  if (e.target.closest('[data-print]')) window.print();
});

function fireConfetti() {
  const canvas = $('confettiCanvas');
  const ctx = canvas && canvas.getContext('2d');
  if (!ctx || reducedMotion.matches) return;
  canvas.style.display = 'block';
  canvas.width = innerWidth; canvas.height = innerHeight;
  const colors = ['#bd975b', '#e3c792', '#102d42', '#10B981', '#3B82F6'];
  const parts = Array.from({ length: 120 }, () => ({
    x: Math.random() * canvas.width, y: Math.random() * canvas.height - canvas.height,
    w: Math.random() * 10 + 5, h: Math.random() * 6 + 3, c: colors[Math.floor(Math.random() * colors.length)],
    vx: (Math.random() - 0.5) * 4, vy: Math.random() * 3 + 2, a: Math.random() * 6.3, s: (Math.random() - 0.5) * 0.2, o: 1
  }));
  let frame = 0;
  (function step() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;
    parts.forEach(p => {
      p.x += p.vx; p.y += p.vy; p.vy += 0.05; p.a += p.s;
      if (frame > 60) p.o -= 0.01;
      if (p.o <= 0) return;
      alive = true;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.a); ctx.globalAlpha = p.o; ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
    });
    frame++;
    if (alive && frame < 200) requestAnimationFrame(step); else { ctx.clearRect(0, 0, canvas.width, canvas.height); canvas.style.display = 'none'; }
  })();
}

/* ---------- تبويبا الدخول والتسجيل ---------- */
const tabs = [$('tab-login'), $('tab-register')];
function selectTab(tab, focus) {
  tabs.forEach(t => {
    const on = t === tab;
    t.setAttribute('aria-selected', String(on));
    t.tabIndex = on ? 0 : -1;
    $(t.getAttribute('aria-controls')).hidden = !on;
  });
  if (focus) tab.focus();
}
tabs.forEach((t, i) => {
  t.addEventListener('click', () => selectTab(t));
  t.addEventListener('keydown', e => {
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) {
      e.preventDefault();
      const next = e.key === 'Home' ? 0 : e.key === 'End' ? tabs.length - 1 : (i + (e.key === 'ArrowLeft' ? 1 : -1) + tabs.length) % tabs.length;
      selectTab(tabs[next], true);
    }
  });
});

$('codeInput').addEventListener('input', e => {
  const el = e.target;
  const atEnd = el.selectionStart === el.value.length;
  el.value = normCode(el.value);
  if (atEnd) el.setSelectionRange(el.value.length, el.value.length);
});

/* ---------- المنطق مع Firebase ---------- */
async function main() {
  let fb;
  try { fb = await firebaseReady(); }
  catch (err) {
    portal.querySelector('[data-error-text]').textContent = explainError(err);
    show('error');
    return;
  }
  const { auth, db, A, F } = fb;

  async function loadResults(seatNo) {
    const q = F.query(F.collection(db, 'results'), F.where('seatNo', '==', seatNo), F.where('published', '==', true));
    const snap = await F.getDocs(q);
    results = snap.docs.map(d => d.data()).sort(newestFirst);
    const summary = portal.querySelector('[data-results-summary]');
    if (!results.length) {
      summary.textContent = 'لا توجد نتائج منشورة لرقم جلوسك حتى الآن. تظهر النتيجة هنا فور نشرها رسميًا.';
      portal.querySelector('[data-state="ready"] .portal-actions').hidden = true;
      resultArea.hidden = true;
      return;
    }
    const n = results.length;
    const ar = String(n).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
    summary.textContent = n === 1 ? 'لديك نتيجة واحدة منشورة.' : n === 2 ? 'لديك نتيجتان منشورتان. الأحدث معروضة أولًا.'
      : `لديك ${ar} ${n <= 10 ? 'نتائج منشورة' : 'نتيجة منشورة'}. الأحدث معروضة أولًا.`;
    portal.querySelector('[data-state="ready"] .portal-actions').hidden = false;
    displayResult(0, false);
  }

  async function route(user) {
    resultArea.hidden = true;
    results = [];
    accountBar.hidden = !user;
    if (!user) { show('signed-out'); return; }
    portal.querySelector('[data-account-email]').textContent = user.email || '';
    if (!user.emailVerified) {
      portal.querySelector('[data-user-email]').textContent = user.email || '';
      show('verify');
      return;
    }
    try {
      if (await resolveStaffRole(fb, user)) { show('staff'); return; }
    } catch (err) {
      portal.querySelector('[data-error-text]').textContent = explainError(err);
      show('error'); return;
    }
    let link = null;
    try {
      const snap = await F.getDoc(F.doc(db, 'studentLinks', user.uid));
      link = snap.exists() ? snap.data() : null;
    } catch (err) {
      portal.querySelector('[data-error-text]').textContent = explainError(err);
      show('error');
      return;
    }
    if (!link) { show('link'); return; }
    portal.querySelector('[data-user-seat]').textContent = link.seatNo;
    show('ready');
    try { await loadResults(link.seatNo); }
    catch (err) {
      portal.querySelector('[data-results-summary]').textContent = 'تعذّر تحميل النتائج: ' + explainError(err);
    }
  }

  A.onAuthStateChanged(auth, user => { route(user); });

  $('panel-login').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget;
    const email = $('loginEmail').value.trim();
    const pass = $('loginPass').value;
    if (!email || !pass) { setMsg('loginMsg', 'اكتب البريد الإلكتروني وكلمة السر.'); return; }
    setMsg('loginMsg', '');
    busy(form, true);
    try { await A.signInWithEmailAndPassword(auth, email, pass); $('loginPass').value = ''; }
    catch (err) { setMsg('loginMsg', explainError(err)); }
    finally { busy(form, false); }
  });

  $('forgotBtn').addEventListener('click', async () => {
    const email = $('loginEmail').value.trim();
    if (!email) { setMsg('loginMsg', 'اكتب بريدك الإلكتروني أولًا ثم اضغط «نسيت كلمة السر؟».'); $('loginEmail').focus(); return; }
    try {
      await A.sendPasswordResetEmail(auth, email);
      setMsg('loginMsg', 'إذا كان البريد مسجلًا فسيصلك رابط تعيين كلمة سر جديدة خلال دقائق.', true);
    } catch (err) { setMsg('loginMsg', explainError(err)); }
  });

  $('panel-register').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget;
    const email = $('regEmail').value.trim();
    const pass = $('regPass').value;
    if (!/^[^\s@/]+@[^\s@/]+\.[^\s@/]+$/.test(email)) { setMsg('regMsg', 'اكتب بريدًا إلكترونيًا صحيحًا.'); return; }
    if (pass.length < 8) { setMsg('regMsg', 'كلمة السر يجب أن تكون ٨ أحرف على الأقل.'); return; }
    if (pass !== $('regPass2').value) { setMsg('regMsg', 'كلمتا السر غير متطابقتين.'); return; }
    setMsg('regMsg', '');
    busy(form, true);
    try {
      const cred = await A.createUserWithEmailAndPassword(auth, email, pass);
      await A.sendEmailVerification(cred.user);
      form.reset();
    } catch (err) { setMsg('regMsg', explainError(err)); }
    finally { busy(form, false); }
  });

  $('resendBtn').addEventListener('click', async () => {
    if (!auth.currentUser) return;
    try { await A.sendEmailVerification(auth.currentUser); setMsg('verifyMsg', 'أُعيد إرسال الرابط. تحقق من بريدك.', true); }
    catch (err) { setMsg('verifyMsg', explainError(err)); }
  });

  $('verifiedBtn').addEventListener('click', async () => {
    const user = auth.currentUser;
    if (!user) return;
    try {
      await user.reload();
      if (!auth.currentUser.emailVerified) { setMsg('verifyMsg', 'لم يُوثَّق البريد بعد. افتح الرابط في بريدك ثم أعد المحاولة.'); return; }
      await auth.currentUser.getIdToken(true);
      setMsg('verifyMsg', '');
      route(auth.currentUser);
    } catch (err) { setMsg('verifyMsg', explainError(err)); }
  });

  $('linkForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget;
    const user = auth.currentUser;
    const seatNo = normSeat($('seatInput').value);
    const code = normCode($('codeInput').value);
    if (!SEAT_RE.test(seatNo)) { setMsg('linkMsg', 'اكتب رقم الجلوس كما هو في بطاقة الامتحان.'); $('seatInput').focus(); return; }
    if (!CODE_RE.test(code)) { setMsg('linkMsg', 'رمز التفعيل يتكون من ١٢ حرفًا ورقمًا بالشكل XXXX-XXXX-XXXX.'); $('codeInput').focus(); return; }
    setMsg('linkMsg', '');
    busy(form, true);
    try {
      const b = F.writeBatch(db);
      b.set(F.doc(db, 'studentLinks', user.uid), { seatNo, code, email: user.email, linkedAt: F.serverTimestamp() });
      b.update(F.doc(db, 'activationCodes', code), { usedBy: user.uid, usedAt: F.serverTimestamp() });
      b.set(F.doc(db, 'seatClaims', seatNo), { uid: user.uid, claimedAt: F.serverTimestamp() });
      await b.commit();
      form.reset();
      await route(user);
      const ready = portal.querySelector('[data-state="ready"] h2');
      if (ready) { ready.tabIndex = -1; ready.focus(); }
    } catch (err) {
      const code2 = err && err.code;
      setMsg('linkMsg', code2 === 'permission-denied' || code2 === 'not-found'
        ? 'رقم الجلوس أو رمز التفعيل غير صحيح، أو استُخدم الرمز من قبل. تأكد منهما، أو راجع مكتب الامتحانات.'
        : explainError(err));
    } finally { busy(form, false); }
  });

  $('signOutBtn').addEventListener('click', async () => {
    await A.signOut(auth);
    resultCard.innerHTML = '';
    selectTab(tabs[0]);
  });
}

portal.querySelector('[data-reload]').addEventListener('click', () => location.reload());
main();
