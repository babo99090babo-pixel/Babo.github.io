/* ============================================================
   عرض المحتوى بأمان — يستخدمه الموقع العام ومعاينة لوحة الإدارة.
   كل نص يُهرَّب قبل العرض، والروابط تُقبل من قائمة آمنة فقط.
   ============================================================ */
(function (root) {
  'use strict';
  const S = root.CMS_SCHEMA;

  /* ---------- أدوات أساسية ---------- */
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function arDigits(v) { return String(v == null ? '' : v).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[d]); }
  function latinDigits(v) {
    return String(v == null ? '' : v).replace(/[٠-٩]/g, d => d.charCodeAt(0) - 0x0660).replace(/[۰-۹]/g, d => d.charCodeAt(0) - 0x06F0);
  }

  let dateFmt = null;
  function fmtDate(iso) {
    if (!iso || !/^\d{4}-\d{2}-\d{2}/.test(String(iso))) return '';
    const d = new Date(String(iso).slice(0, 10) + 'T12:00:00Z');
    if (isNaN(d)) return '';
    try {
      dateFmt = dateFmt || new Intl.DateTimeFormat('ar-SD-u-nu-arab', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
      return dateFmt.format(d);
    } catch (e) { return arDigits(String(iso).slice(0, 10)); }
  }
  function dateRange(a, b) {
    if (!b || b === a) return fmtDate(a);
    return fmtDate(a) + ' – ' + fmtDate(b);
  }

  /* الروابط المسموح بها: https وhttp وmailto وtel والمسارات الداخلية فقط */
  function safeHref(url) {
    const u = String(url || '').trim();
    if (!u || /[\u0000-\u001F\u007F]/.test(u)) return '';
    if (/^(https?:|mailto:|tel:)/i.test(u)) return u;
    if (/^[a-z][a-z0-9+.-]*:/i.test(u) || u.startsWith('//') || u.startsWith('\\')) return '';
    return u;
  }
  function isExternal(href) { return /^https?:\/\//i.test(href) && !(root.location && href.startsWith(root.location.origin)); }
  function resolve(url, base) {
    const u = safeHref(url);
    if (!u) return '';
    if (/^(https?:|mailto:|tel:|#|\/)/i.test(u)) return u;
    return (base || '') + u;
  }
  const NEW_TAB = '<span class="visually-hidden"> (يفتح في نافذة جديدة)</span>';
  function link(href, text, cls) {
    const ext = isExternal(href);
    return `<a href="${esc(href)}"${cls ? ` class="${cls}"` : ''}${ext ? ' target="_blank" rel="noopener noreferrer"' : ''}>${text}${ext ? NEW_TAB : ''}</a>`;
  }

  /* ---------- تنسيق نصي مبسّط وآمن ---------- */
  function inline(raw, base) {
    let out = '';
    let i = 0;
    const re = /\[([^\]\n]{1,300})\]\(([^)\s]{1,2000})\)|\*\*([^*\n]{1,500})\*\*|(https:\/\/[^\s<>()"']{3,2000})/g;
    let m;
    while ((m = re.exec(raw))) {
      out += esc(raw.slice(i, m.index));
      if (m[1] != null) {
        const href = resolve(m[2], base);
        out += href ? link(href, esc(m[1])) : esc(m[1]);
      } else if (m[3] != null) {
        out += '<strong>' + esc(m[3]) + '</strong>';
      } else {
        out += link(m[4], esc(m[4]));
      }
      i = re.lastIndex;
    }
    return out + esc(raw.slice(i));
  }

  function markdown(text, base) {
    const lines = String(text || '').replace(/\r\n?/g, '\n').split('\n');
    const html = [];
    let para = [];
    let list = null;
    let table = null;
    const flushPara = () => { if (para.length) { html.push('<p>' + para.map(l => inline(l, base)).join('<br>') + '</p>'); para = []; } };
    const flushList = () => { if (list) { html.push(`<${list.tag}>` + list.items.map(x => '<li>' + inline(x, base) + '</li>').join('') + `</${list.tag}>`); list = null; } };
    const flushTable = () => {
      if (!table) return;
      const rows = table.filter(r => !/^\s*\|?\s*:?-{2,}/.test(r));
      const cells = r => r.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
      if (rows.length) {
        const [head, ...body] = rows;
        html.push('<div class="table-wrap" tabindex="0" role="region" aria-label="جدول"><table class="data-table"><thead><tr>' +
          cells(head).map(c => '<th scope="col">' + inline(c, base) + '</th>').join('') + '</tr></thead><tbody>' +
          body.map(r => '<tr>' + cells(r).map(c => '<td>' + inline(c, base) + '</td>').join('') + '</tr>').join('') +
          '</tbody></table></div>');
      }
      table = null;
    };
    const flushAll = () => { flushPara(); flushList(); flushTable(); };

    lines.forEach(line => {
      const t = line.trim();
      let m;
      if (!t) { flushAll(); return; }
      if (t.startsWith('|')) { flushPara(); flushList(); (table = table || []).push(t); return; }
      flushTable();
      if ((m = t.match(/^(#{2,4})\s+(.+)$/))) {
        flushAll();
        const level = Math.min(m[1].length, 4);
        html.push(`<h${level}>${inline(m[2], base)}</h${level}>`);
      } else if (/^-{3,}$/.test(t)) {
        flushAll(); html.push('<hr>');
      } else if ((m = t.match(/^[-*•]\s+(.*)$/))) {
        flushPara();
        if (!list || list.tag !== 'ul') { flushList(); list = { tag: 'ul', items: [] }; }
        if (m[1]) list.items.push(m[1]);
      } else if ((m = t.match(/^[0-9٠-٩]{1,3}[.)-]\s+(.*)$/))) {
        flushPara();
        if (!list || list.tag !== 'ol') { flushList(); list = { tag: 'ol', items: [] }; }
        if (m[1]) list.items.push(m[1]);
      } else if ((m = t.match(/^>\s?(.*)$/))) {
        flushAll(); html.push('<blockquote>' + inline(m[1], base) + '</blockquote>');
      } else {
        flushList(); para.push(t);
      }
    });
    flushAll();
    return html.join('\n');
  }

  /* ---------- مكوّنات العرض ---------- */
  function fileKind(url) {
    const m = String(url || '').split('?')[0].match(/\.([a-z0-9]{2,5})$/i);
    const ext = m ? m[1].toLowerCase() : '';
    return { pdf: 'PDF', doc: 'Word', docx: 'Word', xls: 'Excel', xlsx: 'Excel', ppt: 'PowerPoint', pptx: 'PowerPoint', png: 'صورة', jpg: 'صورة', jpeg: 'صورة', webp: 'صورة' }[ext] || 'رابط';
  }
  const ICON = {
    file: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Zm0 0v6h6M12 18v-6m-3 3 3 3 3-3"/></svg>',
    arrow: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5m7-7-7 7 7 7"/></svg>',
    person: '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    mail: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 6 10 7L22 6"/></svg>',
    empty: '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Zm0 0v6h6M9 14h6"/></svg>'
  };

  function attachments(list, base, heading) {
    const items = (list || []).filter(a => a && a.url && safeHref(a.url));
    if (!items.length) return '';
    return (heading ? `<h2 class="block-title">${esc(heading)}</h2>` : '') + '<ul class="doc-list">' + items.map(a => {
      const href = resolve(a.url, base);
      const ext = isExternal(href);
      return `<li><a href="${esc(href)}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ''}>${ICON.file}<span>${esc(a.title || 'ملف')}</span><span class="doc-type">${esc(fileKind(a.url))}</span>${ext ? NEW_TAB : ''}</a></li>`;
    }).join('') + '</ul>';
  }

  function emptyState(title, text, actionHtml) {
    return `<div class="empty-state">${ICON.empty}<h2>${esc(title)}</h2><p>${esc(text)}</p>${actionHtml || ''}</div>`;
  }

  function img(url, alt, base, cls, size) {
    const src = resolve(url, base);
    if (!src) return '';
    const [w, h] = size || [800, 500];
    return `<img class="${cls || ''}" src="${esc(src)}" alt="${esc(alt || '')}" width="${w}" height="${h}" loading="lazy" decoding="async">`;
  }

  /* روابط الصفحات العامة */
  const KNOWN_DEPTS = (S ? S.DEPARTMENTS : []).map(d => d.id);
  function itemUrl(type, id, base) {
    base = base || '';
    const q = encodeURIComponent(id);
    if (type === 'faculty') return base + 'member.html?id=' + q;
    if (type === 'departments') return KNOWN_DEPTS.includes(id) ? base + 'departments/' + id + '.html' : base + 'department.html?id=' + q;
    if (type === 'pages') {
      const p = S && S.TYPES.pages.fixed.find(x => x.id === id);
      return base + (p ? p.path : 'index.html');
    }
    return base + 'item.html?type=' + encodeURIComponent(type) + '&id=' + q;
  }

  const label = (type, key, v) => S ? S.optionLabel(type, key, v) : v;

  /* ---------- البطاقات ---------- */
  function card(type, it, base) {
    const href = itemUrl(type, it.id, base);
    const title = esc(it.title);
    switch (type) {
      case 'faculty': {
        const photo = it.photo ? img(it.photo, 'صورة ' + it.title, base, 'person-photo', [160, 160]) : `<span class="person-photo person-photo-empty">${ICON.person}</span>`;
        const meta = [label('faculty', 'academicTitle', it.academicTitle), it.position].filter(Boolean).map(esc).join(' · ');
        return `<article class="person-card">${photo}<div class="person-body"><h3><a class="stretched" href="${esc(href)}">${title}</a></h3>` +
          (meta ? `<p class="person-title">${meta}</p>` : '') +
          (it.specialization ? `<p class="person-spec">${esc(it.specialization)}</p>` : '') +
          `<p class="person-dept">${esc(S.deptName(it.department))}</p></div></article>`;
      }
      case 'documents': {
        const kind = label('documents', 'kind', it.kind);
        return `<article class="doc-card"><div class="entry-meta"><span class="news-tag">${esc(kind)}</span>${it.approvedAt ? `<span>اعتُمد ${esc(fmtDate(it.approvedAt))}</span>` : ''}</div>` +
          `<h3>${title}</h3><p class="doc-purpose"><strong>الوظيفة:</strong> ${esc(it.purpose)}</p>` +
          (it.howToUse ? `<p class="doc-how"><strong>طريقة الاستخدام:</strong> ${esc(it.howToUse)}</p>` : '') +
          (it.version || it.approvedBy ? `<p class="doc-meta">${[it.version ? 'الإصدار ' + esc(it.version) : '', it.approvedBy ? 'جهة الاعتماد: ' + esc(it.approvedBy) : ''].filter(Boolean).join(' · ')}</p>` : '') +
          attachments(it.attachments, base) + '</article>';
      }
      case 'services': {
        const href2 = safeHref(it.url);
        return `<article class="service-card"><h3>${href2 ? link(href2, title, 'stretched') : title}</h3><p>${esc(it.description)}</p>${it.audience ? `<span class="news-tag">${esc(it.audience)}</span>` : ''}</article>`;
      }
      case 'calendar':
        return `<li class="timeline-item"><time datetime="${esc(it.startDate)}">${esc(dateRange(it.startDate, it.endDate))}</time><div><span class="news-tag">${esc(it.category)}</span><h3>${title}</h3>${it.notes ? `<p>${esc(it.notes)}</p>` : ''}</div></li>`;
      case 'schedules': {
        const meta = [label('schedules', 'kind', it.kind), it.academicYear ? arDigits(it.academicYear) : '', it.semester, it.department ? S.deptName(it.department) : '', it.round ? label('schedules', 'round', it.round) : ''].filter(Boolean).map(esc).join(' · ');
        return `<article class="doc-card"><h3>${title}</h3><p class="doc-meta">${meta}</p>${it.effectiveDate ? `<p class="doc-meta">يسري من ${esc(fmtDate(it.effectiveDate))}</p>` : ''}` +
          (it.body ? `<details class="inline-details"><summary>عرض الجدول</summary><div class="prose">${markdown(it.body, base)}</div></details>` : '') +
          attachments(it.attachments, base) + '</article>';
      }
      case 'gallery':
        return `<figure class="gallery-item">${img(it.image, it.imageAlt, base, '', [600, 400])}<figcaption><strong>${title}</strong>${it.caption ? `<span>${esc(it.caption)}</span>` : ''}${it.date ? `<time datetime="${esc(it.date)}">${esc(fmtDate(it.date))}</time>` : ''}</figcaption></figure>`;
      case 'partners':
        return `<article class="entry-card">${it.logo ? img(it.logo, 'شعار ' + it.title, base, 'partner-logo', [240, 120]) : ''}<div class="entry-meta"><span class="news-tag">${esc(it.kind)}</span>${it.since ? `<span>منذ ${esc(arDigits(it.since))}</span>` : ''}</div><h3><a class="stretched" href="${esc(href)}">${title}</a></h3><p>${esc(it.description)}</p></article>`;
      case 'accreditations':
        return `<article class="entry-card"><div class="entry-meta"><span class="news-tag">${esc(it.status)}</span>${it.grantedAt ? `<time datetime="${esc(it.grantedAt)}">${esc(fmtDate(it.grantedAt))}</time>` : ''}</div><h3><a class="stretched" href="${esc(href)}">${title}</a></h3><p>الجهة المانحة: ${esc(it.issuer)}</p></article>`;
      case 'research':
        return `<article class="entry-card"><div class="entry-meta"><span class="news-tag">${esc(it.kind || 'بحث')}</span>${it.year ? `<span>${esc(arDigits(it.year))}</span>` : ''}</div><h3><a class="stretched" href="${esc(href)}">${title}</a></h3><p>${esc(it.authors)}</p>${it.venue ? `<p class="doc-meta">${esc(it.venue)}</p>` : ''}</article>`;
      case 'projects':
      case 'labs': {
        const tag = type === 'projects' ? (it.academicYear ? arDigits(it.academicYear) : '') : '';
        return `<article class="entry-card">${it.image ? img(it.image, it.imageAlt, base, 'entry-image', [640, 360]) : ''}<div class="entry-meta"><span class="news-tag">${esc(S.deptName(it.department))}</span>${tag ? `<span>${esc(tag)}</span>` : ''}</div><h3><a class="stretched" href="${esc(href)}">${title}</a></h3><p>${esc(it.summary)}</p></article>`;
      }
      default: {
        const tag = type === 'news' ? (it.kind === 'announcement' ? 'إعلان · ' : '') + (it.category || '') : (it.category || '');
        return `<article class="entry-card news-item">${it.image ? img(it.image, it.imageAlt, base, 'entry-image', [640, 360]) : ''}<div class="news-meta"><span class="news-tag">${esc(tag)}</span>${it.date ? `<time datetime="${esc(it.date)}">${esc(fmtDate(it.date))}</time>` : ''}</div>` +
          `<h3><a class="stretched" href="${esc(href)}">${it.pinned ? '<span class="pin-badge">مثبّت</span> ' : ''}${title}</a></h3><p>${esc(it.summary)}</p></article>`;
      }
    }
  }

  /* ---------- صفحات التفاصيل ---------- */
  function section(title, inner) {
    return inner ? `<section class="content-block"><h2 class="block-title">${esc(title)}</h2>${inner}</section>` : '';
  }
  function factList(rows) {
    const r = rows.filter(x => x[1]);
    return r.length ? '<dl class="fact-list">' + r.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${v}</dd></div>`).join('') + '</dl>' : '';
  }

  function detail(type, it, base) {
    const h = [];
    switch (type) {
      case 'news':
      case 'activities':
        h.push(`<p class="article-meta"><span class="news-tag">${esc(type === 'news' ? (it.kind === 'announcement' ? 'إعلان' : 'خبر') + ' · ' + (it.category || '') : it.category)}</span>${it.date ? `<time datetime="${esc(it.date)}">${esc(fmtDate(it.date))}</time>` : ''}${it.department ? `<span>${esc(S.deptName(it.department))}</span>` : ''}</p>`);
        if (it.image) h.push(`<figure class="article-figure">${img(it.image, it.imageAlt, base, '', [1200, 675])}</figure>`);
        h.push(`<p class="article-lede">${esc(it.summary)}</p>`);
        if (it.body) h.push(`<div class="prose">${markdown(it.body, base)}</div>`);
        h.push(attachments(it.attachments, base, 'المرفقات'));
        break;
      case 'research':
        h.push(factList([['المؤلفون', esc(it.authors)], ['سنة النشر', esc(arDigits(it.year || ''))], ['النوع', esc(it.kind)], ['جهة النشر', esc(it.venue)], ['القسم', it.department ? esc(S.deptName(it.department)) : ''], ['رابط النشر', it.url && safeHref(it.url) ? link(safeHref(it.url), esc(it.url)) : '']]));
        h.push(section('الملخص', it.abstract ? `<div class="prose">${markdown(it.abstract, base)}</div>` : ''));
        h.push(attachments(it.attachments, base, 'الملفات'));
        break;
      case 'projects':
        h.push(factList([['العام الدراسي', esc(arDigits(it.academicYear))], ['القسم', esc(S.deptName(it.department))], ['المشرف', esc(it.supervisor)], ['الطلاب', it.studentsConsent && (it.students || []).length ? it.students.map(esc).join('، ') : '']]));
        if (it.image) h.push(`<figure class="article-figure">${img(it.image, it.imageAlt, base, '', [1200, 675])}</figure>`);
        h.push(`<p class="article-lede">${esc(it.summary)}</p>`);
        if (it.body) h.push(`<div class="prose">${markdown(it.body, base)}</div>`);
        h.push(attachments(it.attachments, base, 'المرفقات'));
        break;
      case 'labs':
        h.push(factList([['القسم', esc(S.deptName(it.department))], ['الموقع', esc(it.location)], ['المشرف', esc(it.supervisor)]]));
        if (it.image) h.push(`<figure class="article-figure">${img(it.image, it.imageAlt, base, '', [1200, 675])}</figure>`);
        h.push(`<p class="article-lede">${esc(it.summary)}</p>`);
        if (it.body) h.push(`<div class="prose">${markdown(it.body, base)}</div>`);
        h.push(section('أهم التجهيزات', (it.equipment || []).length ? '<ul class="check-list">' + it.equipment.map(x => `<li>${esc(x)}</li>`).join('') + '</ul>' : ''));
        break;
      case 'partners':
        if (it.logo) h.push(img(it.logo, 'شعار ' + it.title, base, 'partner-logo-lg', [320, 160]));
        h.push(factList([['نوع الجهة', esc(it.kind)], ['منذ', esc(arDigits(it.since || ''))], ['موقع الجهة', it.url && safeHref(it.url) ? link(safeHref(it.url), esc(it.url)) : '']]));
        h.push(`<div class="prose"><p>${esc(it.description)}</p></div>`);
        h.push(attachments(it.attachments, base, 'وثائق الشراكة'));
        break;
      case 'accreditations':
        h.push(factList([['الجهة المانحة', esc(it.issuer)], ['الحالة', esc(it.status)], ['تاريخ المنح', esc(fmtDate(it.grantedAt))], ['ينتهي في', esc(fmtDate(it.expiresAt))], ['التحقق', it.url && safeHref(it.url) ? link(safeHref(it.url), 'رابط التحقق لدى الجهة المانحة') : '']]));
        if (it.scope) h.push(section('نطاق الاعتماد', `<p>${esc(it.scope)}</p>`));
        h.push(attachments(it.attachments, base, 'الوثيقة الرسمية'));
        break;
      case 'documents':
      case 'schedules':
      case 'gallery':
      case 'services':
      case 'calendar':
        h.push(type === 'calendar' ? `<ul class="timeline">${card(type, it, base)}</ul>` : card(type, it, base));
        break;
      default:
        if (it.summary) h.push(`<p class="article-lede">${esc(it.summary)}</p>`);
        if (it.body) h.push(`<div class="prose">${markdown(it.body, base)}</div>`);
    }
    return h.join('\n');
  }

  function page(it, base) {
    return (it.summary ? `<p class="article-lede">${esc(it.summary)}</p>` : '') +
      `<div class="prose">${markdown(it.body, base)}</div>` +
      attachments(it.attachments, base, 'مستندات مرتبطة') +
      (it.approvedBy ? `<p class="approval-note">اعتُمد هذا النص من: ${esc(it.approvedBy)}${it.approvedAt ? ' — ' + esc(fmtDate(it.approvedAt)) : ''}</p>` : '');
  }

  const PENDING = 'لم تُنشر المعلومات المعتمدة لهذا الجزء بعد.';
  function department(it, base, head) {
    const programs = (it.programs || []).length ? '<div class="table-wrap" tabindex="0" role="region" aria-label="البرامج والدرجات"><table class="data-table"><thead><tr><th scope="col">البرنامج</th><th scope="col">الدرجة</th><th scope="col">مدة الدراسة</th><th scope="col">ملاحظات</th></tr></thead><tbody>' +
      it.programs.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.degree)}</td><td>${esc(p.duration)}</td><td>${esc(p.notes)}</td></tr>`).join('') + '</tbody></table></div>' : '';
    let headHtml = '';
    if (it.headName) {
      const profile = head ? `<a href="${esc(itemUrl('faculty', head.id, base))}">الصفحة الشخصية</a>` : '';
      headHtml = `<div class="person-inline">${head && head.photo ? img(head.photo, 'صورة ' + it.headName, base, 'person-photo', [96, 96]) : `<span class="person-photo person-photo-empty">${ICON.person}</span>`}<div><strong>${esc(it.headName)}</strong>${it.headTitle ? `<span>${esc(it.headTitle)}</span>` : ''}${it.headEmail ? `<a href="mailto:${esc(it.headEmail)}" dir="ltr">${esc(it.headEmail)}</a>` : ''}${profile}</div></div>`;
    }
    const courses = (it.courses || []).length ? '<div class="table-wrap" tabindex="0" role="region" aria-label="توصيف المقررات"><table class="data-table"><thead><tr><th scope="col">الرمز</th><th scope="col">المقرر</th><th scope="col">الساعات</th><th scope="col">الفصل</th><th scope="col">الوصف</th></tr></thead><tbody>' +
      it.courses.map(c => `<tr><td dir="ltr">${esc(c.code)}</td><td>${esc(c.name)}</td><td>${esc(c.hours != null ? arDigits(c.hours) : '')}</td><td>${esc(c.semester)}</td><td>${esc(c.description)}</td></tr>`).join('') + '</tbody></table></div>' : '';
    const labs = (it.labs || []).length ? '<ul class="card-list">' + it.labs.map(l => `<li><h3>${esc(l.name)}</h3>${l.description ? `<p>${esc(l.description)}</p>` : ''}</li>`).join('') + '</ul>' : '';
    const blocks = [
      ['dept-about', 'التعريف بالقسم', it.about ? `<div class="prose">${markdown(it.about, base)}</div>` : ''],
      ['dept-programs', 'البرامج والدرجات العلمية', programs],
      ['dept-head', 'رئيس القسم', headHtml],
      ['dept-plan', 'الخطة الدراسية', (it.studyPlan ? `<div class="prose">${markdown(it.studyPlan, base)}</div>` : '') + attachments(it.attachments, base)],
      ['dept-courses', 'توصيف المقررات', courses],
      ['dept-labs', 'المعامل', labs],
      ['dept-careers', 'مجالات العمل', it.careers ? `<div class="prose">${markdown(it.careers, base)}</div>` : '']
    ];
    return blocks.map(([id, title, inner]) => `<section class="content-block" id="${id}" aria-labelledby="${id}-t"><h2 class="block-title" id="${id}-t">${esc(title)}</h2>${inner || `<p class="pending-note">${PENDING}</p>`}</section>`).join('') +
      (it.contactEmail ? `<p class="approval-note">للتواصل مع القسم: <a href="mailto:${esc(it.contactEmail)}" dir="ltr">${esc(it.contactEmail)}</a></p>` : '');
  }

  function member(it, base) {
    const photo = it.photo ? img(it.photo, 'صورة ' + it.title, base, 'profile-photo', [280, 280]) : `<span class="profile-photo person-photo-empty">${ICON.person}</span>`;
    const facts = factList([
      ['اللقب العلمي', esc(it.academicTitle)], ['المؤهل', esc(it.degree)], ['القسم', esc(S.deptName(it.department))],
      ['المنصب', esc(it.position)], ['التخصص', esc(it.specialization)], ['المكتب', esc(it.office)],
      ['البريد المؤسسي', it.email ? `<a href="mailto:${esc(it.email)}" dir="ltr">${esc(it.email)}</a>` : '']
    ]);
    const pubs = (it.publications || []).length ? '<ol class="pub-list">' + it.publications.map(p => {
      const href = p.url && safeHref(p.url);
      return `<li><strong>${href ? link(href, esc(p.title)) : esc(p.title)}</strong>${p.venue || p.year ? `<span>${[esc(p.venue), p.year ? esc(arDigits(p.year)) : ''].filter(Boolean).join('، ')}</span>` : ''}</li>`;
    }).join('') + '</ol>' : '';
    return `<div class="profile-layout"><aside class="profile-card">${photo}${facts}</aside><div class="profile-main">` +
      section('السيرة المختصرة', it.bio ? `<div class="prose">${markdown(it.bio, base)}</div>` : '') +
      section('الاهتمامات البحثية', (it.interests || []).length ? '<ul class="tag-list">' + it.interests.map(x => `<li>${esc(x)}</li>`).join('') + '</ul>' : '') +
      section('الأبحاث والمنشورات', pubs) +
      (!it.bio && !(it.interests || []).length && !pubs ? `<p class="pending-note">لم تُضف السيرة والأبحاث بعد.</p>` : '') +
      '</div></div>';
  }

  root.CMSRender = { esc, arDigits, latinDigits, fmtDate, dateRange, safeHref, resolve, markdown, inline, attachments, emptyState, card, detail, page, department, member, itemUrl, fileKind, ICON };
})(typeof window !== 'undefined' ? window : globalThis);
