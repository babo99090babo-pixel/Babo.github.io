/* ============================================================
   قراءة المحتوى المنشور وعرضه في الصفحات العامة.
   تُقرأ البيانات المنشورة فقط عبر واجهة Firestore العامة (REST)
   دون تحميل مكتبة Firebase كاملة، فتبقى الصفحات خفيفة.
   ============================================================ */
(function () {
  'use strict';
  const cfg = window.SITE_CONFIG;
  const R = window.CMSRender;
  const S = window.CMS_SCHEMA;
  const esc = R.esc;
  const base = document.documentElement.dataset.base || '';

  /* ---------- القراءة من Firestore ---------- */
  function restRoot() {
    const pid = encodeURIComponent(cfg.firebase.projectId);
    const host = cfg.useEmulator ? `http://${cfg.emulator.host}:${cfg.emulator.firestorePort}` : 'https://firestore.googleapis.com';
    return `${host}/v1/projects/${pid}/databases/(default)/documents/`;
  }
  function decode(v) {
    if (!v) return null;
    if ('stringValue' in v) return v.stringValue;
    if ('integerValue' in v) return Number(v.integerValue);
    if ('doubleValue' in v) return v.doubleValue;
    if ('booleanValue' in v) return v.booleanValue;
    if ('nullValue' in v) return null;
    if ('timestampValue' in v) return v.timestampValue;
    if ('arrayValue' in v) return (v.arrayValue.values || []).map(decode);
    if ('mapValue' in v) return decodeFields(v.mapValue.fields || {});
    return null;
  }
  function decodeFields(fields) {
    const o = {};
    Object.keys(fields).forEach(k => { o[k] = decode(fields[k]); });
    return o;
  }
  function toItem(doc) {
    const o = decodeFields(doc.fields || {});
    o.id = doc.name.split('/').pop();
    return o;
  }
  async function fetchJson(url) {
    const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => ctrl && ctrl.abort(), 12000);
    try {
      const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined, credentials: 'omit' });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return await res.json();
    } finally { clearTimeout(timer); }
  }
  const keyParam = () => cfg.useEmulator ? '' : '&key=' + encodeURIComponent(cfg.firebase.apiKey);
  const cache = {};
  function list(type) {
    if (cache['l:' + type]) return cache['l:' + type];
    cache['l:' + type] = (async () => {
      const items = [];
      let token = '';
      do {
        const url = restRoot() + `public/${encodeURIComponent(type)}/items?pageSize=300${token ? '&pageToken=' + encodeURIComponent(token) : ''}${keyParam()}`;
        const data = await fetchJson(url);
        ((data && data.documents) || []).forEach(d => items.push(toItem(d)));
        token = (data && data.nextPageToken) || '';
      } while (token && items.length < 3000);
      const t = S.TYPES[type];
      if (t && t.sort) items.sort(t.sort);
      return items;
    })();
    return cache['l:' + type];
  }
  function get(type, id) {
    const k = 'g:' + type + '/' + id;
    if (cache[k]) return cache[k];
    cache[k] = fetchJson(restRoot() + `public/${encodeURIComponent(type)}/items/${encodeURIComponent(id)}?${keyParam().slice(1)}`)
      .then(d => (d && d.fields ? toItem(d) : null));
    return cache[k];
  }
  // قبل استيراد المحتوى الأولي تبقى نصوص الصفحة الأصلية كما هي.
  // (نقرأ القائمة لا الوثيقة، فلا يظهر خطأ 404 في المتصفح قبل الاستيراد)
  const settings = () => list('settings').then(items => items.find(x => x.id === 'site') || null);

  /* ---------- أدوات العرض ---------- */
  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
  function loading(el) { el.setAttribute('aria-busy', 'true'); }
  function done(el) { el.removeAttribute('aria-busy'); }
  function failure(el, retry) {
    done(el);
    el.innerHTML = `<div class="empty-state is-error" role="alert">${R.ICON.empty}<h2>تعذّر تحميل المحتوى</h2><p>تحقّق من اتصالك بالإنترنت ثم أعد المحاولة.</p><button type="button" class="cta-ghost">إعادة المحاولة</button></div>`;
    $('button', el).addEventListener('click', () => { Object.keys(cache).forEach(k => delete cache[k]); retry(); });
  }
  function normalize(s) {
    return R.latinDigits(String(s || '')).toLowerCase()
      .replace(/[ً-ْـ]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي');
  }
  function setMeta(title, description, canonical) {
    if (title) document.title = title + ' — كلية الهندسة، جامعة دنقلا';
    if (description) {
      const m = $('meta[name="description"]');
      if (m) m.setAttribute('content', description.slice(0, 300));
    }
    // الصفحات المبنية من رابط (?id=) تحصل على عنوان قانوني خاص بها
    if (canonical && !$('link[rel="canonical"]')) {
      const l = document.createElement('link');
      l.rel = 'canonical';
      l.href = canonical;
      document.head.appendChild(l);
    }
  }
  function selfUrl(keys) {
    const u = new URL(cfg.siteUrl.replace(/\/$/, '') + location.pathname);
    const params = new URLSearchParams(location.search);
    keys.forEach(k => { if (params.get(k)) u.searchParams.set(k, params.get(k)); });
    return u.href;
  }

  /* ---------- الإعدادات: التواصل والأرقام وكلمة العميد ---------- */
  const CONTACT_ICONS = {
    pin: '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2A19.79 19.79 0 0 1 3.09 5.18 2 2 0 0 1 5.08 3h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.7 2.79a2 2 0 0 1-.45 2.11L9.06 10.9a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.33 1.83.57 2.79.7a2 2 0 0 1 1.77 2.04Z"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 6 10 7L22 6"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a20 20 0 0 0 0 20 20 20 0 0 0 0-20Z"/>'
  };
  function contactHtml(s, variant) {
    const ext = '<span class="visually-hidden"> (يفتح في نافذة جديدة)</span>';
    const rows = [];
    if (s.address) rows.push(['pin', 'العنوان', esc(s.address).replace(/\n/g, '<br>')]);
    if (s.phone) rows.push(['phone', 'الهاتف', `<a href="tel:${esc(String(s.phone).replace(/[^\d+]/g, ''))}" dir="ltr">${esc(s.phone)}</a>`]);
    if (s.email) rows.push(['mail', 'البريد الإلكتروني', `<a href="mailto:${esc(s.email)}" dir="ltr">${esc(s.email)}</a>`]);
    if (s.workingHours) rows.push(['clock', 'ساعات العمل', esc(s.workingHours)]);
    if (s.facebook && R.safeHref(s.facebook)) rows.push(['globe', 'تابع أخبارنا', `<a href="${esc(s.facebook)}" target="_blank" rel="noopener noreferrer">صفحة الكلية على فيسبوك${ext} ↗</a>`]);
    if (s.mapUrl && R.safeHref(s.mapUrl)) rows.push(['pin', 'الموقع على الخريطة', `<a href="${esc(s.mapUrl)}" target="_blank" rel="noopener noreferrer">عرض الموقع على الخريطة${ext} ↗</a>`]);
    if (variant === 'footer') return rows.map(([, k, v]) => `<li><span>${esc(k)}:</span> ${v}</li>`).join('');
    return rows.map(([icon, k, v]) => `<div><h3><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${CONTACT_ICONS[icon]}</svg> ${esc(k)}</h3><p>${v}</p></div>`).join('');
  }

  async function applySettings() {
    let s;
    try { s = await settings(); } catch (e) { return null; }
    if (!s) return null;
    $$('[data-setting-contact]').forEach(el => {
      const html = contactHtml(s, el.dataset.settingContact);
      if (html) el.innerHTML = html;
    });
    $$('[data-setting]').forEach(el => {
      const v = s[el.dataset.setting];
      if (v) el.textContent = v;
    });
    const facts = $('[data-cms-facts]');
    if (facts) {
      const list = (s.facts || []).filter(x => x && x.verified && x.value && x.label);
      const wrap = facts.closest('[data-facts-section]') || facts;
      if (list.length) {
        facts.innerHTML = list.map(x => `<div><dt>${esc(x.label)}</dt><dd>${esc(R.arDigits(x.value))}</dd></div>`).join('');
        wrap.hidden = false;
      } else wrap.hidden = true;
    }
    const dean = $('[data-cms-dean]');
    if (dean) {
      if (s.deanVerified && s.deanMessage) {
        $('blockquote', dean).textContent = '«' + s.deanMessage.replace(/^«|»$/g, '') + '»';
        $('[data-dean-name]', dean).textContent = s.deanName || '';
        $('[data-dean-title]', dean).textContent = s.deanTitle || 'عميد كلية الهندسة';
        dean.hidden = false;
      } else dean.hidden = true;
    }
    return s;
  }

  /* ---------- القوائم القابلة للبحث والتصفية ---------- */
  const FILTERS = {
    search: { label: 'بحث', kind: 'search' },
    kind: { label: 'النوع', field: 'kind' },
    category: { label: 'التصنيف', field: 'category' },
    department: { label: 'القسم', field: 'department' },
    academicTitle: { label: 'اللقب العلمي', field: 'academicTitle' },
    academicYear: { label: 'العام الدراسي', field: 'academicYear' },
    semester: { label: 'الفصل الدراسي', field: 'semester' },
    year: { label: 'السنة', derive: it => String(it.date || it.year || '').slice(0, 4) },
    album: { label: 'الألبوم', field: 'album' },
    status: { label: 'الحالة', field: 'status' }
  };
  const SEARCH_KEYS = ['title', 'summary', 'body', 'specialization', 'authors', 'venue', 'purpose', 'description', 'supervisor', 'position', 'abstract', 'caption', 'notes'];

  function valueOf(def, it) { return def.derive ? def.derive(it) : (it[def.field] == null ? '' : String(it[def.field])); }
  function optionText(type, key, v) {
    if (key === 'department') return S.deptName(v);
    if (key === 'year' || key === 'academicYear') return R.arDigits(v);
    return S.optionLabel(type, key, v) || v;
  }

  async function renderList(el) {
    const type = el.dataset.cmsList;
    const filters = (el.dataset.filters || '').split(',').map(s => s.trim()).filter(Boolean);
    const pageSize = Number(el.dataset.pageSize || 12);
    const limit = Number(el.dataset.limit || 0);
    const layout = el.dataset.layout || (type === 'faculty' ? 'people' : type === 'calendar' ? 'timeline' : type === 'gallery' ? 'gallery' : 'grid');
    const staticFallback = el.hasAttribute('data-static-fallback');
    const staticHtml = el.innerHTML;
    const run = async () => {
      loading(el);
      let items;
      try {
        if (staticFallback && !(await settings())) { done(el); el.innerHTML = staticHtml; return; }
        items = await list(type);
      } catch (e) {
        if (staticFallback && staticHtml.trim()) { done(el); el.innerHTML = staticHtml; return; }
        failure(el, run); return;
      }
      if (el.dataset.only) {
        const [k, v] = el.dataset.only.split('=');
        items = items.filter(it => String(it[k] || '') === v);
      }
      done(el);
      if (limit) items = items.slice(0, limit);
      if (!items.length) {
        el.innerHTML = R.emptyState(el.dataset.emptyTitle || 'لا يوجد محتوى منشور بعد', el.dataset.emptyText || 'سيظهر المحتوى هنا فور نشره من إدارة الكلية.');
        return;
      }
      if (!filters.length) { el.innerHTML = wrapItems(type, items, layout); return; }
      buildFiltered(el, type, items, filters, pageSize, layout);
    };
    run();
  }

  function wrapItems(type, items, layout) {
    const inner = items.map(it => R.card(type, it, base)).join('');
    if (layout === 'timeline') return `<ul class="timeline">${inner}</ul>`;
    return `<div class="${layout === 'people' ? 'people-grid' : layout === 'gallery' ? 'gallery-grid' : layout === 'stack' ? 'card-stack' : 'card-grid'}">${inner}</div>`;
  }

  function buildFiltered(el, type, items, filters, pageSize, layout) {
    const params = new URLSearchParams(location.search);
    const uid = 'f-' + type;
    const controls = filters.map(key => {
      const def = FILTERS[key];
      if (!def) return '';
      if (def.kind === 'search') {
        return `<label class="filter-field filter-search" for="${uid}-q"><span>${def.label}</span><input type="search" id="${uid}-q" name="q" value="${esc(params.get('q') || '')}" placeholder="اكتب كلمة للبحث" autocomplete="off"></label>`;
      }
      const values = [...new Set(items.map(it => valueOf(def, it)).filter(Boolean))].sort((a, b) => key === 'year' || key === 'academicYear' ? b.localeCompare(a) : optionText(type, key, a).localeCompare(optionText(type, key, b), 'ar'));
      if (values.length < 2 && !params.get(key)) return '';
      return `<label class="filter-field" for="${uid}-${key}"><span>${def.label}</span><select id="${uid}-${key}" name="${key}"><option value="">الكل</option>${values.map(v => `<option value="${esc(v)}"${params.get(key) === v ? ' selected' : ''}>${esc(optionText(type, key, v))}</option>`).join('')}</select></label>`;
    }).join('');
    el.innerHTML = `<form class="filter-bar" role="search" aria-label="تصفية ${esc(S.TYPES[type] ? S.TYPES[type].label : '')}">${controls}<button type="reset" class="filter-reset">مسح التصفية</button></form>` +
      `<p class="filter-count" role="status" aria-live="polite"></p><div class="filter-results"></div><div class="list-more"></div>`;
    const form = $('form', el);
    const count = $('.filter-count', el);
    const results = $('.filter-results', el);
    const more = $('.list-more', el);
    let shown = pageSize;

    function current() {
      const state = {};
      $$('select, input', form).forEach(c => { if (c.value) state[c.name] = c.value; });
      return state;
    }
    function apply(resetPage) {
      if (resetPage) shown = pageSize;
      const st = current();
      const q = normalize(st.q || '');
      const matched = items.filter(it => {
        for (const key of filters) {
          const def = FILTERS[key];
          if (!def || def.kind === 'search' || !st[key]) continue;
          if (valueOf(def, it) !== st[key]) return false;
        }
        if (q) {
          const hay = normalize(SEARCH_KEYS.map(k => Array.isArray(it[k]) ? it[k].join(' ') : (it[k] || '')).join(' ') + ' ' + S.deptName(it.department));
          if (!q.split(/\s+/).every(w => hay.includes(w))) return false;
        }
        return true;
      });
      count.textContent = matched.length ? `${R.arDigits(matched.length)} ${matched.length === 1 ? 'نتيجة' : 'نتائج'}` : '';
      results.innerHTML = matched.length ? wrapItems(type, matched.slice(0, shown), layout)
        : R.emptyState('لا توجد نتائج مطابقة', 'جرّب كلمات بحث أخرى أو امسح التصفية.');
      more.innerHTML = matched.length > shown ? `<button type="button" class="cta-ghost">عرض المزيد (${R.arDigits(matched.length - shown)})</button>` : '';
      const url = new URL(location.href);
      ['q', ...filters].forEach(k => { if (st[k]) url.searchParams.set(k, st[k]); else url.searchParams.delete(k); });
      history.replaceState(null, '', url);
    }
    form.addEventListener('input', () => apply(true));
    form.addEventListener('change', () => apply(true));
    form.addEventListener('submit', e => { e.preventDefault(); apply(true); });
    form.addEventListener('reset', () => setTimeout(() => apply(true)));
    more.addEventListener('click', e => {
      if (!e.target.closest('button')) return;
      const firstNew = shown;
      shown += pageSize;
      apply(false);
      const target = $$('.filter-results article, .filter-results li, .filter-results figure', el)[firstNew];
      const focusable = target && target.querySelector('a, button');
      if (focusable) focusable.focus();
    });
    apply(true);
  }

  /* ---------- الصفحات المؤسسية ---------- */
  async function renderPage(el) {
    const id = el.dataset.cmsPage;
    loading(el);
    try {
      const it = await get('pages', id);
      done(el);
      if (!it) return; // يبقى النص الثابت أو حالة «قيد الإعداد»
      el.innerHTML = R.page(it, base);
      const h1 = $('.page-head h1');
      if (h1 && it.title) h1.textContent = it.title;
      setMeta(it.title, it.summary);
    } catch (e) { done(el); }
  }

  /* ---------- الأقسام ---------- */
  async function renderDepartment(el) {
    const id = el.dataset.cmsDepartment || new URLSearchParams(location.search).get('id') || '';
    const known = S.DEPARTMENTS.find(d => d.id === id);
    const run = async () => {
      loading(el);
      let it, faculty;
      try { [it, faculty] = await Promise.all([get('departments', id), list('faculty').catch(() => [])]); }
      catch (e) { failure(el, run); return; }
      done(el);
      if (!it && !known) {
        el.innerHTML = R.emptyState('لم يُعثر على القسم', 'ربما تغيّر رابط الصفحة. تصفّح قائمة الأقسام العلمية.', `<a class="cta-ghost" href="${base}departments.html">الأقسام العلمية</a>`);
        return;
      }
      const data = it || { title: known.name, summary: known.summary };
      const head = data.headProfile ? faculty.find(x => x.id === data.headProfile) : null;
      el.innerHTML = R.department(data, base, head);
      const members = faculty.filter(x => x.department === id);
      const membersEl = $('[data-dept-members]');
      if (membersEl) {
        membersEl.innerHTML = members.length ? `<div class="people-grid">${members.map(m => R.card('faculty', m, base)).join('')}</div>`
          : `<p class="pending-note">لم تُنشر بيانات أعضاء هيئة التدريس في هذا القسم بعد.</p>`;
      }
      const h1 = $('.page-head h1');
      if (h1) h1.textContent = data.title;
      const intro = $('.page-head [data-dept-summary]');
      if (intro && data.summary) intro.textContent = data.summary;
      if (it) setMeta(data.title, data.summary, el.dataset.cmsDepartment ? null : selfUrl(['id']));
    };
    run();
  }

  async function renderDepartmentsList(el) {
    const invite = el.querySelector('.dept-invitation');
    const extra = invite ? invite.outerHTML : '';
    const run = async () => {
      loading(el);
      let items = [];
      try { items = await list('departments'); } catch (e) { /* تُعرض القائمة الأساسية */ }
      done(el);
      const byId = Object.fromEntries(items.map(x => [x.id, x]));
      const all = S.DEPARTMENTS.map(d => ({ id: d.id, number: d.number, icon: d.icon, title: (byId[d.id] || {}).title || d.name, summary: (byId[d.id] || {}).summary || d.summary }))
        .concat(items.filter(x => !S.DEPARTMENTS.some(d => d.id === x.id)).map((x, i) => ({ ...x, number: String(S.DEPARTMENTS.length + i + 1).padStart(2, '0') })));
      el.innerHTML = all.map(d => `<li><div class="dept-top"><span class="dept-icon"><svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d.icon || '<path d="M4 19V5l8-3 8 3v14l-8 3-8-3Z"/>'}</svg></span><span class="dept-number" aria-hidden="true">${esc(d.number)}</span></div>` +
        `<h3><a class="stretched" href="${esc(R.itemUrl('departments', d.id, base))}">${esc(d.title)}</a></h3><p>${esc(d.summary)}</p></li>`).join('') + extra;
    };
    run();
  }

  /* ---------- صفحة العنصر الواحد ---------- */
  const LIST_PAGES = {
    news: ['news.html', 'الأخبار والإعلانات'], research: ['research.html', 'البحث العلمي'], projects: ['projects.html', 'مشاريع التخرج'],
    labs: ['labs.html', 'المعامل'], activities: ['activities.html', 'الأنشطة والفعاليات'], partners: ['partners.html', 'الشراكات'],
    accreditations: ['accreditation.html', 'الاعتمادات'], gallery: ['gallery.html', 'معرض الصور'], documents: ['regulations.html', 'اللوائح والنماذج'],
    schedules: ['schedules.html', 'الجداول'], calendar: ['calendar.html', 'التقويم الأكاديمي'], services: ['students.html', 'خدمات الطلاب']
  };
  async function renderItem(el) {
    const params = new URLSearchParams(location.search);
    const type = el.dataset.cmsItem || params.get('type');
    const id = params.get('id') || '';
    const listPage = type === 'faculty' ? ['staff.html', 'هيئة التدريس'] : LIST_PAGES[type];
    if (!listPage || !/^[a-z0-9][a-z0-9-]{0,79}$/.test(id)) {
      el.innerHTML = R.emptyState('الصفحة غير موجودة', 'الرابط غير صحيح أو ناقص.', `<a class="cta-ghost" href="${base}index.html">الصفحة الرئيسية</a>`);
      return;
    }
    const crumb = $('[data-crumb-list]');
    if (crumb) { crumb.href = base + listPage[0]; crumb.textContent = listPage[1]; }
    const kicker = $('.page-head .section-kicker');
    if (kicker) kicker.textContent = listPage[1];
    const run = async () => {
      loading(el);
      let it;
      try { it = await get(type, id); } catch (e) { failure(el, run); return; }
      done(el);
      if (!it) {
        el.innerHTML = R.emptyState('لم يُعثر على هذا المحتوى', 'ربما أُزيل أو تغيّر رابطه.', `<a class="cta-ghost" href="${base + listPage[0]}">العودة إلى ${esc(listPage[1])}</a>`);
        return;
      }
      el.innerHTML = type === 'faculty' ? R.member(it, base) : R.detail(type, it, base);
      const h1 = $('.page-head h1');
      if (h1) h1.textContent = it.title;
      const current = $('[data-crumb-current]');
      if (current) current.textContent = it.title;
      const intro = $('.page-head [data-item-intro]');
      if (intro) intro.textContent = type === 'faculty' ? [it.academicTitle, S.deptName(it.department)].filter(Boolean).join(' · ') : '';
      setMeta(it.title, it.summary || it.description || it.purpose || it.specialization, selfUrl(['type', 'id']));
    };
    run();
  }

  /* ---------- الهيكل الإداري: القيادات من دليل هيئة التدريس ---------- */
  async function renderLeaders(el) {
    try {
      const people = (await list('faculty')).filter(x => x.position);
      if (people.length) el.innerHTML = `<h2 class="block-title">القيادات الأكاديمية</h2><div class="people-grid">${people.map(p => R.card('faculty', p, base)).join('')}</div>`;
    } catch (e) { /* اختياري */ }
  }

  /* ---------- التشغيل ---------- */
  function start() {
    applySettings();
    $$('[data-cms-list]').forEach(renderList);
    $$('[data-cms-page]').forEach(renderPage);
    $$('[data-cms-department]').forEach(renderDepartment);
    $$('[data-cms-departments]').forEach(renderDepartmentsList);
    $$('[data-cms-item]').forEach(renderItem);
    $$('[data-cms-leaders]').forEach(renderLeaders);
  }
  window.CMSPublic = { list, get, settings, decodeFields };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
