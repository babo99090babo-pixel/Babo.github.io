/* ============================================================
   تهيئة Firebase للصفحات التي تحتاج تسجيل الدخول (النتائج والإدارة).
   تُحمَّل مكتبات Firebase من خوادم Google الرسمية (gstatic).
   ============================================================ */
const cfg = window.SITE_CONFIG;
const SDK = `https://www.gstatic.com/firebasejs/${cfg.sdkVersion}/`;

let ready = null;

export function firebaseReady() {
  if (ready) return ready;
  ready = (async () => {
    if (!cfg || !cfg.firebase || !cfg.firebase.apiKey || !cfg.firebase.projectId) {
      throw Object.assign(new Error('Firebase is not configured'), { code: 'app/not-configured' });
    }
    const [{ initializeApp }, A, F] = await Promise.all([
      import(SDK + 'firebase-app.js'),
      import(SDK + 'firebase-auth.js'),
      import(SDK + 'firebase-firestore.js')
    ]);
    const app = initializeApp(cfg.firebase);
    const auth = A.getAuth(app);
    auth.languageCode = 'ar';
    const db = F.getFirestore(app);
    if (cfg.useEmulator) {
      const e = cfg.emulator;
      A.connectAuthEmulator(auth, `http://${e.host}:${e.authPort}`, { disableWarnings: true });
      F.connectFirestoreEmulator(db, e.host, e.firestorePort);
    }
    return { app, auth, db, A, F, cfg, SDK };
  })();
  return ready;
}

/* رسائل الأخطاء بالعربية */
export function explainError(err) {
  const code = (err && err.code) || '';
  const map = {
    'auth/invalid-credential': 'البريد أو كلمة السر غير صحيحة.',
    'auth/wrong-password': 'البريد أو كلمة السر غير صحيحة.',
    'auth/user-not-found': 'البريد أو كلمة السر غير صحيحة.',
    'auth/invalid-email': 'اكتب بريدًا إلكترونيًا صحيحًا.',
    'auth/missing-password': 'اكتب كلمة السر.',
    'auth/weak-password': 'كلمة السر ضعيفة. استخدم ٨ أحرف على الأقل.',
    'auth/password-does-not-meet-requirements': 'كلمة السر لا تستوفي شروط الأمان المطلوبة.',
    'auth/email-already-in-use': 'هذا البريد مسجّل من قبل. استخدم «تسجيل الدخول» أو «نسيت كلمة السر».',
    'auth/too-many-requests': 'محاولات كثيرة. انتظر قليلًا ثم حاول مرة أخرى.',
    'auth/network-request-failed': 'تعذّر الاتصال بالإنترنت.',
    'auth/unauthorized-domain': 'هذا العنوان غير مسموح به في إعدادات Firebase (Authorized domains).',
    'auth/operation-not-allowed': 'طريقة الدخول المختارة غير مفعّلة في Firebase. اطلب من مسؤول المشروع تفعيلها، أو استخدم البريد وكلمة المرور.',
    'auth/popup-closed-by-user': 'أُغلقت نافذة Google قبل إكمال الدخول. يمكنك المحاولة مجددًا.',
    'auth/popup-blocked': 'منع المتصفح نافذة الدخول. اسمح بالنوافذ المنبثقة لهذا الموقع ثم حاول مجددًا.',
    'auth/cancelled-popup-request': 'أُلغيت محاولة الدخول السابقة. أكمل الدخول في النافذة الحالية.',
    'auth/account-exists-with-different-credential': 'هذا البريد مرتبط بطريقة دخول أخرى. ادخل بالطريقة الأصلية أو استخدم استعادة كلمة المرور.',
    'auth/requires-recent-login': 'لأمان حسابك، سجّل الخروج ثم ادخل مجددًا وأعد المحاولة.',
    'permission-denied': 'لا تملك صلاحية تنفيذ هذا الإجراء.',
    'unavailable': 'تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم أعد المحاولة.',
    'deadline-exceeded': 'استغرق الاتصال وقتًا طويلًا. أعد المحاولة.',
    'not-found': 'العنصر المطلوب غير موجود.',
    'app/not-configured': 'خدمة تسجيل الدخول غير مُعدّة بعد. يُرجى التواصل مع مسؤول الموقع.'
  };
  return map[code] || ('حدث خطأ غير متوقع' + (code ? ' (' + code + ')' : '') + '. أعد المحاولة.');
}
