/* القائمة الرئيسية: فتح وإغلاق على الهاتف، والقوائم الفرعية بلوحة المفاتيح واللمس. */
(() => {
  'use strict';
  const toggle = document.querySelector('.menu-toggle');
  const navigation = document.getElementById('mainNavigation');
  if (!navigation) return;
  document.documentElement.classList.add('nav-enhanced');
  const subToggles = Array.from(navigation.querySelectorAll('.sub-toggle'));

  function setSub(button, open) {
    button.setAttribute('aria-expanded', String(open));
    button.closest('.has-sub').classList.toggle('open', open);
  }
  function closeSubs(except) { subToggles.forEach(b => { if (b !== except) setSub(b, false); }); }
  function setOpen(open, restoreFocus) {
    if (!toggle) return;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'إغلاق القائمة الرئيسية' : 'فتح القائمة الرئيسية');
    navigation.classList.toggle('is-open', open);
    if (!open) closeSubs();
    if (restoreFocus) toggle.focus();
  }

  subToggles.forEach(button => button.addEventListener('click', () => {
    const open = button.getAttribute('aria-expanded') !== 'true';
    closeSubs(button);
    setSub(button, open);
  }));
  if (toggle) toggle.addEventListener('click', () => setOpen(toggle.getAttribute('aria-expanded') !== 'true'));
  navigation.addEventListener('click', event => {
    if (event.target.closest('a')) { closeSubs(); setOpen(false); }
  });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    const openSub = subToggles.find(b => b.getAttribute('aria-expanded') === 'true');
    if (openSub) { setSub(openSub, false); openSub.focus(); return; }
    if (toggle && toggle.getAttribute('aria-expanded') === 'true') setOpen(false, true);
  });
  document.addEventListener('click', event => {
    if (!navigation.contains(event.target) && !(toggle && toggle.contains(event.target))) { closeSubs(); setOpen(false); }
  });
  // إغلاق القائمة الفرعية عند انتقال التركيز خارجها
  navigation.addEventListener('focusout', event => {
    const li = event.target.closest('.has-sub');
    if (li && !li.contains(event.relatedTarget)) {
      const b = li.querySelector('.sub-toggle');
      if (b && window.matchMedia('(min-width: 1181px)').matches) setSub(b, false);
    }
  });
  window.matchMedia('(min-width: 1181px)').addEventListener('change', () => setOpen(false));
})();
