/* ============================================================
   قراءة ملف النتائج القديم (results-data.js) دون تنفيذه.
   الملف كان يُنفَّذ سابقًا كبرنامج، وهذا خطر إن عُدّل؛ هنا نقرأ
   القيم فقط: كائنات ومصفوفات ونصوص وأرقام وtrue/false/null.
   ============================================================ */
export function parseLegacyResults(text) {
  const start = text.search(/RESULTS_DATA\s*=\s*\[/);
  if (start < 0) throw new Error('لم يُعثر على RESULTS_DATA في الملف.');
  const p = new Parser(text, text.indexOf('[', start));
  const value = p.value();
  if (!Array.isArray(value)) throw new Error('صيغة الملف غير متوقعة.');
  return value;
}

class Parser {
  constructor(src, pos) { this.s = src; this.i = pos; }
  fail(msg) {
    const line = this.s.slice(0, this.i).split('\n').length;
    throw new Error(`${msg} (السطر ${line})`);
  }
  ws() {
    for (;;) {
      const c = this.s[this.i];
      if (c === ' ' || c === '\n' || c === '\r' || c === '\t' || c === '﻿') { this.i++; continue; }
      if (c === '/' && this.s[this.i + 1] === '/') { const e = this.s.indexOf('\n', this.i); this.i = e < 0 ? this.s.length : e; continue; }
      if (c === '/' && this.s[this.i + 1] === '*') { const e = this.s.indexOf('*/', this.i + 2); if (e < 0) this.fail('تعليق غير مغلق'); this.i = e + 2; continue; }
      return;
    }
  }
  value() {
    this.ws();
    const c = this.s[this.i];
    if (c === '[') return this.array();
    if (c === '{') return this.object();
    if (c === '"' || c === "'") return this.string();
    if (c === '-' || (c >= '0' && c <= '9')) return this.number();
    for (const [word, v] of [['true', true], ['false', false], ['null', null]]) {
      if (this.s.startsWith(word, this.i)) { this.i += word.length; return v; }
    }
    this.fail('قيمة غير مسموح بها');
  }
  array() {
    const out = [];
    this.i++;
    for (;;) {
      this.ws();
      if (this.s[this.i] === ']') { this.i++; return out; }
      out.push(this.value());
      this.ws();
      if (this.s[this.i] === ',') { this.i++; continue; }
      if (this.s[this.i] === ']') { this.i++; return out; }
      this.fail('متوقع «,» أو «]»');
    }
  }
  object() {
    const out = {};
    this.i++;
    for (;;) {
      this.ws();
      if (this.s[this.i] === '}') { this.i++; return out; }
      let key;
      if (this.s[this.i] === '"' || this.s[this.i] === "'") key = this.string();
      else {
        const m = /^[A-Za-z_$][\w$]*/.exec(this.s.slice(this.i, this.i + 64));
        if (!m) this.fail('اسم حقل غير صالح');
        key = m[0]; this.i += key.length;
      }
      if (key === '__proto__' || key === 'constructor' || key === 'prototype') this.fail('اسم حقل غير مسموح');
      this.ws();
      if (this.s[this.i] !== ':') this.fail('متوقع «:»');
      this.i++;
      out[key] = this.value();
      this.ws();
      if (this.s[this.i] === ',') { this.i++; continue; }
      if (this.s[this.i] === '}') { this.i++; return out; }
      this.fail('متوقع «,» أو «}»');
    }
  }
  string() {
    const q = this.s[this.i++];
    let out = '';
    for (;;) {
      const c = this.s[this.i++];
      if (c === undefined) this.fail('نص غير مغلق');
      if (c === q) return out;
      if (c === '\\') {
        const n = this.s[this.i++];
        const map = { n: '\n', t: '\t', r: '\r', b: '\b', f: '\f', '"': '"', "'": "'", '\\': '\\', '/': '/' };
        if (n === 'u') { out += String.fromCharCode(parseInt(this.s.slice(this.i, this.i + 4), 16)); this.i += 4; }
        else if (n in map) out += map[n];
        else out += n;
      } else out += c;
    }
  }
  number() {
    const m = /^-?\d+(\.\d+)?([eE][+-]?\d+)?/.exec(this.s.slice(this.i, this.i + 40));
    if (!m) this.fail('رقم غير صالح');
    this.i += m[0].length;
    return Number(m[0]);
  }
}
