/* الإداريون الثلاثة والصلاحيات الأخرى. القائمة تُحمى بقواعد الخادم. */
import { $, esc, fmtTime } from './util.js';
import { ROLE_LABELS, ROLE_DESCRIPTIONS } from './app.js';
import { adminEmails, emailKey, STAFF_ROLES } from '../staff-access.js';

export async function render(ctx) {
  const { db, F } = ctx.fb;
  const rosterRef = F.doc(db, 'adminAccess', 'roster');
  const [rosterSnap, snap] = await Promise.all([F.getDocFromServer(rosterRef), F.getDocs(F.collection(db, 'staff'))]);
  if (!rosterSnap.exists()) throw new Error('لم تُهيَّأ قائمة الإداريين بعد. راجع مسؤول المشروع.');
  const originalEmails = rosterSnap.data().emails;
  let staff = snap.docs.map(d => ({ ...d.data(), email: d.id })).sort((a, b) => a.email.localeCompare(b.email));
  const actor = emailKey(ctx.user.email);
  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>المستخدمون والصلاحيات</h1><p>اربط الإدارة بالبريد الشخصي لكل مسؤول. تُطبَّق الصلاحيات على الخادم، ويُسحب دور المدير السابق عند حفظ التبديل.</p></div></section>
    <section class="card" aria-labelledby="adminsTitle"><h2 id="adminsTitle">الإداريون الثلاثة</h2>
      <p class="hint">لكل بريد في القائمة صلاحيات المدير كاملة بعد توثيقه. يمكنك تغيير بريد أي مدير آخر أو إفراغ مقعده. لتبديل بريدك، اطلب من مدير آخر إجراء التبديل.</p>
      <form id="adminsForm" class="fields" novalidate>
        ${Array.from({ length: 3 }, (_, i) => {
          const email = originalEmails[i] || '';
          return `<label>بريد المدير ${['الأول', 'الثاني', 'الثالث'][i]}${email === actor ? ' (أنت)' : ''}
            <input type="email" id="adminEmail${i}" dir="ltr" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="254" value="${esc(email)}" ${email === actor ? 'readonly aria-describedby="adminsHint"' : ''} placeholder="name@example.com"></label>`;
        }).join('')}
        <p class="field-hint" id="adminsHint">يُقبل Gmail وأي بريد شخصي صحيح. يجب بقاء مدير واحد على الأقل. لا تُحذف حسابات الدخول عند استبدالها؛ تتغير صلاحياتها فقط.</p>
        <p class="form-msg" id="adminsMsg" role="alert"></p>
        <div class="row-actions"><button class="btn primary" id="saveAdmins" type="submit">حفظ الإداريين</button></div>
      </form>
      <p class="hint">يختار المدير الجديد «إنشاء حساب بالبريد الشخصي» في صفحة الدخول ويوثّق بريده، أو يستخدم Google إذا كان مفعّلًا. لا تشارك كلمات المرور.</p>
    </section>
    <section class="card"><h2>الأدوار</h2><dl class="roles-list">${Object.entries(ROLE_LABELS).map(([k, v]) => `<div><dt>${esc(v)}</dt><dd>${esc(ROLE_DESCRIPTIONS[k])}</dd></div>`).join('')}</dl></section>
    <section class="card"><h2>صلاحيات الموظفين الأخرى</h2>
      <form id="staffForm" class="fields" novalidate>
        <label>البريد الإلكتروني <input type="email" id="sEmail" required dir="ltr" autocomplete="off" placeholder="name@example.com" aria-describedby="sEmailHint"></label>
        <label>الاسم <input type="text" id="sName" maxlength="100"></label>
        <label>الدور <select id="sRole">${STAFF_ROLES.map(k => `<option value="${k}">${esc(ROLE_LABELS[k])}</option>`).join('')}</select></label>
        <label class="check-inline"><input type="checkbox" id="sActive" checked> الحساب مفعّل</label>
        <p class="field-hint" id="sEmailHint">يدخل الموظف ببريده الشخصي بعد إنشاء حساب وتوثيقه. دور المدير يُمنح من قائمة الإداريين الثلاثة أعلاه فقط.</p>
        <p class="form-msg" id="sMsg" role="alert"></p>
        <div class="row-actions"><button class="btn primary" id="saveStaff" type="submit">حفظ الصلاحية</button></div>
      </form></section>
    <section class="card"><h2>صلاحيات الموظفين الحالية</h2>
      <div class="scroll table-card"><table class="list-table"><thead><tr><th scope="col">البريد</th><th scope="col">الاسم</th><th scope="col">الدور</th><th scope="col">الحالة</th><th scope="col">آخر تعديل</th><th scope="col">إجراءات</th></tr></thead><tbody id="staffBody"></tbody></table></div>
      <p class="hint">أي سجل مدير قديم خارج قائمة الإداريين الثلاثة لا يمنح صلاحية، ويمكن إزالته من هذا الجدول.</p></section>`;

  function draw() {
    $('#staffBody').innerHTML = staff.map(s => `<tr><td dir="ltr">${esc(s.email)}</td><td>${esc(s.name || '')}</td><td>${esc(ROLE_LABELS[s.role] || s.role)}</td>
      <td>${s.role === 'admin' ? '<span class="status-badge st-none">سجل قديم بلا صلاحية</span>' : s.active ? '<span class="status-badge st-published">مفعّل</span>' : '<span class="status-badge st-none">معطّل</span>'}</td>
      <td>${esc(fmtTime(s.assignedAt))}</td>
      <td><button class="btn small" type="button" data-edit="${esc(s.email)}">تعديل</button> <button class="btn small danger" type="button" data-remove="${esc(s.email)}">إزالة</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty-row">لا توجد صلاحيات إضافية.</td></tr>';
  }
  draw();
  $('#adminsForm').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = $('#adminsMsg'); msg.textContent = '';
    let emails;
    try { emails = adminEmails([0, 1, 2].map(i => $(`#adminEmail${i}`).value), actor); }
    catch (error) { msg.textContent = error.message; return; }
    if (JSON.stringify(emails) === JSON.stringify(originalEmails)) { msg.textContent = 'لم تتغير قائمة الإداريين.'; return; }
    if (!(await ctx.confirm({ title: 'تغيير الإداريين', message: 'سيحصل أصحاب العناوين الجديدة على صلاحيات المدير بعد توثيق البريد، وسيفقد أصحاب العناوين المحذوفة دور المدير فور الحفظ. راجع العناوين جيدًا.', confirmLabel: 'حفظ التغيير', danger: true }))) return;
    $('#saveAdmins').disabled = true;
    try {
      await F.runTransaction(db, async transaction => {
        const current = await transaction.get(rosterRef);
        if (!current.exists() || JSON.stringify(current.data().emails) !== JSON.stringify(originalEmails)) throw new Error('عدّل مدير آخر القائمة أثناء فتح الصفحة. أعد فتح «المستخدمون والصلاحيات» وراجع القائمة الجديدة.');
        transaction.set(rosterRef, { emails, updatedBy: ctx.user.uid, updatedAt: F.serverTimestamp() });
        ctx.audit('users', 'replace-admins', 'adminAccess/roster', 'تحديث قائمة الإداريين: ' + emails.join('، '), transaction);
      });
      ctx.toast('حُفظ الإداريون، وسُحبت صلاحية العناوين المحذوفة.');
      ctx.rerender();
    } catch (error) { msg.textContent = error.message && !error.code ? error.message : ctx.explain(error); }
    finally { if ($('#saveAdmins')) $('#saveAdmins').disabled = false; }
  });
  $('#staffBody').addEventListener('click', async e => {
    const edit = e.target.closest('[data-edit]');
    const remove = e.target.closest('[data-remove]');
    if (edit) {
      const s = staff.find(x => x.email === edit.dataset.edit);
      $('#sEmail').value = s.email; $('#sName').value = s.name || '';
      $('#sRole').value = STAFF_ROLES.includes(s.role) ? s.role : 'editor'; $('#sActive').checked = !!s.active; $('#sEmail').focus();
    }
    if (remove) {
      const email = remove.dataset.remove;
      if (!(await ctx.confirm({ title: 'إزالة صلاحية الموظف', message: `ستُزال صلاحية الموظف ${email}. إن كان في قائمة الإداريين، يبقى مديرًا حتى يُزال من تلك القائمة. لن يُحذف حساب الدخول.`, confirmLabel: 'إزالة', danger: true }))) return;
      remove.disabled = true;
      try {
        const batch = F.writeBatch(db);
        batch.delete(F.doc(db, 'staff', email));
        ctx.audit('users', 'remove-role', `staff/${email}`, `إزالة صلاحية ${email}`, batch);
        await batch.commit();
        staff = staff.filter(x => x.email !== email); draw(); ctx.toast('أُزيلت الصلاحية.');
      } catch (error) { ctx.toast('تعذّر التنفيذ: ' + ctx.explain(error), 'error'); remove.disabled = false; }
    }
  });
  $('#staffForm').addEventListener('submit', async e => {
    e.preventDefault();
    const email = emailKey($('#sEmail').value), role = $('#sRole').value;
    const active = $('#sActive').checked, name = $('#sName').value.trim();
    const msg = $('#sMsg'); msg.textContent = '';
    if (!ctx.S.EMAIL_RE.test(email) || email.includes('/')) { msg.textContent = 'اكتب بريدًا إلكترونيًا صحيحًا.'; $('#sEmail').focus(); return; }
    if (!STAFF_ROLES.includes(role)) { msg.textContent = 'اختر دورًا صحيحًا.'; return; }
    const existing = staff.find(x => x.email === email);
    $('#saveStaff').disabled = true;
    try {
      const batch = F.writeBatch(db);
      batch.set(F.doc(db, 'staff', email), { role, active, name, assignedBy: ctx.user.uid, assignedAt: F.serverTimestamp() });
      ctx.audit('users', existing ? 'change-role' : 'grant-role', `staff/${email}`, `${email}: ${ROLE_LABELS[role]}${active ? '' : ' (معطّل)'}`, batch);
      await batch.commit();
      const fresh = await F.getDoc(F.doc(db, 'staff', email));
      staff = staff.filter(x => x.email !== email).concat([{ ...fresh.data(), email }]).sort((a, b) => a.email.localeCompare(b.email));
      draw(); e.target.reset(); $('#sActive').checked = true; ctx.toast('حُفظت الصلاحية. يجب توثيق البريد قبل الدخول.');
    } catch (error) { msg.textContent = 'تعذّر الحفظ: ' + ctx.explain(error); }
    finally { if ($('#saveStaff')) $('#saveStaff').disabled = false; }
  });
}
