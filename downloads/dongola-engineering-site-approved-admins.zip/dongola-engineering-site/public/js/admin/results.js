/* ============================================================
   إدارة النتائج (مسؤول النتائج والمدير فقط).
   batches/{id}            بيانات الدفعة والمواد، دون أسماء الطلاب
   results/{id}__{seatNo}  نتيجة طالب واحد؛ لا يقرؤها إلا صاحبها بعد النشر
   activationCodes/{code}  رمز لمرة واحدة يربط حساب الطالب برقم جلوسه
   ============================================================ */
import { $, $$, esc, download, stamp, commitInChunks, toLatinDigits, activationCode, fmtTime, toJsonValue, readFileText, randomString } from './util.js';
import { parseLegacyResults } from './legacy-parse.js';
import { notice } from './app.js';
import { POINTS, VALID_GRADES, SEMESTERS, SPECS, STATUSES, CLASSES, ROUNDS, SEAT_RE, BATCH_ID_RE, normSeat, normGrade, parseGpa, batchTitle, fullTitle, autoRow, autoClass, blankStudent, normalizeBatch } from './results-logic.js';


/* ===== التحميل ===== */
async function loadBatches(ctx) {
  const { db, F } = ctx.fb;
  const snap = await F.getDocs(F.collection(db, 'batches'));
  return snap.docs.map(d => {
    const x = d.data();
    return { id: d.id, ...x, round: x.round || 1, _legacy: Array.isArray(x.students) };
  }).sort((a, b) => String(b.year).localeCompare(String(a.year)) || a.round - b.round || SEMESTERS.indexOf(a.semester) - SEMESTERS.indexOf(b.semester));
}
async function loadBatchStudents(ctx, meta) {
  const { db, F } = ctx.fb;
  const snap = await F.getDocs(F.query(F.collection(db, 'results'), F.where('batchId', '==', meta.id)));
  const rows = snap.docs.map(d => d.data()).sort((a, b) => (a.num || 0) - (b.num || 0));
  return rows;
}

export async function render(ctx, rest) {
  const [sub, id] = rest;
  if (!sub) return renderEditorPage(ctx, null);
  if (sub === 'batch') return renderEditorPage(ctx, decodeURIComponent(id || ''));
  if (sub === 'codes') return renderCodes(ctx);
  if (sub === 'import') return renderImport(ctx);
  if (sub === 'log') return renderLog(ctx);
  ctx.main.innerHTML = notice('الصفحة غير موجودة', '');
}

/* ===================================================================
   محرر الدفعات
   =================================================================== */
async function renderEditorPage(ctx, openId) {
  const { db, F } = ctx.fb;
  let batches = await loadBatches(ctx);
  let cur = null;
  let dirty = false;
  const legacyCount = batches.filter(b => b._legacy).length;

  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>الدفعات والنتائج</h1><p>أدخل النتائج وراجعها، ثم انشرها. لا يرى الطالب إلا نتيجته، وبعد النشر فقط.</p></div>
      <button class="btn primary" id="addBatch" type="button">+ نتيجة جديدة</button></section>
    ${legacyCount ? `<div class="alert warn" role="alert"><strong>توجد ${legacyCount} دفعة بالصيغة القديمة</strong> (بيانات الطلاب داخل وثيقة الدفعة). رحّلها إلى الصيغة الآمنة من <a href="#/results/import">الاستيراد والترحيل</a>.</div>` : ''}
    <div class="layout results-layout-admin">
      <aside aria-label="قائمة النتائج"><h2>النتائج</h2><div id="batchList"></div></aside>
      <div id="editor" class="results-editor" aria-label="محرر النتائج"></div>
    </div>`;

  function markDirty() { dirty = true; ctx.setDirty(true); }
  function markClean() { dirty = false; ctx.setDirty(false); }

  function renderList() {
    const years = [...new Set(batches.map(b => b.year))].sort().reverse();
    const all = cur && cur._new ? batches.concat([cur]) : batches;
    $('#batchList').innerHTML = all.length ? years.concat(cur && cur._new && !years.includes(cur.year) ? [cur.year] : []).map(y => {
      const list = all.filter(b => b.year === y);
      return `<div class="year-group"><h3>${esc(y || 'بدون عام')}</h3>` + list.map(b => {
        const st = b._legacy ? '<span class="status-badge st-changed">صيغة قديمة</span>' : b.published ? '<span class="status-badge st-published">منشورة</span>' : '<span class="status-badge st-draft">غير منشورة</span>';
        return `<button class="batch-link" type="button" data-id="${esc(b.id)}" aria-current="${cur && b.id === cur.id}">${esc(batchTitle(b))}<small>${ROUNDS[b.round] || ''} · ${b._new ? 'جديدة لم تُحفظ' : (b.studentCount ?? (b.students || []).length) + ' طالب'}</small>${st}</button>`;
      }).join('') + '</div>';
    }).join('') : '<p class="hint">لا توجد نتائج بعد. أضف نتيجة جديدة أو استورد ملف النتائج من «الاستيراد والترحيل».</p>';
  }

  async function openBatch(id) {
    if (dirty && !(await ctx.confirm({ title: 'تعديلات غير محفوظة', message: 'لم تحفظ تعديلات النتيجة الحالية. فتح نتيجة أخرى سيُفقدها.', confirmLabel: 'متابعة دون حفظ', danger: true }))) return;
    const meta = batches.find(b => b.id === id);
    if (!meta) return;
    $('#editor').innerHTML = '<p class="admin-loading">جارٍ تحميل النتيجة…</p>';
    if (meta._legacy) {
      cur = { ...normalizeBatch({ ...meta }), _legacy: true };
    } else {
      const rows = await loadBatchStudents(ctx, meta);
      cur = normalizeBatch({ ...meta, students: rows });
    }
    cur._origSeats = new Set(cur.students.map(s => s.seatNo));
    markClean();
    ctx.replaceRoute('results/batch/' + encodeURIComponent(id));
    render();
  }

  function render() { renderList(); renderEditor(); }

  function renderEditor() {
    const ed = $('#editor');
    const b = cur;
    if (!b) {
      ed.innerHTML = `<div class="card empty"><h2>لا توجد نتيجة مختارة</h2><p>اختر نتيجة من القائمة، أو أضف نتيجة جديدة.</p></div>`;
      return;
    }
    const locked = b._legacy;
    const yearOpts = [...new Set(batches.map(x => x.year).filter(Boolean))];
    ed.innerHTML = `
      ${locked ? `<div class="alert warn" role="alert">هذه الدفعة بالصيغة القديمة ولا يمكن تعديلها قبل ترحيلها. انتقل إلى <a href="#/results/import">الاستيراد والترحيل</a>.</div>` : ''}
      <section class="card batch-status-card">
        <div><strong>حالة النشر:</strong> ${b.published ? '<span class="status-badge st-published">منشورة — يراها الطلاب المرتبطون</span>' : '<span class="status-badge st-draft">غير منشورة — لا يراها الطلاب</span>'}</div>
        <div class="row-actions">
          <button class="btn primary" type="button" data-act="save"${locked ? ' disabled' : ''}>حفظ التغييرات</button>
          ${b._new ? '' : `<button class="btn" type="button" data-act="${b.published ? 'unpublish' : 'publish'}"${locked ? ' disabled' : ''}>${b.published ? 'إخفاء عن الطلاب' : 'نشر للطلاب'}</button>`}
        </div>
      </section>
      <fieldset class="card" ${locked ? 'disabled' : ''}>
        <h2><span class="spacer">بيانات النتيجة</span>
          <button class="btn small" type="button" data-act="round2">إنشاء الدور الثاني من هذه النتيجة</button>
          <button class="btn small danger" type="button" data-act="delBatch">حذف النتيجة</button></h2>
        <div class="fields">
          <label>العام الدراسي <input data-f="year" value="${esc(b.year)}" list="yearList" placeholder="2025/2026" dir="ltr"></label>
          <datalist id="yearList">${yearOpts.map(y => `<option value="${esc(y)}">`).join('')}</datalist>
          <label>الدور <select data-f="round">${Object.entries(ROUNDS).map(([k, v]) => `<option value="${k}" ${+k === b.round ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
          <label>الدورة <input data-f="session" value="${esc(b.session)}" placeholder="دورة أغسطس 2026م"></label>
          <label>الفصل <select data-f="semester">${SEMESTERS.map(s => `<option ${s === b.semester ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
          <label>التخصص <select data-f="specialization">${[...new Set([...SPECS, b.specialization])].map(s => `<option ${s === b.specialization ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select></label>
        </div>
      </fieldset>
      <fieldset class="card" ${locked ? 'disabled' : ''}>
        <h2><span class="spacer">المواد (${b.subjects.length})</span><button class="btn small" type="button" data-act="addSubj">+ مادة</button></h2>
        <div class="scroll" style="max-height:none"><table class="subj-table">
          <thead><tr><th>#</th><th>اسم المادة</th><th>الساعات</th><th><span class="visually-hidden">حذف</span></th></tr></thead>
          <tbody>${b.subjects.map((s, i) => `<tr>
            <td class="num">${i + 1}</td>
            <td><input class="sname" data-si="${i}" data-sf="name" value="${esc(s.name)}" aria-label="اسم المادة ${i + 1}"></td>
            <td><input class="shours" data-si="${i}" data-sf="hours" value="${s.hours}" inputmode="numeric" aria-label="ساعات المادة ${i + 1}"></td>
            <td><button class="icon-btn" type="button" data-act="delSubj" data-i="${i}" aria-label="حذف المادة ${i + 1}">✕</button></td></tr>`).join('')}
          </tbody></table></div>
      </fieldset>
      <fieldset class="card" ${locked ? 'disabled' : ''}>
        <h2><span class="spacer">الطلاب (${b.students.length})</span>
          <button class="btn small" type="button" data-act="addStudent">+ طالب</button>
          <button class="btn small" type="button" data-act="paste">لصق من Excel</button>
          <button class="btn small" type="button" data-act="recalc">احسب المعدلات للكل</button></h2>
        <div class="scroll"><table class="stud-table">
          <thead><tr><th>#</th><th>رقم الجلوس</th><th>الاسم</th>
            ${b.subjects.map(s => `<th class="subj" title="${esc(s.name)} (${s.hours} س)">${esc(s.name)}<br><small>${s.hours} س</small></th>`).join('')}
            <th>م. فصلي</th><th>م. تراكمي</th><th>الحالة</th><th>التقدير</th><th>الملاحظات</th><th><span class="visually-hidden">حذف</span></th></tr></thead>
          <tbody id="studBody">${b.students.map((st, r) => rowHTML(b, st, r)).join('')}</tbody>
        </table></div>
        <p class="hint">التقديرات: A B C D F، و«ك» للغياب بعذر. عند إدخال التقديرات يُحسب المعدل الفصلي والحالة تلقائيًا، ويمكنك تعديلهما يدويًا. المعدل التراكمي يُدخل يدويًا (ويساوي الفصلي في الفصل الأول).</p>
        <ul class="warn-list" id="warnings"></ul>
      </fieldset>`;
    updateWarnings();
  }

  const gradeClass = g => g ? (VALID_GRADES.includes(g) ? 'g-' + g : 'invalid') : '';
  function rowHTML(b, st, r) {
    const n = r + 1;
    return `<tr data-r="${r}">
      <td class="num">${n}</td>
      <td><input class="seat${st.seatNo && !SEAT_RE.test(st.seatNo) ? ' invalid' : ''}" data-k="seatNo" value="${esc(st.seatNo)}" aria-label="رقم جلوس الطالب ${n}" dir="ltr"></td>
      <td><input class="name" data-k="name" value="${esc(st.name)}" aria-label="اسم الطالب ${n}"></td>
      ${b.subjects.map((s, i) => `<td><input class="grade ${gradeClass(st.grades[i])}" data-g="${i}" value="${esc(st.grades[i] || '')}" maxlength="2" aria-label="تقدير الطالب ${n} في ${esc(s.name)}"></td>`).join('')}
      <td><input class="gpa" data-k="semesterGPA" value="${st.semesterGPA != null ? st.semesterGPA.toFixed(2) : ''}" aria-label="المعدل الفصلي للطالب ${n}"></td>
      <td><input class="gpa" data-k="cumulativeGPA" value="${st.cumulativeGPA != null ? st.cumulativeGPA.toFixed(2) : ''}" aria-label="المعدل التراكمي للطالب ${n}"></td>
      <td><select class="status" data-k="status" aria-label="حالة الطالب ${n}">${['', ...STATUSES].map(s => `<option ${s === (st.status || '') ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      <td><select class="cls" data-k="classification" aria-label="تقدير الطالب ${n}">${['', ...CLASSES].map(s => `<option ${s === (st.classification || '') ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      <td><input class="notes" data-k="notes" value="${esc(st.notes)}" aria-label="ملاحظات الطالب ${n}"></td>
      <td><button class="icon-btn" type="button" data-act="delStudent" aria-label="حذف الطالب ${n}">✕</button></td>
    </tr>`;
  }
  function refreshRow(r) {
    const tr = document.querySelector(`#studBody tr[data-r="${r}"]`);
    if (!tr) return;
    const active = document.activeElement;
    const sel = active && tr.contains(active) ? (active.dataset.k ? `[data-k="${active.dataset.k}"]` : `[data-g="${active.dataset.g}"]`) : null;
    const pos = sel && active.selectionStart != null ? active.selectionStart : null;
    tr.outerHTML = rowHTML(cur, cur.students[r], r);
    if (sel) {
      const el = document.querySelector(`#studBody tr[data-r="${r}"] ${sel}`);
      if (el) { el.focus(); if (pos != null && el.setSelectionRange) try { el.setSelectionRange(pos, pos); } catch (e) { /* */ } }
    }
  }
  function problems(b) {
    const w = [];
    const seen = {};
    if (!b.year) w.push('اكتب العام الدراسي.');
    else if (!/^\d{4}\/\d{4}$/.test(b.year)) w.push('العام الدراسي بالصيغة 2025/2026.');
    if (!b.subjects.length) w.push('أضف مادة واحدة على الأقل.');
    b.students.forEach((st, i) => {
      if (!st.seatNo) w.push(`الطالب رقم ${i + 1}: رقم الجلوس فارغ.`);
      else if (!SEAT_RE.test(st.seatNo)) w.push(`الطالب رقم ${i + 1}: رقم الجلوس «${st.seatNo}» يحتوي رموزًا غير مسموحة (المسموح: أرقام وحروف إنجليزية وشرطة).`);
      else if (seen[st.seatNo]) w.push(`رقم الجلوس ${st.seatNo} مكرر (الصف ${seen[st.seatNo]} والصف ${i + 1}).`);
      else seen[st.seatNo] = i + 1;
      if (!st.name) w.push(`الطالب رقم ${i + 1}: الاسم فارغ.`);
      st.grades.forEach((g, gi) => { if (g && !VALID_GRADES.includes(g)) w.push(`الطالب رقم ${i + 1}: تقدير غير معروف «${g}» في ${b.subjects[gi].name}.`); });
      if (!st.status) w.push(`الطالب رقم ${i + 1}: الحالة غير محددة.`);
    });
    return w;
  }
  function updateWarnings() {
    if (!cur || !$('#warnings')) return;
    const w = problems(cur);
    $('#warnings').innerHTML = w.slice(0, 12).map(x => `<li>${esc(x)}</li>`).join('') + (w.length > 12 ? `<li>و ${w.length - 12} ملاحظات أخرى…</li>` : '');
  }

  /* ----- أحداث المحرر ----- */
  const ed = $('#editor');
  ed.addEventListener('input', e => {
    const b = cur; if (!b) return;
    const t = e.target;
    if (t.dataset.f) { b[t.dataset.f] = t.dataset.f === 'round' ? +t.value : t.value.trim(); markDirty(); renderList(); updateWarnings(); return; }
    if (t.dataset.si != null) {
      const s = b.subjects[+t.dataset.si];
      if (t.dataset.sf === 'hours') s.hours = parseFloat(toLatinDigits(t.value)) || 0; else s.name = t.value;
      markDirty(); return;
    }
    const tr = t.closest('#studBody tr'); if (!tr) return;
    const r = +tr.dataset.r; const st = b.students[r];
    if (t.dataset.g != null) { st.grades[+t.dataset.g] = normGrade(t.value) || null; autoRow(st, b); markDirty(); refreshRow(r); updateWarnings(); return; }
    const k = t.dataset.k;
    if (k === 'seatNo') st.seatNo = normSeat(t.value);
    else if (k === 'semesterGPA' || k === 'cumulativeGPA') {
      st[k] = parseGpa(t.value);
      if (k === 'cumulativeGPA') { autoClass(st); tr.querySelector('[data-k="classification"]').value = st.classification || ''; tr.querySelector('[data-k="notes"]').value = st.notes || ''; }
    } else if (k === 'status') { st.status = t.value; autoClass(st); refreshRow(r); }
    else if (k === 'classification') st.classification = t.value || null;
    else st[k] = t.value;
    markDirty(); updateWarnings();
  });
  ed.addEventListener('change', e => { if (e.target.dataset.f) renderList(); });
  ed.addEventListener('click', async e => {
    const btn = e.target.closest('[data-act]'); if (!btn || !cur) return;
    const b = cur; const act = btn.dataset.act;
    const r = btn.closest('#studBody tr') ? +btn.closest('#studBody tr').dataset.r : null;
    if (act === 'save') return saveBatch();
    if (act === 'publish' || act === 'unpublish') return setPublished(act === 'publish');
    if (act === 'addSubj') { b.subjects.push({ name: 'مادة جديدة', hours: 3 }); b.students.forEach(s => s.grades.push(null)); }
    else if (act === 'delSubj') {
      const i = +btn.dataset.i;
      if (!(await ctx.confirm({ title: 'حذف مادة', message: `حذف مادة «${b.subjects[i].name}» وتقديراتها من كل الطلاب؟`, confirmLabel: 'حذف', danger: true }))) return;
      b.subjects.splice(i, 1); b.students.forEach(s => s.grades.splice(i, 1));
    } else if (act === 'addStudent') {
      b.students.push(blankStudent(b)); markDirty(); renderEditor();
      const inputs = $$('#studBody input.seat'); inputs[inputs.length - 1].focus(); return;
    } else if (act === 'delStudent') {
      const st = b.students[r];
      if (!(await ctx.confirm({ title: 'حذف طالب', message: `حذف الطالب ${st.name || st.seatNo || ''} من هذه النتيجة؟ يُحذف من قاعدة البيانات عند الحفظ.`, confirmLabel: 'حذف', danger: true }))) return;
      b.students.splice(r, 1);
    } else if (act === 'recalc') { b.students.forEach(st => autoRow(st, b)); ctx.toast('تم حساب المعدلات والحالات. راجع المعدل التراكمي يدويًا.'); }
    else if (act === 'paste') { openPaste(); return; }
    else if (act === 'delBatch') { return deleteBatch(); }
    else if (act === 'round2') {
      if (dirty && !(await ctx.confirm({ title: 'تعديلات غير محفوظة', message: 'احفظ تعديلات النتيجة الحالية أولًا، أو تابع دون حفظها.', confirmLabel: 'متابعة دون حفظ', danger: true }))) return;
      cur = {
        id: 'b-' + randomString(10), _new: true, _origSeats: new Set(), year: b.year, round: 2, session: '', semester: b.semester, specialization: b.specialization, published: false,
        subjects: b.subjects.map(s => ({ ...s })),
        students: b.students.filter(s => s.status !== 'نجاح').map(s => ({ ...blankStudent(b), seatNo: s.seatNo, name: s.name, grades: s.grades.map(g => g === 'F' || g === 'ك' ? null : g) }))
      };
      ctx.toast(`أُنشئت نتيجة الدور الثاني وفيها ${cur.students.length} طالب (غير الناجحين). أدخل التقديرات ثم احفظ.`);
    }
    markDirty(); render();
  });

  $('#addBatch').addEventListener('click', async () => {
    if (dirty && !(await ctx.confirm({ title: 'تعديلات غير محفوظة', message: 'ستُفقد تعديلات النتيجة الحالية.', confirmLabel: 'متابعة دون حفظ', danger: true }))) return;
    const last = cur;
    cur = { id: 'b-' + randomString(10), _new: true, _origSeats: new Set(), year: last ? last.year : '', round: 1, session: last ? last.session : '', semester: SEMESTERS[0], specialization: last ? last.specialization : SPECS[0], published: false, subjects: [{ name: 'مادة جديدة', hours: 3 }], students: [] };
    markDirty(); render();
    $('[data-f="year"]').focus();
  });
  $('#batchList').addEventListener('click', e => { const b = e.target.closest('.batch-link'); if (b && (!cur || b.dataset.id !== cur.id)) openBatch(b.dataset.id); });

  /* ----- اللصق من Excel ----- */
  function openPaste() {
    const b = cur;
    $('#pasteCols').innerHTML = ['رقم الجلوس', 'الاسم', ...b.subjects.map(s => 'تقدير: ' + s.name), 'المعدل التراكمي (اختياري)'].map(x => `<li>${esc(x)}</li>`).join('');
    $('#pasteText').value = ''; $('#pasteReplace').checked = false;
    const dlg = $('#pasteDlg');
    dlg.returnValue = '';
    dlg.querySelector('form').onsubmit = e => {
      if (!e.submitter || e.submitter.value !== 'ok') return;
      const n = b.subjects.length;
      const rows = $('#pasteText').value.split(/\r?\n/).map(l => l.split('\t')).filter(c => c.join('').trim());
      if (!rows.length) return;
      const list = rows.map(c => {
        const st = blankStudent(b);
        st.seatNo = normSeat(c[0] || ''); st.name = (c[1] || '').trim();
        for (let i = 0; i < n; i++) st.grades[i] = normGrade(c[2 + i]) || null;
        autoRow(st, b);
        const cum = parseGpa(c[2 + n] || '');
        if (cum != null) { st.cumulativeGPA = cum; autoClass(st); }
        return st;
      });
      if ($('#pasteReplace').checked) b.students = list; else b.students.push(...list);
      markDirty(); render();
      ctx.toast(`أضيف ${list.length} طالب. راجع الملاحظات أسفل الجدول ثم احفظ.`);
    };
    dlg.showModal();
    $('#pasteText').focus();
  }

  /* ----- الحفظ والنشر والحذف ----- */
  async function saveBatch() {
    const b = cur;
    const w = problems(b);
    if (w.length) { ctx.toast('أصلح الملاحظات أسفل جدول الطلاب قبل الحفظ (' + w.length + ').', 'error'); $('#warnings').scrollIntoView({ block: 'center' }); return; }
    if (!BATCH_ID_RE.test(b.id)) { ctx.toast('معرّف الدفعة غير صالح.', 'error'); return; }
    const meta = { year: b.year, round: b.round, session: b.session, semester: b.semester, specialization: b.specialization, subjects: b.subjects };
    const ops = [];
    ops.push(x => x.set(F.doc(db, 'batches', b.id), { ...meta, published: b.published, studentCount: b.students.length, updatedAt: F.serverTimestamp(), updatedBy: ctx.user.uid, updatedByEmail: ctx.user.email }));
    const seats = new Set();
    b.students.forEach((st, i) => {
      seats.add(st.seatNo);
      ops.push(x => x.set(F.doc(db, 'results', `${b.id}__${st.seatNo}`), { batchId: b.id, num: i + 1, ...st, grades: st.grades.map(g => g || null), published: b.published, ...meta }));
    });
    const removed = [...b._origSeats].filter(s => !seats.has(s));
    removed.forEach(seat => ops.push(x => x.delete(F.doc(db, 'results', `${b.id}__${seat}`))));
    const wasNew = !!b._new;
    ops.push(x => ctx.audit('results', wasNew ? 'create-batch' : 'save-batch', `batches/${b.id}`, `${fullTitle(b)}: ${b.students.length} طالب${removed.length ? `، حُذف ${removed.length}` : ''}`, x));
    const btns = $$('[data-act="save"]'); btns.forEach(x => { x.disabled = true; x.textContent = 'جارٍ الحفظ…'; });
    try {
      await commitInChunks(F, db, ops);
      b._origSeats = seats; b._new = false;
      batches = await loadBatches(ctx);
      markClean();
      ctx.replaceRoute('results/batch/' + encodeURIComponent(b.id));
      render();
      ctx.toast(b.published ? 'حُفظت التغييرات، وهي ظاهرة الآن للطلاب المرتبطين.' : 'حُفظت التغييرات. النتيجة غير منشورة بعد.');
    } catch (err) {
      ctx.toast('لم يتم الحفظ: ' + ctx.explain(err), 'error');
      btns.forEach(x => { x.disabled = false; x.textContent = 'حفظ التغييرات'; });
    }
  }

  async function setPublished(on) {
    const b = cur;
    if (dirty) { ctx.toast('احفظ التغييرات أولًا، ثم انشر.', 'error'); return; }
    const ok = await ctx.confirm({
      title: on ? 'نشر النتيجة للطلاب' : 'إخفاء النتيجة عن الطلاب',
      message: on ? `ستظهر نتيجة «${fullTitle(b)}» لكل طالب (${b.students.length}) فور تسجيل دخوله، ولن يرى أي طالب نتيجة غيره.` : `ستختفي نتيجة «${fullTitle(b)}» من حسابات الطلاب حتى تُنشر مجددًا.`,
      confirmLabel: on ? 'نشر الآن' : 'إخفاء', danger: !on
    });
    if (!ok) return;
    const ops = [x => x.update(F.doc(db, 'batches', b.id), { published: on, updatedAt: F.serverTimestamp(), updatedBy: ctx.user.uid, updatedByEmail: ctx.user.email })];
    b.students.forEach(st => ops.push(x => x.update(F.doc(db, 'results', `${b.id}__${st.seatNo}`), { published: on })));
    ops.push(x => ctx.audit('results', on ? 'publish-batch' : 'unpublish-batch', `batches/${b.id}`, `${fullTitle(b)}: ${b.students.length} طالب`, x));
    try {
      await commitInChunks(F, db, ops);
      b.published = on;
      batches = await loadBatches(ctx);
      render();
      ctx.toast(on ? 'نُشرت النتيجة. يراها كل طالب في حسابه.' : 'أُخفيت النتيجة عن الطلاب.');
    } catch (err) { ctx.toast('تعذّر التنفيذ: ' + ctx.explain(err), 'error'); }
  }

  async function deleteBatch() {
    const b = cur;
    if (b._new) { cur = null; markClean(); render(); return; }
    const ok = await ctx.confirm({ title: 'حذف النتيجة', message: `ستُحذف نتيجة «${fullTitle(b)}» بكل طلابها (${b.students.length}) من قاعدة البيانات. خذ نسخة احتياطية أولًا إن لم تكن متأكدًا.`, confirmLabel: 'حذف نهائي', danger: true, requireText: 'حذف' });
    if (!ok) return;
    const ops = [...b._origSeats].map(seat => x => x.delete(F.doc(db, 'results', `${b.id}__${seat}`)));
    ops.push(x => x.delete(F.doc(db, 'batches', b.id)));
    ops.push(x => ctx.audit('results', 'delete-batch', `batches/${b.id}`, `${fullTitle(b)}: ${b._origSeats.size} طالب`, x));
    try {
      await commitInChunks(F, db, ops);
      batches = await loadBatches(ctx);
      cur = null; markClean();
      ctx.replaceRoute('results');
      render();
      ctx.toast('حُذفت النتيجة.');
    } catch (err) { ctx.toast('تعذّر الحذف: ' + ctx.explain(err), 'error'); }
  }

  render();
  const toOpen = openId && batches.some(b => b.id === openId) ? openId : null;
  if (toOpen) openBatch(toOpen);
}

/* ===================================================================
   رموز التفعيل وربط الحسابات
   =================================================================== */
async function renderCodes(ctx) {
  const { db, F } = ctx.fb;
  ctx.main.innerHTML = '<p class="admin-loading">جارٍ تحميل أرقام الجلوس والحسابات…</p>';
  const [resSnap, codeSnap, linkSnap, batchSnap] = await Promise.all([
    F.getDocs(F.collection(db, 'results')), F.getDocs(F.collection(db, 'activationCodes')),
    F.getDocs(F.collection(db, 'studentLinks')), F.getDocs(F.collection(db, 'batches'))
  ]);
  const batchNames = Object.fromEntries(batchSnap.docs.map(d => [d.id, fullTitle({ ...d.data(), round: d.data().round || 1 })]));
  const seats = new Map();
  resSnap.forEach(d => {
    const r = d.data();
    const s = seats.get(r.seatNo) || { seatNo: r.seatNo, name: r.name, batches: new Set(), year: '' };
    s.batches.add(r.batchId);
    if (String(r.year || '') >= s.year) { s.year = String(r.year || ''); s.name = r.name; }
    seats.set(r.seatNo, s);
  });
  // الدفعات القديمة غير المرحّلة
  batchSnap.forEach(d => (d.data().students || []).forEach(st => {
    const seat = normSeat(st.seatNo || '');
    if (seat && !seats.has(seat)) seats.set(seat, { seatNo: seat, name: st.name, batches: new Set([d.id]), year: d.data().year || '' });
  }));
  const codes = codeSnap.docs.map(d => ({ code: d.id, ...d.data() }));
  const links = linkSnap.docs.map(d => ({ uid: d.id, ...d.data() }));
  const linkBySeat = new Map(links.map(l => [l.seatNo, l]));
  const openCodes = new Map();
  codes.filter(c => !c.usedBy).forEach(c => { (openCodes.get(c.seatNo) || openCodes.set(c.seatNo, []).get(c.seatNo)).push(c); });
  const rows = [...seats.values()].sort((a, b) => a.seatNo.localeCompare(b.seatNo, 'en', { numeric: true }));
  const statusOf = s => linkBySeat.has(s.seatNo) ? 'linked' : openCodes.has(s.seatNo) ? 'code' : 'none';
  const batchOpts = Object.entries(batchNames).sort((a, b) => a[1].localeCompare(b[1], 'ar'));

  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>رموز التفعيل والحسابات</h1>
      <p>يربط الطالب حسابه برقم جلوسه برمز لمرة واحدة تسلّمه له الكلية شخصيًا بعد التحقق من هويته. لا يستطيع أي حساب الاطلاع على نتيجة دون هذا الربط.</p></div></section>
    <section class="card">
      <form class="list-tools" role="search" aria-label="تصفية أرقام الجلوس">
        <label>بحث <input type="search" id="cSearch" placeholder="رقم الجلوس أو الاسم" autocomplete="off"></label>
        <label>الدفعة <select id="cBatch"><option value="">كل الدفعات</option>${batchOpts.map(([id, t]) => `<option value="${esc(id)}">${esc(t)}</option>`).join('')}</select></label>
        <label>الحالة <select id="cStatus"><option value="">الكل</option><option value="none">بدون رمز ولا حساب</option><option value="code">رمز صادر لم يُستخدم</option><option value="linked">حساب مرتبط</option></select></label>
        <p class="list-count" id="cCount" role="status" aria-live="polite"></p>
      </form>
      <div class="row-actions"><button class="btn primary" type="button" id="bulkIssue">إصدار رموز لمن ليس لديه رمز أو حساب (حسب التصفية)</button></div>
      <div class="scroll table-card"><table class="list-table">
        <thead><tr><th scope="col">رقم الجلوس</th><th scope="col">الاسم</th><th scope="col">الحالة</th><th scope="col">إجراءات</th></tr></thead>
        <tbody id="cBody"></tbody></table></div>
    </section>
    <section class="card codes-output" id="codesOut" hidden aria-labelledby="codesOutTitle"></section>`;

  function filtered() {
    const q = toLatinDigits($('#cSearch').value.trim()).toUpperCase();
    const bt = $('#cBatch').value, st = $('#cStatus').value;
    return rows.filter(s => (!bt || s.batches.has(bt)) && (!st || statusOf(s) === st) && (!q || s.seatNo.includes(q) || String(s.name || '').includes($('#cSearch').value.trim())));
  }
  function draw() {
    const list = filtered();
    $('#cCount').textContent = `${list.length} من ${rows.length} رقم جلوس`;
    $('#cBody').innerHTML = list.length ? list.map(s => {
      const st = statusOf(s);
      const link = linkBySeat.get(s.seatNo);
      const label = st === 'linked' ? `<span class="status-badge st-published">مرتبط</span> <small dir="ltr">${esc(link.email || '')}</small>`
        : st === 'code' ? '<span class="status-badge st-changed">رمز صادر لم يُستخدم</span>' : '<span class="status-badge st-none">بدون رمز</span>';
      const actions = st === 'linked'
        ? `<button class="btn small danger" type="button" data-revoke="${esc(s.seatNo)}">إلغاء الربط</button>`
        : `<button class="btn small" type="button" data-issue="${esc(s.seatNo)}">${st === 'code' ? 'إعادة إصدار الرمز' : 'إصدار رمز'}</button>`;
      return `<tr><th scope="row" dir="ltr">${esc(s.seatNo)}</th><td>${esc(s.name)}</td><td>${label}</td><td>${actions}</td></tr>`;
    }).join('') : '<tr><td colspan="4" class="empty-row">لا توجد أرقام جلوس مطابقة.</td></tr>';
  }
  ['cSearch', 'cBatch', 'cStatus'].forEach(id => $('#' + id).addEventListener(id === 'cSearch' ? 'input' : 'change', draw));
  draw();

  function showCodes(issued) {
    const out = $('#codesOut');
    out.hidden = false;
    out.innerHTML = `<h2 id="codesOutTitle">الرموز الصادرة الآن (${issued.length})</h2>
      <div class="alert warn">هذه الرموز سرية ولا تُعرض مرة أخرى بعد مغادرة الصفحة إلا لمسؤول النتائج. سلّم كل رمز لصاحبه شخصيًا بعد التحقق من هويته، ولا تنشرها في مجموعات أو قوائم عامة. احذف أي ملف منزَّل بعد الطباعة.</div>
      <div class="row-actions"><button class="btn" type="button" id="printCodes">طباعة</button><button class="btn" type="button" id="csvCodes">تنزيل ملف CSV</button></div>
      <div class="scroll"><table class="list-table codes-table"><thead><tr><th scope="col">رقم الجلوس</th><th scope="col">الاسم</th><th scope="col">رمز التفعيل</th></tr></thead>
      <tbody>${issued.map(c => `<tr><td dir="ltr">${esc(c.seatNo)}</td><td>${esc(c.name)}</td><td dir="ltr" class="code-cell">${esc(c.code)}</td></tr>`).join('')}</tbody></table></div>`;
    $('#printCodes').addEventListener('click', () => { document.body.classList.add('print-codes'); window.print(); setTimeout(() => document.body.classList.remove('print-codes'), 500); });
    $('#csvCodes').addEventListener('click', () => {
      const csv = '﻿' + ['رقم الجلوس,الاسم,رمز التفعيل', ...issued.map(c => [c.seatNo, c.name, c.code].map(v => `"${String(v || '').replace(/"/g, '""')}"`).join(','))].join('\r\n');
      download(`activation-codes-${stamp()}.csv`, csv, 'text/csv;charset=utf-8');
    });
    out.scrollIntoView({ block: 'start' });
    out.querySelector('h2').tabIndex = -1;
    out.querySelector('h2').focus({ preventScroll: true });
  }

  async function issue(seatList) {
    const issued = [];
    const ops = [];
    seatList.forEach(s => {
      (openCodes.get(s.seatNo) || []).forEach(c => ops.push(x => x.delete(F.doc(db, 'activationCodes', c.code))));
      const code = activationCode();
      issued.push({ seatNo: s.seatNo, name: s.name, code });
      ops.push(x => x.set(F.doc(db, 'activationCodes', code), { seatNo: s.seatNo, usedBy: null, usedAt: null, createdAt: F.serverTimestamp(), createdBy: ctx.user.uid }));
    });
    ops.push(x => ctx.audit('results', 'issue-codes', 'activationCodes', `إصدار ${issued.length} رمز تفعيل`, x));
    await commitInChunks(F, db, ops);
    issued.forEach(c => openCodes.set(c.seatNo, [{ code: c.code, seatNo: c.seatNo }]));
    draw();
    showCodes(issued);
  }

  $('#cBody').addEventListener('click', async e => {
    const iss = e.target.closest('[data-issue]');
    const rev = e.target.closest('[data-revoke]');
    if (iss) {
      const s = seats.get(iss.dataset.issue);
      const again = openCodes.has(s.seatNo);
      if (again && !(await ctx.confirm({ title: 'إعادة إصدار الرمز', message: `سيُلغى الرمز السابق لرقم الجلوس ${s.seatNo} ويصدر رمز جديد.`, confirmLabel: 'إصدار رمز جديد' }))) return;
      try { await issue([s]); ctx.toast('صدر الرمز. سلّمه للطالب شخصيًا.'); } catch (err) { ctx.toast('تعذّر الإصدار: ' + ctx.explain(err), 'error'); }
    }
    if (rev) {
      const seat = rev.dataset.revoke;
      const link = linkBySeat.get(seat);
      const ok = await ctx.confirm({ title: 'إلغاء ربط الحساب', message: `سيُفصل الحساب ${link.email || ''} عن رقم الجلوس ${seat} فلا يرى نتائجه. يحتاج الطالب رمزًا جديدًا لإعادة الربط. استخدم هذا عند ربط خاطئ أو فقدان الحساب.`, confirmLabel: 'إلغاء الربط', danger: true, requireText: seat });
      if (!ok) return;
      try {
        const b = F.writeBatch(db);
        b.delete(F.doc(db, 'studentLinks', link.uid));
        b.delete(F.doc(db, 'seatClaims', seat));
        ctx.audit('results', 'revoke-link', `studentLinks/${link.uid}`, `إلغاء ربط رقم الجلوس ${seat}`, b);
        await b.commit();
        linkBySeat.delete(seat);
        draw();
        ctx.toast('أُلغي الربط. أصدر رمزًا جديدًا إن لزم.');
      } catch (err) { ctx.toast('تعذّر إلغاء الربط: ' + ctx.explain(err), 'error'); }
    }
  });
  $('#bulkIssue').addEventListener('click', async () => {
    const targets = filtered().filter(s => statusOf(s) === 'none');
    if (!targets.length) { ctx.toast('لا توجد أرقام جلوس بدون رمز أو حساب في التصفية الحالية.'); return; }
    const ok = await ctx.confirm({ title: 'إصدار رموز التفعيل', message: `سيصدر ${targets.length} رمز تفعيل لأرقام الجلوس الظاهرة التي ليس لها رمز ولا حساب مرتبط. اطبع القائمة وسلّم كل رمز لصاحبه.`, confirmLabel: 'إصدار' });
    if (!ok) return;
    try { await issue(targets); } catch (err) { ctx.toast('تعذّر الإصدار: ' + ctx.explain(err), 'error'); }
  });
}

/* ===================================================================
   الاستيراد والترحيل
   =================================================================== */
function backupPayload(kind, batches) {
  return JSON.stringify({ format: 'dongola-results-backup', version: 2, kind, createdAt: new Date().toISOString(), batches: toJsonValue(batches) }, null, 1);
}

async function renderImport(ctx) {
  const { db, F } = ctx.fb;
  const batchSnap = await F.getDocs(F.collection(db, 'batches'));
  const legacy = batchSnap.docs.filter(d => Array.isArray(d.data().students)).map(d => ({ id: d.id, ...d.data() }));
  const existingIds = new Set(batchSnap.docs.map(d => d.id));

  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>الاستيراد والترحيل</h1><p>نقل النتائج السابقة إلى الصيغة الآمنة، أو استيراد ملف نتائج. كل ما يُستورد يُحفظ «غير منشور» حتى تراجعه وتنشره.</p></div></section>

    <section class="card" aria-labelledby="migTitle">
      <h2 id="migTitle">ترحيل النتائج المخزنة بالصيغة القديمة</h2>
      ${legacy.length ? `
        <p>في قاعدة البيانات <strong>${legacy.length}</strong> دفعة بالصيغة القديمة (كل الطلاب داخل وثيقة الدفعة، وكانت القواعد القديمة تسمح للجميع بقراءتها). الترحيل ينقل كل طالب إلى نتيجة مستقلة محمية، ويحذف بيانات الطلاب من وثيقة الدفعة.</p>
        <ul class="plain-list">${legacy.map(b => `<li>${esc(fullTitle({ ...b, round: b.round || 1 }))} — ${b.students.length} طالب</li>`).join('')}</ul>
        <ol class="steps-admin">
          <li><button class="btn" type="button" id="migBackup">١. تنزيل نسخة احتياطية من البيانات القديمة</button><p class="hint">احفظ الملف في مكان آمن خارج مجلد الموقع؛ فيه بيانات الطلاب.</p></li>
          <li><label class="check-inline"><input type="checkbox" id="migKeep" checked> إبقاء النتائج المرحَّلة منشورة لأصحابها (كما كانت ظاهرة سابقًا)</label></li>
          <li><button class="btn primary" type="button" id="migRun" disabled>٢. ترحيل ${legacy.length} دفعة الآن</button></li>
        </ol>
        <div id="migReport" role="status" aria-live="polite"></div>` : '<p class="ok-note">لا توجد بيانات بالصيغة القديمة. كل النتائج محفوظة بالصيغة الآمنة.</p>'}
    </section>

    <section class="card" aria-labelledby="impTitle">
      <h2 id="impTitle">استيراد ملف نتائج</h2>
      <p>يقبل ملف <code>results-data.js</code> بصيغة الموقع السابق، أو نسخة احتياطية JSON من هذه اللوحة. يُقرأ الملف داخل متصفحك دون تنفيذه، ولا يُرفع إلا إلى قاعدة البيانات المحمية.</p>
      <label class="btn" for="impFile">اختيار ملف…</label>
      <input type="file" id="impFile" accept=".js,.json,application/json,text/javascript" class="file-input">
      <div id="impPreview"></div>
    </section>`;

  if (legacy.length) {
    let backedUp = false;
    $('#migBackup').addEventListener('click', () => {
      download(`legacy-results-backup-${stamp()}.json`, backupPayload('legacy', legacy));
      backedUp = true;
      $('#migRun').disabled = false;
      ctx.toast('نُزّلت النسخة الاحتياطية. احفظها في مكان آمن.');
    });
    $('#migRun').addEventListener('click', async () => {
      if (!backedUp) return;
      const keep = $('#migKeep').checked;
      const total = legacy.reduce((n, b) => n + b.students.length, 0);
      const ok = await ctx.confirm({ title: 'ترحيل النتائج', message: `سيُنقل ${total} سجل طالب من ${legacy.length} دفعة إلى الصيغة الآمنة${keep ? '، وتبقى منشورة لأصحابها' : '، وتُحفظ غير منشورة'}.`, confirmLabel: 'ترحيل' });
      if (!ok) return;
      $('#migRun').disabled = true;
      const report = [];
      try {
        for (const raw of legacy) {
          const b = normalizeBatch({ ...raw, published: keep });
          const bad = b.students.filter(s => !SEAT_RE.test(s.seatNo));
          if (bad.length) { report.push(`${fullTitle(b)}: لم تُرحَّل — ${bad.length} رقم جلوس غير صالح. صحّحه بعد الاستيراد من ملف.`); continue; }
          await writeBatchWithResults(ctx, b, 'migrate-batch');
          const check = await F.getDocs(F.query(F.collection(db, 'results'), F.where('batchId', '==', b.id)));
          report.push(`${fullTitle(b)}: نُقل ${b.students.length} طالب، والموجود الآن ${check.size}. ${check.size === b.students.length ? '✓' : '⚠ راجع العدد'}`);
        }
        $('#migReport').innerHTML = '<h3>نتيجة الترحيل</h3><ul class="plain-list">' + report.map(r => `<li>${esc(r)}</li>`).join('') + '</ul>';
        ctx.toast('اكتمل الترحيل.');
      } catch (err) {
        $('#migReport').innerHTML = `<p class="alert error">توقف الترحيل: ${esc(ctx.explain(err))}. لم تُفقد البيانات؛ أعد المحاولة.</p>`;
        $('#migRun').disabled = false;
      }
    });
  }

  $('#impFile').addEventListener('change', async e => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    let parsed;
    try {
      const text = await readFileText(file, 20 * 1024 * 1024);
      if (/^\s*\{/.test(text)) {
        const json = JSON.parse(text);
        if (json.format !== 'dongola-results-backup' || !Array.isArray(json.batches)) throw new Error('ليست نسخة نتائج من هذه اللوحة.');
        parsed = json.batches;
      } else parsed = parseLegacyResults(text);
      parsed = parsed.map(b => normalizeBatch({ ...b, id: BATCH_ID_RE.test(String(b.id || '')) ? b.id : 'b-' + randomString(10), published: false }));
    } catch (err) {
      $('#impPreview').innerHTML = `<p class="alert error">تعذّرت قراءة الملف: ${esc(err.code === 'too-large' ? 'الملف أكبر من ٢٠ ميغابايت.' : err.message)}</p>`;
      return;
    }
    const issues = [];
    parsed.forEach(b => {
      if (!b.year) issues.push(`${batchTitle(b)}: العام الدراسي فارغ — يُضاف لاحقًا من المحرر.`);
      const seen = new Set();
      b.students.forEach(s => {
        if (!SEAT_RE.test(s.seatNo)) issues.push(`${batchTitle(b)}: رقم جلوس غير صالح «${s.seatNo}».`);
        else if (seen.has(s.seatNo)) issues.push(`${batchTitle(b)}: رقم جلوس مكرر ${s.seatNo}.`);
        seen.add(s.seatNo);
      });
    });
    const clash = parsed.filter(b => existingIds.has(b.id));
    $('#impPreview').innerHTML = `
      <h3>محتوى الملف: ${parsed.length} دفعة، ${parsed.reduce((n, b) => n + b.students.length, 0)} سجل طالب</h3>
      <div class="scroll"><table class="list-table"><thead><tr><th scope="col">الدفعة</th><th scope="col">الطلاب</th><th scope="col">ملاحظة</th></tr></thead><tbody>
      ${parsed.map(b => `<tr><td>${esc(fullTitle(b))}</td><td>${b.students.length}</td><td>${existingIds.has(b.id) ? 'موجودة بنفس المعرّف — ستُستبدل' : 'جديدة'}</td></tr>`).join('')}</tbody></table></div>
      ${issues.length ? `<ul class="warn-list">${issues.slice(0, 15).map(x => `<li>${esc(x)}</li>`).join('')}${issues.length > 15 ? `<li>و ${issues.length - 15} أخرى…</li>` : ''}</ul>` : ''}
      ${issues.some(x => x.includes('رقم جلوس')) ? '<p class="alert error">صحّح أرقام الجلوس غير الصالحة أو المكررة في الملف ثم أعد اختياره.</p>' :
        `<div class="row-actions"><button class="btn primary" type="button" id="impSave">حفظ كنتائج غير منشورة${clash.length ? ` (واستبدال ${clash.length})` : ''}</button></div>`}`;
    const save = $('#impSave');
    if (!save) return;
    save.addEventListener('click', async () => {
      if (clash.length && !(await ctx.confirm({ title: 'استبدال نتائج موجودة', message: `${clash.length} من الدفعات موجودة وستُستبدل بنسخة الملف (وتُخفى عن الطلاب حتى تُنشر).`, confirmLabel: 'استبدال', danger: true }))) return;
      save.disabled = true;
      try {
        for (const b of parsed) await writeBatchWithResults(ctx, b, 'import-batch');
        $('#impPreview').innerHTML = `<p class="ok-note">استوردت ${parsed.length} دفعة غير منشورة. راجعها وانشرها من <a href="#/results">الدفعات والنتائج</a>.</p>`;
        ctx.toast('اكتمل الاستيراد.');
      } catch (err) { save.disabled = false; ctx.toast('تعذّر الاستيراد: ' + ctx.explain(err), 'error'); }
    });
  });
}

/** يكتب دفعة كاملة بالصيغة الآمنة: وثيقة الدفعة دون طلاب + نتيجة لكل طالب */
async function writeBatchWithResults(ctx, b, action) {
  const { db, F } = ctx.fb;
  const meta = { year: b.year, round: b.round, session: b.session, semester: b.semester, specialization: b.specialization, subjects: b.subjects };
  const prev = await F.getDocs(F.query(F.collection(db, 'results'), F.where('batchId', '==', b.id)));
  const seats = new Set(b.students.map(s => s.seatNo));
  const ops = [];
  prev.docs.filter(d => !seats.has(d.data().seatNo)).forEach(d => ops.push(x => x.delete(d.ref)));
  b.students.forEach((st, i) => ops.push(x => x.set(F.doc(db, 'results', `${b.id}__${st.seatNo}`), { batchId: b.id, num: i + 1, ...st, published: b.published, ...meta })));
  // set يستبدل الوثيقة كاملة، فتُحذف منها قائمة الطلاب القديمة
  ops.push(x => x.set(F.doc(db, 'batches', b.id), { ...meta, published: b.published, studentCount: b.students.length, updatedAt: F.serverTimestamp(), updatedBy: ctx.user.uid, updatedByEmail: ctx.user.email }));
  ops.push(x => ctx.audit('results', action, `batches/${b.id}`, `${fullTitle(b)}: ${b.students.length} طالب`, x));
  await commitInChunks(F, db, ops);
}

/* ===================================================================
   سجل النتائج
   =================================================================== */
async function renderLog(ctx) {
  const { db, F } = ctx.fb;
  const q = F.query(F.collection(db, 'audit'), F.where('area', '==', 'results'), F.orderBy('at', 'desc'), F.limit(150));
  const snap = await F.getDocs(q);
  const { ACTIONS } = await import('./audit.js');
  ctx.main.innerHTML = `<section class="page-intro"><div><h1>سجل النتائج</h1><p>آخر ١٥٠ عملية على النتائج ورموز التفعيل. لا يمكن تعديل السجل أو حذفه.</p></div></section>
    <section class="card"><div class="scroll table-card"><table class="list-table"><thead><tr><th scope="col">الوقت</th><th scope="col">المستخدم</th><th scope="col">الإجراء</th><th scope="col">التفاصيل</th></tr></thead><tbody>
    ${snap.docs.map(d => { const a = d.data(); return `<tr><td>${esc(fmtTime(a.at))}</td><td dir="ltr">${esc(a.email)}</td><td>${esc(ACTIONS[a.action] || a.action)}</td><td>${esc(a.summary)}</td></tr>`; }).join('') || '<tr><td colspan="4" class="empty-row">لا توجد عمليات مسجلة بعد.</td></tr>'}
    </tbody></table></div></section>`;
}
