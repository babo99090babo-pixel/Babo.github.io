/* الصفحة الرئيسية للوحة: ملخص بحسب الدور وما يحتاج متابعة */
import { esc, fmtTime } from './util.js';
import { ROLE_LABELS, ROLE_DESCRIPTIONS } from './app.js';

export async function render(ctx) {
  const { db, F } = ctx.fb;
  const role = ctx.role;
  const S = ctx.S;
  const types = Object.entries(S.TYPES).filter(([, t]) => t.roles.includes(role));
  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>مرحبًا</h1><p>دورك: <strong>${esc(ROLE_LABELS[role])}</strong> — ${esc(ROLE_DESCRIPTIONS[role])}</p></div></section>
    <div class="dash-grid" id="dash"></div>`;
  const dash = document.getElementById('dash');
  const cards = [];

  if (role !== 'results') {
    const counts = await Promise.all(types.map(async ([id, t]) => {
      const [d, p] = await Promise.all([F.getDocs(F.collection(db, 'drafts', id, 'items')), F.getDocs(F.collection(db, 'public', id, 'items'))]);
      const pending = d.docs.filter(x => ['draft', 'changed'].includes(x.data()._status)).length;
      return { id, t, published: p.size, pending };
    }));
    cards.push(`<section class="card dash-card"><h2>المحتوى</h2><table class="list-table compact"><thead><tr><th scope="col">القسم</th><th scope="col">منشور</th><th scope="col">بانتظار النشر</th></tr></thead><tbody>` +
      counts.map(c => `<tr><th scope="row"><a href="#/content/${c.id}">${esc(c.t.label)}</a></th><td>${c.published}</td><td>${c.pending ? `<span class="status-badge st-draft">${c.pending}</span>` : '0'}</td></tr>`).join('') + '</tbody></table></section>');
    if (ctx.canEditType('settings')) {
      const s = await F.getDoc(F.doc(db, 'public', 'settings', 'items', 'site'));
      const todo = [];
      if (!s.exists()) todo.push('<li>لم يُستورد المحتوى الحالي للموقع بعد. افتح <a href="#/backup">النسخ الاحتياطي ← استيراد المحتوى الحالي</a>.</li>');
      else {
        const d = s.data();
        const unverified = (d.facts || []).filter(x => !x.verified).length;
        if (unverified) todo.push(`<li>${unverified} من أرقام «الكلية في أرقام» غير موثَّقة ولا تظهر في الموقع. <a href="#/content/settings/edit/site">راجعها</a>.</li>`);
        if (d.deanMessage && !d.deanVerified) todo.push('<li>كلمة العميد غير معتمدة ولا تظهر. <a href="#/content/settings/edit/site">راجعها</a>.</li>');
        const domain = (ctx.cfg.institutionalEmailDomain || '').toLowerCase();
        if (d.email && (!domain || !String(d.email).toLowerCase().endsWith('@' + domain))) todo.push('<li>بريد التواصل المنشور ليس بريدًا مؤسسيًا للجامعة.</li>');
      }
      const pagesPub = await F.getDocs(F.collection(db, 'public', 'pages', 'items'));
      const missing = S.TYPES.pages.fixed.filter(p => !pagesPub.docs.some(d => d.id === p.id)).map(p => p.title);
      if (missing.length) todo.push(`<li>صفحات لم يُنشر نصها المعتمد: ${missing.map(esc).join('، ')}.</li>`);
      cards.push(`<section class="card dash-card"><h2>يحتاج متابعة</h2>${todo.length ? `<ul class="plain-list">${todo.join('')}</ul>` : '<p class="ok-note">لا توجد ملاحظات.</p>'}</section>`);
    }
  }
  if (role === 'admin' || role === 'results') {
    const [b, links, codes] = await Promise.all([F.getDocs(F.collection(db, 'batches')), F.getDocs(F.collection(db, 'studentLinks')), F.getDocs(F.collection(db, 'activationCodes'))]);
    const legacy = b.docs.filter(d => Array.isArray(d.data().students)).length;
    const unpublished = b.docs.filter(d => !d.data().published).length;
    const openCodes = codes.docs.filter(d => !d.data().usedBy).length;
    cards.push(`<section class="card dash-card"><h2>النتائج</h2><dl class="stat-list">
      <div><dt>الدفعات</dt><dd>${b.size}</dd></div><div><dt>غير منشورة</dt><dd>${unpublished}</dd></div>
      <div><dt>حسابات طلاب مرتبطة</dt><dd>${links.size}</dd></div><div><dt>رموز لم تُستخدم</dt><dd>${openCodes}</dd></div></dl>
      ${legacy ? `<p class="alert warn">${legacy} دفعة بالصيغة القديمة تحتاج <a href="#/results/import">ترحيلًا</a>.</p>` : ''}
      <div class="row-actions"><a class="btn small" href="#/results">الدفعات</a><a class="btn small" href="#/results/codes">رموز التفعيل</a></div></section>`);
  }
  if (role === 'admin') {
    const a = await F.getDocs(F.query(F.collection(db, 'audit'), F.orderBy('at', 'desc'), F.limit(8)));
    const { ACTIONS } = await import('./audit.js');
    cards.push(`<section class="card dash-card dash-wide"><h2>آخر التغييرات</h2>${a.size ? `<ul class="plain-list">${a.docs.map(d => { const x = d.data(); return `<li><span class="muted">${esc(fmtTime(x.at))}</span> — <span dir="ltr">${esc(x.email)}</span>: ${esc(ACTIONS[x.action] || x.action)} — ${esc(x.summary)}</li>`; }).join('')}</ul><a href="#/audit">السجل كاملًا</a>` : '<p>لا توجد تغييرات مسجلة بعد.</p>'}</section>`);
  }
  dash.innerHTML = cards.join('') || '<section class="card"><p>اختر قسمًا من القائمة.</p></section>';
}
