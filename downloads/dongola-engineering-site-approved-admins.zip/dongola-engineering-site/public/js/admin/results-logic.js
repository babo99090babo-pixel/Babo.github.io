/* منطق النتائج دون واجهة: التقديرات والمعدلات وتنسيق البيانات (قابل للاختبار) */
import { toLatinDigits } from './util.js';
/* ===== الإعدادات (من النظام السابق — تحتاج تأكيدًا رسميًا من الكلية) ===== */
// نقاط التقديرات مستنتجة من النتائج السابقة: A=4، B=3، C=2.5، D=2، F=0
export const POINTS = { A: 4, B: 3, C: 2.5, D: 2, F: 0 };
export const VALID_GRADES = ['A', 'B', 'C', 'D', 'F', 'ك'];
export function classify(gpa) {
  if (gpa == null) return null;
  if (gpa >= 3.5) return 'ممتاز';
  if (gpa >= 3.0) return 'جيد جداً';
  if (gpa >= 2.5) return 'جيد';
  return 'مقبول';
}
export const SEMESTERS = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر'].map(s => 'الفصل الدراسي ' + s);
export const SPECS = ['هندسة مدنية', 'هندسة كهربائية', 'هندسة التحكم', 'هندسة الحاسوب', 'هندسة الاتصالات'];
export const STATUSES = ['نجاح', 'ملحق', 'إعادة تقييم', 'إعادة'];
export const CLASSES = ['ممتاز', 'جيد جداً', 'جيد', 'مقبول'];
export const ROUNDS = { 1: 'الدور الأول', 2: 'الدور الثاني' };
export const SEAT_RE = /^[0-9A-Za-z-]{1,20}$/;
export const BATCH_ID_RE = /^[a-z0-9][a-z0-9-]{0,79}$/;

export const round2 = x => Math.round(x * 100) / 100;
export const normSeat = s => toLatinDigits(s).replace(/[\s‎‏]/g, '').replace(/[‐-―]/g, '-').toUpperCase();
export function normGrade(g) {
  g = toLatinDigits(g || '').trim().toUpperCase();
  if (g === 'ك' || g === 'K') return 'ك';
  return g;
}
export function parseGpa(v) {
  v = toLatinDigits(v).replace('،', '.').replace(',', '.').trim();
  if (v === '') return null;
  const n = parseFloat(v);
  return isFinite(n) ? round2(n) : null;
}
export const batchTitle = b => `${b.semester} · ${b.specialization}`;
export const fullTitle = b => `${batchTitle(b)} — ${ROUNDS[b.round] || ''} — ${b.year}`;

/* الحساب التلقائي (كما في المحرر السابق) */
export function autoRow(st, batch) {
  const g = st.grades;
  const fails = g.filter(x => x === 'F').length;
  const complete = batch.subjects.every((s, i) => g[i] in POINTS);
  if (fails > 0) {
    st.semesterGPA = null; st.cumulativeGPA = null; st.classification = null;
    if (st.status !== 'إعادة') st.status = 'ملحق';
    st.notes = st.status === 'إعادة' ? 'إعادة الفصل كاملاً' : 'ملحق/' + fails;
  } else if (complete) {
    let pts = 0, hrs = 0;
    batch.subjects.forEach((s, i) => { pts += POINTS[g[i]] * s.hours; hrs += s.hours; });
    st.semesterGPA = hrs ? round2(pts / hrs) : null;
    if (st.cumulativeGPA == null && batch.semester === SEMESTERS[0]) st.cumulativeGPA = st.semesterGPA;
    st.status = 'نجاح';
    autoClass(st);
  }
}
export function autoClass(st) {
  if (st.status !== 'نجاح') return;
  st.classification = classify(st.cumulativeGPA != null ? st.cumulativeGPA : st.semesterGPA);
  st.notes = st.classification ? 'نجاح / ' + st.classification : 'نجاح';
}
export const blankStudent = b => ({ seatNo: '', name: '', grades: b.subjects.map(() => null), semesterGPA: null, cumulativeGPA: null, status: '', classification: null, notes: '' });
export function normalizeStudent(st, subjects) {
  return {
    seatNo: normSeat(st.seatNo || ''), name: String(st.name || '').trim(),
    grades: subjects.map((_, i) => (st.grades || [])[i] || null),
    semesterGPA: st.semesterGPA ?? null, cumulativeGPA: st.cumulativeGPA ?? null,
    status: st.status || '', classification: st.classification || null, notes: st.notes || ''
  };
}
export function normalizeBatch(b) {
  const subjects = (b.subjects || []).map(x => ({ name: String(x.name || ''), hours: Number(x.hours) || 0 }));
  return {
    id: b.id, year: String(b.year || ''),
    round: typeof b.round === 'number' ? b.round : (String(b.round || '').includes('الثاني') ? 2 : 1),
    session: b.session || '', semester: b.semester || SEMESTERS[0], specialization: b.specialization || SPECS[0],
    subjects, published: !!b.published,
    students: (b.students || []).map(st => normalizeStudent(st, subjects))
  };
}
