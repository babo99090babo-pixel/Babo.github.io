/* ============================================================
   النسخ الاحتياطي والاستعادة واستيراد المحتوى الأولي.
   ملفات النسخ تُنزَّل إلى جهازك؛ احفظها خارج مجلد الموقع،
   ولا ترفع نسخة النتائج إلى أي مكان عام (فيها بيانات الطلاب).
   ============================================================ */
import { $, esc, download, stamp, commitInChunks, toJsonValue, fromJsonValue, readFileText } from './util.js';

const CONTENT_FORMAT = 'dongola-cms-backup';
const RESULTS_FORMAT = 'dongola-results-backup';

export async function render(ctx) {
  const role = ctx.role;
  const canContent = role === 'admin';
  const canInitial = role === 'admin' || role === 'editor';
  const canResults = role === 'admin' || role === 'results';
  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>النسخ الاحتياطي والاستعادة</h1><p>خذ نسخة قبل أي تغيير كبير، واحفظها في مكان آمن خارج مجلد الموقع. الاستعادة تكتب العناصر الموجودة في الملف ولا تحذف غيرها.</p></div></section>
    ${canInitial ? `<section class="card" aria-labelledby="initTitle"><h2 id="initTitle">استيراد المحتوى الحالي للموقع</h2>
      <p>ينقل النصوص الموجودة حاليًا في الموقع (الأخبار الثلاثة، ونبذات الأقسام، وبيانات التواصل، والأرقام، وكلمة العميد) إلى لوحة الإدارة لتُدار من هنا. لا يكتب فوق أي عنصر موجود.</p>
      <p class="hint">الأرقام وكلمة العميد تُستورد «غير موثَّقة»، فلا تظهر في الموقع حتى يعلّمها المسؤول موثَّقة من «إعدادات الموقع».</p>
      <div class="row-actions"><button class="btn primary" type="button" id="initRun">معاينة المحتوى الأولي</button></div><div id="initOut" role="status" aria-live="polite"></div></section>` : ''}
    ${canContent ? `<section class="card" aria-labelledby="cTitle"><h2 id="cTitle">المحتوى والصلاحيات</h2>
      <div class="row-actions"><button class="btn" type="button" id="cBackup">تنزيل نسخة احتياطية للمحتوى</button>
      <label class="btn" for="cRestoreFile">استعادة من نسخة…</label><input type="file" id="cRestoreFile" accept=".json,application/json" class="file-input"></div>
      <div id="cOut" role="status" aria-live="polite"></div></section>` : ''}
    ${canResults ? `<section class="card" aria-labelledby="rTitle"><h2 id="rTitle">النتائج ورموز التفعيل وربط الحسابات</h2>
      <div class="alert warn">نسخة النتائج تحتوي أسماء الطلاب ودرجاتهم ورموز التفعيل غير المستخدمة. احفظها مشفّرة في جهاز أو وسيط آمن، ولا ترسلها بالبريد أو تضعها في مجلد الموقع.</div>
      <div class="row-actions"><button class="btn" type="button" id="rBackup">تنزيل نسخة احتياطية للنتائج</button>
      <label class="btn" for="rRestoreFile">استعادة من نسخة…</label><input type="file" id="rRestoreFile" accept=".json,application/json" class="file-input"></div>
      <div id="rOut" role="status" aria-live="polite"></div></section>` : ''}
    <section class="card"><h2>النسخ الدوري التلقائي</h2><p>للنسخ الكامل الدوري (مع سجل التغييرات) يوجد سكربت في مجلد <code>tools</code> يعمل من جهاز المسؤول بمفتاح خدمة محفوظ خارج المشروع. التفاصيل في دليل التشغيل.</p></section>`;

  if (canInitial) $('#initRun').addEventListener('click', () => initialImport(ctx));
  if (canContent) {
    $('#cBackup').addEventListener('click', () => backupContent(ctx));
    $('#cRestoreFile').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f) restoreContent(ctx, f); });
  }
  if (canResults) {
    $('#rBackup').addEventListener('click', () => backupResults(ctx));
    $('#rRestoreFile').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f) restoreResults(ctx, f); });
  }
}

/* ---------- المحتوى ---------- */
async function backupContent(ctx) {
  const { db, F } = ctx.fb;
  const out = $('#cOut');
  out.textContent = 'جارٍ التجهيز…';
  try {
    const content = { public: {}, drafts: {} };
    for (const type of Object.keys(ctx.S.TYPES)) {
      for (const area of ['public', 'drafts']) {
        const snap = await F.getDocs(F.collection(db, area, type, 'items'));
        if (snap.size) content[area][type] = Object.fromEntries(snap.docs.map(d => [d.id, toJsonValue(d.data())]));
      }
    }
    const staffSnap = await F.getDocs(F.collection(db, 'staff'));
    const staff = Object.fromEntries(staffSnap.docs.map(d => [d.id, toJsonValue(d.data())]));
    const count = Object.values(content.public).concat(Object.values(content.drafts)).reduce((n, o) => n + Object.keys(o).length, 0);
    download(`content-backup-${stamp()}.json`, JSON.stringify({ format: CONTENT_FORMAT, version: 1, createdAt: new Date().toISOString(), createdBy: ctx.user.email, content, staff }, null, 1));
    await ctx.audit('backup', 'backup-content', 'content', `نسخة احتياطية: ${count} وثيقة محتوى و${staffSnap.size} صلاحية`);
    out.textContent = `نُزّلت النسخة (${count} وثيقة محتوى، ${staffSnap.size} صلاحية).`;
  } catch (err) { out.textContent = 'تعذّر إنشاء النسخة: ' + ctx.explain(err); }
}

async function restoreContent(ctx, file) {
  const { db, F } = ctx.fb;
  const out = $('#cOut');
  let data;
  try {
    data = JSON.parse(await readFileText(file, 50 * 1024 * 1024));
    if (data.format !== CONTENT_FORMAT || !data.content) throw new Error('ليست نسخة محتوى من هذه اللوحة.');
  } catch (err) { out.innerHTML = `<p class="alert error">تعذّرت قراءة الملف: ${esc(err.message)}</p>`; return; }
  const ops = [];
  let docs = 0;
  const ID_RE = /^[a-z0-9][a-z0-9-]{0,79}$/;
  for (const area of ['public', 'drafts']) {
    for (const [type, items] of Object.entries(data.content[area] || {})) {
      if (!ctx.S.TYPES[type]) continue;
      for (const [id, raw] of Object.entries(items)) {
        if (!ID_RE.test(id)) continue;
        const v = fromJsonValue(raw, F);
        if (!v.title) continue;
        const restoredFrom = raw._updatedAt && raw._updatedAt.__ts ? raw._updatedAt.__ts : null;
        const docData = { ...v, _updatedBy: ctx.user.uid, _updatedAt: F.serverTimestamp(), _restoredFrom: restoredFrom };
        if (area === 'drafts' && !['draft', 'published', 'changed'].includes(docData._status)) docData._status = 'draft';
        ops.push(b => b.set(F.doc(db, area, type, 'items', id), docData));
        docs++;
      }
    }
  }
  const staff = Object.entries(data.staff || {}).filter(([email, s]) => email === email.toLowerCase() && ['editor', 'news', 'results'].includes(s.role));
  staff.forEach(([email, s]) => ops.push(b => b.set(F.doc(db, 'staff', email), { role: s.role, active: !!s.active, name: s.name || '', assignedBy: ctx.user.uid, assignedAt: F.serverTimestamp() })));
  const ok = await ctx.confirm({ title: 'استعادة المحتوى', message: `سيُكتب ${docs} وثيقة محتوى و${staff.length} صلاحية من نسخة ${data.createdAt || ''}. العناصر الحالية بنفس المعرّف ستُستبدل، والعناصر غير الموجودة في النسخة تبقى كما هي.`, confirmLabel: 'استعادة', danger: true, requireText: 'استعادة' });
  if (!ok) return;
  out.textContent = 'جارٍ الاستعادة…';
  try {
    await commitInChunks(F, db, ops);
    await ctx.audit('backup', 'restore-content', 'content', `استعادة ${docs} وثيقة محتوى و${staff.length} صلاحية من نسخة ${data.createdAt || ''}`);
    out.textContent = `اكتملت الاستعادة: ${docs} وثيقة محتوى و${staff.length} صلاحية.`;
    ctx.toast('اكتملت الاستعادة.');
  } catch (err) { out.textContent = 'توقفت الاستعادة: ' + ctx.explain(err); }
}

/* ---------- النتائج ---------- */
async function backupResults(ctx) {
  const { db, F } = ctx.fb;
  const out = $('#rOut');
  out.textContent = 'جارٍ التجهيز…';
  try {
    const grab = async name => Object.fromEntries((await F.getDocs(F.collection(db, name))).docs.map(d => [d.id, toJsonValue(d.data())]));
    const [batches, results, activationCodes, studentLinks, seatClaims] = await Promise.all(['batches', 'results', 'activationCodes', 'studentLinks', 'seatClaims'].map(grab));
    const payload = { format: RESULTS_FORMAT, version: 2, kind: 'full', createdAt: new Date().toISOString(), createdBy: ctx.user.email,
      batches: Object.entries(batches).map(([id, b]) => ({ id, ...b })), results, activationCodes, studentLinks, seatClaims };
    download(`results-backup-${stamp()}.json`, JSON.stringify(payload, null, 1));
    await ctx.audit('backup', 'backup-results', 'results', `نسخة احتياطية: ${Object.keys(batches).length} دفعة و${Object.keys(results).length} نتيجة`);
    out.textContent = `نُزّلت النسخة (${Object.keys(batches).length} دفعة، ${Object.keys(results).length} نتيجة، ${Object.keys(activationCodes).length} رمز، ${Object.keys(studentLinks).length} ربط).`;
  } catch (err) { out.textContent = 'تعذّر إنشاء النسخة: ' + ctx.explain(err); }
}

async function restoreResults(ctx, file) {
  const { db, F } = ctx.fb;
  const out = $('#rOut');
  let data;
  try {
    data = JSON.parse(await readFileText(file, 100 * 1024 * 1024));
    if (data.format !== RESULTS_FORMAT || !Array.isArray(data.batches)) throw new Error('ليست نسخة نتائج من هذه اللوحة.');
  } catch (err) { out.innerHTML = `<p class="alert error">تعذّرت قراءة الملف: ${esc(err.message)}</p>`; return; }
  const SEAT_RE = /^[0-9A-Za-z-]{1,20}$/;
  const CODE_RE = /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/;
  const ops = [];
  const results = Object.assign({}, data.results || {});
  // نسخة الترحيل القديمة: الطلاب داخل الدفعة ← تُحوَّل إلى نتائج مستقلة
  data.batches.forEach(b => {
    if (!Array.isArray(b.students)) return;
    b.students.forEach((st, i) => {
      const seatNo = String(st.seatNo || '').replace(/\s+/g, '').toUpperCase();
      if (!SEAT_RE.test(seatNo)) return;
      results[`${b.id}__${seatNo}`] = { batchId: b.id, num: i + 1, seatNo, name: st.name || '', grades: st.grades || [], semesterGPA: st.semesterGPA ?? null, cumulativeGPA: st.cumulativeGPA ?? null, status: st.status || '', classification: st.classification || null, notes: st.notes || '', published: true, year: b.year, round: b.round, session: b.session, semester: b.semester, specialization: b.specialization, subjects: b.subjects };
    });
  });
  data.batches.forEach(b => {
    const { id, students, ...meta } = fromJsonValue(b, F);
    if (!/^[a-z0-9][a-z0-9-]{0,79}$/.test(id)) return;
    ops.push(x => x.set(F.doc(db, 'batches', id), { ...meta, round: meta.round || 1, year: String(meta.year || ''), subjects: meta.subjects || [], published: Array.isArray(students) ? true : !!meta.published }));
  });
  let rc = 0;
  Object.entries(results).forEach(([id, r]) => {
    const v = fromJsonValue(r, F);
    if (!SEAT_RE.test(v.seatNo || '') || id !== `${v.batchId}__${v.seatNo}`) return;
    ops.push(x => x.set(F.doc(db, 'results', id), { ...v, published: !!v.published, name: String(v.name || ''), grades: v.grades || [] }));
    rc++;
  });
  let cc = 0;
  Object.entries(data.activationCodes || {}).forEach(([code, c]) => {
    if (!CODE_RE.test(code)) return;
    ops.push(x => x.set(F.doc(db, 'activationCodes', code), fromJsonValue(c, F)));
    cc++;
  });
  // الربط لا يُستبدل إن وُجد (القواعد تمنع تعديله)، فنكتب غير الموجود فقط
  const links = Object.entries(data.studentLinks || {});
  const claims = Object.entries(data.seatClaims || {});
  const existingLinks = new Set((await F.getDocs(F.collection(db, 'studentLinks'))).docs.map(d => d.id));
  const existingClaims = new Set((await F.getDocs(F.collection(db, 'seatClaims'))).docs.map(d => d.id));
  const newLinks = links.filter(([uid]) => !existingLinks.has(uid));
  const newClaims = claims.filter(([seat]) => !existingClaims.has(seat));
  newLinks.forEach(([uid, l]) => ops.push(x => x.set(F.doc(db, 'studentLinks', uid), fromJsonValue(l, F))));
  newClaims.forEach(([seat, c]) => ops.push(x => x.set(F.doc(db, 'seatClaims', seat), fromJsonValue(c, F))));
  const ok = await ctx.confirm({ title: 'استعادة النتائج', message: `سيُكتب ${data.batches.length} دفعة و${rc} نتيجة و${cc} رمز و${newLinks.length} ربط حساب من نسخة ${data.createdAt || ''}، بحالة النشر المحفوظة فيها.`, confirmLabel: 'استعادة', danger: true, requireText: 'استعادة' });
  if (!ok) return;
  out.textContent = 'جارٍ الاستعادة…';
  try {
    await commitInChunks(F, db, ops);
    await ctx.audit('backup', 'restore-results', 'results', `استعادة ${data.batches.length} دفعة و${rc} نتيجة من نسخة ${data.createdAt || ''}`);
    out.textContent = `اكتملت الاستعادة: ${data.batches.length} دفعة، ${rc} نتيجة، ${cc} رمز، ${newLinks.length} ربط.`;
    ctx.toast('اكتملت الاستعادة.');
  } catch (err) { out.textContent = 'توقفت الاستعادة: ' + ctx.explain(err); }
}

/* ---------- المحتوى الأولي ---------- */
async function initialImport(ctx) {
  const { db, F } = ctx.fb;
  const out = $('#initOut');
  let seed;
  try {
    const res = await fetch('data/initial-content.json', { cache: 'no-store' });
    seed = await res.json();
  } catch (err) { out.textContent = 'تعذّر تحميل ملف المحتوى الأولي.'; return; }
  const plan = [];
  for (const item of seed.items) {
    if (!ctx.canEditType(item.type)) continue;
    const [d, p] = await Promise.all([F.getDoc(F.doc(db, 'drafts', item.type, 'items', item.id)), F.getDoc(F.doc(db, 'public', item.type, 'items', item.id))]);
    plan.push({ ...item, exists: d.exists() || p.exists() });
  }
  const todo = plan.filter(x => !x.exists);
  out.innerHTML = `<div class="scroll"><table class="list-table"><thead><tr><th scope="col">العنصر</th><th scope="col">النوع</th><th scope="col">الإجراء</th></tr></thead><tbody>` +
    plan.map(x => `<tr><td>${esc(x.data.title)}</td><td>${esc(ctx.S.TYPES[x.type].label)}</td><td>${x.exists ? 'موجود — لن يُغيَّر' : x.publish ? 'يُستورد ويُنشر' : 'يُستورد مسودة'}</td></tr>`).join('') +
    `</tbody></table></div>` + (todo.length ? `<div class="row-actions"><button class="btn primary" type="button" id="initConfirm">استيراد ${todo.length} عنصر</button></div>` : '<p class="ok-note">كل عناصر المحتوى الأولي موجودة في اللوحة.</p>');
  const btn = $('#initConfirm');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    btn.disabled = true;
    try {
      const ops = [];
      todo.forEach(x => {
        const clean = { ...ctx.S.clean(x.type, x.data) };
        const meta = { _updatedBy: ctx.user.uid, _updatedAt: F.serverTimestamp() };
        if (x.publish) ops.push(b => b.set(F.doc(db, 'public', x.type, 'items', x.id), { ...clean, ...meta, _publishedAt: F.serverTimestamp() }));
        ops.push(b => b.set(F.doc(db, 'drafts', x.type, 'items', x.id), { ...clean, ...meta, _updatedByEmail: ctx.user.email, _status: x.publish ? 'published' : 'draft', ...(x.publish ? { _publishedAt: F.serverTimestamp() } : {}) }));
      });
      ops.push(b => ctx.audit('content', 'import-initial', 'content', `استيراد ${todo.length} عنصر من المحتوى الحالي للموقع`, b));
      await commitInChunks(F, db, ops);
      out.innerHTML = `<p class="ok-note">استُورد ${todo.length} عنصر. راجع «إعدادات الموقع» لتوثيق الأرقام وكلمة العميد قبل ظهورها.</p>`;
      ctx.toast('اكتمل الاستيراد.');
    } catch (err) { btn.disabled = false; out.insertAdjacentHTML('beforeend', `<p class="alert error">${esc(ctx.explain(err))}</p>`); }
  });
}
