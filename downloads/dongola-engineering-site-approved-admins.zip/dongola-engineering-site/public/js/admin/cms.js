/* ============================================================
   إدارة المحتوى: القوائم والنماذج والمسودات والمعاينة والنشر.
   المسودات في drafts/{type}/items، والمنشور في public/{type}/items.
   لا يرى الزوار إلا المنشور.
   ============================================================ */
import { $, $$, esc, newId, fmtTime } from './util.js';
import { notice } from './app.js';

const STATUS = {
  none: ['لم يُنشأ بعد', 'st-none'],
  draft: ['مسودة', 'st-draft'],
  published: ['منشور', 'st-published'],
  changed: ['منشور، وفيه تعديلات غير منشورة', 'st-changed']
};
const PREFIX = { news: 'news', departments: 'dept', faculty: 'member', calendar: 'cal', schedules: 'sched', documents: 'doc', services: 'svc',
  research: 'res', projects: 'proj', labs: 'lab', activities: 'act', partners: 'partner', accreditations: 'accr', gallery: 'img', pages: 'page' };

export async function render(ctx, [type, action, id]) {
  const T = ctx.S.TYPES[type];
  if (!T) { ctx.main.innerHTML = notice('نوع غير معروف', 'اختر قسمًا من القائمة.'); return; }
  if (!ctx.canEditType(type)) { ctx.main.innerHTML = notice('لا تملك صلاحية هذا القسم', 'هذا النوع من المحتوى خارج صلاحية دورك.'); return; }
  if (!action) return renderList(ctx, type);
  if (action === 'new') return renderEditor(ctx, type, null);
  if (action === 'edit' && id) return renderEditor(ctx, type, decodeURIComponent(id));
  ctx.main.innerHTML = notice('الصفحة غير موجودة', '');
}

/* ---------- تحميل ---------- */
async function loadAll(ctx, type) {
  const { db, F } = ctx.fb;
  const T = ctx.S.TYPES[type];
  const [drafts, pubs] = await Promise.all([
    F.getDocs(F.collection(db, 'drafts', type, 'items')),
    F.getDocs(F.collection(db, 'public', type, 'items'))
  ]);
  const map = new Map();
  const pubIds = new Set(pubs.docs.map(d => d.id));
  drafts.forEach(d => map.set(d.id, { id: d.id, ...d.data() }));
  pubs.forEach(d => { if (!map.has(d.id)) map.set(d.id, { id: d.id, ...d.data(), _status: 'published' }); });
  (T.fixed || []).forEach(f => { if (!map.has(f.id)) map.set(f.id, { id: f.id, title: f.title, _status: 'none', _fixed: true }); else map.get(f.id)._fixed = true; });
  const items = [...map.values()].map(it => ({ ...it, _effective: effectiveStatus(it, pubIds.has(it.id)) }));
  return items;
}
function effectiveStatus(it, isPublic) {
  if (!isPublic) return it._status === 'none' ? 'none' : 'draft';
  return it._status === 'changed' ? 'changed' : 'published';
}
function badge(status) {
  const [label, cls] = STATUS[status] || STATUS.draft;
  return `<span class="status-badge ${cls}">${esc(label)}</span>`;
}
function columnValue(ctx, type, key, it) {
  const v = it[key];
  if (v == null || v === '') return '—';
  const field = ctx.S.TYPES[type].fields.find(f => f.key === key);
  if (field && field.type === 'date') return esc(ctx.R.fmtDate(v));
  if (key === 'summary') return esc(String(v).slice(0, 90)) + (String(v).length > 90 ? '…' : '');
  return esc(ctx.S.optionLabel(type, key, v));
}

/* ---------- القائمة ---------- */
async function renderList(ctx, type) {
  const T = ctx.S.TYPES[type];
  const items = await loadAll(ctx, type);
  const sorted = items.slice().sort(T.sort || ((a, b) => String(b._updatedAt && b._updatedAt.seconds || 0) - String(a._updatedAt && a._updatedAt.seconds || 0)));
  const fieldLabel = key => (T.fields.find(f => f.key === key) || {}).label || key;
  const canAdd = T.allowNew !== false;
  ctx.main.innerHTML = `
    <section class="page-intro">
      <div><h1>${esc(T.label)}</h1><p>${esc(T.description)}</p></div>
      ${canAdd ? `<a class="btn primary" href="#/content/${type}/new">+ إضافة ${esc(T.singular)}</a>` : ''}
    </section>
    <section class="card">
      <form class="list-tools" role="search" aria-label="تصفية القائمة">
        <label>بحث <input type="search" id="listSearch" placeholder="ابحث بالعنوان" autocomplete="off"></label>
        <label>الحالة <select id="listStatus"><option value="">الكل</option>${Object.entries(STATUS).map(([k, [l]]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select></label>
        <p class="list-count" id="listCount" role="status" aria-live="polite"></p>
      </form>
      <div class="scroll table-card"><table class="list-table">
        <thead><tr><th scope="col">العنوان</th><th scope="col">الحالة</th>${T.columns.map(c => `<th scope="col">${esc(fieldLabel(c))}</th>`).join('')}<th scope="col">آخر تعديل</th><th scope="col"><span class="visually-hidden">إجراءات</span></th></tr></thead>
        <tbody id="listBody"></tbody>
      </table></div>
    </section>`;
  const body = $('#listBody');
  function draw() {
    const q = $('#listSearch').value.trim().toLowerCase();
    const st = $('#listStatus').value;
    const rows = sorted.filter(it => (!st || it._effective === st) && (!q || String(it.title || '').toLowerCase().includes(q)));
    $('#listCount').textContent = `${rows.length} من ${sorted.length}`;
    body.innerHTML = rows.length ? rows.map(it => `<tr>
      <th scope="row" class="title-cell"><a href="#/content/${type}/edit/${encodeURIComponent(it.id)}">${esc(it.title || '(بدون عنوان)')}</a></th>
      <td>${badge(it._effective)}</td>
      ${T.columns.map(c => `<td>${columnValue(ctx, type, c, it)}</td>`).join('')}
      <td class="muted">${it._updatedAt ? esc(fmtTime(it._updatedAt)) : '—'}${it._updatedByEmail ? `<br><small dir="ltr">${esc(it._updatedByEmail)}</small>` : ''}</td>
      <td><a class="btn small" href="#/content/${type}/edit/${encodeURIComponent(it.id)}" aria-label="تعديل ${esc(it.title || '')}">${it._effective === 'none' ? 'إنشاء' : 'تعديل'}</a></td>
    </tr>`).join('') : `<tr><td colspan="${4 + T.columns.length}" class="empty-row">${sorted.length ? 'لا توجد عناصر مطابقة.' : `لا يوجد ${esc(T.singular)} بعد.${canAdd ? ' اضغط «إضافة» للبدء.' : ''}`}</td></tr>`;
  }
  $('#listSearch').addEventListener('input', draw);
  $('#listStatus').addEventListener('change', draw);
  draw();
}

/* ---------- قيم افتراضية ---------- */
function blankValue(field) {
  if (field.default != null) return field.default;
  switch (field.type) {
    case 'checkbox': return false;
    case 'list': case 'attachments': case 'repeater': return [];
    default: return '';
  }
}
function forEdit(T, data) {
  const out = {};
  T.fields.forEach(f => {
    let v = data[f.key];
    if (v === undefined || v === null) v = blankValue(f);
    if (f.type === 'list') v = (Array.isArray(v) ? v : []).join('\n');
    if (f.type === 'number') v = v === '' || v == null ? '' : String(v);
    if (f.type === 'repeater') v = (v || []).map(row => { const r = {}; f.fields.forEach(sf => { r[sf.key] = row && row[sf.key] != null ? (sf.type === 'number' ? String(row[sf.key]) : row[sf.key]) : blankValue(sf); }); return r; });
    if (f.type === 'attachments') v = (v || []).map(a => ({ title: a.title || '', url: a.url || '' }));
    out[f.key] = v;
  });
  return out;
}

/* ---------- عناصر النموذج ---------- */
const fid = path => 'f-' + path.replace(/\./g, '-');
function control(ctx, type, field, value, path) {
  const id = fid(path);
  const described = [field.hint ? id + '-hint' : '', id + '-err'].filter(Boolean).join(' ');
  const a = `id="${id}" data-path="${path}" data-type="${field.type}" aria-describedby="${described}"${field.readonly ? ' readonly' : ''}`;
  const ltr = field.dir === 'ltr' || field.type === 'email' || field.type === 'url' || field.type === 'image' ? ' dir="ltr"' : '';
  const ph = field.placeholder ? ` placeholder="${esc(field.placeholder)}"` : '';
  const opts = (list, current, emptyLabel) => `<option value="">${emptyLabel}</option>` + list.map(o => {
    const [v, l] = Array.isArray(o) ? o : [o, o];
    return `<option value="${esc(v)}"${String(current) === String(v) ? ' selected' : ''}>${esc(l)}</option>`;
  }).join('');
  switch (field.type) {
    case 'text': return `<input type="text" ${a} value="${esc(value)}"${field.max ? ` maxlength="${field.max}"` : ''}${ltr}${ph}>`;
    case 'email': return `<input type="email" ${a} value="${esc(value)}" autocomplete="off"${ltr}${ph}>`;
    case 'url': return `<input type="url" ${a} value="${esc(value)}" placeholder="https://"${ltr}>`;
    case 'number': return `<input type="number" ${a} value="${esc(value)}" inputmode="numeric"${field.min != null ? ` min="${field.min}"` : ''}${field.max != null ? ` max="${field.max}"` : ''}>`;
    case 'date': return `<input type="date" ${a} value="${esc(value)}">`;
    case 'textarea': return `<textarea ${a} rows="${field.rows || 4}"${field.max ? ` maxlength="${field.max}"` : ''}${ph}>${esc(value)}</textarea>${field.max ? `<span class="char-count" data-count-for="${path}" aria-hidden="true">${String(value || '').length} / ${field.max}</span>` : ''}`;
    case 'list': return `<textarea ${a} rows="4">${esc(value)}</textarea>`;
    case 'select': return `<select ${a}>${opts(field.options, value, '— اختر —')}</select>`;
    case 'department': return `<select ${a}>${opts(ctx.S.DEPARTMENTS.map(d => [d.id, d.name]), value, 'الكلية (عام)')}</select>`;
    case 'facultyRef': return `<select ${a} data-faculty-ref data-current="${esc(value)}"><option value="">— بدون —</option>${value ? `<option value="${esc(value)}" selected>${esc(value)}</option>` : ''}</select>`;
    case 'richtext': return `<div class="rt-toolbar" role="toolbar" aria-label="أدوات التنسيق" aria-controls="${id}">
        <button type="button" data-md="h2">عنوان</button><button type="button" data-md="h3">عنوان فرعي</button><button type="button" data-md="bold">غامق</button>
        <button type="button" data-md="ul">قائمة</button><button type="button" data-md="ol">قائمة مرقّمة</button><button type="button" data-md="link">رابط</button><button type="button" data-md="table">جدول</button>
        <button type="button" data-md="preview" aria-pressed="false">معاينة النص</button></div>
      <textarea ${a} rows="${field.rows || 10}" class="rt-area"${field.max ? ` maxlength="${field.max}"` : ''}>${esc(value)}</textarea>
      <div class="rt-preview prose" data-preview-for="${path}" hidden></div>`;
    case 'image': return `<div class="image-field"><input type="text" ${a} value="${esc(value)}" placeholder="images/… أو https://…"${ltr}>
        ${ctx.cfg.storageUploads ? `<label class="btn small upload-btn">رفع صورة<input type="file" accept="image/png,image/jpeg,image/webp" data-upload="${path}" data-kind="image" class="file-input"></label>` : ''}
        <span class="image-preview" data-image-preview="${path}">${value ? `<img src="${esc(ctx.R.resolve(value, ''))}" alt="">` : ''}</span></div>`;
    default: return '';
  }
}
function fieldBlock(ctx, type, field, value, path) {
  const id = fid(path);
  const req = field.required ? ' <span class="req" title="مطلوب للنشر">*</span>' : field.requiredToPublish ? ' <span class="req-pub">مطلوب للنشر</span>' : '';
  const hint = field.hint ? `<p class="field-hint" id="${id}-hint">${esc(field.hint)}</p>` : '';
  const err = `<p class="field-error" id="${id}-err" hidden></p>`;
  if (field.type === 'checkbox') {
    return `<div class="field field-checkbox" data-field="${path}"><label class="check-field" for="${id}"><input type="checkbox" id="${id}" data-path="${path}" data-type="checkbox" aria-describedby="${field.hint ? id + '-hint ' : ''}${id}-err"${value ? ' checked' : ''}> <span>${esc(field.label)}${req}</span></label>${hint}${err}</div>`;
  }
  if (field.type === 'repeater' || field.type === 'attachments') return repeaterBlock(ctx, type, field, value, path);
  const wide = ['textarea', 'richtext', 'list'].includes(field.type) ? ' field-wide' : '';
  return `<div class="field field-${field.type}${wide}" data-field="${path}"><label for="${id}">${esc(field.label)}${req}</label>${control(ctx, type, field, value, path)}${hint}${err}</div>`;
}
const ATTACH_FIELDS = [
  { key: 'title', label: 'اسم الملف كما يظهر للزائر', type: 'text', max: 200 },
  { key: 'url', label: 'رابط الملف', type: 'text', dir: 'ltr', placeholder: 'files/اسم-الملف.pdf أو https://…' }
];
function repeaterBlock(ctx, type, field, rows, path) {
  const sub = field.type === 'attachments' ? ATTACH_FIELDS : field.fields;
  const id = fid(path);
  const add = field.type === 'attachments' ? 'إضافة ملف' : (field.addLabel || 'إضافة عنصر');
  const note = field.type === 'attachments' && !ctx.cfg.storageUploads
    ? '<p class="field-hint">ضع الملف المعتمد في مجلد <code>files</code> بالموقع ثم اكتب رابطه هنا، أو استخدم رابطًا رسميًا يبدأ بـ https://. (رفع الملفات من اللوحة يحتاج تفعيل Cloud Storage.)</p>' : '';
  return `<fieldset class="field field-repeater field-wide" data-field="${path}" aria-describedby="${field.hint ? id + '-hint ' : ''}${id}-err">
    <legend>${esc(field.label)}${field.required ? ' <span class="req">*</span>' : ''}</legend>
    ${field.hint ? `<p class="field-hint" id="${id}-hint">${esc(field.hint)}</p>` : ''}${note}
    <ol class="repeater-rows">${(rows || []).map((row, i) => `<li class="repeater-row">
      <div class="row-head"><span>${field.type === 'attachments' ? 'ملف' : 'عنصر'} ${i + 1}</span><div class="row-tools">
        <button type="button" class="icon-btn" data-act="up" data-path="${path}" data-i="${i}" aria-label="تحريك العنصر ${i + 1} للأعلى"${i === 0 ? ' disabled' : ''}>↑</button>
        <button type="button" class="icon-btn" data-act="down" data-path="${path}" data-i="${i}" aria-label="تحريك العنصر ${i + 1} للأسفل"${i === rows.length - 1 ? ' disabled' : ''}>↓</button>
        <button type="button" class="icon-btn danger" data-act="remove" data-path="${path}" data-i="${i}" aria-label="حذف العنصر ${i + 1}">✕</button></div></div>
      <div class="row-fields">${sub.map(sf => fieldBlock(ctx, type, sf, row[sf.key], `${path}.${i}.${sf.key}`)).join('')}
      ${field.type === 'attachments' && ctx.cfg.storageUploads ? `<label class="btn small upload-btn">رفع ملف<input type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,image/png,image/jpeg,image/webp" data-upload="${path}.${i}.url" data-kind="file" class="file-input"></label>` : ''}</div>
    </li>`).join('')}</ol>
    <button type="button" class="btn small" data-act="add" data-path="${path}">+ ${esc(add)}</button>
    <p class="field-error" id="${id}-err" hidden></p>
  </fieldset>`;
}

function getPath(obj, path) { return path.split('.').reduce((o, k) => (o == null ? o : o[k]), obj); }
function setPath(obj, path, value) {
  const keys = path.split('.');
  let o = obj;
  keys.slice(0, -1).forEach(k => { o = o[k]; });
  o[keys[keys.length - 1]] = value;
}

/* ---------- المحرر ---------- */
async function renderEditor(ctx, type, id) {
  const { db, F } = ctx.fb;
  const S = ctx.S;
  const T = S.TYPES[type];
  if (!id && T.allowNew === false) { ctx.main.innerHTML = notice('لا يمكن إضافة عنصر هنا', 'هذا القسم له عناصر ثابتة؛ اختر أحدها من القائمة.'); return; }
  let draft = null, pub = null;
  if (id) {
    const [d, p] = await Promise.all([F.getDoc(F.doc(db, 'drafts', type, 'items', id)), F.getDoc(F.doc(db, 'public', type, 'items', id))]);
    draft = d.exists() ? d.data() : null;
    pub = p.exists() ? p.data() : null;
  }
  const fixed = (T.fixed || []).find(f => f.id === id);
  if (id && !draft && !pub && !fixed) { ctx.main.innerHTML = notice('العنصر غير موجود', 'ربما حُذف. ارجع إلى القائمة.'); return; }
  const base = draft || pub || (fixed ? { title: fixed.title, summary: fixed.summary || '', body: fixed.template || '' } : {});
  const state = {
    id, data: forEdit(T, base), published: !!pub,
    status: pub ? (draft && draft._status === 'changed' ? 'changed' : 'published') : (draft ? 'draft' : 'none'),
    meta: draft || pub || {}
  };

  ctx.main.innerHTML = `
    <nav class="crumbs" aria-label="مسار الصفحة"><a href="#/content/${type}">${esc(T.label)}</a> <span aria-hidden="true">/</span> <span aria-current="page">${id ? 'تعديل' : 'إضافة'}</span></nav>
    <section class="page-intro"><div><h1>${id ? esc(base.title || T.singular) : 'إضافة ' + esc(T.singular)}</h1><p>${esc(T.description)}</p></div></section>
    <div class="editor-layout">
      <form class="card editor-form" id="editorForm" novalidate>
        <div class="form-errors" id="formErrors" role="alert" tabindex="-1" hidden></div>
        <div class="fields-grid">${T.fields.map(f => fieldBlock(ctx, type, f, state.data[f.key], f.key)).join('')}</div>
      </form>
      <aside class="card publish-panel" aria-labelledby="pubTitle">
        <h2 id="pubTitle">النشر</h2>
        <p class="pub-status" id="pubStatus"></p>
        <dl class="pub-meta" id="pubMeta"></dl>
        <div class="pub-actions">
          <button type="button" class="btn" id="saveDraft">حفظ كمسودة</button>
          <button type="button" class="btn" id="previewBtn">معاينة</button>
          <button type="button" class="btn primary" id="publishBtn">نشر</button>
          <button type="button" class="btn" id="unpublishBtn">إلغاء النشر</button>
          <button type="button" class="btn danger" id="deleteBtn">حذف</button>
        </div>
        <ul class="warn-list" id="warnList"></ul>
        <details class="pub-help"><summary>ما الفرق بين المسودة والنشر؟</summary>
          <p>«حفظ كمسودة» يحفظ عملك دون أن يراه الزوار. «معاينة» تعرض الصفحة كما ستظهر قبل الحفظ. «نشر» يجعل المحتوى ظاهرًا في الموقع فورًا، ويسجَّل في سجل التغييرات.</p></details>
      </aside>
    </div>`;

  const form = $('#editorForm');
  function refreshPanel() {
    const [label, cls] = STATUS[state.status];
    $('#pubStatus').innerHTML = `الحالة: <span class="status-badge ${cls}">${esc(label)}</span>`;
    const m = state.meta;
    $('#pubMeta').innerHTML = (m._updatedAt ? `<div><dt>آخر حفظ</dt><dd>${esc(fmtTime(m._updatedAt))}</dd></div>` : '') +
      (m._updatedByEmail ? `<div><dt>بواسطة</dt><dd dir="ltr">${esc(m._updatedByEmail)}</dd></div>` : '') +
      (m._publishedAt ? `<div><dt>آخر نشر</dt><dd>${esc(fmtTime(m._publishedAt))}</dd></div>` : '');
    $('#publishBtn').textContent = state.status === 'changed' ? 'نشر التعديلات' : state.published ? 'تحديث المنشور' : 'نشر';
    $('#unpublishBtn').hidden = !state.published;
    $('#deleteBtn').hidden = !state.id || !!fixed;
    const warns = S.warnings(type, S.clean(type, state.data));
    $('#warnList').innerHTML = warns.map(w => `<li>${esc(w)}</li>`).join('');
  }
  refreshPanel();

  // قائمة أعضاء هيئة التدريس لحقل «صفحة رئيس القسم»
  $$('select[data-faculty-ref]', form).forEach(async sel => {
    try {
      const snap = await F.getDocs(F.collection(db, 'drafts', 'faculty', 'items'));
      const cur = sel.dataset.current;
      sel.innerHTML = '<option value="">— بدون —</option>' + snap.docs.map(d => `<option value="${esc(d.id)}"${d.id === cur ? ' selected' : ''}>${esc(d.data().title || d.id)}</option>`).join('');
    } catch { /* يبقى الخيار الحالي */ }
  });

  /* ربط الحقول بالحالة */
  function readInput(el) {
    if (el.type === 'checkbox') return el.checked;
    return el.value;
  }
  form.addEventListener('input', e => {
    const el = e.target;
    const path = el.dataset.path;
    if (!path) return;
    setPath(state.data, path, readInput(el));
    ctx.setDirty(true);
    clearError(path);
    const counter = form.querySelector(`[data-count-for="${CSS.escape(path)}"]`);
    if (counter) counter.textContent = `${el.value.length} / ${el.maxLength}`;
    const prev = form.querySelector(`[data-image-preview="${CSS.escape(path)}"]`);
    if (prev) { const src = ctx.R.resolve(el.value.trim(), ''); prev.innerHTML = src ? `<img src="${esc(src)}" alt="">` : ''; }
    const rt = form.querySelector(`[data-preview-for="${CSS.escape(path)}"]`);
    if (rt && !rt.hidden) rt.innerHTML = ctx.R.markdown(el.value, '');
  });
  form.addEventListener('change', e => { if (e.target.type === 'checkbox' || e.target.tagName === 'SELECT') refreshPanel(); });

  /* أدوات التنسيق والمكررات */
  form.addEventListener('click', e => {
    const md = e.target.closest('[data-md]');
    if (md) { formatText(ctx, md); return; }
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const path = btn.dataset.path;
    const rows = getPath(state.data, path);
    const field = T.fields.find(f => f.key === path);
    const i = Number(btn.dataset.i);
    let focusIndex = null;
    if (btn.dataset.act === 'add') {
      const sub = field.type === 'attachments' ? ATTACH_FIELDS : field.fields;
      const r = {};
      sub.forEach(sf => { r[sf.key] = blankValue(sf); });
      rows.push(r);
      focusIndex = rows.length - 1;
    } else if (btn.dataset.act === 'remove') {
      rows.splice(i, 1); focusIndex = Math.min(i, rows.length - 1);
    } else if (btn.dataset.act === 'up' && i > 0) {
      [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]]; focusIndex = i - 1;
    } else if (btn.dataset.act === 'down' && i < rows.length - 1) {
      [rows[i + 1], rows[i]] = [rows[i], rows[i + 1]]; focusIndex = i + 1;
    }
    ctx.setDirty(true);
    const block = form.querySelector(`[data-field="${CSS.escape(path)}"]`);
    block.outerHTML = repeaterBlock(ctx, type, field, rows, path);
    const nb = form.querySelector(`[data-field="${CSS.escape(path)}"]`);
    const target = focusIndex != null && focusIndex >= 0 ? nb.querySelectorAll('.repeater-row')[focusIndex] : null;
    const f = target ? target.querySelector(btn.dataset.act === 'add' ? 'input, select, textarea' : `[data-act="${btn.dataset.act}"]`) : nb.querySelector('[data-act="add"]');
    if (f) f.focus();
  });

  /* رفع الملفات (عند تفعيل Cloud Storage) */
  form.addEventListener('change', async e => {
    const input = e.target.closest('input[data-upload]');
    if (!input || !input.files[0]) return;
    const file = input.files[0];
    input.value = '';
    try {
      const url = await uploadFile(ctx, type, file, input.dataset.kind);
      setPath(state.data, input.dataset.upload, url);
      const target = form.querySelector(`[data-path="${CSS.escape(input.dataset.upload)}"]`);
      if (target) { target.value = url; target.dispatchEvent(new Event('input', { bubbles: true })); }
      ctx.toast('رُفع الملف. احفظ أو انشر لاعتماده.');
    } catch (err) { ctx.toast(err.userMessage || ctx.explain(err), 'error'); }
  });

  /* الأخطاء */
  function clearError(path) {
    const top = path.split('.')[0];
    const err = $('#' + fid(top) + '-err');
    if (err) { err.hidden = true; err.textContent = ''; }
    const el = $('#' + fid(path));
    if (el) el.removeAttribute('aria-invalid');
  }
  function showErrors(errors) {
    $$('.field-error', form).forEach(p => { p.hidden = true; p.textContent = ''; });
    $$('[aria-invalid]', form).forEach(el => el.removeAttribute('aria-invalid'));
    const box = $('#formErrors');
    if (!errors.length) { box.hidden = true; return; }
    const byKey = {};
    errors.forEach(er => { (byKey[er.key] = byKey[er.key] || []).push(er.message); });
    Object.entries(byKey).forEach(([key, msgs]) => {
      const p = $('#' + fid(key) + '-err');
      if (p) { p.textContent = msgs.join(' '); p.hidden = false; }
      const el = $('#' + fid(key));
      if (el) el.setAttribute('aria-invalid', 'true');
    });
    box.innerHTML = `<h2>يلزم تصحيح ${errors.length === 1 ? 'ملاحظة واحدة' : errors.length + ' ملاحظات'} قبل المتابعة:</h2><ul>` +
      errors.map(er => `<li><a href="#${fid(er.key)}">${esc(er.label)}: ${esc(er.message)}</a></li>`).join('') + '</ul>';
    box.hidden = false;
    box.focus();
  }
  $('#formErrors').addEventListener('click', e => {
    const a = e.target.closest('a[href^="#f-"]');
    if (!a) return;
    e.preventDefault();
    const target = document.getElementById(a.getAttribute('href').slice(1));
    const focusable = target && (target.matches('input, select, textarea') ? target : target.querySelector('input, select, textarea, button'));
    if (focusable) { focusable.focus(); focusable.scrollIntoView({ block: 'center' }); }
  });

  /* الحفظ والنشر */
  const who = () => ({ _updatedBy: ctx.user.uid, _updatedByEmail: ctx.user.email, _updatedAt: F.serverTimestamp() });
  function setButtons(on) { $$('.pub-actions button').forEach(b => { b.disabled = on; }); }
  async function persist(kind) {
    const clean = S.clean(type, state.data);
    const errors = S.validate(type, clean, kind === 'publish' ? 'publish' : 'draft');
    showErrors(errors);
    if (errors.length) return false;
    const newItem = !state.id;
    if (kind === 'publish') {
      const warns = S.warnings(type, clean);
      const ok = await ctx.confirm({
        title: state.published ? 'تحديث المحتوى المنشور' : 'نشر المحتوى',
        message: 'سيظهر هذا المحتوى للزوار فور النشر.' + (warns.length ? '\n\nتنبيهات: ' + warns.join(' — ') : ''),
        confirmLabel: state.published ? 'تحديث المنشور' : 'نشر الآن'
      });
      if (!ok) return false;
    }
    const docId = state.id || newId(PREFIX[type] || type);
    setButtons(true);
    try {
      const b = F.writeBatch(db);
      if (kind === 'publish') {
        b.set(F.doc(db, 'public', type, 'items', docId), { ...clean, _updatedBy: ctx.user.uid, _updatedAt: F.serverTimestamp(), _publishedAt: F.serverTimestamp() });
        b.set(F.doc(db, 'drafts', type, 'items', docId), { ...clean, ...who(), _status: 'published', _publishedAt: F.serverTimestamp() });
        ctx.audit('content', state.published ? 'republish' : 'publish', `${type}/${docId}`, `${T.singular}: ${clean.title}`, b);
      } else {
        b.set(F.doc(db, 'drafts', type, 'items', docId), { ...clean, ...who(), _status: state.published ? 'changed' : 'draft', ...(state.meta._publishedAt ? { _publishedAt: state.meta._publishedAt } : {}) });
        if (newItem) ctx.audit('content', 'create-draft', `${type}/${docId}`, `${T.singular}: ${clean.title}`, b);
      }
      await b.commit();
      const snap = await F.getDoc(F.doc(db, 'drafts', type, 'items', docId));
      state.meta = snap.exists() ? snap.data() : state.meta;
      state.id = docId;
      if (kind === 'publish') { state.published = true; state.status = 'published'; }
      else state.status = state.published ? 'changed' : 'draft';
      ctx.setDirty(false);
      if (newItem) ctx.replaceRoute(`content/${type}/edit/${docId}`);
      refreshPanel();
      ctx.toast(kind === 'publish' ? 'نُشر المحتوى، وهو ظاهر الآن في الموقع.' : 'حُفظت المسودة. لن تظهر للزوار قبل النشر.');
      return true;
    } catch (err) {
      ctx.toast('لم يتم الحفظ: ' + ctx.explain(err), 'error');
      return false;
    } finally { setButtons(false); }
  }
  $('#saveDraft').addEventListener('click', () => persist('draft'));
  $('#publishBtn').addEventListener('click', () => persist('publish'));
  $('#previewBtn').addEventListener('click', () => openPreview(ctx, type, state.id, S.clean(type, state.data)));
  $('#unpublishBtn').addEventListener('click', async () => {
    const ok = await ctx.confirm({ title: 'إلغاء النشر', message: 'سيختفي هذا المحتوى من الموقع، ويبقى مسودة في اللوحة يمكن نشرها لاحقًا.', confirmLabel: 'إلغاء النشر', danger: true });
    if (!ok) return;
    setButtons(true);
    try {
      const clean = S.clean(type, state.data);
      const b = F.writeBatch(db);
      b.delete(F.doc(db, 'public', type, 'items', state.id));
      b.set(F.doc(db, 'drafts', type, 'items', state.id), { ...clean, ...who(), _status: 'draft' });
      ctx.audit('content', 'unpublish', `${type}/${state.id}`, `${T.singular}: ${clean.title}`, b);
      await b.commit();
      state.published = false; state.status = 'draft';
      ctx.setDirty(false);
      refreshPanel();
      ctx.toast('أُلغي النشر. المحتوى محفوظ كمسودة.');
    } catch (err) { ctx.toast('تعذّر إلغاء النشر: ' + ctx.explain(err), 'error'); }
    finally { setButtons(false); }
  });
  $('#deleteBtn').addEventListener('click', async () => {
    const title = S.clean(type, state.data).title || 'هذا العنصر';
    const ok = await ctx.confirm({ title: 'حذف نهائي', message: `سيُحذف «${title}» من المسودات ومن الموقع. لا يمكن التراجع إلا من نسخة احتياطية.`, confirmLabel: 'حذف نهائي', danger: true, requireText: 'حذف' });
    if (!ok) return;
    setButtons(true);
    try {
      const b = F.writeBatch(db);
      b.delete(F.doc(db, 'public', type, 'items', state.id));
      b.delete(F.doc(db, 'drafts', type, 'items', state.id));
      ctx.audit('content', 'delete', `${type}/${state.id}`, `${T.singular}: ${title}`, b);
      await b.commit();
      ctx.setDirty(false);
      ctx.toast('حُذف العنصر.');
      ctx.navigate(`#/content/${type}`);
    } catch (err) { ctx.toast('تعذّر الحذف: ' + ctx.explain(err), 'error'); setButtons(false); }
  });
}

/* أدوات التنسيق داخل مربع النص */
function formatText(ctx, btn) {
  const ta = btn.closest('.field').querySelector('textarea');
  const kind = btn.dataset.md;
  if (kind === 'preview') {
    const prev = btn.closest('.field').querySelector('.rt-preview');
    const on = prev.hidden;
    prev.hidden = !on;
    btn.setAttribute('aria-pressed', String(on));
    if (on) prev.innerHTML = ctx.R.markdown(ta.value, '') || '<p class="muted">لا يوجد نص بعد.</p>';
    return;
  }
  const s = ta.selectionStart, e = ta.selectionEnd, v = ta.value, sel = v.slice(s, e);
  const lineStart = v.lastIndexOf('\n', s - 1) + 1;
  let insert, from = s, to = e, caret;
  const prefix = { h2: '## ', h3: '### ', ul: '- ', ol: '1. ' }[kind];
  if (prefix) { from = to = lineStart; insert = prefix; caret = s + prefix.length; }
  else if (kind === 'bold') { insert = `**${sel || 'نص غامق'}**`; caret = s + insert.length; }
  else if (kind === 'link') { insert = `[${sel || 'نص الرابط'}](https://)`; caret = s + insert.length - 1; }
  else if (kind === 'table') { insert = `${s && v[s - 1] !== '\n' ? '\n' : ''}| العمود الأول | العمود الثاني |\n|---|---|\n| | |\n`; caret = s + insert.length; }
  ta.setRangeText(insert, from, to, 'end');
  ta.focus();
  ta.setSelectionRange(caret, caret);
  ta.dispatchEvent(new Event('input', { bubbles: true }));
}

/* المعاينة في نافذة مستقلة بتصميم الموقع، دون حفظ */
let previewPayload = null;
let previewListening = false;
function openPreview(ctx, type, id, data) {
  previewPayload = { type, id: id || 'preview', data };
  if (!previewListening) {
    window.addEventListener('message', e => {
      if (e.origin !== location.origin || e.data !== 'cms-preview-ready' || !previewPayload) return;
      e.source.postMessage({ kind: 'cms-preview', payload: previewPayload }, location.origin);
    });
    previewListening = true;
  }
  // نسخة احتياطية للمتصفحات التي تفتح المعاينة دون ربطها بهذه النافذة
  try { localStorage.setItem('cms-preview', JSON.stringify({ ...previewPayload, at: Date.now() })); } catch { /* التخزين غير متاح */ }
  const w = window.open('preview.html', 'cms-preview');
  if (!w) ctx.toast('اسمح للمتصفح بفتح نافذة جديدة لعرض المعاينة.', 'error');
}

async function uploadFile(ctx, type, file, kind) {
  const okType = kind === 'image' ? /^image\/(png|jpeg|webp)$/ : /^(application\/pdf|image\/(png|jpeg|webp)|application\/vnd\.openxmlformats-officedocument\.(wordprocessingml\.document|spreadsheetml\.sheet))$/;
  if (!okType.test(file.type)) throw Object.assign(new Error('type'), { userMessage: 'نوع الملف غير مسموح. المسموح: PDF وWord وExcel والصور.' });
  if (file.size > 10 * 1024 * 1024) throw Object.assign(new Error('size'), { userMessage: 'حجم الملف أكبر من ١٠ ميغابايت.' });
  const St = await import(ctx.fb.SDK + 'firebase-storage.js');
  const storage = St.getStorage(ctx.fb.app);
  const safe = file.name.toLowerCase().replace(/[^a-z0-9.\-_]+/g, '-').replace(/-+/g, '-').slice(-80);
  const ref = St.ref(storage, `content/${type}/${Date.now()}-${safe}`);
  await St.uploadBytes(ref, file, { contentType: file.type });
  return St.getDownloadURL(ref);
}
