/* أدوات مشتركة للوحة الإدارة */
export const $ = (sel, el) => (el || document).querySelector(sel);
export const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
export const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const toLatinDigits = s => String(s == null ? '' : s).replace(/[٠-٩]/g, d => d.charCodeAt(0) - 0x0660).replace(/[۰-۹]/g, d => d.charCodeAt(0) - 0x06F0);
export const arDigits = v => String(v == null ? '' : v).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function randomString(n, alphabet = 'abcdefghijkmnpqrstuvwxyz23456789') {
  const bytes = new Uint8Array(n);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, b => alphabet[b % alphabet.length]).join('');
}
/** رمز تفعيل من ١٢ خانة (نحو ٦٠ بت عشوائية) بالشكل XXXX-XXXX-XXXX */
export function activationCode() {
  return randomString(12, CODE_ALPHABET).replace(/(.{4})(?=.)/g, '$1-');
}
export function newId(prefix) {
  const d = new Date();
  const ymd = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  return `${prefix}-${ymd}-${randomString(5)}`;
}

let dateTimeFmt;
export function fmtTime(ts) {
  if (!ts) return '—';
  const d = typeof ts.toDate === 'function' ? ts.toDate() : new Date(ts);
  if (isNaN(d)) return '—';
  dateTimeFmt = dateTimeFmt || new Intl.DateTimeFormat('ar-SD-u-nu-arab', { dateStyle: 'medium', timeStyle: 'short' });
  return dateTimeFmt.format(d);
}

/* ---------- الإشعارات ---------- */
export function toast(message, kind) {
  const t = $('#toast');
  t.textContent = message;
  t.dataset.kind = kind || 'info';
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, kind === 'error' ? 9000 : 5000);
}

/* ---------- نافذة تأكيد يمكن استخدامها بلوحة المفاتيح ---------- */
export function confirmDialog({ title, message, confirmLabel = 'تأكيد', danger = false, requireText = '' }) {
  return new Promise(resolve => {
    const dlg = $('#confirmDlg');
    $('#confirmTitle', dlg).textContent = title;
    $('#confirmMessage', dlg).textContent = message;
    const ok = $('#confirmOk', dlg);
    ok.textContent = confirmLabel;
    ok.classList.toggle('danger-solid', danger);
    const wrap = $('#confirmTypeWrap', dlg);
    const input = $('#confirmType', dlg);
    wrap.hidden = !requireText;
    input.value = '';
    $('#confirmTypeLabel', dlg).textContent = requireText ? `للتأكيد اكتب: ${requireText}` : '';
    ok.disabled = !!requireText;
    input.oninput = () => { ok.disabled = input.value.trim() !== requireText; };
    dlg.returnValue = '';
    // نحسم النتيجة عند الضغط مباشرة؛ حدث close قد يتأخر في بعض المتصفحات
    let settled = false;
    const finish = v => { if (!settled) { settled = true; resolve(v); } };
    ok.onclick = () => { if (!ok.disabled) finish(true); };
    $('#confirmCancel', dlg).onclick = () => finish(false);
    dlg.oncancel = () => finish(false);
    dlg.onclose = () => finish(dlg.returnValue === 'ok');
    dlg.showModal();
    (requireText ? input : $('#confirmCancel', dlg)).focus();
  });
}

export function download(name, text, type) {
  const blob = new Blob([text], { type: type || 'application/json;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

export function stamp() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}

/* قيم Firestore ↔ JSON للنسخ الاحتياطية */
export function toJsonValue(v) {
  if (v == null) return v;
  if (typeof v.toDate === 'function' && typeof v.seconds === 'number') return { __ts: v.toDate().toISOString() };
  if (Array.isArray(v)) return v.map(toJsonValue);
  if (typeof v === 'object') { const o = {}; Object.keys(v).forEach(k => { o[k] = toJsonValue(v[k]); }); return o; }
  return v;
}
export function fromJsonValue(v, F) {
  if (v == null) return v;
  if (Array.isArray(v)) return v.map(x => fromJsonValue(x, F));
  if (typeof v === 'object') {
    if (Object.keys(v).length === 1 && typeof v.__ts === 'string') return F.Timestamp.fromDate(new Date(v.__ts));
    const o = {}; Object.keys(v).forEach(k => { o[k] = fromJsonValue(v[k], F); }); return o;
  }
  return v;
}

/** تنفيذ عمليات كثيرة على دفعات (حد Firestore ٥٠٠ عملية للدفعة) */
export async function commitInChunks(F, db, ops, size = 400) {
  for (let i = 0; i < ops.length; i += size) {
    const b = F.writeBatch(db);
    ops.slice(i, i + size).forEach(op => op(b));
    await b.commit();
  }
}

export function readFileText(file, maxBytes) {
  if (maxBytes && file.size > maxBytes) return Promise.reject(Object.assign(new Error('too-large'), { code: 'too-large' }));
  return file.text();
}
