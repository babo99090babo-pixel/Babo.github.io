/* ============================================================
   لوحة الإدارة — الدخول والصلاحيات والتنقل بين الأقسام.
   تظهر الأقسام بحسب الدور، لكن المنع الحقيقي في firestore.rules.
   ============================================================ */
import { firebaseReady, explainError } from '../firebase-init.js';
import { $, $$, esc, toast, confirmDialog } from './util.js';
import { resolveStaffRole, emailKey, STAFF_ROLES } from '../staff-access.js';

const S = window.CMS_SCHEMA;
const cfg = window.SITE_CONFIG;

export const ROLE_LABELS = {
  admin: 'المدير',
  editor: 'محرر المحتوى',
  news: 'محرر الأخبار',
  results: 'مسؤول النتائج'
};
export const ROLE_DESCRIPTIONS = {
  admin: 'كل الصلاحيات: المحتوى والنتائج والمستخدمون والسجل والنسخ الاحتياطي.',
  editor: 'تحرير كل محتوى الموقع العام ونشره. لا يصل إلى النتائج ولا إلى المستخدمين.',
  news: 'تحرير الأخبار والأنشطة ومعرض الصور ونشرها فقط.',
  results: 'إدارة النتائج ونشرها ورموز تفعيل حسابات الطلاب. لا يعدّل محتوى الموقع.'
};

const ALL = ['admin', 'editor', 'news', 'results'];
const PAGES = {
  dashboard: { label: 'الرئيسية', roles: ALL, load: () => import('./dashboard.js') },
  content: { label: 'المحتوى', roles: ['admin', 'editor', 'news'], load: () => import('./cms.js') },
  results: { label: 'النتائج', roles: ['admin', 'results'], load: () => import('./results.js') },
  users: { label: 'المستخدمون والصلاحيات', roles: ['admin'], load: () => import('./users.js') },
  audit: { label: 'سجل التغييرات', roles: ['admin'], load: () => import('./audit.js') },
  backup: { label: 'النسخ الاحتياطي والاستعادة', roles: ['admin', 'results', 'editor'], load: () => import('./backup.js') },
  help: { label: 'دليل الاستخدام', roles: ALL, load: () => import('./help.js') }
};

const ctx = {
  fb: null, user: null, role: null, S, R: window.CMSRender, cfg,
  main: null, dirty: false,
  toast, confirm: confirmDialog, explain: explainError,
  canEditType(type) { const t = S.TYPES[type]; return !!t && t.roles.includes(this.role); },
  setDirty(on, label) {
    this.dirty = !!on;
    $('#dirtyFlag').textContent = on ? '● ' + (label || 'تعديلات غير محفوظة') : '';
  },
  navigate(hash) { location.hash = hash; },
  /** يُضاف سجل لكل تغيير مهم، في نفس الدفعة إن أُعطيت */
  audit(area, action, target, summary, batch) {
    const { db, F } = this.fb;
    const ref = F.doc(F.collection(db, 'audit'));
    const data = { area, action, target: String(target).slice(0, 200), summary: String(summary || '').slice(0, 500), by: this.user.uid, email: this.user.email, role: this.role, at: F.serverTimestamp() };
    if (batch) { batch.set(ref, data); return null; }
    return F.setDoc(ref, data);
  }
};
window.addEventListener('beforeunload', e => { if (ctx.dirty) { e.preventDefault(); e.returnValue = ''; } });
// نماذج البحث والتصفية لا تُرسل؛ تعمل أثناء الكتابة (سياسة الأمان تمنع معالجات onsubmit المضمّنة)
document.addEventListener('submit', e => { if (e.target.matches('form.list-tools')) e.preventDefault(); });

/* ---------- القائمة الجانبية ---------- */
function renderNav() {
  const role = ctx.role;
  const link = (hash, label, extra = '') => `<a href="#/${hash}" data-route="${hash}"${extra}>${esc(label)}</a>`;
  let html = `<ul class="nav-group">${'<li>' + link('dashboard', 'الرئيسية') + '</li>'}</ul>`;
  if (PAGES.content.roles.includes(role)) {
    Object.entries(S.GROUPS).forEach(([gid, glabel]) => {
      const types = Object.entries(S.TYPES).filter(([, t]) => t.group === gid && t.roles.includes(role));
      if (!types.length) return;
      html += `<h2 class="nav-heading">${esc(glabel)}</h2><ul class="nav-group">` + types.map(([id, t]) => `<li>${link('content/' + id, t.label)}</li>`).join('') + '</ul>';
    });
  }
  if (PAGES.results.roles.includes(role)) {
    html += `<h2 class="nav-heading">النتائج</h2><ul class="nav-group">` +
      [['results', 'الدفعات والنتائج'], ['results/codes', 'رموز التفعيل والحسابات'], ['results/import', 'الاستيراد والترحيل'], ['results/log', 'سجل النتائج']]
        .map(([h, l]) => `<li>${link(h, l)}</li>`).join('') + '</ul>';
  }
  const admin = [['users', PAGES.users], ['audit', PAGES.audit], ['backup', PAGES.backup]].filter(([, p]) => p.roles.includes(role));
  if (admin.length) html += `<h2 class="nav-heading">الإدارة</h2><ul class="nav-group">` + admin.map(([h, p]) => `<li>${link(h, p.label)}</li>`).join('') + '</ul>';
  html += `<ul class="nav-group nav-foot"><li>${link('help', 'دليل الاستخدام')}</li></ul>`;
  $('#adminNav').innerHTML = html;
}
function markNav(hash) {
  const links = $$('#adminNav a[data-route]');
  let best = null;
  links.forEach(a => {
    const r = a.dataset.route;
    if ((hash === r || hash.startsWith(r + '/')) && (!best || r.length > best.dataset.route.length)) best = a;
  });
  links.forEach(a => a.toggleAttribute('aria-current', a === best));
  if (best) best.setAttribute('aria-current', 'page');
}

/* ---------- التوجيه ---------- */
let currentHash = null;
let renderToken = 0;
async function route(force) {
  const hash = (location.hash || '#/dashboard').replace(/^#\/?/, '') || 'dashboard';
  if (!force && hash === currentHash) return;
  if (ctx.dirty && currentHash !== null && !force) {
    const leave = await confirmDialog({ title: 'تعديلات غير محفوظة', message: 'لديك تعديلات لم تُحفظ في هذه الصفحة. هل تريد المغادرة وفقدانها؟', confirmLabel: 'المغادرة دون حفظ', danger: true });
    if (!leave) { history.replaceState(null, '', '#/' + currentHash); return; }
  }
  ctx.setDirty(false);
  currentHash = hash;
  const [page, ...rest] = hash.split('/');
  const def = PAGES[page];
  const main = ctx.main;
  markNav(hash);
  closeMobileNav();
  if (!def) { main.innerHTML = notice('الصفحة غير موجودة', 'اختر قسمًا من القائمة.'); return; }
  if (!def.roles.includes(ctx.role)) {
    main.innerHTML = notice('لا تملك صلاحية هذا القسم', `دورك الحالي: ${ROLE_LABELS[ctx.role]}. اطلب من المدير تعديل صلاحيتك إن احتجت هذا القسم.`);
    return;
  }
  const token = ++renderToken;
  main.innerHTML = '<p class="admin-loading">جارٍ التحميل…</p>';
  try {
    const mod = await def.load();
    if (token !== renderToken) return;
    await mod.render(ctx, rest);
  } catch (err) {
    console.error(err);
    if (token === renderToken) main.innerHTML = notice('تعذّر فتح هذا القسم', explainError(err));
  }
  if (token === renderToken) {
    const h = main.querySelector('h1, h2');
    if (h) { h.tabIndex = -1; h.focus({ preventScroll: true }); }
    window.scrollTo(0, 0);
  }
}
export function notice(title, text) {
  return `<section class="card empty"><h2>${esc(title)}</h2><p>${esc(text)}</p></section>`;
}
ctx.rerender = () => route(true);
/** تغيير العنوان دون إعادة فتح الصفحة (مثلًا بعد أول حفظ لعنصر جديد) */
ctx.replaceRoute = hash => { currentHash = hash; history.replaceState(null, '', '#/' + hash); markNav(hash); };

function closeMobileNav() {
  const t = $('#navToggle');
  t.setAttribute('aria-expanded', 'false');
  $('#adminNav').classList.remove('is-open');
}

/* ---------- الدخول ---------- */
function showLogin(msg) {
  $('#loginView').hidden = false;
  $('#appView').hidden = true;
  $('#loginForm').hidden = false;
  $('#registerForm').hidden = true;
  $('#gate').hidden = true;
  $('#loginErr').textContent = msg || '';
}
function showGate(kind, user) {
  $('#loginView').hidden = false;
  $('#appView').hidden = true;
  $('#loginForm').hidden = true;
  $('#registerForm').hidden = true;
  $('#gate').hidden = false;
  $('#gateErr').textContent = '';
  const verify = kind === 'verify';
  $('#gateKicker').textContent = verify ? 'خطوة مطلوبة' : 'لا توجد صلاحية';
  $('#gateTitle').textContent = verify ? 'وثّق بريدك الإلكتروني' : 'هذا الحساب لا يملك دورًا إداريًا';
  $('#gateText').textContent = verify
    ? `لا تُمنح الصلاحيات الإدارية إلا لبريد موثّق. اضغط «إرسال رابط التوثيق»، وافتح الرابط من بريد ${user.email}، ثم اضغط «وثّقت بريدي، تابع».`
    : `سجّلت الدخول بالبريد ${user.email}، لكن لم يُمنح له دور في لوحة الإدارة. اطلب من مدير حالي إضافة بريدك من «المستخدمون والصلاحيات». إنشاء الحساب وحده لا يمنح صلاحية. إن كنت طالبًا فاستخدم بوابة النتائج.`;
  $('#gateVerified').hidden = !verify;
  $('#gateResend').hidden = !verify;
}

async function main() {
  ctx.main = $('#adminMain');
  const form = $('#loginForm');
  let fb;
  try { fb = await firebaseReady(); }
  catch (err) {
    showLogin(explainError(err));
    $('#loginBtn').disabled = true;
    return;
  }
  ctx.fb = fb;
  const { auth, A } = fb;

  if (cfg.useEmulator) {
    $('#envNotice').hidden = false;
    $('#envNotice').textContent = 'وضع المحاكي المحلي: البيانات هنا تجريبية ولا تمس الموقع المنشور.';
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('#loginEmail').value.trim();
    const pass = $('#loginPass').value;
    if (!email || !pass) { $('#loginErr').textContent = 'اكتب البريد الإلكتروني وكلمة السر.'; return; }
    $('#loginErr').textContent = '';
    $('#loginBtn').disabled = true;
    try { await A.signInWithEmailAndPassword(auth, email, pass); $('#loginPass').value = ''; }
    catch (err) { $('#loginErr').textContent = explainError(err); }
    finally { $('#loginBtn').disabled = false; }
  });
  $('#showRegister').addEventListener('click', () => {
    form.hidden = true;
    $('#registerForm').hidden = false;
    $('#registerEmail').value = $('#loginEmail').value;
    $('#registerEmail').focus();
  });
  $('#showLogin').addEventListener('click', () => showLogin());
  $('#registerForm').addEventListener('submit', async e => {
    e.preventDefault();
    const email = emailKey($('#registerEmail').value);
    const password = $('#registerPass').value;
    const message = $('#registerErr');
    message.textContent = '';
    if (!S.EMAIL_RE.test(email)) { message.textContent = 'اكتب بريدك الإلكتروني الصحيح.'; return; }
    if (password.length < 8) { message.textContent = 'استخدم كلمة مرور خاصة بالموقع من ٨ أحرف على الأقل.'; return; }
    if (password !== $('#registerConfirm').value) { message.textContent = 'كلمتا المرور غير متطابقتين.'; return; }
    $('#registerBtn').disabled = true;
    try {
      const credential = await A.createUserWithEmailAndPassword(auth, email, password);
      e.target.reset();
      await A.sendEmailVerification(credential.user);
      $('#gateErr').textContent = 'أرسلنا رابط التوثيق إلى بريدك. افتحه ثم اضغط «وثّقت بريدي، تابع».';
    } catch (err) {
      if (auth.currentUser) $('#gateErr').textContent = explainError(err);
      else message.textContent = explainError(err);
    } finally { $('#registerBtn').disabled = false; }
  });
  $('#googleBtn').hidden = cfg.adminGoogleSignIn === false;
  $('#googleBtn').addEventListener('click', async () => {
    $('#loginErr').textContent = '';
    $('#googleBtn').disabled = true;
    try {
      const provider = new A.GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await A.signInWithPopup(auth, provider);
    } catch (err) { $('#loginErr').textContent = explainError(err); }
    finally { $('#googleBtn').disabled = false; }
  });
  $('#forgotBtn').addEventListener('click', async () => {
    const email = $('#loginEmail').value.trim();
    if (!email) { $('#loginErr').textContent = 'اكتب بريدك أولًا ثم اضغط «نسيت كلمة السر؟».'; $('#loginEmail').focus(); return; }
    try { await A.sendPasswordResetEmail(auth, email); $('#loginErr').textContent = 'إذا كان البريد مسجلًا فسيصلك رابط تغيير كلمة السر.'; }
    catch (err) { $('#loginErr').textContent = explainError(err); }
  });
  $('#gateResend').addEventListener('click', async () => {
    try { await A.sendEmailVerification(auth.currentUser); $('#gateErr').textContent = 'أُرسل الرابط. تحقق من بريدك (ومجلد الرسائل غير المرغوبة).'; }
    catch (err) { $('#gateErr').textContent = explainError(err); }
  });
  $('#gateVerified').addEventListener('click', async () => {
    try {
      await auth.currentUser.reload();
      if (!auth.currentUser.emailVerified) { $('#gateErr').textContent = 'لم يُوثَّق البريد بعد. افتح الرابط في بريدك ثم أعد المحاولة.'; return; }
      await auth.currentUser.getIdToken(true);
      onUser(auth.currentUser);
    } catch (err) { $('#gateErr').textContent = explainError(err); }
  });
  $('#gateSignOut').addEventListener('click', () => A.signOut(auth));
  $('#logoutBtn').addEventListener('click', async () => {
    if (ctx.dirty && !(await confirmDialog({ title: 'تعديلات غير محفوظة', message: 'ستفقد التعديلات غير المحفوظة. هل تريد الخروج؟', confirmLabel: 'خروج', danger: true }))) return;
    ctx.setDirty(false);
    await A.signOut(auth);
  });
  $('#navToggle').addEventListener('click', () => {
    const t = $('#navToggle');
    const open = t.getAttribute('aria-expanded') !== 'true';
    t.setAttribute('aria-expanded', String(open));
    $('#adminNav').classList.toggle('is-open', open);
  });

  let stopAccess = null;
  let authGeneration = 0;
  function clearAccess() {
    stopAccess?.();
    stopAccess = null;
    ctx.user = null; ctx.role = null; currentHash = null;
    ctx.setDirty(false);
    ++renderToken;
    ctx.main.innerHTML = '';
    $('#adminNav').innerHTML = '';
  }
  async function onUser(user) {
    const generation = ++authGeneration;
    clearAccess();
    if (!user) { showLogin(); return; }
    if (!user.emailVerified) { showGate('verify', user); return; }
    showLogin('جارٍ التحقق من صلاحيات الحساب…');
    let role;
    try { role = await resolveStaffRole(fb, user); }
    catch (err) { if (generation === authGeneration) showLogin(explainError(err)); return; }
    if (generation !== authGeneration) return;
    if (!role) { showGate('none', user); return; }
    ctx.user = user;
    ctx.role = role;
    $('#loginView').hidden = true;
    $('#appView').hidden = false;
    $('#who').textContent = user.email;
    $('#roleLabel').textContent = 'كلية الهندسة — جامعة دنقلا · ' + ROLE_LABELS[role];
    renderNav();
    route(true);
    // إزالة المدير من القائمة تُغلق لوحته المفتوحة أيضًا؛ الخادم يرفض عملياته فورًا.
    const ref = role === 'admin'
      ? fb.F.doc(fb.db, 'adminAccess', 'roster')
      : fb.F.doc(fb.db, 'staff', emailKey(user.email));
    stopAccess = fb.F.onSnapshot(ref, snapshot => {
      if (generation !== authGeneration || snapshot.metadata.fromCache) return;
      const data = snapshot.exists() ? snapshot.data() : null;
      const nextRole = role === 'admin'
        ? data?.emails?.includes(emailKey(user.email)) ? 'admin' : null
        : data?.active && STAFF_ROLES.includes(data.role) ? data.role : null;
      if (nextRole !== ctx.role) onUser(user);
    }, error => {
      if (generation !== authGeneration) return;
      if (error.code === 'permission-denied') onUser(user);
      else { clearAccess(); showLogin(explainError(error)); }
    });
  }
  A.onAuthStateChanged(auth, onUser);
  window.addEventListener('hashchange', () => { if (ctx.user) route(false); });
}

main();
