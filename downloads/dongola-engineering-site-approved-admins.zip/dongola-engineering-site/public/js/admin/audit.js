/* سجل التغييرات (للمدير): يُضاف إليه ولا يُعدَّل ولا يُحذف — تفرض ذلك قواعد الخادم */
import { $, esc, fmtTime } from './util.js';

export const ACTIONS = {
  'create-draft': 'إنشاء مسودة', publish: 'نشر', republish: 'تحديث المنشور', unpublish: 'إلغاء النشر', delete: 'حذف',
  'create-batch': 'إنشاء نتيجة', 'save-batch': 'حفظ نتيجة', 'publish-batch': 'نشر نتيجة للطلاب', 'unpublish-batch': 'إخفاء نتيجة',
  'delete-batch': 'حذف نتيجة', 'import-batch': 'استيراد نتيجة', 'migrate-batch': 'ترحيل نتيجة', 'issue-codes': 'إصدار رموز تفعيل',
  'revoke-link': 'إلغاء ربط حساب طالب', 'grant-role': 'منح دور', 'change-role': 'تعديل دور', 'remove-role': 'إزالة دور',
  'backup-content': 'نسخة احتياطية للمحتوى', 'backup-results': 'نسخة احتياطية للنتائج', 'restore-content': 'استعادة المحتوى',
  'restore-results': 'استعادة النتائج', 'import-initial': 'استيراد المحتوى الأولي'
};
const AREAS = { content: 'المحتوى', results: 'النتائج', users: 'المستخدمون', backup: 'النسخ الاحتياطي' };

export async function render(ctx) {
  const { db, F } = ctx.fb;
  ctx.main.innerHTML = `
    <section class="page-intro"><div><h1>سجل التغييرات</h1><p>كل نشر وحذف وتعديل للنتائج والصلاحيات يُسجَّل هنا مع البريد والوقت. السجل للإطلاع فقط ولا يمكن تعديله.</p></div></section>
    <section class="card">
      <form class="list-tools" aria-label="تصفية السجل">
        <label>المجال <select id="aArea"><option value="">الكل</option>${Object.entries(AREAS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></label>
        <label>بحث <input type="search" id="aSearch" placeholder="بريد أو عنوان" autocomplete="off"></label>
        <p class="list-count" id="aCount" role="status" aria-live="polite"></p>
      </form>
      <div class="scroll table-card"><table class="list-table"><thead><tr><th scope="col">الوقت</th><th scope="col">المستخدم</th><th scope="col">الدور</th><th scope="col">المجال</th><th scope="col">الإجراء</th><th scope="col">التفاصيل</th></tr></thead><tbody id="aBody"><tr><td colspan="6">جارٍ التحميل…</td></tr></tbody></table></div>
      <p class="hint">يعرض آخر ٣٠٠ عملية. للأرشيف الكامل استخدم النسخة الاحتياطية من سطر الأوامر (انظر الدليل).</p>
    </section>`;
  const snap = await F.getDocs(F.query(F.collection(db, 'audit'), F.orderBy('at', 'desc'), F.limit(300)));
  const rows = snap.docs.map(d => d.data());
  const { ROLE_LABELS } = await import('./app.js');
  function draw() {
    const area = $('#aArea').value;
    const q = $('#aSearch').value.trim().toLowerCase();
    const list = rows.filter(a => (!area || a.area === area) && (!q || `${a.email} ${a.summary} ${a.target}`.toLowerCase().includes(q)));
    $('#aCount').textContent = `${list.length} عملية`;
    $('#aBody').innerHTML = list.map(a => `<tr><td>${esc(fmtTime(a.at))}</td><td dir="ltr">${esc(a.email)}</td><td>${esc(ROLE_LABELS[a.role] || a.role)}</td><td>${esc(AREAS[a.area] || a.area)}</td><td>${esc(ACTIONS[a.action] || a.action)}</td><td>${esc(a.summary)}<br><small class="muted" dir="ltr">${esc(a.target)}</small></td></tr>`).join('')
      || '<tr><td colspan="6" class="empty-row">لا توجد عمليات مطابقة.</td></tr>';
  }
  $('#aArea').addEventListener('change', draw);
  $('#aSearch').addEventListener('input', draw);
  draw();
}
