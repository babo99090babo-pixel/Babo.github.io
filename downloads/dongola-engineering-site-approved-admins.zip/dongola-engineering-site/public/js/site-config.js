/* ============================================================
   إعدادات الموقع العامة — كلية الهندسة، جامعة دنقلا
   قيم Firebase هنا ليست سرية (تظهر في أي موقع يستخدم Firebase)؛
   الحماية الفعلية في قواعد firestore.rules على الخادم.
   لا تضع هنا أي مفتاح خادم (service account) أو كلمة سر.
   ============================================================ */
window.SITE_CONFIG = {
  siteName: 'كلية الهندسة — جامعة دنقلا',
  // عنوان الموقع المنشور. غيّره عند ربط نطاق الجامعة (ثم أعد توليد الصفحات: npm run build).
  siteUrl: 'https://dongola-eng.web.app',
  // نطاق البريد المؤسسي (مثل uofd.edu.sd). عند ضبطه تنبّه اللوحة إلى أي بريد خارجه.
  institutionalEmailDomain: '',
  // يتطلب تفعيل Google في Firebase Authentication. يمكن إخفاؤه عند استخدام البريد وكلمة المرور فقط.
  adminGoogleSignIn: true,
  firebase: {
    apiKey: 'AIzaSyDreu8tbJync_OG5eZfuoEh8J4c4LQjLao',
    authDomain: 'dongola-eng.firebaseapp.com',
    projectId: 'dongola-eng',
    storageBucket: 'dongola-eng.firebasestorage.app',
    messagingSenderId: '254083168152',
    appId: '1:254083168152:web:42b096f05fa87c5d471ded'
  },
  sdkVersion: '12.19.0',
  // رفع الملفات مباشرةً يتطلب تفعيل Cloud Storage (خطة Blaze). عند false تُضاف الملفات بروابط.
  storageUploads: false,
  // المحاكي المحلي للتجربة فقط: يعمل على localhost عند فتح أي صفحة بـ ?emulator=1
  emulator: { projectId: 'demo-dongola', host: '127.0.0.1', authPort: 9099, firestorePort: 8080 }
};

(function () {
  'use strict';
  var cfg = window.SITE_CONFIG;
  var local = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  var flag = null;
  try {
    var params = new URLSearchParams(location.search);
    if (params.has('emulator')) sessionStorage.setItem('useEmulator', params.get('emulator') === '0' ? '0' : '1');
    flag = sessionStorage.getItem('useEmulator');
  } catch (e) { /* التخزين غير متاح */ }
  cfg.useEmulator = local && flag === '1';
  if (cfg.useEmulator) {
    cfg.firebase = Object.assign({}, cfg.firebase, { apiKey: 'demo-api-key', projectId: cfg.emulator.projectId, authDomain: cfg.emulator.projectId + '.firebaseapp.com' });
  }
})();
