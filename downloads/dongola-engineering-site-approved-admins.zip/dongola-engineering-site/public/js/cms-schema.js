/* ============================================================
   مخطط المحتوى — يحدد أنواع المحتوى وحقولها وقواعد التحقق.
   تستخدمه لوحة الإدارة لبناء النماذج، والصفحات العامة للعرض.
   ============================================================ */
(function (root) {
  'use strict';

  const DEPARTMENTS = [
    { id: 'civil', name: 'الهندسة المدنية', spec: 'هندسة مدنية', number: '01',
      summary: 'الإنشاءات والطرق والموارد المائية والمساحة، مع تركيز على مشاريع الري والجسور في الولاية الشمالية.',
      icon: '<path d="M3 21h18M5 21V9l7-6 7 6v12M9 21v-6h6v6M9 10h6"/>' },
    { id: 'electrical', name: 'الهندسة الكهربائية', spec: 'هندسة كهربائية', number: '02',
      summary: 'توليد الطاقة ونقلها وتوزيعها، والآلات الكهربائية، وشبكات الجهد المنخفض والمتوسط.',
      icon: '<path d="m13 2-9 12h7l-1 8 10-12h-7l1-8Z"/>' },
    { id: 'control', name: 'هندسة التحكم', spec: 'هندسة التحكم', number: '03',
      summary: 'أنظمة التحكم الآلي والقياس والأتمتة الصناعية والمتحكمات المنطقية القابلة للبرمجة.',
      icon: '<path d="M5 3v5m0 4v9M12 3v9m0 4v5M19 3v2m0 4v12M2 8h6m1 8h6m1-11h6"/>' },
    { id: 'computer', name: 'هندسة الحاسوب', spec: 'هندسة الحاسوب', number: '04',
      summary: 'العتاد والبرمجيات والشبكات وأنظمة التشغيل وبناء التطبيقات وقواعد البيانات.',
      icon: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4m-4-12-2 2 2 2m8-4 2 2-2 2"/>' },
    { id: 'communications', name: 'هندسة الاتصالات', spec: 'هندسة الاتصالات', number: '05',
      summary: 'شبكات الاتصال السلكية واللاسلكية ومعالجة الإشارات وأنظمة الإرسال والاستقبال.',
      icon: '<circle cx="12" cy="10" r="2"/><path d="m12 12-4 10m4-10 4 10M5 3a10 10 0 0 0 0 14M19 3a10 10 0 0 1 0 14M8 6a6 6 0 0 0 0 8m8-8a6 6 0 0 1 0 8M9.5 18h5"/>' }
  ];

  const SEMESTERS = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر']
    .map(s => 'الفصل الدراسي ' + s);

  /* ---------- أدوات بناء الحقول ---------- */
  const f = {
    title: (label = 'العنوان', hint) => ({ key: 'title', label, type: 'text', required: true, max: 200, hint }),
    summary: (label = 'ملخص قصير', required = true) => ({ key: 'summary', label, type: 'textarea', rows: 3, required, max: 400, hint: 'يظهر في البطاقات ونتائج البحث ومعاينات المشاركة. جملة أو جملتان.' }),
    body: (label = 'النص الكامل', required = false) => ({ key: 'body', label, type: 'richtext', required, max: 30000 }),
    date: (key = 'date', label = 'التاريخ', required = true) => ({ key, label, type: 'date', required }),
    dept: (required = false) => ({ key: 'department', label: 'القسم', type: 'department', required }),
    image: () => ({ key: 'image', label: 'صورة', type: 'image', hint: 'صورة حقيقية مأذون بنشرها فقط. يُفضَّل WebP أو JPG بعرض لا يقل عن 1200 بكسل.' }),
    imageAlt: (required = false) => ({ key: 'imageAlt', label: 'وصف الصورة', type: 'text', max: 200, required, hint: 'وصف قصير لما في الصورة لمن يستخدم قارئ الشاشة.' }),
    attachments: (label = 'المرفقات', required = false, hint) => ({ key: 'attachments', label, type: 'attachments', required, hint: hint || 'مستندات معتمدة فقط (PDF أو Word أو Excel أو صور).' }),
    year: (required = true) => ({ key: 'academicYear', label: 'العام الدراسي', type: 'text', required, pattern: '^\\d{4}/\\d{4}$', placeholder: '2026/2027', dir: 'ltr', hint: 'بالصيغة 2026/2027.' })
  };

  const TYPES = {
    news: {
      label: 'الأخبار والإعلانات', singular: 'خبر أو إعلان', group: 'news', roles: ['admin', 'editor', 'news'],
      description: 'الأخبار والإعلانات الرسمية. تظهر في صفحة الأخبار، وأحدثها في الصفحة الرئيسية.',
      fields: [
        f.title(),
        { key: 'kind', label: 'النوع', type: 'select', required: true, options: [['news', 'خبر'], ['announcement', 'إعلان']], default: 'news' },
        { key: 'category', label: 'التصنيف', type: 'select', required: true,
          options: ['شؤون أكاديمية', 'القبول والتسجيل', 'الامتحانات والنتائج', 'حياة جامعية', 'البحث العلمي', 'فعاليات وأنشطة', 'إعلانات إدارية'] },
        f.date('date', 'تاريخ النشر'),
        f.dept(),
        f.summary(),
        f.body(),
        f.image(), f.imageAlt(),
        f.attachments(),
        { key: 'pinned', label: 'تثبيت في أعلى قائمة الأخبار', type: 'checkbox' }
      ],
      columns: ['date', 'category'],
      sort: (a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || String(b.date || '').localeCompare(String(a.date || ''))
    },

    departments: {
      label: 'الأقسام العلمية', singular: 'قسم', group: 'academic', roles: ['admin', 'editor'],
      description: 'صفحة مستقلة لكل قسم: التعريف والبرامج ورئيس القسم والخطة والمقررات والمعامل ومجالات العمل.',
      fixed: DEPARTMENTS.map(d => ({ id: d.id, title: d.name, summary: d.summary })),
      allowNew: true,
      fields: [
        f.title('اسم القسم'),
        f.summary('نبذة قصيرة'),
        { key: 'about', label: 'التعريف بالقسم', type: 'richtext', max: 20000 },
        { key: 'programs', label: 'البرامج والدرجات العلمية', type: 'repeater', addLabel: 'إضافة برنامج',
          fields: [
            { key: 'name', label: 'اسم البرنامج', type: 'text', required: true, max: 200 },
            { key: 'degree', label: 'الدرجة الممنوحة', type: 'text', max: 200 },
            { key: 'duration', label: 'مدة الدراسة', type: 'text', max: 100 },
            { key: 'notes', label: 'ملاحظات', type: 'text', max: 300 }
          ] },
        { key: 'headName', label: 'رئيس القسم — الاسم', type: 'text', max: 150 },
        { key: 'headTitle', label: 'رئيس القسم — الدرجة العلمية', type: 'text', max: 100 },
        { key: 'headEmail', label: 'رئيس القسم — البريد المؤسسي', type: 'email' },
        { key: 'headProfile', label: 'صفحة رئيس القسم في دليل هيئة التدريس', type: 'facultyRef', hint: 'اختياري: اختر العضو إن كانت صفحته منشورة.' },
        { key: 'studyPlan', label: 'الخطة الدراسية', type: 'richtext', max: 20000, hint: 'ملخص الخطة، ويمكن إرفاق الخطة المعتمدة كاملة في الحقل التالي.' },
        f.attachments('ملفات الخطة الدراسية المعتمدة'),
        { key: 'courses', label: 'توصيف المقررات', type: 'repeater', addLabel: 'إضافة مقرر',
          fields: [
            { key: 'code', label: 'رمز المقرر', type: 'text', max: 30, dir: 'ltr' },
            { key: 'name', label: 'اسم المقرر', type: 'text', required: true, max: 200 },
            { key: 'hours', label: 'الساعات المعتمدة', type: 'number', min: 0, max: 12 },
            { key: 'semester', label: 'الفصل الدراسي', type: 'select', options: SEMESTERS },
            { key: 'description', label: 'وصف المقرر', type: 'textarea', max: 1500 }
          ] },
        { key: 'labs', label: 'معامل القسم', type: 'repeater', addLabel: 'إضافة معمل',
          fields: [
            { key: 'name', label: 'اسم المعمل', type: 'text', required: true, max: 200 },
            { key: 'description', label: 'الوصف', type: 'textarea', max: 1000 }
          ] },
        { key: 'careers', label: 'مجالات العمل', type: 'richtext', max: 10000 },
        { key: 'contactEmail', label: 'بريد القسم', type: 'email' }
      ],
      columns: ['summary']
    },

    faculty: {
      label: 'هيئة التدريس', singular: 'عضو هيئة تدريس', group: 'academic', roles: ['admin', 'editor'],
      description: 'دليل أعضاء هيئة التدريس. لا تُنشر بيانات عضو أو صورته إلا بعد موافقته.',
      fields: [
        f.title('الاسم الكامل'),
        { key: 'academicTitle', label: 'اللقب العلمي', type: 'select', required: true,
          options: ['بروفيسور', 'أستاذ مشارك', 'أستاذ مساعد', 'محاضر', 'مساعد تدريس', 'مهندس معمل', 'أخرى'] },
        { key: 'degree', label: 'أعلى مؤهل', type: 'select', options: ['دكتوراه', 'ماجستير', 'بكالوريوس', 'أخرى'] },
        f.dept(true),
        { key: 'position', label: 'المنصب الإداري', type: 'text', max: 150, hint: 'مثل: عميد الكلية، رئيس القسم. اتركه فارغًا إن لم يوجد.' },
        { key: 'specialization', label: 'التخصص الدقيق', type: 'text', required: true, max: 200 },
        { key: 'email', label: 'البريد المؤسسي', type: 'email', institutional: true },
        { key: 'office', label: 'المكتب', type: 'text', max: 120 },
        { key: 'photo', label: 'الصورة الشخصية', type: 'image', hint: 'صورة رسمية بموافقة العضو. اتركها فارغة لعرض رمز بديل.' },
        { key: 'bio', label: 'السيرة المختصرة', type: 'richtext', max: 10000 },
        { key: 'interests', label: 'الاهتمامات البحثية', type: 'list', hint: 'مجال في كل سطر.' },
        { key: 'publications', label: 'الأبحاث والمنشورات', type: 'repeater', addLabel: 'إضافة بحث',
          fields: [
            { key: 'title', label: 'عنوان البحث', type: 'text', required: true, max: 300 },
            { key: 'year', label: 'السنة', type: 'number', min: 1950, max: 2100 },
            { key: 'venue', label: 'المجلة أو المؤتمر', type: 'text', max: 300 },
            { key: 'url', label: 'الرابط', type: 'url' }
          ] },
        { key: 'order', label: 'ترتيب العرض', type: 'number', min: 0, max: 9999, hint: 'الأصغر يظهر أولًا داخل القسم.' },
        { key: 'consent', label: 'وافق العضو على نشر هذه البيانات والصورة', type: 'checkbox', requiredToPublish: true }
      ],
      columns: ['department', 'academicTitle'],
      sort: (a, b) => (Number(a.order ?? 9999) - Number(b.order ?? 9999)) || String(a.title).localeCompare(String(b.title), 'ar')
    },

    pages: {
      label: 'الصفحات المؤسسية', singular: 'صفحة', group: 'institution', roles: ['admin', 'editor'],
      description: 'نصوص الصفحات الثابتة. لا يُنشر نص إلا بعد اعتماده من الجهة المختصة بالكلية.',
      fixed: [
        { id: 'about', title: 'التعريف بالكلية', path: 'about.html', template: '## نبذة عن الكلية\n\n\n## ما تقدمه الكلية\n\n- ' },
        { id: 'vision', title: 'الرؤية والرسالة والأهداف', path: 'vision.html', template: '## الرؤية\n\n\n## الرسالة\n\n\n## الأهداف\n\n- ' },
        { id: 'structure', title: 'الهيكل الإداري', path: 'structure.html', template: '## عمادة الكلية\n\n\n## الأقسام العلمية\n\n\n## اللجان والمكاتب\n\n- ' },
        { id: 'history', title: 'تاريخ الكلية', path: 'history.html', template: '## التأسيس\n\n\n## محطات بارزة\n\n- ' },
        { id: 'admission', title: 'شروط القبول والتسجيل', path: 'admission.html', template: '## شروط القبول\n\n- \n\n## خطوات التسجيل\n\n1. \n\n## المستندات المطلوبة\n\n- \n\n## الرسوم الدراسية\n\n' },
        { id: 'privacy', title: 'سياسة الخصوصية', path: 'privacy.html', template: '' }
      ],
      allowNew: false,
      fields: [
        f.title('عنوان الصفحة'),
        f.summary('مقدمة قصيرة', false),
        f.body('نص الصفحة', true),
        f.attachments('مستندات مرتبطة'),
        { key: 'approvedBy', label: 'الجهة التي اعتمدت النص', type: 'text', max: 200, requiredToPublish: true, hint: 'مثل: مجلس الكلية، العمادة. مطلوب قبل النشر.' },
        { key: 'approvedAt', label: 'تاريخ الاعتماد', type: 'date' }
      ],
      columns: ['approvedBy']
    },

    calendar: {
      label: 'التقويم الأكاديمي', singular: 'موعد', group: 'students', roles: ['admin', 'editor'],
      description: 'مواعيد العام الدراسي المعتمدة: بداية الدراسة والتسجيل والامتحانات والعطلات.',
      fields: [
        f.title('الموعد'),
        f.year(),
        { key: 'category', label: 'التصنيف', type: 'select', required: true, options: ['الدراسة', 'التسجيل', 'الامتحانات', 'النتائج', 'العطلات', 'فعاليات', 'أخرى'] },
        f.date('startDate', 'يبدأ في'),
        f.date('endDate', 'ينتهي في', false),
        { key: 'notes', label: 'ملاحظات', type: 'textarea', max: 600 }
      ],
      columns: ['startDate', 'category'],
      sort: (a, b) => String(a.startDate || '').localeCompare(String(b.startDate || ''))
    },

    schedules: {
      label: 'جداول الدراسة والامتحانات', singular: 'جدول', group: 'students', roles: ['admin', 'editor'],
      description: 'جداول المحاضرات والامتحانات لكل فصل وقسم، مع ملف الجدول المعتمد.',
      fields: [
        f.title('عنوان الجدول'),
        { key: 'kind', label: 'نوع الجدول', type: 'select', required: true, options: [['study', 'جدول المحاضرات'], ['exam', 'جدول الامتحانات']] },
        f.year(),
        { key: 'semester', label: 'الفصل الدراسي', type: 'select', options: SEMESTERS },
        f.dept(),
        { key: 'round', label: 'الدور (للامتحانات)', type: 'select', options: [['1', 'الدور الأول'], ['2', 'الدور الثاني']] },
        f.date('effectiveDate', 'يسري من', false),
        { key: 'body', label: 'الجدول أو ملاحظات', type: 'richtext', max: 20000, hint: 'يمكن كتابة الجدول بصيغة الجدول النصي (انظر دليل التنسيق)، أو إرفاق ملفه.' },
        f.attachments('ملف الجدول المعتمد')
      ],
      columns: ['kind', 'academicYear'],
      sort: (a, b) => String(b.academicYear || '').localeCompare(String(a.academicYear || '')) || String(b.effectiveDate || '').localeCompare(String(a.effectiveDate || '')),
      custom: d => (!d.body && !(d.attachments || []).length) ? [{ key: 'attachments', message: 'أرفق ملف الجدول أو اكتبه في حقل «الجدول أو ملاحظات».' }] : []
    },

    documents: {
      label: 'اللوائح والنماذج', singular: 'مستند', group: 'students', roles: ['admin', 'editor'],
      description: 'اللوائح والنماذج والأدلة المعتمدة القابلة للتنزيل، مع توضيح وظيفة كل نموذج.',
      fields: [
        f.title('اسم المستند'),
        { key: 'kind', label: 'النوع', type: 'select', required: true, options: [['regulation', 'لائحة'], ['form', 'نموذج'], ['guide', 'دليل'], ['circular', 'تعميم']] },
        { key: 'purpose', label: 'وظيفة المستند', type: 'textarea', required: true, max: 800, hint: 'لماذا يُستخدم هذا المستند ومن يحتاجه.' },
        { key: 'howToUse', label: 'طريقة الاستخدام أو التقديم', type: 'textarea', max: 1200, hint: 'مثال: يُطبع ويُعبّأ ويُسلَّم إلى مكتب الشؤون العلمية. مطلوب للنماذج.' },
        f.dept(),
        { key: 'version', label: 'رقم الإصدار', type: 'text', max: 40 },
        { key: 'approvedBy', label: 'جهة الاعتماد', type: 'text', max: 200 },
        f.date('approvedAt', 'تاريخ الاعتماد', false),
        f.attachments('ملف المستند', true)
      ],
      columns: ['kind', 'approvedAt'],
      custom: d => d.kind === 'form' && !String(d.howToUse || '').trim() ? [{ key: 'howToUse', message: 'وضّح طريقة استخدام النموذج وأين يُسلَّم.' }] : []
    },

    services: {
      label: 'روابط الخدمات الرسمية', singular: 'رابط خدمة', group: 'students', roles: ['admin', 'editor'],
      description: 'روابط الخدمات الإلكترونية الرسمية للجامعة (التسجيل، الرسوم، البريد…). أضف الروابط الرسمية فقط.',
      fields: [
        f.title('اسم الخدمة'),
        { key: 'description', label: 'ماذا تقدم الخدمة', type: 'textarea', required: true, max: 400 },
        { key: 'url', label: 'الرابط الرسمي', type: 'url', required: true, httpsOnly: true },
        { key: 'audience', label: 'الفئة', type: 'select', options: ['الطلاب الحاليون', 'المتقدمون للقبول', 'الخريجون', 'الجميع'] },
        { key: 'order', label: 'ترتيب العرض', type: 'number', min: 0, max: 999 }
      ],
      columns: ['audience', 'url'],
      sort: (a, b) => Number(a.order ?? 999) - Number(b.order ?? 999)
    },

    research: {
      label: 'البحث العلمي', singular: 'بحث', group: 'research', roles: ['admin', 'editor'],
      description: 'الأبحاث المنشورة لأعضاء الكلية مع بيانات النشر.',
      fields: [
        f.title('عنوان البحث'),
        { key: 'authors', label: 'المؤلفون', type: 'text', required: true, max: 400 },
        { key: 'year', label: 'سنة النشر', type: 'number', required: true, min: 1950, max: 2100 },
        { key: 'kind', label: 'النوع', type: 'select', options: ['ورقة علمية', 'ورقة مؤتمر', 'رسالة جامعية', 'كتاب أو فصل', 'تقرير فني'] },
        { key: 'venue', label: 'المجلة أو المؤتمر', type: 'text', max: 300 },
        f.dept(),
        { key: 'abstract', label: 'الملخص', type: 'richtext', max: 8000 },
        { key: 'url', label: 'رابط النشر أو DOI', type: 'url' },
        f.attachments()
      ],
      columns: ['year', 'authors'],
      sort: (a, b) => Number(b.year || 0) - Number(a.year || 0)
    },

    projects: {
      label: 'مشاريع التخرج', singular: 'مشروع', group: 'research', roles: ['admin', 'editor'],
      description: 'مشاريع تخرج الطلاب. لا تُنشر أسماء الطلاب إلا بموافقتهم.',
      fields: [
        f.title('عنوان المشروع'),
        f.year(),
        f.dept(true),
        { key: 'supervisor', label: 'المشرف', type: 'text', max: 200 },
        { key: 'students', label: 'أسماء الطلاب', type: 'list', hint: 'اسم في كل سطر. اتركه فارغًا إن لم يوافق الطلاب على النشر.' },
        { key: 'studentsConsent', label: 'وافق الطلاب على نشر أسمائهم', type: 'checkbox' },
        f.summary(),
        f.body('وصف المشروع'),
        f.image(), f.imageAlt(),
        f.attachments()
      ],
      columns: ['academicYear', 'department'],
      sort: (a, b) => String(b.academicYear || '').localeCompare(String(a.academicYear || '')),
      custom: d => (d.students || []).length && !d.studentsConsent ? [{ key: 'studentsConsent', message: 'أكّد موافقة الطلاب على نشر أسمائهم، أو احذف الأسماء.' }] : []
    },

    labs: {
      label: 'المعامل', singular: 'معمل', group: 'research', roles: ['admin', 'editor'],
      description: 'معامل الكلية وتجهيزاتها.',
      fields: [
        f.title('اسم المعمل'),
        f.dept(),
        f.summary(),
        f.body('الوصف والتجارب'),
        { key: 'equipment', label: 'أهم التجهيزات', type: 'list', hint: 'جهاز في كل سطر.' },
        { key: 'location', label: 'الموقع', type: 'text', max: 200 },
        { key: 'supervisor', label: 'المشرف على المعمل', type: 'text', max: 200 },
        f.image(), f.imageAlt()
      ],
      columns: ['department']
    },

    activities: {
      label: 'الأنشطة والفعاليات', singular: 'نشاط', group: 'news', roles: ['admin', 'editor', 'news'],
      description: 'الندوات وورش العمل والزيارات الميدانية والأنشطة الطلابية.',
      fields: [
        f.title('عنوان النشاط'),
        f.date('date', 'تاريخ النشاط'),
        { key: 'category', label: 'النوع', type: 'select', required: true, options: ['ندوة', 'ورشة عمل', 'زيارة ميدانية', 'محاضرة عامة', 'مسابقة', 'نشاط طلابي', 'أخرى'] },
        f.dept(),
        f.summary(),
        f.body(),
        f.image(), f.imageAlt(),
        f.attachments()
      ],
      columns: ['date', 'category'],
      sort: (a, b) => String(b.date || '').localeCompare(String(a.date || ''))
    },

    partners: {
      label: 'الشراكات', singular: 'شراكة', group: 'research', roles: ['admin', 'editor'],
      description: 'الجهات الشريكة للكلية. لا تُنشر شراكة إلا باتفاقية أو مذكرة تفاهم موثقة.',
      fields: [
        f.title('اسم الجهة'),
        { key: 'kind', label: 'نوع الجهة', type: 'select', required: true, options: ['جامعة أو مؤسسة أكاديمية', 'شركة أو جهة صناعية', 'جهة حكومية', 'منظمة'] },
        { key: 'description', label: 'مجال الشراكة', type: 'textarea', required: true, max: 800 },
        { key: 'since', label: 'منذ عام', type: 'number', min: 1950, max: 2100 },
        { key: 'url', label: 'موقع الجهة', type: 'url' },
        { key: 'logo', label: 'شعار الجهة', type: 'image', hint: 'بإذن الجهة.' },
        f.attachments('وثيقة الاتفاقية أو مذكرة التفاهم'),
        { key: 'documented', label: 'توجد اتفاقية أو مذكرة تفاهم موثقة', type: 'checkbox', requiredToPublish: true }
      ],
      columns: ['kind', 'since']
    },

    accreditations: {
      label: 'الاعتمادات', singular: 'اعتماد', group: 'institution', roles: ['admin', 'editor'],
      description: 'الاعتمادات الأكاديمية والمهنية. لا يُنشر اعتماد دون وثيقة رسمية.',
      fields: [
        f.title('اسم الاعتماد'),
        { key: 'issuer', label: 'الجهة المانحة', type: 'text', required: true, max: 200 },
        { key: 'status', label: 'الحالة', type: 'select', required: true, options: ['ساري', 'قيد الإجراء', 'منتهٍ'] },
        f.date('grantedAt', 'تاريخ المنح', false),
        f.date('expiresAt', 'ينتهي في', false),
        { key: 'scope', label: 'نطاق الاعتماد', type: 'textarea', max: 800, hint: 'البرامج أو الأقسام المشمولة.' },
        { key: 'url', label: 'رابط التحقق لدى الجهة المانحة', type: 'url' },
        f.attachments('الوثيقة الرسمية', true)
      ],
      columns: ['issuer', 'status']
    },

    gallery: {
      label: 'معرض الصور', singular: 'صورة', group: 'news', roles: ['admin', 'editor', 'news'],
      description: 'صور حقيقية من الكلية وفعالياتها، بإذن من يظهر فيها.',
      fields: [
        f.title('عنوان الصورة'),
        { key: 'image', label: 'الصورة', type: 'image', required: true },
        f.imageAlt(true),
        f.date('date', 'تاريخ الالتقاط', false),
        { key: 'album', label: 'الألبوم', type: 'text', max: 100, hint: 'مثل: حفل التخريج ٢٠٢٦.' },
        { key: 'caption', label: 'تعليق', type: 'textarea', max: 400 },
        { key: 'consent', label: 'الصورة حقيقية ومأذون بنشرها', type: 'checkbox', requiredToPublish: true }
      ],
      columns: ['album', 'date'],
      sort: (a, b) => String(b.date || '').localeCompare(String(a.date || ''))
    },

    settings: {
      label: 'إعدادات الموقع', singular: 'إعدادات', group: 'institution', roles: ['admin', 'editor'],
      description: 'بيانات التواصل وأرقام الكلية وكلمة العميد كما تظهر في الصفحة الرئيسية.',
      fixed: [{ id: 'site', title: 'إعدادات الموقع' }],
      allowNew: false,
      fields: [
        { key: 'title', label: 'اسم الإعداد', type: 'text', required: true, max: 100, readonly: true },
        { key: 'aboutIntro', label: 'نبذة الكلية (الصفحة الرئيسية)', type: 'textarea', max: 800 },
        { key: 'address', label: 'العنوان', type: 'textarea', rows: 2, max: 300 },
        { key: 'phone', label: 'الهاتف', type: 'text', max: 40, dir: 'ltr', placeholder: '+249 …' },
        { key: 'email', label: 'البريد الإلكتروني للتواصل', type: 'email', institutional: true },
        { key: 'facebook', label: 'صفحة فيسبوك', type: 'url', httpsOnly: true },
        { key: 'workingHours', label: 'ساعات العمل', type: 'text', max: 150 },
        { key: 'mapUrl', label: 'رابط الموقع على الخريطة', type: 'url', httpsOnly: true },
        { key: 'facts', label: 'الكلية في أرقام', type: 'repeater', addLabel: 'إضافة رقم', hint: 'لا يظهر في الموقع إلا الرقم المعلَّم «موثَّق رسميًا».',
          fields: [
            { key: 'value', label: 'الرقم', type: 'text', required: true, max: 20 },
            { key: 'label', label: 'الوصف', type: 'text', required: true, max: 60 },
            { key: 'source', label: 'مصدر التوثيق', type: 'text', max: 150 },
            { key: 'verified', label: 'موثَّق رسميًا', type: 'checkbox' }
          ] },
        { key: 'deanName', label: 'اسم العميد', type: 'text', max: 150 },
        { key: 'deanTitle', label: 'صفة العميد', type: 'text', max: 100 },
        { key: 'deanMessage', label: 'كلمة العميد', type: 'textarea', max: 1500 },
        { key: 'deanVerified', label: 'الاسم والكلمة معتمدان من العمادة', type: 'checkbox' }
      ],
      columns: []
    }
  };

  const GROUPS = {
    news: 'الأخبار والأنشطة',
    academic: 'الأقسام وهيئة التدريس',
    students: 'القبول وخدمات الطلاب',
    research: 'البحث العلمي والمشاريع',
    institution: 'الكلية'
  };

  /* ---------- التحقق ---------- */
  const EMAIL_RE = /^[^\s@/]+@[^\s@/]+\.[^\s@/]+$/;
  const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
  const ALLOWED_FILES = /\.(pdf|docx?|xlsx?|pptx?|png|jpe?g|webp)(\?.*)?$/i;

  function isSafeUrl(url, httpsOnly) {
    const u = String(url || '').trim();
    if (!u) return false;
    if (/^https:\/\//i.test(u)) return true;
    if (!httpsOnly && /^http:\/\//i.test(u)) return true;
    if (!httpsOnly && /^(files|images)\/[\w\-./]+$/i.test(u) && !u.includes('..')) return true;
    return false;
  }

  function fieldErrors(field, value, data, phase) {
    const out = [];
    const empty = value == null || value === '' || (Array.isArray(value) && !value.length) || value === false;
    // المسودة تُحفظ ناقصة؛ الحقول المطلوبة تُفرض عند النشر (والعنوان دائمًا)
    if (field.required && empty && field.type !== 'checkbox' && (phase === 'publish' || field.key === 'title')) out.push('هذا الحقل مطلوب.');
    if (field.requiredToPublish && phase === 'publish' && empty) {
      out.push(field.type === 'checkbox' ? 'يجب تأكيد هذا البند قبل النشر.' : 'هذا الحقل مطلوب قبل النشر.');
    }
    if (empty) return out;
    const s = typeof value === 'string' ? value : '';
    if (field.max && s.length > field.max) out.push(`الحد الأقصى ${field.max} حرفًا (المكتوب ${s.length}).`);
    if (field.pattern && s && !new RegExp(field.pattern).test(s)) out.push('الصيغة غير صحيحة' + (field.placeholder ? ` (مثال: ${field.placeholder}).` : '.'));
    switch (field.type) {
      case 'email': if (!EMAIL_RE.test(s)) out.push('اكتب بريدًا إلكترونيًا صحيحًا.'); break;
      case 'url': if (!isSafeUrl(s, field.httpsOnly)) out.push(field.httpsOnly ? 'الرابط يجب أن يبدأ بـ https://' : 'الرابط يجب أن يبدأ بـ https:// أو يشير إلى ملف داخل الموقع (files/…).'); break;
      case 'image': if (!isSafeUrl(s, false) || !/\.(png|jpe?g|webp|svg)(\?.*)?$|^https:\/\/firebasestorage\.googleapis\.com\//i.test(s)) out.push('رابط صورة غير صالح (PNG أو JPG أو WebP).'); break;
      case 'date': if (!DATE_RE.test(s) || isNaN(Date.parse(s))) out.push('تاريخ غير صالح.'); break;
      case 'number': {
        const n = Number(value);
        if (!isFinite(n)) out.push('اكتب رقمًا.');
        else {
          if (field.min != null && n < field.min) out.push(`أقل قيمة ${field.min}.`);
          if (field.max != null && n > field.max) out.push(`أكبر قيمة ${field.max}.`);
        }
        break;
      }
      case 'attachments':
        (value || []).forEach((a, i) => {
          if (!a || !String(a.title || '').trim()) out.push(`المرفق ${i + 1}: اكتب اسم الملف.`);
          if (!a || !isSafeUrl(a.url, false)) out.push(`المرفق ${i + 1}: الرابط غير صالح.`);
          else if (!/^https:\/\//i.test(a.url) && !ALLOWED_FILES.test(a.url)) out.push(`المرفق ${i + 1}: نوع الملف غير مسموح.`);
        });
        break;
      case 'repeater':
        (value || []).forEach((row, i) => {
          field.fields.forEach(sub => {
            fieldErrors(sub, row ? row[sub.key] : null, row, phase).forEach(m => out.push(`${field.addLabel ? '' : ''}العنصر ${i + 1} — ${sub.label}: ${m}`));
          });
        });
        break;
    }
    return out;
  }

  function validate(typeName, data, phase) {
    const type = TYPES[typeName];
    const errors = [];
    type.fields.forEach(field => {
      fieldErrors(field, data[field.key], data, phase).forEach(message => errors.push({ key: field.key, label: field.label, message }));
    });
    if (typeName === 'calendar' && data.endDate && data.startDate && data.endDate < data.startDate) {
      errors.push({ key: 'endDate', label: 'ينتهي في', message: 'تاريخ النهاية قبل تاريخ البداية.' });
    }
    if (type.custom) type.custom(data).forEach(e => errors.push({ label: (type.fields.find(x => x.key === e.key) || {}).label || '', ...e }));
    return errors;
  }

  function warnings(typeName, data) {
    const type = TYPES[typeName];
    const out = [];
    const domain = (root.SITE_CONFIG && root.SITE_CONFIG.institutionalEmailDomain || '').toLowerCase();
    type.fields.forEach(field => {
      const v = data[field.key];
      if (field.institutional && v && domain && !String(v).toLowerCase().endsWith('@' + domain)) {
        out.push(`${field.label}: البريد ليس من النطاق المؤسسي (${domain}).`);
      }
    });
    if (typeName === 'settings') {
      (data.facts || []).filter(x => !x.verified).forEach(x => out.push(`الرقم «${x.value} ${x.label}» غير موثَّق ولن يظهر في الموقع.`));
      if (data.deanMessage && !data.deanVerified) out.push('كلمة العميد غير معلَّمة كمعتمدة.');
    }
    return out;
  }

  /* تنظيف القيم قبل الحفظ: قص المسافات وحذف الصفوف الفارغة */
  function clean(typeName, data) {
    const type = TYPES[typeName];
    const out = {};
    const cleanField = (field, v) => {
      switch (field.type) {
        case 'checkbox': return !!v;
        case 'number': return v === '' || v == null || !isFinite(Number(v)) ? null : Number(v);
        case 'list': return (Array.isArray(v) ? v : String(v || '').split(/\r?\n/)).map(x => String(x).trim()).filter(Boolean);
        case 'attachments': return (v || []).map(a => ({ title: String(a.title || '').trim(), url: String(a.url || '').trim() })).filter(a => a.title || a.url);
        case 'repeater': return (v || []).map(row => {
          const r = {};
          field.fields.forEach(sub => { r[sub.key] = cleanField(sub, row ? row[sub.key] : null); });
          return r;
        }).filter(r => Object.values(r).some(x => x !== '' && x != null && x !== false && !(Array.isArray(x) && !x.length)));
        default: return v == null ? '' : String(v).trim();
      }
    };
    type.fields.forEach(field => { out[field.key] = cleanField(field, data[field.key]); });
    return out;
  }

  function deptName(id) {
    const d = DEPARTMENTS.find(x => x.id === id);
    return d ? d.name : (id ? id : 'الكلية');
  }

  function optionLabel(typeName, key, value) {
    const field = TYPES[typeName].fields.find(x => x.key === key);
    if (!field) return value;
    if (field.type === 'department') return deptName(value);
    if (field.options) {
      const opt = field.options.find(o => (Array.isArray(o) ? o[0] : o) === value);
      if (opt) return Array.isArray(opt) ? opt[1] : opt;
    }
    return value;
  }

  const api = { DEPARTMENTS, SEMESTERS, TYPES, GROUPS, validate, warnings, clean, isSafeUrl, deptName, optionLabel, EMAIL_RE };
  root.CMS_SCHEMA = api;
})(typeof window !== 'undefined' ? window : globalThis);
