// صلاحية المدير مصدرها قائمة قابلة للتغيير على الخادم، وليست بريدًا ثابتًا في الواجهة.
export const STAFF_ROLES = ['editor', 'news', 'results'];
export const ADMIN_EMAIL_RE = /^[^\s/@]+@[^\s/@]+\.[^\s/@]+$/;
export const emailKey = email => String(email || '').trim().toLowerCase();

export function adminEmails(values, actor) {
  const emails = values.map(emailKey).filter(Boolean);
  if (!emails.length || emails.length > 3) throw new Error('أضف من مدير واحد إلى ثلاثة مديرين.');
  if (emails.some(email => email.length > 254 || !ADMIN_EMAIL_RE.test(email))) throw new Error('اكتب بريدًا إلكترونيًا صحيحًا لكل مدير.');
  if (new Set(emails).size !== emails.length) throw new Error('لا يمكن استخدام البريد نفسه لمديرين.');
  if (actor && !emails.includes(emailKey(actor))) throw new Error('احتفظ ببريدك الحالي. يستطيع مدير آخر استبداله حتى لا تفقد الإدارة كلها.');
  return emails;
}

export async function resolveStaffRole(fb, user) {
  const email = emailKey(user?.email);
  if (!user?.emailVerified || !email) return null;
  const { db, F } = fb;
  try {
    const roster = await F.getDocFromServer(F.doc(db, 'adminAccess', 'roster'));
    if (roster.exists() && roster.data().emails?.includes(email)) return 'admin';
  } catch (error) {
    // القائمة خاصة بالإداريين. الرفض المتوقع لا يمنع قراءة دور الموظف نفسه.
    if (error.code !== 'permission-denied') throw error;
  }
  const staff = await F.getDocFromServer(F.doc(db, 'staff', email));
  const data = staff.exists() ? staff.data() : null;
  return data?.active && STAFF_ROLES.includes(data.role) ? data.role : null;
}
