// ============================================================
// بيانات وهمية للمحاكي المحلي فقط — لا تحتوي أي بيانات طلاب حقيقية.
// التشغيل (والمحاكي يعمل): npm run seed
// يرفض العمل على أي مشروع لا يبدأ اسمه بـ demo- (أي لا يلمس الإنتاج).
//
// حسابات التجربة (كلها في المحاكي فقط، وكلمة السر للجميع: Test-Pass-2026):
//   admin@test.local    المدير
//   admin2@test.local   المدير الثاني
//   admin3@test.local   المدير الثالث
//   editor@test.local   محرر المحتوى
//   news@test.local     محرر الأخبار
//   results@test.local  مسؤول النتائج
//   student1@test.local طالب مرتبط برقم الجلوس T-1001
//   student2@test.local طالب مرتبط برقم الجلوس T-1002
//   student3@test.local طالب موثّق غير مرتبط (رمز تفعيله TEST-AAAA-BBB3 لرقم الجلوس T-1003)
//   pending@test.local  حساب لم يوثّق بريده
// ============================================================
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';

const PROJECT = process.env.GCLOUD_PROJECT || 'demo-dongola';
if (!PROJECT.startsWith('demo-')) { console.error('مرفوض: هذا السكربت للمحاكي فقط (مشروع demo-*).'); process.exit(1); }
process.env.FIRESTORE_EMULATOR_HOST ||= '127.0.0.1:8080';
process.env.FIREBASE_AUTH_EMULATOR_HOST ||= '127.0.0.1:9099';

initializeApp({ projectId: PROJECT });
const db = getFirestore();
const auth = getAuth();
const PASSWORD = 'Test-Pass-2026';
const now = FieldValue.serverTimestamp();

async function user(email, verified = true) {
  try { return await auth.getUserByEmail(email); }
  catch { return auth.createUser({ email, password: PASSWORD, emailVerified: verified }); }
}

const SUBJECTS = [
  { name: 'رياضيات هندسية ١ (تجريبي)', hours: 3 },
  { name: 'ميكانيكا هندسية (تجريبي)', hours: 3 },
  { name: 'رسم هندسي (تجريبي)', hours: 2 },
  { name: 'فيزياء عامة (تجريبي)', hours: 3 }
];
const BATCH = { year: '2025/2026', round: 1, session: 'دورة تجريبية', semester: 'الفصل الدراسي الأول', specialization: 'هندسة مدنية', subjects: SUBJECTS };

function result(batchId, meta, seatNo, i, published, grades, sgpa, cgpa, status, cls, notes) {
  return [`results/${batchId}__${seatNo}`, { batchId, seatNo, num: i, name: `طالب تجريبي ${i}`, grades, semesterGPA: sgpa, cumulativeGPA: cgpa, status, classification: cls, notes, published, ...meta }];
}

async function main() {
  const u = {};
  for (const name of ['admin', 'admin2', 'admin3', 'editor', 'news', 'results', 'student1', 'student2', 'student3']) u[name] = await user(`${name}@test.local`);
  u.pending = await user('pending@test.local', false);

  const docs = [];
  const staff = (role) => ({ role, active: true, name: 'حساب تجريبي', assignedBy: 'seed', assignedAt: now });
  docs.push(['adminAccess/roster', { emails: ['admin@test.local', 'admin2@test.local', 'admin3@test.local'], updatedBy: 'seed', updatedAt: now }]);
  docs.push(['staff/editor@test.local', staff('editor')], ['staff/news@test.local', staff('news')], ['staff/results@test.local', staff('results')]);

  // النتائج
  docs.push(['batches/demo-sem1-civil', { ...BATCH, published: true, studentCount: 5, updatedAt: now, updatedBy: 'seed' }]);
  const m1 = { ...BATCH };
  docs.push(
    result('demo-sem1-civil', m1, 'T-1001', 1, true, ['A', 'B', 'A', 'B'], 3.5, 3.5, 'نجاح', 'ممتاز', 'نجاح / ممتاز'),
    result('demo-sem1-civil', m1, 'T-1002', 2, true, ['C', 'F', 'B', 'D'], null, null, 'ملحق', null, 'ملحق/1'),
    result('demo-sem1-civil', m1, 'T-1003', 3, true, ['B', 'B', 'C', 'B'], 2.9, 2.9, 'نجاح', 'جيد', 'نجاح / جيد'),
    result('demo-sem1-civil', m1, 'T-1004', 4, true, ['A', 'A', 'B', 'A'], 3.79, 3.79, 'نجاح', 'ممتاز', 'نجاح / ممتاز'),
    result('demo-sem1-civil', m1, 'T-1005', 5, true, ['D', 'C', 'C', 'B'], 2.4, 2.4, 'نجاح', 'مقبول', 'نجاح / مقبول')
  );
  const B2 = { ...BATCH, semester: 'الفصل الدراسي الثاني', session: 'دورة تجريبية ٢' };
  docs.push(['batches/demo-sem2-civil', { ...B2, published: false, studentCount: 2, updatedAt: now, updatedBy: 'seed' }]);
  docs.push(
    result('demo-sem2-civil', B2, 'T-1001', 1, false, ['B', 'B', 'A', 'A'], 3.4, 3.45, 'نجاح', 'جيد جداً', 'نجاح / جيد جداً'),
    result('demo-sem2-civil', B2, 'T-1002', 2, false, ['C', 'C', 'C', 'C'], 2.5, 2.5, 'نجاح', 'جيد', 'نجاح / جيد')
  );
  // دفعة بالصيغة القديمة (الطلاب داخل وثيقة الدفعة) لتجربة أداة الترحيل
  docs.push(['batches/demo-legacy', { year: '2024/2025', round: 1, session: 'دورة قديمة تجريبية', semester: 'الفصل الدراسي الثالث', specialization: 'هندسة مدنية', subjects: SUBJECTS,
    students: [
      { num: 1, name: 'طالب تجريبي قديم ١', seatNo: 'L-2001', grades: ['A', 'A', 'B', 'B'], semesterGPA: 3.5, cumulativeGPA: 3.4, status: 'نجاح', classification: 'جيد جداً', notes: 'نجاح / جيد جداً' },
      { num: 2, name: 'طالب تجريبي قديم ٢', seatNo: 'L-2002', grades: ['C', 'F', 'C', 'C'], semesterGPA: null, cumulativeGPA: null, status: 'ملحق', classification: null, notes: 'ملحق/1' }
    ] }]);

  // الربط ورموز التفعيل
  docs.push(
    [`studentLinks/${u.student1.uid}`, { seatNo: 'T-1001', code: 'TEST-AAAA-BBB5', email: 'student1@test.local', linkedAt: now }],
    [`studentLinks/${u.student2.uid}`, { seatNo: 'T-1002', code: 'TEST-AAAA-BBB6', email: 'student2@test.local', linkedAt: now }],
    ['seatClaims/T-1001', { uid: u.student1.uid, claimedAt: now }],
    ['seatClaims/T-1002', { uid: u.student2.uid, claimedAt: now }],
    ['activationCodes/TEST-AAAA-BBB5', { seatNo: 'T-1001', usedBy: u.student1.uid, usedAt: now, createdAt: now, createdBy: 'seed' }],
    ['activationCodes/TEST-AAAA-BBB6', { seatNo: 'T-1002', usedBy: u.student2.uid, usedAt: now, createdAt: now, createdBy: 'seed' }],
    ['activationCodes/TEST-AAAA-BBB3', { seatNo: 'T-1003', usedBy: null, usedAt: null, createdAt: now, createdBy: 'seed' }],
    ['activationCodes/TEST-CCCC-DDD4', { seatNo: 'T-1004', usedBy: null, usedAt: null, createdAt: now, createdBy: 'seed' }]
  );

  // محتوى منشور ومسودات (كله معلَّم «تجريبي»)
  const meta = { _updatedBy: 'seed', _updatedAt: now };
  const pub = (type, id, data) => {
    docs.push([`public/${type}/items/${id}`, { ...data, ...meta }]);
    docs.push([`drafts/${type}/items/${id}`, { ...data, ...meta, _status: 'published', _publishedAt: now }]);
  };
  const draft = (type, id, data) => docs.push([`drafts/${type}/items/${id}`, { ...data, ...meta, _status: 'draft' }]);

  pub('settings', 'site', { title: 'إعدادات الموقع', aboutIntro: 'نص تجريبي لنبذة الكلية يظهر في المحاكي فقط.', address: 'عنوان تجريبي\nدنقلا', phone: '+249 000 000 000', email: 'info@test.local', facebook: 'https://www.facebook.com/', workingHours: 'من الأحد إلى الخميس (تجريبي)', mapUrl: '',
    facts: [{ value: '5', label: 'أقسام علمية', source: 'تجريبي', verified: true }, { value: '99', label: 'رقم غير موثق', source: '', verified: false }],
    deanName: 'اسم تجريبي', deanTitle: 'عميد كلية الهندسة', deanMessage: 'كلمة تجريبية للعميد.', deanVerified: true });
  pub('news', 'demo-news-1', { title: '[تجريبي] افتتاح معمل جديد', kind: 'news', category: 'شؤون أكاديمية', date: '2026-10-01', department: 'civil', summary: 'خبر تجريبي لاختبار العرض.', body: '## تفاصيل\n\nنص **تجريبي** مع [رابط داخلي](news.html).\n\n- بند أول\n- بند ثانٍ', image: '', imageAlt: '', attachments: [], pinned: false });
  pub('news', 'demo-news-2', { title: '[تجريبي] إعلان مواعيد التسجيل', kind: 'announcement', category: 'القبول والتسجيل', date: '2026-09-15', department: '', summary: 'إعلان تجريبي.', body: '', image: '', imageAlt: '', attachments: [{ title: 'ملف تجريبي', url: 'files/README.txt' }], pinned: true });
  pub('news', 'demo-news-3', { title: '[تجريبي] ندوة علمية', kind: 'news', category: 'فعاليات وأنشطة', date: '2025-12-10', department: 'electrical', summary: 'خبر أرشيفي تجريبي.', body: '', image: '', imageAlt: '', attachments: [], pinned: false });
  draft('news', 'demo-news-draft', { title: '[تجريبي] مسودة لم تُنشر', kind: 'news', category: 'عام', date: '2026-10-10', summary: 'لا يجب أن تظهر للزوار.', body: '' });
  pub('faculty', 'demo-member-1', { title: 'د. عضو تجريبي أول', academicTitle: 'أستاذ مساعد', degree: 'دكتوراه', department: 'civil', position: 'رئيس القسم (تجريبي)', specialization: 'هندسة إنشائية (تجريبي)', email: 'member1@test.local', office: '', photo: '', bio: 'سيرة تجريبية.', interests: ['الخرسانة', 'الجسور'], publications: [{ title: 'بحث تجريبي', year: 2025, venue: 'مجلة تجريبية', url: '' }], order: 1, consent: true });
  pub('faculty', 'demo-member-2', { title: 'م. عضو تجريبي ثانٍ', academicTitle: 'محاضر', degree: 'ماجستير', department: 'computer', position: '', specialization: 'شبكات الحاسوب (تجريبي)', email: 'member2@test.local', office: '', photo: '', bio: '', interests: [], publications: [], order: 2, consent: true });
  pub('departments', 'civil', { title: 'الهندسة المدنية', summary: 'الإنشاءات والطرق والموارد المائية والمساحة، مع تركيز على مشاريع الري والجسور في الولاية الشمالية.', about: 'نص تعريفي **تجريبي** للقسم.', programs: [{ name: 'برنامج تجريبي', degree: 'درجة تجريبية', duration: 'مدة تجريبية', notes: '' }], headName: 'د. عضو تجريبي أول', headTitle: 'أستاذ مساعد', headEmail: 'member1@test.local', headProfile: 'demo-member-1', studyPlan: '', attachments: [], courses: [{ code: 'TST 101', name: 'مقرر تجريبي', hours: 3, semester: 'الفصل الدراسي الأول', description: 'وصف تجريبي.' }], labs: [{ name: 'معمل تجريبي', description: '' }], careers: '- مجال تجريبي', contactEmail: '' });
  pub('calendar', 'demo-cal-1', { title: '[تجريبي] بداية الدراسة', academicYear: '2026/2027', category: 'الدراسة', startDate: '2026-11-01', endDate: '', notes: '' });
  pub('calendar', 'demo-cal-2', { title: '[تجريبي] امتحانات نهاية الفصل', academicYear: '2026/2027', category: 'الامتحانات', startDate: '2027-02-10', endDate: '2027-02-25', notes: 'موعد تجريبي.' });
  pub('documents', 'demo-doc-1', { title: '[تجريبي] نموذج طلب إعادة تصحيح', kind: 'form', purpose: 'وظيفة تجريبية.', howToUse: 'طريقة تجريبية.', department: '', version: '1', approvedBy: 'جهة تجريبية', approvedAt: '2026-01-01', attachments: [{ title: 'النموذج', url: 'files/README.txt' }] });
  pub('services', 'demo-svc-1', { title: '[تجريبي] خدمة إلكترونية', description: 'رابط تجريبي.', url: 'https://example.com/', audience: 'الجميع', order: 1 });

  const writer = db.bulkWriter();
  docs.forEach(([path, data]) => writer.set(db.doc(path), data));
  await writer.close();
  console.log(`أُنشئت ${Object.keys(u).length} حسابات تجريبية و${docs.length} وثيقة في المحاكي (${PROJECT}).`);
}

main().catch(err => { console.error(err); process.exit(1); });
