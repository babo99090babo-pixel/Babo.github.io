// تهيئة الإداريين لأول مرة فقط، بهوية موثوقة خارج المتصفح.
// لا يعيد هذا الأمر كتابة قائمة موجودة ولا ينشئ حسابات تسجيل دخول.
import { parseArgs } from 'node:util';

const HELP = `تهيئة الإداريين لأول مرة (بحد أقصى ثلاثة):
  npm run admins:init -- --project dongola-eng --emails first@example.com,second@example.com,third@example.com

للمحاكي المحلي فقط:
  npm run admins:init -- --project demo-dongola --emulator --emails admin@test.local

الإنتاج يحتاج Application Default Credentials موثوقة بصلاحية الكتابة إلى Firestore.
لا تضع مفاتيح الخدمة في المشروع أو public/، ولا تشاركها في المحادثات.
تغييرات الإداريين اللاحقة تتم من لوحة «المستخدمون والصلاحيات».
`;

async function main() {
  const { values } = parseArgs({
    options: {
      project: { type: 'string' },
      emails: { type: 'string' },
      emulator: { type: 'boolean', default: false },
      help: { type: 'boolean', short: 'h', default: false }
    },
    strict: true,
    allowPositionals: false
  });
  if (values.help) { console.log(HELP); return; }
  const project = values.project;
  if (!project || !/^[a-z][a-z0-9-]{4,61}[a-z0-9]$/.test(project)) {
    throw new Error('حدّد معرّف مشروع Firebase الصحيح صراحةً باستخدام --project.');
  }
  const emails = (values.emails || '').split(',').map(email => email.trim().toLowerCase());
  if (emails.length < 1 || emails.length > 3 || emails.some(email => email.length > 254 || !/^[^\s/@]+@[^\s/@]+\.[^\s/@]+$/.test(email))) {
    throw new Error('اكتب بريدًا صحيحًا إلى ثلاثة عناوين بريد صحيحة، مفصولة بفواصل، باستخدام --emails.');
  }
  if (new Set(emails).size !== emails.length) throw new Error('عناوين الإداريين يجب أن تكون مختلفة.');

  if (values.emulator) {
    if (project !== 'demo-dongola') throw new Error('المحاكي مسموح فقط مع --project demo-dongola.');
    const host = process.env.FIRESTORE_EMULATOR_HOST || '127.0.0.1:8080';
    if (!/^(127\.0\.0\.1|localhost):[0-9]{1,5}$/.test(host)) throw new Error('عنوان المحاكي يجب أن يكون محليًا مع رقم المنفذ.');
    process.env.FIRESTORE_EMULATOR_HOST = host;
  } else {
    if (process.env.FIRESTORE_EMULATOR_HOST) throw new Error('يوجد FIRESTORE_EMULATOR_HOST؛ استخدم --project demo-dongola --emulator أو ألغِ المتغير قبل العمل على الإنتاج.');
    if (project.startsWith('demo-')) throw new Error('مشروع demo يحتاج الخيار --emulator؛ لن يُرسَل إلى الإنتاج.');
  }

  const { initializeApp, applicationDefault, deleteApp } = await import('firebase-admin/app');
  const { getFirestore, FieldValue } = await import('firebase-admin/firestore');
  const app = initializeApp(values.emulator ? { projectId: project } : { projectId: project, credential: applicationDefault() });
  try {
    // create، وليس set: يمنع استبدال الإداريين الحاليين حتى مع تشغيل أمرين معًا.
    await getFirestore(app).doc('adminAccess/roster').create({
      emails,
      updatedBy: 'bootstrap',
      updatedAt: FieldValue.serverTimestamp()
    });
    console.log(`تمت تهيئة ${emails.length} حساب/حسابات إدارية للمشروع ${project}.`);
    console.log('ينشئ كل إداري حساب دخوله بنفس البريد ويوثّقه، ثم يدخل إلى admin.html.');
    console.log('للتبديل لاحقًا استخدم «المستخدمون والصلاحيات»؛ لا تعِد تشغيل التهيئة.');
  } catch (error) {
    if (error.code === 6 || error.code === 'already-exists') {
      throw new Error('قائمة الإداريين موجودة بالفعل؛ لم تُغيّر. عدّلها من لوحة الإدارة، أو اتبع استرداد الوصول الموثوق في docs/ADMIN-ACCOUNTS-AR.md.');
    }
    throw new Error('تعذّرت التهيئة. تحقق من المشروع، والصلاحية الموثوقة، واتصال Firestore. رمز الخطأ: ' + (error.code || 'unknown'));
  } finally {
    await deleteApp(app);
  }
}

main().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
