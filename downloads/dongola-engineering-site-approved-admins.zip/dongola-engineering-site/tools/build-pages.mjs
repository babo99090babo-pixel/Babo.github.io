// ============================================================
// مولّد الصفحات: يجمع الترويسة والقائمة والتذييل ووسوم المشاركة
// مع محتوى كل صفحة من src/pages، ويكتب الناتج في public/.
// التشغيل: npm run build  (لا يحتاج أي حزمة خارجية)
// شغّله بعد تعديل القائمة أو التذييل أو أي ملف في src/.
// ============================================================
import { readFileSync, writeFileSync, readdirSync, mkdirSync } from 'node:fs';
import { dirname, join, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC = join(ROOT, 'public');
const SRC = join(ROOT, 'src');

// نقرأ الإعدادات والمخطط من ملفات الموقع نفسها حتى لا تتكرر البيانات
const sandbox = { window: {}, location: { hostname: 'build', search: '' }, URLSearchParams, sessionStorage: { getItem: () => null, setItem() {} } };
sandbox.globalThis = sandbox.window;
vm.runInNewContext(readFileSync(join(PUBLIC, 'js/site-config.js'), 'utf8'), sandbox);
vm.runInNewContext(readFileSync(join(PUBLIC, 'js/cms-schema.js'), 'utf8'), sandbox);
const CONFIG = sandbox.window.SITE_CONFIG;
const { DEPARTMENTS } = sandbox.window.CMS_SCHEMA;
const SITE_URL = CONFIG.siteUrl.replace(/\/$/, '');

const ar = n => String(n).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const YEAR = new Date().getFullYear();

export const ICONS = {
  arrow: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5m7-7-7 7 7 7"/></svg>',
  chevron: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>',
  menu: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
  results: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Zm0 0v6h6M8 13h8m-8 4h5"/></svg>',
  pin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg>',
  phone: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2A19.79 19.79 0 0 1 3.09 5.18 2 2 0 0 1 5.08 3h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.7 2.79a2 2 0 0 1-.45 2.11L9.06 10.9a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.33 1.83.57 2.79.7a2 2 0 0 1 1.77 2.04Z"/></svg>',
  mail: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 6 10 7L22 6"/></svg>',
  globe: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a20 20 0 0 0 0 20 20 20 0 0 0 0-20Z"/></svg>',
  book: '<svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v15M12 5C8 2 4 3 2 4v15c3-1 7-1 10 1 3-2 7-2 10-1V4c-3-1-7-2-10 1Z"/></svg>',
  users: '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/><circle cx="9" cy="7" r="4"/></svg>',
  search: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="7.5"/><path d="m16 16 5 5"/></svg>',
  lock: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
  calendar: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
  file: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Zm0 0v6h6M8 13h8m-8 4h5"/></svg>',
  table: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>',
  cap: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c3 2 9 2 12 0v-5"/></svg>',
  link: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>'
};

// ---------- القائمة الرئيسية (مصدر واحد لكل الصفحات) ----------
const NAV = [
  { id: 'about', label: 'عن الكلية', href: 'about.html', children: [
    ['about.html', 'التعريف بالكلية'], ['vision.html', 'الرؤية والرسالة والأهداف'], ['structure.html', 'الهيكل الإداري'],
    ['history.html', 'تاريخ الكلية'], ['accreditation.html', 'الاعتمادات'], ['gallery.html', 'معرض الصور'] ] },
  { id: 'departments', label: 'الأقسام العلمية', href: 'departments.html', children: [
    ['departments.html', 'كل الأقسام'], ...DEPARTMENTS.map(d => ['departments/' + d.id + '.html', d.name]) ] },
  { id: 'staff', label: 'هيئة التدريس', href: 'staff.html' },
  { id: 'students', label: 'القبول والطلاب', href: 'students.html', children: [
    ['students.html', 'خدمات الطلاب'], ['admission.html', 'القبول والتسجيل'], ['calendar.html', 'التقويم الأكاديمي'],
    ['schedules.html', 'جداول الدراسة والامتحانات'], ['regulations.html', 'اللوائح والنماذج'] ] },
  { id: 'research', label: 'البحث والمشاريع', href: 'research.html', children: [
    ['research.html', 'البحث العلمي'], ['projects.html', 'مشاريع التخرج'], ['labs.html', 'المعامل'],
    ['activities.html', 'الأنشطة والفعاليات'], ['partners.html', 'الشراكات'] ] },
  { id: 'news', label: 'الأخبار', href: 'news.html' },
  { id: 'contact', label: 'تواصل معنا', href: 'contact.html' }
];

function header(p) {
  const b = p.base;
  const cur = (href) => href === p.path ? ' aria-current="page"' : '';
  const items = NAV.map(n => {
    const top = p.nav === n.id ? ' aria-current="' + (n.href === p.path ? 'page' : 'true') + '"' : '';
    if (!n.children) return `<li><a href="${b}${n.href}"${top}>${n.label}</a></li>`;
    return `<li class="has-sub"><a href="${b}${n.href}"${top}>${n.label}</a>` +
      `<button type="button" class="sub-toggle" aria-expanded="false" aria-controls="sub-${n.id}" aria-label="القائمة الفرعية: ${n.label}">${ICONS.chevron}</button>` +
      `<ul class="nav-sub" id="sub-${n.id}">${n.children.map(([h, l]) => `<li><a href="${b}${h}"${cur(h)}>${l}</a></li>`).join('')}</ul></li>`;
  }).join('\n        ');
  return `<a class="skip-link" href="#main-content">تخطَّ إلى المحتوى</a>
<div class="utility-bar"><div class="wrap"><span>جامعة دنقلا <i class="utility-dot" aria-hidden="true"></i> كلية الهندسة</span><span>السودان · الولاية الشمالية</span></div></div>
<header class="top">
  <div class="wrap top-inner">
    <a class="brand" href="${b}index.html" aria-label="كلية الهندسة، جامعة دنقلا — الرئيسية">
      <picture class="mark"><source srcset="${b}images/logo/logo.webp" type="image/webp"><img src="${b}images/logo/logo.png" alt="" width="240" height="152"></picture>
      <span><b>كلية الهندسة</b><span class="sub">جامعة دنقلا</span></span>
    </a>
    <button class="menu-toggle" type="button" aria-controls="mainNavigation" aria-expanded="false" aria-label="فتح القائمة الرئيسية">${ICONS.menu}</button>
    <nav class="main" id="mainNavigation" aria-label="القائمة الرئيسية">
      <ul class="nav-list">
        ${items}
      </ul>
    </nav>
    <a class="btn-results" href="${b}results.html"${p.path === 'results.html' ? ' aria-current="page"' : ''}>${ICONS.results} بوابة النتائج</a>
  </div>
</header>`;
}

function footer(p) {
  const b = p.base;
  const links = list => list.map(([h, l]) => `<li><a href="${b}${h}">${l}</a></li>`).join('');
  return `<footer class="site">
  <div class="wrap footer-grid">
    <div class="footer-brand">
      <a class="footer-logo" href="${b}index.html" aria-label="الصفحة الرئيسية"><img src="${b}images/logo/logo.webp" alt="شعار جامعة دنقلا" width="96" height="61" loading="lazy"></a>
      <p>كلية الهندسة، جامعة دنقلا. تعليم هندسي يجمع الأساس النظري والتطبيق العملي.</p>
    </div>
    <nav aria-labelledby="ft-college"><h2 id="ft-college">الكلية</h2><ul>${links([['about.html', 'التعريف بالكلية'], ['vision.html', 'الرؤية والرسالة'], ['departments.html', 'الأقسام العلمية'], ['staff.html', 'هيئة التدريس'], ['news.html', 'الأخبار والإعلانات']])}</ul></nav>
    <nav aria-labelledby="ft-students"><h2 id="ft-students">الطلاب</h2><ul>${links([['admission.html', 'القبول والتسجيل'], ['calendar.html', 'التقويم الأكاديمي'], ['schedules.html', 'الجداول'], ['regulations.html', 'اللوائح والنماذج'], ['results.html', 'بوابة النتائج']])}</ul></nav>
    <div><h2>تواصل معنا</h2><ul class="footer-contact" data-setting-contact="footer">
      <li><span>العنوان:</span> دنقلا، الولاية الشمالية، السودان</li>
      <li><span>الهاتف:</span> <a href="tel:+249991974489" dir="ltr">+249 991 974 489</a></li>
      <li><span>البريد الإلكتروني:</span> <a href="mailto:babo99090babo@gmail.com" dir="ltr">babo99090babo@gmail.com</a></li>
    </ul></div>
  </div>
  <div class="footer-bottom"><div class="wrap">
    <span>© ${ar(YEAR)} كلية الهندسة — جامعة دنقلا. جميع الحقوق محفوظة.</span>
    <nav class="footer-links" aria-label="روابط إضافية"><a href="${b}privacy.html">سياسة الخصوصية</a><a href="${b}contact.html">تواصل معنا</a><a href="${b}admin.html" rel="nofollow">دخول الإدارة</a></nav>
  </div></div>
</footer>`;
}

function pageHead(p) {
  if (!p.heading) return '';
  const b = p.base;
  const crumbs = (p.crumbs || []).map(([h, l, attrs]) => `<a href="${b}${h}"${attrs ? ' ' + attrs : ''}>${l}</a><span aria-hidden="true">/</span>`).join('');
  return `<div class="page-head"><div class="wrap">
    <nav class="breadcrumbs" aria-label="مسار الصفحة"><a href="${b}index.html">الرئيسية</a><span aria-hidden="true">/</span>${crumbs}<span aria-current="page"${p.crumbAttr ? ' ' + p.crumbAttr : ''}>${p.crumbCurrent || p.heading}</span></nav>
    ${p.kicker ? `<p class="section-kicker">${p.kicker}</p>` : ''}<h1>${p.heading}</h1>${p.intro ? `<p${p.introAttr ? ' ' + p.introAttr : ''}>${p.intro}</p>` : ''}
  </div></div>`;
}

function jsonLd() {
  const data = {
    '@context': 'https://schema.org', '@type': 'CollegeOrUniversity',
    name: 'كلية الهندسة — جامعة دنقلا', url: SITE_URL + '/', logo: SITE_URL + '/images/logo/logo-large.png',
    address: { '@type': 'PostalAddress', addressLocality: 'دنقلا', addressRegion: 'الولاية الشمالية', addressCountry: 'SD' },
    parentOrganization: { '@type': 'CollegeOrUniversity', name: 'جامعة دنقلا' },
    sameAs: ['https://www.facebook.com/share/1JSj3kq5bR/']
  };
  return `<script type="application/ld+json">${JSON.stringify(data)}</script>`;
}

function layout(p, content) {
  const b = p.base;
  const url = SITE_URL + '/' + (p.path === 'index.html' ? '' : p.path);
  const fullTitle = p.path === 'index.html' ? 'كلية الهندسة — جامعة دنقلا' : `${p.title} — كلية الهندسة، جامعة دنقلا`;
  const css = ['css/fonts.css', 'css/style.css', ...(p.css || [])].map(h => `<link rel="stylesheet" href="${b}${h}">`).join('\n');
  const scripts = ['js/site-config.js'];
  if (p.cms) scripts.push('js/cms-schema.js', 'js/cms-render.js', 'js/cms-public.js');
  scripts.push('js/site.js');
  const scriptTags = scripts.map(s => `<script src="${b}${s}" defer></script>`)
    .concat((p.modules || []).map(s => `<script type="module" src="${b}${s}"></script>`)).join('\n');
  const robots = p.robots ? `<meta name="robots" content="${p.robots}">\n` : '';
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl" data-base="${b}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#102d42">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(p.description)}">
${robots}${p.canonical === false ? '' : `<link rel="canonical" href="${url}">\n`}
<meta property="og:type" content="${p.ogType || 'website'}">
<meta property="og:site_name" content="كلية الهندسة — جامعة دنقلا">
<meta property="og:locale" content="ar_AR">
<meta property="og:title" content="${esc(p.title)}">
<meta property="og:description" content="${esc(p.description)}">
<meta property="og:url" content="${url}">
<meta property="og:image" content="${SITE_URL}/images/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="شعار جامعة دنقلا مع عبارة كلية الهندسة">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="${b}favicon.ico" sizes="any">
<link rel="icon" type="image/png" href="${b}favicon.png">
<link rel="apple-touch-icon" href="${b}apple-touch-icon.png">
<link rel="preload" href="${b}fonts/cairo-variable.woff2" as="font" type="font/woff2" crossorigin>
${css}
${scriptTags}
${p.jsonLd ? jsonLd() + '\n' : ''}</head>
<body${p.bodyClass ? ` class="${p.bodyClass}"` : ''}${p.page ? ` data-page="${p.page}"` : ''}>
${header(p)}
<main id="main-content" tabindex="-1">
${pageHead(p)}
${content.trim()}
</main>
${footer(p)}
</body>
</html>
`;
}

// ---------- قراءة الصفحات ----------
function parse(file) {
  const raw = readFileSync(file, 'utf8').replace(/\r\n/g, '\n');
  const m = raw.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
  if (!m) throw new Error('Missing front matter: ' + file);
  return { meta: JSON.parse(m[1]), body: m[2] };
}
function fill(text, vars) {
  return text.replace(/\{\{\s*([\w.:-]+)\s*\}\}/g, (all, key) => {
    if (key.startsWith('icon:')) return ICONS[key.slice(5)] || '';
    const v = key.split('.').reduce((o, k) => (o == null ? undefined : o[k]), vars);
    if (v === undefined) throw new Error('Unknown placeholder {{' + key + '}}');
    return v;
  });
}

const pages = [];
function emit(meta, body) {
  const path = meta.path;
  const depth = path.split('/').length - 1;
  // صفحة 404 تُعرض على أي مسار، فروابطها مطلقة
  const p = { ...meta, base: meta.base != null ? meta.base : '../'.repeat(depth) };
  const subnav = Object.fromEntries(NAV.filter(n => n.children).map(n => [n.id,
    `<nav class="side-nav" aria-labelledby="side-${n.id}"><h2 id="side-${n.id}">${n.label}</h2><ul>` +
    n.children.map(([h, l]) => `<li><a href="${p.base}${h}"${h === path ? ' aria-current="page"' : ''}>${l}</a></li>`).join('') + '</ul></nav>']));
  const vars = { base: p.base, year: ar(YEAR), siteUrl: SITE_URL, subnav, ...(meta.vars || {}) };
  const html = layout({ ...p, heading: meta.heading && fill(meta.heading, vars), intro: meta.intro && fill(meta.intro, vars) }, fill(body, vars));
  const out = join(PUBLIC, path);
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, html);
  pages.push(p);
}

for (const name of readdirSync(join(SRC, 'pages')).filter(f => f.endsWith('.html')).sort()) {
  const { meta, body } = parse(join(SRC, 'pages', name));
  meta.path = meta.path || name;
  emit(meta, body);
}

// صفحة مستقلة لكل قسم علمي من قالب واحد
{
  const { meta, body } = parse(join(SRC, 'templates', 'department.html'));
  DEPARTMENTS.forEach(d => {
    emit({
      ...meta, path: `departments/${d.id}.html`, title: d.name,
      description: `قسم ${d.name} بكلية الهندسة، جامعة دنقلا: ${d.summary}`,
      heading: d.name, intro: d.summary, crumbCurrent: d.name, vars: { dept: d }
    }, body);
  });
}

// خريطة الموقع وملف robots
const sitemap = pages.filter(p => p.sitemap !== false && !p.robots)
  .map(p => `  <url><loc>${SITE_URL}/${p.path === 'index.html' ? '' : p.path}</loc><changefreq>${p.changefreq || 'monthly'}</changefreq><priority>${p.priority || (p.path === 'index.html' ? '1.0' : '0.7')}</priority></url>`);
writeFileSync(join(PUBLIC, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${sitemap.join('\n')}\n</urlset>\n`);
writeFileSync(join(PUBLIC, 'robots.txt'), `User-agent: *\nDisallow: /admin.html\nAllow: /\n\nSitemap: ${SITE_URL}/sitemap.xml\n`);

// إعدادات المحاكي: نفس firebase.json مع السماح بالاتصال بالمحاكي المحلي
const fb = JSON.parse(readFileSync(join(ROOT, 'firebase.json'), 'utf8'));
fb.hosting.headers.forEach(h => h.headers.forEach(x => {
  if (x.key === 'Content-Security-Policy') {
    x.value = x.value.replace('connect-src ', 'connect-src http://127.0.0.1:8080 http://127.0.0.1:9099 ws://127.0.0.1:8080 ')
      .replace('frame-src ', 'frame-src http://127.0.0.1:9099 ')
      .replace('; upgrade-insecure-requests', '');
  }
  if (x.key === 'Strict-Transport-Security') x.value = 'max-age=0';
  // في التجربة المحلية تظهر التعديلات فور إعادة التحميل
  if (x.key === 'Cache-Control') x.value = 'no-cache';
}));
writeFileSync(join(ROOT, 'firebase.emulator.json'), JSON.stringify(fb, null, 2) + '\n');

console.log(`تم توليد ${pages.length} صفحة، وخريطة الموقع (${sitemap.length} رابطًا)، وإعدادات المحاكي.`);
