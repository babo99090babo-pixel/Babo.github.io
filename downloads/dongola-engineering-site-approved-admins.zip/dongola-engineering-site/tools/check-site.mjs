// ============================================================
// فحص ملفات النشر قبل الرفع:
//  - الروابط والملفات الداخلية موجودة
//  - العنوان والوصف والاتجاه ووسوم المشاركة في كل صفحة
//  - لا معالجات أحداث أو شيفرات مضمّنة تمنعها سياسة الأمان
//  - لا مفاتيح خادم ولا بيانات طلاب في public/
// التشغيل: npm run check
// لفحص تسرّب بيانات الطلاب الحقيقية: اضبط PRIVATE_RESULTS_FILE على مسار الملف الأصلي (خارج المشروع).
// يُطبع العدد فقط، ولا تُطبع أي بيانات شخصية.
// ============================================================
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname, relative, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseLegacyResults } from '../public/js/admin/legacy-parse.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC = join(ROOT, 'public');
const problems = [];
const warnings = [];
const files = [];
(function walk(dir) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) walk(p); else files.push(p);
  }
})(PUBLIC);
const rel = p => relative(PUBLIC, p).replace(/\\/g, '/');
const html = files.filter(f => f.endsWith('.html'));
const titles = new Map();

for (const file of html) {
  const src = readFileSync(file, 'utf8');
  const name = rel(file);
  const noindex = /<meta name="robots" content="noindex/.test(src);
  if (!/<html lang="ar" dir="rtl"/.test(src)) problems.push(`${name}: يجب lang="ar" dir="rtl"`);
  const title = (src.match(/<title>([^<]*)<\/title>/) || [])[1];
  if (!title) problems.push(`${name}: لا يوجد <title>`);
  else if (!noindex) { if (titles.has(title)) problems.push(`${name}: العنوان مكرر مع ${titles.get(title)}`); titles.set(title, name); }
  const desc = (src.match(/<meta name="description" content="([^"]*)"/) || [])[1];
  if (!desc || desc.length < 40) problems.push(`${name}: وصف الصفحة مفقود أو قصير جدًا`);
  if (!/<meta name="viewport"/.test(src)) problems.push(`${name}: لا يوجد viewport`);
  if (name !== 'admin.html' && !/property="og:title"/.test(src)) problems.push(`${name}: لا توجد وسوم مشاركة og`);
  if ((src.match(/<h1[\s>]/g) || []).length !== 1 && name !== 'admin.html') problems.push(`${name}: يجب أن تحتوي عنوانًا رئيسيًا h1 واحدًا`);
  if (/\son[a-z]+\s*=\s*["']/i.test(src)) problems.push(`${name}: معالج حدث مضمّن (تمنعه سياسة الأمان)`);
  for (const m of src.matchAll(/<script(?![^>]*\bsrc=)([^>]*)>/g)) {
    if (!/type="application\/ld\+json"/.test(m[1])) problems.push(`${name}: شيفرة مضمّنة <script> (تمنعها سياسة الأمان)`);
  }
  for (const m of src.matchAll(/<img\b[^>]*>/g)) if (!/\balt=/.test(m[0])) problems.push(`${name}: صورة بلا alt`);
  const base = /data-base="([^"]*)"/.exec(src);
  for (const m of src.matchAll(/\b(?:href|src|srcset)="([^"]+)"/g)) {
    let url = m[1].split(/[?#]/)[0];
    if (!url || /^(https?:|mailto:|tel:|data:|javascript:)/i.test(m[1]) || m[1].startsWith('#')) continue;
    if (/\{\{|\$\{/.test(url)) { problems.push(`${name}: قالب لم يُستبدل ${url}`); continue; }
    const target = url.startsWith('/') ? join(PUBLIC, url) : join(dirname(file), url);
    if (!existsSync(target)) problems.push(`${name}: رابط مكسور ${m[1]}`);
  }
  void base;
}

// الملفات المرتبطة من CSS
for (const css of files.filter(f => f.endsWith('.css'))) {
  for (const m of readFileSync(css, 'utf8').matchAll(/url\(['"]?([^'")]+)['"]?\)/g)) {
    if (/^(data:|https?:)/.test(m[1])) continue;
    if (!existsSync(join(dirname(css), m[1]))) problems.push(`${rel(css)}: ملف مفقود ${m[1]}`);
  }
}

// خريطة الموقع
const sitemap = readFileSync(join(PUBLIC, 'sitemap.xml'), 'utf8');
for (const m of sitemap.matchAll(/<loc>[^<]*?\.app\/([^<]*)<\/loc>/g)) {
  const p = m[1] || 'index.html';
  if (!existsSync(join(PUBLIC, p))) problems.push(`sitemap.xml: صفحة غير موجودة ${p}`);
}

// مفاتيح خادم أو بيانات حساسة
const SECRET = /BEGIN (RSA )?PRIVATE KEY|"private_key"\s*:|"client_email"\s*:\s*"[^"]+iam\.gserviceaccount\.com"|service_account/;
for (const f of files) {
  if (!['.html', '.js', '.json', '.css', '.txt', '.xml', '.svg'].includes(extname(f))) continue;
  const t = readFileSync(f, 'utf8');
  if (SECRET.test(t)) problems.push(`${rel(f)}: يبدو أنه يحتوي مفتاح خادم`);
  if (/RESULTS_DATA\s*=\s*\[/.test(t)) problems.push(`${rel(f)}: يحتوي بيانات نتائج بالصيغة القديمة`);
}
for (const banned of ['results-data.js', 'results-admin.html']) {
  if (files.some(f => rel(f).endsWith(banned))) problems.push(`ملف لا يجوز نشره: ${banned}`);
}
if (files.some(f => /(^|\/)backup-|backup[^/]*\.(json|zip)$|\.(bak|enc)$/i.test(rel(f)))) problems.push('يوجد ملف نسخة احتياطية داخل public/');

// مقارنة مع بيانات الطلاب الحقيقية (تُطبع الأعداد فقط)
const privateFile = process.env.PRIVATE_RESULTS_FILE;
if (privateFile && existsSync(privateFile)) {
  const data = parseLegacyResults(readFileSync(privateFile, 'utf8'));
  const names = new Set(); const seats = new Set();
  data.forEach(b => (b.students || []).forEach(s => { if (s.name && s.name.length > 6) names.add(s.name); if (s.seatNo) seats.add(String(s.seatNo)); }));
  let hits = 0;
  for (const f of files) {
    if (!['.html', '.js', '.json', '.txt', '.xml'].includes(extname(f))) continue;
    const t = readFileSync(f, 'utf8');
    for (const n of names) if (t.includes(n)) hits++;
    for (const s of seats) if (s.length >= 5 && new RegExp(`["'>\\s]${s.replace(/[-]/g, '\\-')}["'<\\s]`).test(t)) hits++;
  }
  if (hits) problems.push(`عُثر على ${hits} تطابقًا مع أسماء أو أرقام جلوس حقيقية داخل public/`);
  else console.log(`فحص الخصوصية: لا يوجد أي من ${names.size} اسمًا و${seats.size} رقم جلوس حقيقيًا في ملفات النشر.`);
} else warnings.push('لم يُفحص تسرب بيانات الطلاب الحقيقية (اضبط PRIVATE_RESULTS_FILE).');

console.log(`فُحصت ${html.length} صفحة و${files.length} ملفًا.`);
warnings.forEach(w => console.log('تنبيه: ' + w));
if (problems.length) {
  console.error(`\n${problems.length} مشكلة:`);
  problems.forEach(p => console.error(' - ' + p));
  process.exit(1);
}
console.log('لا توجد مشكلات.');
