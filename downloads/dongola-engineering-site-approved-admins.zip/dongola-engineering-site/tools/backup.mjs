// ============================================================
// نسخة احتياطية كاملة لقاعدة Firestore إلى ملف JSON على جهاز المسؤول.
//
// للإنتاج:
//   set GOOGLE_APPLICATION_CREDENTIALS=D:\مفاتيح-آمنة\dongola-eng-backup.json   (خارج مجلد المشروع)
//   set BACKUP_PASSPHRASE=عبارة-مرور-طويلة   (اختياري لكنه موصى به: يشفّر الملف)
//   node tools/backup.mjs --project dongola-eng --out D:\Dongolasite-backups
// للمحاكي:
//   node tools/backup.mjs --project demo-dongola --emulator
// خيارات: --only results,batches,...  لنسخ مجموعات بعينها
// ============================================================
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { backupPayload, encrypt } from './lib/firestore-backup.mjs';

const args = Object.fromEntries(process.argv.slice(2).map((a, i, all) => a.startsWith('--') ? [a.slice(2), all[i + 1] && !all[i + 1].startsWith('--') ? all[i + 1] : true] : null).filter(Boolean));
const project = args.project || process.env.GCLOUD_PROJECT;
if (!project) { console.error('حدّد المشروع: --project dongola-eng'); process.exit(1); }
if (args.emulator) process.env.FIRESTORE_EMULATOR_HOST ||= '127.0.0.1:8080';
if (!process.env.FIRESTORE_EMULATOR_HOST && !process.env.GOOGLE_APPLICATION_CREDENTIALS) {
  console.error('اضبط GOOGLE_APPLICATION_CREDENTIALS على مسار مفتاح الخدمة (محفوظ خارج مجلد المشروع).');
  process.exit(1);
}
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outDir = resolve(args.out || join(ROOT, '..', 'Dongolasite-backups'));
if (outDir.startsWith(join(ROOT, 'public'))) { console.error('مرفوض: لا تحفظ النسخ داخل مجلد النشر public.'); process.exit(1); }

initializeApp(process.env.FIRESTORE_EMULATOR_HOST ? { projectId: project } : { projectId: project, credential: applicationDefault() });
const db = getFirestore();
const only = typeof args.only === 'string' ? args.only.split(',') : undefined;

const payload = await backupPayload(db, project, { only });
let text = JSON.stringify(payload);
const pass = process.env.BACKUP_PASSPHRASE;
if (pass) text = encrypt(text, pass);
mkdirSync(outDir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const file = join(outDir, `firestore-${project}-${stamp}${pass ? '.enc' : ''}.json`);
writeFileSync(file, text);
console.log(`تم: ${payload.count} وثيقة ← ${file}${pass ? ' (مشفّر)' : ' (غير مشفّر — احفظه في مكان آمن)'}`);
