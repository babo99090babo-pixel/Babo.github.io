// ============================================================
// استعادة نسخة احتياطية كاملة إلى Firestore.
// تكتب الوثائق الموجودة في الملف كما هي، ولا تحذف غيرها.
//
// جرّب أولًا على المحاكي:
//   node tools/restore.mjs --project demo-dongola --emulator --file نسخة.json
// معاينة دون كتابة:
//   node tools/restore.mjs --project dongola-eng --file نسخة.json --dry-run
// على الإنتاج (يتطلب تأكيدًا صريحًا باسم المشروع):
//   node tools/restore.mjs --project dongola-eng --file نسخة.json --confirm-production dongola-eng
// خيارات: --only results,batches   لاستعادة مجموعات بعينها
// ============================================================
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { readFileSync } from 'node:fs';
import { restoreAll, decrypt } from './lib/firestore-backup.mjs';

const args = Object.fromEntries(process.argv.slice(2).map((a, i, all) => a.startsWith('--') ? [a.slice(2), all[i + 1] && !all[i + 1].startsWith('--') ? all[i + 1] : true] : null).filter(Boolean));
const project = args.project;
if (!project || !args.file) { console.error('الاستخدام: node tools/restore.mjs --project <المشروع> --file <ملف النسخة> [--emulator] [--dry-run]'); process.exit(1); }
if (args.emulator) process.env.FIRESTORE_EMULATOR_HOST ||= '127.0.0.1:8080';
const emulator = !!process.env.FIRESTORE_EMULATOR_HOST;
if (!emulator && !args['dry-run'] && args['confirm-production'] !== project) {
  console.error(`مرفوض: الاستعادة على مشروع حقيقي تحتاج --confirm-production ${project}`);
  process.exit(1);
}
if (!emulator && !process.env.GOOGLE_APPLICATION_CREDENTIALS) { console.error('اضبط GOOGLE_APPLICATION_CREDENTIALS على مسار مفتاح الخدمة.'); process.exit(1); }

initializeApp(emulator ? { projectId: project } : { projectId: project, credential: applicationDefault() });
const db = getFirestore();
const payload = JSON.parse(decrypt(readFileSync(args.file, 'utf8'), process.env.BACKUP_PASSPHRASE));
const only = typeof args.only === 'string' ? args.only.split(',') : undefined;
const r = await restoreAll(db, payload, { dryRun: !!args['dry-run'], only });
console.log(args['dry-run'] ? `معاينة: ستُكتب ${r.planned} وثيقة من نسخة ${payload.createdAt}.` : `تمت الاستعادة: ${r.written} من ${r.planned} وثيقة (نسخة ${payload.createdAt}).`);
