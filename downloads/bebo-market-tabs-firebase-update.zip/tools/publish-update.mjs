import {access, copyFile, mkdir, mkdtemp, readFile, writeFile} from 'node:fs/promises';
import {createInterface} from 'node:readline/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {ROOT, CONFIG_KEYS, validateFirebaseConfig} from './config-lib.mjs';

const PROJECT = 'babo-market';
const REQUIRED_KEYS = ['apiKey', 'authDomain', 'projectId', 'appId'];

async function readOptional(file) {
  try { return await readFile(file); }
  catch (error) { if (error.code === 'ENOENT') return undefined; throw error; }
}

function parseJson(bytes, label) {
  if (!bytes?.toString('utf8').trim()) return {};
  try { return JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, '')); }
  catch { throw new Error(`${label} is not valid JSON. Keep the file and check it before publishing.`); }
}

function parsePublicConfig(bytes) {
  if (!bytes?.toString('utf8').trim()) return {};
  const source = bytes.toString('utf8').replace(/^\uFEFF/, '');
  const match = source.match(/^\s*(?:\/\*[\s\S]*?\*\/\s*)?window\.BEBO_FIREBASE_CONFIG\s*=\s*(\{[\s\S]*\})\s*;?\s*$/);
  if (!match) throw new Error('public/js/firebase-config.js is not a supported Web configuration. Keep it and check it before publishing.');
  return parseJson(Buffer.from(match[1]), 'public/js/firebase-config.js');
}

function inspectConfig(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${label} must contain a Firebase Web configuration object.`);
  if ('private_key' in value || 'client_email' in value || value.type === 'service_account') {
    throw new Error(`Stopped: ${label} contains server credentials. Do not put a service-account key in this update.`);
  }
  const declaredProject = typeof value.projectId === 'string' ? value.projectId.trim() : value.projectId;
  if (declaredProject !== undefined && declaredProject !== null && declaredProject !== '' && declaredProject !== PROJECT) {
    throw new Error(`Stopped: ${label} must belong to ${PROJECT}. No project was changed.`);
  }
  const clean = Object.fromEntries(CONFIG_KEYS.filter(key => typeof value[key] === 'string').map(key => [key, value[key].trim()]));
  try {
    validateFirebaseConfig(value, {required: true});
    return clean;
  } catch { return null; }
}

function compatible(left, right) {
  return left && right && REQUIRED_KEYS.every(key => left[key] === right[key]);
}

function publicSource(config) {
  const json = JSON.stringify(config, null, 2).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return '/* Public Firebase Web configuration; never put a service-account key here. */\nwindow.BEBO_FIREBASE_CONFIG = ' + json + ';\n';
}

export async function publishUpdate({root = ROOT} = {}) {
  const metadata = parseJson(await readOptional(path.join(root, 'package.json')), 'package.json');
  if (metadata.name !== 'bebo-market') throw new Error('Copy this update into the original Bebo Market project folder.');
  for (const file of ['public/index.html', 'public/js/navigation.js', 'tools/check-site.mjs', 'firebase.json']) {
    try { await access(path.join(root, file)); }
    catch { throw new Error(`Missing ${file}. Merge the update with your original market folder before publishing.`); }
  }
  const hosting = parseJson(await readOptional(path.join(root, 'firebase.json')), 'firebase.json').hosting;
  if (!hosting || Array.isArray(hosting) || hosting.public !== 'public' || hosting.target
    || (hosting.site && hosting.site !== PROJECT)) {
    throw new Error('Stopped: this update requires the original Hosting configuration with public set to public. No Hosting configuration was changed.');
  }
  const cli = path.join(root, 'node_modules/firebase-tools/lib/bin/firebase.js');
  try { await access(cli); }
  catch { throw new Error('Firebase CLI is missing. Run setup-firebase.bat from the original market folder, then reopen publish-update.bat.'); }

  const rootFile = path.join(root, 'firebase.config.json');
  const publicFile = path.join(root, 'public/js/firebase-config.js');
  const rootBytes = await readOptional(rootFile);
  const publicBytes = await readOptional(publicFile);
  const rootConfig = inspectConfig(parseJson(rootBytes, 'firebase.config.json'), 'firebase.config.json');
  const publicConfig = inspectConfig(parsePublicConfig(publicBytes), 'public/js/firebase-config.js');

  console.log(`This update publishes website files only to: ${PROJECT}`);
  console.log('Firestore data, rules, indexes and existing Hosting settings are preserved.');
  if (!rootConfig || !publicConfig) console.log('Incomplete Web settings will be recovered for the same project after confirmation.');
  const prompt = createInterface({input: process.stdin, output: process.stdout});
  let answer;
  try { answer = (await prompt.question('Type PUBLISH to continue: ')).trim(); }
  finally { prompt.close(); }
  if (answer !== 'PUBLISH') {
    console.log('Publishing cancelled. No configuration was written and no deployment was started.');
    return;
  }

  function firebase(args, {capture = false} = {}) {
    const result = spawnSync(process.execPath, [cli, ...args], {
      cwd: root, encoding: capture ? 'utf8' : undefined,
      stdio: capture ? ['ignore', 'pipe', 'pipe'] : 'inherit', maxBuffer: 2 * 1024 * 1024
    });
    if (result.error || result.status !== 0) throw new Error('Firebase stopped. Check the message above and sign in with the owner of babo-market before trying again.');
    return result.stdout;
  }

  // Firebase reuses its existing local login; the browser is opened only if needed.
  firebase(['login']);
  let config = rootConfig || publicConfig;
  if (!config) {
    let response;
    try { response = JSON.parse(firebase(['apps:sdkconfig', 'WEB', '--project', PROJECT, '--json', '--non-interactive'], {capture: true})); }
    catch { throw new Error('Could not read the Web app settings. Sign in as the project owner and check that babo-market has one registered Web app.'); }
    config = inspectConfig(response.result?.sdkConfig, 'Firebase Web app settings');
    if (!config || config.projectId !== PROJECT) throw new Error('Firebase did not return complete Web settings for babo-market. No deployment was started.');
  }

  const changes = [];
  if (!rootConfig) changes.push({file: rootFile, bytes: rootBytes, backup: 'firebase.config.json', value: JSON.stringify(config, null, 2) + '\n'});
  if (!compatible(config, publicConfig)) changes.push({file: publicFile, bytes: publicBytes, backup: 'firebase-config.public.js', value: publicSource(config)});
  if (changes.length) {
    const backupParent = path.join(root, '.bebo-update-backups');
    await mkdir(backupParent, {recursive: true, mode: 0o700});
    const backup = await mkdtemp(path.join(backupParent, 'update-'));
    for (const change of changes) {
      if (change.bytes !== undefined) await copyFile(change.file, path.join(backup, change.backup));
    }
    for (const change of changes) await writeFile(change.file, change.value);
    console.log('Web settings recovered. Previous files are saved privately under .bebo-update-backups.');
  }

  const check = spawnSync(process.execPath, [path.join(root, 'tools/check-site.mjs')], {cwd: root, stdio: 'inherit'});
  if (check.error || check.status !== 0) throw new Error('Site check failed. Read the file errors above before publishing.');
  firebase(['deploy', '--only', 'hosting', '--project', PROJECT]);
  console.log('Website update published successfully.');
  console.log('Open https://babo-market.web.app/ and press Ctrl+F5.');
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  publishUpdate().catch(error => { console.error(error.message); process.exitCode = 1; });
}
