import {getCatalog, createOrder, isConfigured} from './backend.js';
import {initNavigation, navigateToSection, refreshPills} from './navigation.js';
import {
  CATEGORY_NAMES, MAX_DISTINCT_ITEMS, MAX_QUANTITY, addCartItems, cartSummary,
  escapeHtml, filterCatalog, parseCart, reconcileCart, resolveSavedCart, safeWhatsAppUrl,
  sanitizeCatalog, serializeCart, validateCustomer,
} from './market-core.js';

const $ = id => document.getElementById(id);
const html = escapeHtml;
let catalog = sanitizeCatalog(null);
let cart = [];
let unresolvedCart = [];
let cartVerifiedByLiveCatalog = false;
let currentFilter = 'all';
let currentStoreId = null;
let temporaryItems = new Map();
let activeDialog = null;
let dialogOpener = null;
let inertElements = [];
let submitting = false;
let request = null;
let savedResult = null;
let storageWarning = '';
let toastTimer;

function configured() {
  try { return isConfigured() === true; } catch { return false; }
}

function canOrder() {
  return configured() && catalog.configured && catalog.source === 'firebase'
    && catalog.settings.demoMode === false && navigator.onLine !== false;
}

function setText(id, value) { if ($(id)) $(id).textContent = value; }

function formatPrice(value) {
  return `${Number(value || 0).toLocaleString('ar-SD')} ${catalog.settings.currency}`;
}

function readCart() {
  try { return parseCart(localStorage.getItem('beboCart')); }
  catch {
    storageWarning = 'حفظ السلة على هذا الجهاز غير متاح؛ ستبقى السلة في هذه الصفحة فقط.';
    return [];
  }
}

function saveCart() {
  try { localStorage.setItem('beboCart', serializeCart(unresolvedCart.length ? unresolvedCart : cart)); }
  catch {
    storageWarning = 'تعذّر حفظ السلة على هذا الجهاز. أبقِ الصفحة مفتوحة حتى تكمل طلبك.';
    updateNotices();
  }
}

function invalidateDraft() {
  request = null;
  savedResult = null;
  const result = $('orderResult');
  if (result) { result.hidden = true; result.replaceChildren(); }
  setText('orderError', '');
}

function commitCart(items, {discardUnresolved = false} = {}) {
  if (unresolvedCart.length && !discardUnresolved) {
    showToast('سلتك المحفوظة تنتظر القائمة المباشرة. أعد الاتصال أو فرّغ السلة بنفسك قبل بدء سلة جديدة.');
    return false;
  }
  const focused = document.activeElement;
  const focusAction = focused?.dataset?.action;
  const focusIndex = focused?.dataset?.index;
  if (discardUnresolved) unresolvedCart = [];
  cart = reconcileCart(items, catalog).items;
  cartVerifiedByLiveCatalog = catalog.source === 'firebase';
  invalidateDraft();
  saveCart();
  updateNotices();
  renderCart();
  if (focusIndex !== undefined && ['change-cart-qty', 'remove-item'].includes(focusAction)) {
    const replacement = $('cartItems')?.querySelector(`[data-action="${focusAction}"][data-index="${focusIndex}"]`);
    (replacement || $('cartSidebar')?.querySelector('[data-action="toggle-cart"]'))?.focus();
  }
  return true;
}

function updateNotices() {
  const demo = catalog.source !== 'firebase' || catalog.settings.demoMode;
  const notice = $('catalogNotice');
  if (notice) {
    notice.hidden = !demo && !storageWarning && !unresolvedCart.length;
    notice.textContent = [demo
      ? catalog.source === 'offline'
        ? 'تعذّر تحديث القائمة المباشرة. المعروض للتصفّح فقط؛ الطلب الإلكتروني متوقف حتى عودة الاتصال. تواصل معنا للتحقّق من المتاجر والأسعار.'
        : 'قائمة تجريبية للتعرّف على الموقع. المتاجر والأسعار المعروضة أمثلة؛ تواصل معنا قبل الطلب.'
      : '', unresolvedCart.length ? 'سلتك المحفوظة محميّة وتنتظر تحديث القائمة المباشرة؛ لن نستبدلها بمنتجات العرض التجريبي.' : '', storageWarning].filter(Boolean).join(' ');
  }
  const offline = navigator.onLine === false;
  if ($('connectionNotice')) {
    $('connectionNotice').hidden = !offline;
    $('connectionNotice').textContent = 'أنت غير متصل بالإنترنت. سلتك باقية؛ عد للاتصال قبل تسجيل الطلب.';
  }
  updatePrepareButton();
}

function applyCatalogSettings() {
  const settings = catalog.settings;
  document.title = `${settings.siteName} | توصيل دنقلا`;
  document.querySelectorAll('[data-site-name]').forEach(element => { element.textContent = settings.siteName; });
  document.querySelectorAll('[data-category-count]').forEach(element => {
    const count = catalog.stores.filter(store => store.enabled && store.category === element.dataset.categoryCount).length;
    element.textContent = `${count.toLocaleString('ar-SD')} متجر`;
  });
  const enabledStores = catalog.stores.filter(store => store.enabled);
  document.querySelectorAll('[data-count-stores]').forEach(element => {
    element.textContent = enabledStores.length.toLocaleString('ar-SD');
  });
  document.querySelectorAll('[data-count-category]').forEach(element => {
    element.textContent = enabledStores.filter(store => store.category === element.dataset.countCategory).length.toLocaleString('ar-SD');
  });
  document.querySelectorAll('[data-city]').forEach(element => { element.textContent = settings.city; });
  if ($('phonePreviewStores')) $('phonePreviewStores').innerHTML = enabledStores.slice(0, 4).map(store =>
    `<button type="button" class="app-item" data-action="open-store" data-store-id="${html(store.id)}">${html(store.icon)} ${html(store.name)}</button>`
  ).join('') || '<p class="store-note">لا توجد متاجر في القائمة حاليًا.</p>';
  setText('storeCount', `${catalog.stores.filter(store => store.enabled).length.toLocaleString('ar-SD')} متجر في القائمة`);
  setText('deliveryNote', settings.deliveryNote);
  setText('availabilityNote', settings.availabilityNote);
  document.querySelectorAll('[data-contact]').forEach(link => {
    const kind = link.dataset.contact;
    if (kind === 'phone') link.href = `tel:${settings.phone}`;
    if (kind === 'facebook') link.href = settings.facebookUrl;
    if (kind === 'whatsapp') {
      let message = '';
      try { message = new URL(link.href).searchParams.get('text') || ''; } catch { /* Safe contact URL below. */ }
      link.href = `https://wa.me/${settings.whatsappNumber}${message ? `?text=${encodeURIComponent(message)}` : ''}`;
    }
    if (link.matches('.contact-card')) {
      const detail = link.querySelector('p');
      if (detail && kind === 'phone') detail.textContent = settings.phone;
      if (detail && kind === 'whatsapp') detail.textContent = `+${settings.whatsappNumber}`;
      if (detail && kind === 'facebook') detail.textContent = new URL(settings.facebookUrl).pathname.replace(/^\//, '@');
    }
    if (link.target === '_blank') link.rel = 'noopener noreferrer';
  });
  updateNotices();
  refreshPills();
}

async function loadCatalog({fresh = false} = {}) {
  const next = sanitizeCatalog(await getCatalog({fresh}));
  const previous = serializeCart(unresolvedCart.length ? unresolvedCart : cart);
  const previousPrices = JSON.stringify(cart.map(item => [item.storeId, item.productId, item.price]));
  const previousFee = catalog.settings.deliveryFee;
  const pendingRequest = Boolean(request) && !savedResult;
  catalog = next;
  // Keep the quoted cart while resolving an uncertain write. Refreshing it must
  // not silently discard the idempotency key of an order that may already exist.
  let reconciled;
  if (pendingRequest) reconciled = {items: cart, changes: []};
  else if (catalog.source === 'firebase' || unresolvedCart.length || cartVerifiedByLiveCatalog) {
    reconciled = resolveSavedCart(unresolvedCart.length ? unresolvedCart : cart, catalog);
    unresolvedCart = reconciled.unresolved;
    cartVerifiedByLiveCatalog = catalog.source === 'firebase';
  } else reconciled = reconcileCart(cart, catalog); // A new, unsaved demo-session cart.
  cart = reconciled.items;
  const changed = !pendingRequest && (previous !== serializeCart(unresolvedCart.length ? unresolvedCart : cart)
    || previousPrices !== JSON.stringify(cart.map(item => [item.storeId, item.productId, item.price]))
    || previousFee !== catalog.settings.deliveryFee);
  if (changed) {
    invalidateDraft();
    // A fallback list must not overwrite a cart saved from the live catalog.
    if (catalog.source === 'firebase') saveCart();
  }
  applyCatalogSettings();
  renderStores();
  renderCart();
  return {changed, removed: reconciled.changes.some(change => change.type === 'unavailable')};
}

function renderStores() {
  const grid = $('storesGrid');
  if (!grid) return;
  const stores = filterCatalog(catalog.stores, currentFilter, $('searchInput')?.value || '');
  if (!stores.length) {
    grid.innerHTML = '<div class="store-empty"><span aria-hidden="true">🔍</span><h3>لا توجد نتائج</h3><p>جرّب كلمة أخرى أو اختر قسم الكل.</p></div>';
    return;
  }
  grid.innerHTML = stores.map(store => `
    <button type="button" class="store-card" data-action="open-store" data-store-id="${html(store.id)}" aria-label="${html(`عرض منتجات ${store.name}`)}">
      <span class="store-card-image ${store.category}">
        <span aria-hidden="true">${html(store.icon)}</span>
        <span class="store-status ${store.isOpen ? 'open' : 'closed'}">${store.isOpen ? 'مفتوح للطلبات' : 'مغلق حاليًا'}</span>
      </span>
      <span class="store-card-body">
        <strong class="store-name">${html(store.name)}</strong>
        <span class="store-desc">${html(store.description)}</span>
        <span class="store-meta"><span>${html(CATEGORY_NAMES[store.category])}</span><span>${html(store.deliveryTime || 'وقت التوصيل بالتأكيد')}</span></span>
      </span>
    </button>`).join('');
}

function setFilter(category, scroll = false, focus = false) {
  currentFilter = category === 'all' || Object.hasOwn(CATEGORY_NAMES, category) ? category : 'all';
  document.querySelectorAll('[data-filter]').forEach(button => {
    const selected = button.dataset.filter === currentFilter;
    button.classList.toggle('active', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  renderStores();
  refreshPills();
  if (scroll) navigateToSection('stores', {focus});
}

function setMenu(open) {
  $('navLinks')?.classList.toggle('active', open);
  $('menuToggle')?.setAttribute('aria-expanded', String(open));
}

function focusableElements(dialog) {
  return [...dialog.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex="0"]')]
    .filter(element => !element.hidden && !element.closest('[hidden]') && element.getClientRects().length > 0);
}

function closeDialog({restore = true} = {}) {
  if (!activeDialog) return;
  activeDialog.classList.remove('active');
  activeDialog.setAttribute('aria-hidden', 'true');
  activeDialog.inert = true;
  $('cartOverlay')?.classList.remove('active');
  $('cartBtn')?.setAttribute('aria-expanded', 'false');
  inertElements.forEach(([element, wasInert]) => { element.inert = wasInert; });
  inertElements = [];
  activeDialog = null;
  document.body.style.overflow = '';
  if (restore && dialogOpener?.isConnected) dialogOpener.focus();
  dialogOpener = null;
}

function openDialog(id) {
  const dialog = $(id);
  if (!dialog) return;
  const opener = document.activeElement;
  closeDialog({restore: false});
  dialogOpener = opener;
  activeDialog = dialog;
  dialog.inert = false;
  dialog.classList.add('active');
  dialog.setAttribute('aria-hidden', 'false');
  dialog.setAttribute('tabindex', '-1');
  if (id === 'cartSidebar') {
    $('cartOverlay')?.classList.add('active');
    $('cartBtn')?.setAttribute('aria-expanded', 'true');
  }
  setMenu(false);
  document.body.style.overflow = 'hidden';
  for (const element of document.body.children) {
    if (element === dialog || element.contains(dialog) || element === $('cartOverlay') || ['SCRIPT', 'STYLE'].includes(element.tagName)) continue;
    inertElements.push([element, element.inert]);
    element.inert = true;
  }
  (focusableElements(dialog)[0] || dialog).focus();
}

function openStore(id) {
  const store = catalog.stores.find(item => String(item.id) === String(id) && item.enabled);
  if (!store) return;
  currentStoreId = store.id;
  temporaryItems = new Map();
  setText('modalStoreName', `${store.icon} ${store.name}`);
  setText('modalStoreCategory', CATEGORY_NAMES[store.category]);
  setText('modalStoreRating', store.isOpen ? 'نؤكّد التوفّر قبل التنفيذ' : 'المتجر مغلق حاليًا');
  setText('modalStoreTime', store.deliveryTime || 'وقت التوصيل بالتأكيد');
  renderProducts(store);
  updateModalTotal();
  openDialog('storeModal');
}

function renderProducts(store) {
  const products = store.products.filter(product => product.enabled);
  if (!$('productsList')) return;
  $('productsList').innerHTML = products.length ? products.map(product => {
    const available = store.isOpen && product.available;
    return `<div class="product-item">
      <div class="product-info"><h4>${html(product.emoji)} ${html(product.name)}</h4><span class="product-price">${html(formatPrice(product.price))}</span>
      ${available ? '' : `<small class="store-note">${store.isOpen ? 'غير متوفر حاليًا' : 'الطلب متوقف؛ المتجر مغلق'}</small>`}</div>
      <div class="product-actions">
        <button type="button" class="qty-btn" data-action="change-product-qty" data-product-id="${html(product.id)}" data-delta="-1" aria-label="${html(`تقليل كمية ${product.name}`)}" disabled>−</button>
        <span class="qty-value" id="qty-${html(product.id)}" aria-live="polite">0</span>
        <button type="button" class="qty-btn" data-action="change-product-qty" data-product-id="${html(product.id)}" data-delta="1" aria-label="${html(`زيادة كمية ${product.name}`)}" ${available ? '' : 'disabled'}>+</button>
      </div></div>`;
  }).join('') : '<p class="store-note">لم يضف المتجر منتجات متاحة بعد.</p>';
  const addButton = $('storeModal')?.querySelector('[data-action="add-cart"]');
  if (addButton) addButton.disabled = Boolean(unresolvedCart.length) || !store.isOpen || !products.some(product => product.available);
}

function changeProductQuantity(productId, delta) {
  const store = catalog.stores.find(item => String(item.id) === String(currentStoreId));
  const product = store?.products.find(item => String(item.id) === String(productId));
  if (!store?.isOpen || !product?.available || !product.enabled) return;
  const key = String(product.id);
  const quantity = Math.max(0, Math.min(MAX_QUANTITY, (temporaryItems.get(key) || 0) + delta));
  temporaryItems.set(key, quantity);
  setText(`qty-${product.id}`, quantity);
  $('productsList')?.querySelectorAll('[data-action="change-product-qty"]').forEach(button => {
    if (button.dataset.productId === key) button.disabled = Number(button.dataset.delta) < 0 ? quantity === 0 : quantity === MAX_QUANTITY;
  });
  updateModalTotal();
}

function updateModalTotal() {
  const store = catalog.stores.find(item => String(item.id) === String(currentStoreId));
  const total = store?.products.reduce((sum, product) => sum + product.price * (temporaryItems.get(String(product.id)) || 0), 0) || 0;
  setText('modalTotal', formatPrice(total));
}

function addSelectedToCart() {
  const store = catalog.stores.find(item => String(item.id) === String(currentStoreId));
  if (!store?.isOpen || submitting) return;
  if (unresolvedCart.length) return showToast('سلتك المحفوظة محميّة. انتظر تحديث القائمة المباشرة أو فرّغ السلة لبدء سلة جديدة.');
  const additions = store.products.filter(product => product.enabled && product.available && temporaryItems.get(String(product.id)) > 0)
    .map(product => ({storeId: store.id, productId: product.id, qty: temporaryItems.get(String(product.id))}));
  if (!additions.length) return showToast('اختر منتجًا واحدًا على الأقل.');
  if (additions.length > MAX_DISTINCT_ITEMS) return showToast('الطلب الواحد يتسع إلى 10 أصناف مختلفة.');
  const next = addCartItems(cart, additions);
  if (next.error) return showToast(next.error === 'item-limit' ? 'الطلب الواحد يتسع إلى 10 أصناف مختلفة.' : 'الحد الأعلى 99 قطعة من الصنف الواحد.');
  if (!commitCart(next.items)) return;
  closeDialog();
  showToast('أُضيفت المنتجات إلى السلة.');
}

function renderCart() {
  const summary = cartSummary(cart, catalog.settings.deliveryFee);
  const pendingCount = unresolvedCart.reduce((sum, item) => sum + item.qty, 0);
  const count = summary.count + pendingCount;
  setText('cartCount', count);
  $('cartBtn')?.setAttribute('aria-label', `سلة التسوق، ${count} قطعة`);
  if ($('cartFooter')) $('cartFooter').style.display = count ? 'block' : 'none';
  if ($('cartItems')) $('cartItems').innerHTML = unresolvedCart.length
    ? `<div class="notice"><strong>سلتك المحفوظة باقية: ${pendingCount} قطعة</strong><p>ننتظر القائمة المباشرة لعرض أسماء المنتجات وأسعارها الصحيحة. أعد الاتصال؛ ستعود السلة تلقائيًا. يمكنك تفريغها بنفسك إذا أردت بدء سلة جديدة.</p></div>`
    : cart.length ? cart.map((item, index) => `
    <div class="cart-item"><div class="cart-item-info">
      <h4>${html(item.emoji)} ${html(item.name)}</h4><small>${html(item.storeName)} · ${html(formatPrice(item.price))} للقطعة</small>
      <div class="product-actions cart-quantity">
        <button type="button" class="qty-btn" data-action="change-cart-qty" data-index="${index}" data-delta="-1" aria-label="${html(`تقليل كمية ${item.name}`)}" ${submitting ? 'disabled' : ''}>−</button>
        <span class="qty-value">${item.qty}</span>
        <button type="button" class="qty-btn" data-action="change-cart-qty" data-index="${index}" data-delta="1" aria-label="${html(`زيادة كمية ${item.name}`)}" ${submitting || item.qty >= MAX_QUANTITY ? 'disabled' : ''}>+</button>
      </div></div><div class="cart-item-end"><span class="cart-item-price">${html(formatPrice(item.price * item.qty))}</span>
      <button type="button" class="cart-item-remove" data-action="remove-item" data-index="${index}" aria-label="${html(`حذف ${item.name} من السلة`)}" ${submitting ? 'disabled' : ''}>✕</button></div></div>`).join('')
    : '<div class="cart-empty"><span class="cart-empty-icon" aria-hidden="true">🛒</span><p>السلة فارغة</p><small>اختر متجرًا وأضف المنتجات التي تحتاجها.</small></div>';
  setText('cartSubtotal', unresolvedCart.length ? 'بانتظار تحديث القائمة' : formatPrice(summary.subtotal));
  setText('cartDelivery', unresolvedCart.length ? 'بانتظار تحديث القائمة' : formatPrice(summary.deliveryFee));
  setText('cartTotal', unresolvedCart.length ? 'بانتظار تحديث القائمة' : formatPrice(summary.total));
  updatePrepareButton();
  if (count && !canOrder() && !savedResult && !submitting) renderContactHelp();
  else if (!savedResult && $('orderResult')?.dataset.state === 'contact') {
    $('orderResult').hidden = true;
    $('orderResult').replaceChildren();
  }
}

function changeCartQuantity(index, delta) {
  if (submitting || !cart[index]) return;
  const items = cart.map(item => ({...item}));
  items[index].qty = Math.min(MAX_QUANTITY, items[index].qty + delta);
  commitCart(items.filter(item => item.qty > 0));
}

function updatePrepareButton() {
  const button = document.querySelector('[data-action="prepare-order"]');
  if (!button) return;
  button.disabled = submitting || !cart.length || !canOrder() || Boolean(savedResult);
  button.textContent = submitting ? 'جارٍ تسجيل الطلب…' : savedResult ? 'الطلب مسجل — افتح واتساب أدناه' : 'تسجيل الطلب وتجهيز رسالة واتساب';
  button.setAttribute('aria-busy', String(submitting));
}

function renderContactHelp(message = '', state = 'contact') {
  const result = $('orderResult');
  if (!result) return;
  result.hidden = false;
  result.dataset.state = state;
  const offline = navigator.onLine === false;
  const inquiry = state === 'error-contact' && request?.id
    ? `السلام عليكم، أريد التحقق من تسجيل الطلب رقم ${request.id} قبل تكرار المحاولة.`
    : 'السلام عليكم، أريد الاستفسار عن المتاجر والتوصيل في دنقلا.';
  result.innerHTML = `<p>${html(message || (offline ? 'تسجيل الطلب يحتاج اتصالًا بالإنترنت. سلتك باقية هنا.' : 'الطلبات الإلكترونية غير مفعّلة لهذه القائمة حاليًا. اسألنا عن المتاجر والتوفّر عبر واتساب.'))}</p>
    <a class="btn btn-whatsapp btn-block" href="https://wa.me/${catalog.settings.whatsappNumber}?text=${encodeURIComponent(inquiry)}" target="_blank" rel="noopener noreferrer">استفسار عبر واتساب</a>
    <a class="btn btn-outline btn-block" href="tel:${catalog.settings.phone}">اتصل بنا: <bdi>${catalog.settings.phone}</bdi></a>`;
}

function showFieldErrors(errors = {}) {
  const fields = {name: 'customerName', phone: 'customerPhone', address: 'customerAddress', notes: 'orderNotes'};
  for (const [key, id] of Object.entries(fields)) {
    const field = $(id);
    if (!field) continue;
    const errorId = `${id}Error`;
    let error = $(errorId);
    if (!error) {
      error = document.createElement('small');
      error.id = errorId;
      error.className = 'field-error';
      field.insertAdjacentElement('afterend', error);
    }
    error.textContent = errors[key] || '';
    error.hidden = !errors[key];
    field.setAttribute('aria-invalid', String(Boolean(errors[key])));
    const ids = new Set((field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean));
    ids.add(errorId);
    field.setAttribute('aria-describedby', [...ids].join(' '));
  }
}

function formData() {
  return validateCustomer({name: $('customerName')?.value || '', phone: $('customerPhone')?.value || '',
    address: $('customerAddress')?.value || '', notes: $('orderNotes')?.value || ''});
}

function newRequestId() {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const value = [...bytes].map(byte => byte.toString(16).padStart(2, '0')).join('');
  return `${value.slice(0, 8)}-${value.slice(8, 12)}-${value.slice(12, 16)}-${value.slice(16, 20)}-${value.slice(20)}`;
}

function showOrderError(message) { setText('orderError', message); showToast(message); }

async function prepareOrder() {
  if (submitting || savedResult) return;
  if (!cart.length) return showOrderError('أضف منتجات إلى السلة أولًا.');
  if (!canOrder()) { renderContactHelp(); return; }
  const data = formData();
  showFieldErrors(data.errors);
  if (!data.valid) {
    const first = {name: 'customerName', phone: 'customerPhone', address: 'customerAddress', notes: 'orderNotes'}[Object.keys(data.errors)[0]];
    $(first)?.focus();
    return showOrderError('راجع الحقول الموضّحة قبل تسجيل الطلب.');
  }
  setText('orderError', '');
  submitting = true;
  ['customerName', 'customerPhone', 'customerAddress', 'orderNotes'].forEach(id => { if ($(id)) $(id).disabled = true; });
  renderCart();
  try {
    if (!request) {
      const refreshed = await loadCatalog({fresh: true});
      if (!canOrder()) throw new Error('catalog-unavailable');
      if (refreshed.changed) {
        showOrderError(refreshed.removed ? 'تغيّر توفّر بعض المنتجات. حدّثنا السلة؛ راجعها ثم سجّل الطلب.' : 'تحدّثت الأسعار أو رسوم التوصيل. راجع الإجمالي الجديد ثم سجّل الطلب.');
        return;
      }
      request = {
        id: newRequestId(),
        payload: {customer: data.customer, notes: data.notes,
          items: cart.map(({storeId, productId, qty}) => ({storeId, productId, qty})), catalogVersion: catalog.version},
      };
    }
    // Retry the exact earlier payload before refreshing prices: the write may have
    // succeeded even if its response was lost, and the adapter checks this ID first.
    const result = await createOrder({...request.payload, requestId: request.id});
    if (!result?.order?.id) throw new Error('invalid-order-response');
    savedResult = {order: result.order, message: String(result.message || ''), whatsappUrl: safeWhatsAppUrl(result.whatsappUrl, catalog.settings.whatsappNumber)};
    renderOrderResult();
    saveCart(); // Keep the cart until its owner explicitly empties it.
    showToast('سُجّل الطلب للمراجعة. افتح واتساب وأرسل الرسالة لتأكيد التفاصيل.');
  } catch (error) {
    // Retain the request ID after network failures so a retry cannot duplicate an order.
    const code = String(error?.code || error?.message || '');
    if (/BEBO_VERSION_CONFLICT|BEBO_PRODUCT_UNAVAILABLE/.test(code)) {
      // These explicit responses mean no order was recorded for this request.
      request = null;
      await loadCatalog({fresh: true}).catch(() => {});
    }
    const message = /catalog|version|price|unavailable|not.available/i.test(code)
      ? 'تعذّر تسجيل الطلب لأن القائمة تغيّرت أو غير متاحة. راجع السلة وحاول مجددًا.'
      : /permission|unauth|config|demo/i.test(code)
        ? 'تسجيل الطلب غير متاح حاليًا. تواصل معنا عبر واتساب؛ سلتك باقية.'
        : 'تعذّر تأكيد تسجيل الطلب. سلتك باقية؛ تحقّق من الاتصال وأعد المحاولة بنفس التفاصيل.';
    showOrderError(message);
    renderContactHelp('إذا تعذّر تكرار المحاولة، تواصل معنا للاستفسار عن تسجيل طلبك. لا ترسل الطلب مرتين قبل التحقّق.', 'error-contact');
  } finally {
    submitting = false;
    ['customerName', 'customerPhone', 'customerAddress', 'orderNotes'].forEach(id => { if ($(id)) $(id).disabled = false; });
    renderCart();
    if (savedResult) {
      renderOrderResult();
      if (activeDialog === $('cartSidebar')) $('orderResult')?.focus();
    }
  }
}

function renderOrderResult() {
  const panel = $('orderResult');
  if (!panel || !savedResult) return;
  const {order, whatsappUrl, message} = savedResult;
  const status = {pending: 'قيد المراجعة', confirmed: 'تم التأكيد', delivering: 'قيد التوصيل', completed: 'مكتمل', cancelled: 'ملغي'}[order.status] || 'راجع الحالة مع الإدارة';
  panel.hidden = false;
  panel.dataset.state = 'saved';
  panel.setAttribute('tabindex', '-1');
  panel.innerHTML = `<h4>سُجّل الطلب رقم <bdi>${html(order.id)}</bdi></h4>
    <p><strong>حالة الطلب: ${status}</strong></p>
    <p>${order.status === 'pending' ? 'الطلب قيد المراجعة، ولم يُؤكّد الدفع أو التنفيذ. افتح واتساب واضغط إرسال هناك، لنتأكد معك من التوفّر والتوصيل.' : 'هذا طلب محفوظ سابقًا. تواصل مع الإدارة عبر واتساب لمتابعة حالته وتفاصيله.'}</p>
    <p><strong>الإجمالي المسجل: ${html(formatPrice(order.total))}</strong></p>
    ${whatsappUrl ? `<a class="btn btn-whatsapp btn-block" href="${html(whatsappUrl)}" target="_blank" rel="noopener noreferrer">فتح الطلب في واتساب</a>` : '<p class="field-error">تعذّر تجهيز رابط واتساب؛ انسخ الرسالة واتصل بنا.</p>'}
    ${message ? '<button type="button" class="btn btn-outline btn-block" data-action="copy-order-message">نسخ رسالة الطلب</button>' : ''}
    <a class="btn btn-outline btn-block" href="tel:${catalog.settings.phone}">اتصل بنا: <bdi>${catalog.settings.phone}</bdi></a>
    <p class="field-hint">ستبقى المنتجات في السلة حتى تفرّغها بنفسك.</p>`;
  updatePrepareButton();
}

async function copyOrderMessage() {
  if (!savedResult?.message) return;
  try {
    if (!navigator.clipboard?.writeText) throw new Error('clipboard-unavailable');
    await navigator.clipboard.writeText(savedResult.message);
    showToast('نُسخت رسالة الطلب. الصقها في محادثة واتساب معنا.');
  } catch {
    let field = $('orderMessageCopy');
    if (!field) {
      const label = document.createElement('label');
      label.htmlFor = 'orderMessageCopy';
      label.textContent = 'انسخ هذه الرسالة يدويًا:';
      field = document.createElement('textarea');
      field.id = 'orderMessageCopy';
      field.rows = 7;
      field.readOnly = true;
      $('orderResult')?.append(label, field);
    }
    field.value = savedResult.message;
    field.focus();
    field.select();
    showToast('حدّدنا الرسالة؛ استخدم أمر النسخ في جهازك.');
  }
}

function showToast(message) {
  let toast = $('appToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'appToast';
    toast.className = 'toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    document.body.append(toast);
  }
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.hidden = false;
  toastTimer = setTimeout(() => { toast.hidden = true; }, 5500);
}

function initEvents() {
  initNavigation();
  $('searchInput')?.addEventListener('input', renderStores);
  ['customerName', 'customerPhone', 'customerAddress', 'orderNotes'].forEach(id => {
    $(id)?.addEventListener('input', () => {
      if (!submitting) {
        invalidateDraft();
        showFieldErrors();
        updatePrepareButton();
        if ((cart.length || unresolvedCart.length) && !canOrder()) renderContactHelp();
      }
    });
  });
  document.addEventListener('click', event => {
    if (!(event.target instanceof Element)) return;
    if (event.target === $('storeModal') || event.target === $('confirmModal')) return closeDialog();
    if (event.target.closest('#navLinks a')) setMenu(false);
    const filter = event.target.closest('[data-filter], [data-category]');
    if (filter) return setFilter(filter.dataset.filter || filter.dataset.category, Boolean(filter.dataset.category), event.detail === 0);
    const button = event.target.closest('[data-action]');
    if (!button || button.disabled) return;
    const action = button.dataset.action;
    if (action === 'toggle-menu') setMenu(!$('navLinks')?.classList.contains('active'));
    if (action === 'toggle-cart') activeDialog === $('cartSidebar') ? closeDialog() : openDialog('cartSidebar');
    if (action === 'close-modal') closeDialog();
    if (action === 'open-store') openStore(button.dataset.storeId);
    if (action === 'change-product-qty') changeProductQuantity(button.dataset.productId, Number(button.dataset.delta));
    if (action === 'add-cart') addSelectedToCart();
    if (action === 'change-cart-qty') changeCartQuantity(Number(button.dataset.index), Number(button.dataset.delta));
    if (action === 'remove-item' && !submitting) commitCart(cart.filter((_, index) => index !== Number(button.dataset.index)));
    if (action === 'clear-cart' && !submitting && (cart.length || unresolvedCart.length)) {
      openDialog('confirmModal');
      dialogOpener = $('cartBtn');
    }
    if (action === 'cancel-clear-cart') {
      openDialog('cartSidebar');
      dialogOpener = $('cartBtn');
    }
    if (action === 'confirm-clear-cart' && !submitting) {
      commitCart([], {discardUnresolved: true});
      closeDialog();
      showToast('أُفرغت السلة.');
    }
    if (action === 'prepare-order') void prepareOrder();
    if (action === 'copy-order-message') void copyOrderMessage();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { closeDialog(); setMenu(false); }
    if (event.key !== 'Tab' || !activeDialog) return;
    const elements = focusableElements(activeDialog);
    if (!elements.length) { event.preventDefault(); activeDialog.focus(); return; }
    const first = elements[0];
    const last = elements.at(-1);
    if (event.shiftKey && (document.activeElement === first || !activeDialog.contains(document.activeElement))) {
      event.preventDefault(); last.focus();
    } else if (!event.shiftKey && (document.activeElement === last || !activeDialog.contains(document.activeElement))) {
      event.preventDefault(); first.focus();
    }
  });
  window.addEventListener('offline', () => { updateNotices(); renderCart(); });
  window.addEventListener('online', () => {
    updateNotices();
    void loadCatalog({fresh: true}).catch(() => { updateNotices(); });
  });
}

async function init() {
  unresolvedCart = readCart();
  if ($('storeModal')) $('storeModal').inert = true;
  if ($('cartSidebar')) $('cartSidebar').inert = true;
  if ($('confirmModal')) $('confirmModal').inert = true;
  initEvents();
  setFilter('all');
  setText('catalogNotice', 'جارٍ تحميل قائمة المتاجر…');
  try { await loadCatalog(); }
  catch {
    catalog = sanitizeCatalog({source: 'offline'});
    applyCatalogSettings();
    renderStores();
    renderCart();
    showToast('تعذّر تحميل القائمة. تواصل معنا عبر واتساب أو الهاتف.');
  }
}

// Read-only diagnostics contain no customer details or administrator credentials.
window.BeboMarket = Object.freeze({
  getCatalog: () => structuredClone(catalog),
  getCart: () => (unresolvedCart.length ? unresolvedCart : cart).map(({storeId, productId, qty}) => ({storeId, productId, qty})),
});

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
else void init();
