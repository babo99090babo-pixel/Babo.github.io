/* Only public same-origin assets are cached. Firebase data and admin screens are never cached here. */
const CACHE = 'bebo-market-public-v4-tabs-20261109';
const BASE = new URL('.', self.location.href);
const ASSETS = ['./', './index.html', './css/style.css', './css/fonts.css', './css/tabs.css', './css/branding.css', './images/babo-market-logo.webp', './images/favicon.png', './images/apple-touch-icon.png', './images/icon-192.png', './images/icon-512.png', './images/icon-maskable-512.png', './js/app.js', './js/navigation.js', './js/backend.js', './js/firebase-init.js', './js/firebase-config.js', './js/market-core.js', './js/pwa.js', './manifest.json', './fonts/cairo-variable.woff2', './data/default-catalog.json'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS.map(path => new URL(path, BASE).href))));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('bebo-market-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== BASE.origin || !url.pathname.startsWith(BASE.pathname) || url.pathname.startsWith(new URL('admin/', BASE).pathname)) return;
  event.respondWith((async () => {
    try {
      const response = await fetch(request);
      if (response.ok && response.type === 'basic') {
        const cache = await caches.open(CACHE);
        await cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      const cached = await caches.match(request);
      if (cached) return cached;
      if (request.mode === 'navigate') {
        const fallback = await caches.match(new URL('index.html', BASE).href);
        if (fallback) return fallback;
      }
      return Response.error();
    }
  })());
});
