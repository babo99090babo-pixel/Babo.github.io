import { test } from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import { validateFirebaseConfig } from '../tools/config-lib.mjs';
const valid = {apiKey:'public-client-key',authDomain:'bebo-market-test.firebaseapp.com',projectId:'bebo-market-test',appId:'1:123:web:abc'};
test('allows an unconfigured preview but requires all fields for publishing', () => {
  assert.equal(validateFirebaseConfig({apiKey:'',authDomain:'',projectId:'',appId:''}), false);
  assert.throws(() => validateFirebaseConfig({}, {required:true}));
  assert.equal(validateFirebaseConfig(valid, {required:true}), true);
});
test('refuses the existing college project and service-account credentials', () => {
  assert.throws(() => validateFirebaseConfig({...valid,projectId:'dongola-eng'}));
  assert.throws(() => validateFirebaseConfig({...valid,private_key:'example-private-key'}));
  assert.throws(() => validateFirebaseConfig({...valid,type:'service_account'}));
});
test('rejects partial configuration and unsafe project/domain strings', () => {
  assert.throws(() => validateFirebaseConfig({...valid,appId:''}));
  assert.throws(() => validateFirebaseConfig({...valid,authDomain:'https://bad.example/path'}));
  assert.throws(() => validateFirebaseConfig({...valid,projectId:'../other-site'}));
});

test('Windows launchers use CRLF ASCII without embedded command control characters', () => {
  for(const name of ['deploy.bat','setup-firebase.bat','preview.bat']) {
    const bytes=readFileSync(new URL('../'+name,import.meta.url));
    assert.ok([...bytes].every(value=>value===9||value===10||value===13||(value>=32&&value<=126)),name);
    assert.ok(!bytes.toString('ascii').replaceAll('\r\n','').includes('\n'),name);
  }
});
