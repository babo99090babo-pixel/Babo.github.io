import assert from 'node:assert/strict';
import { after, before, beforeEach, test } from 'node:test';
import { readFile } from 'node:fs/promises';
import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import {
  collection, deleteDoc, doc, getDoc, getDocs, serverTimestamp, setDoc,
  Timestamp, updateDoc, writeBatch, setLogLevel
} from 'firebase/firestore';

// Expected denials are asserted below; keep their SDK diagnostics from obscuring test results.
setLogLevel('silent');

// The separate project keeps this destructive test fixture away from UI QA.
const projectId = 'demo-bebo-market-rules';
const [host, portText] = (process.env.FIRESTORE_EMULATOR_HOST || '127.0.0.1:8080').split(':');
const adminEmail = 'owner@example.com';
const id = 'order-request-000001';
let env;

function catalog() {
  const products = Object.fromEntries(Array.from({ length: 10 }, (_, index) => {
    const productId = String(index + 1);
    return [`1_${productId}`, {
      storeId: '1', productId, storeName: 'متجر دنقلا', name: `منتج ${productId}`,
      emoji: '🥬', price: 100 + index, available: true, storeOpen: true
    }];
  }));
  return {
    version: 1,
    settings: {
      siteName: 'ببو ماركت', city: 'دنقلا', phone: '+249991974489',
      whatsappNumber: '249991974489', facebookUrl: 'https://www.facebook.com/Babo0Nasir',
      deliveryFee: 500, currency: 'جنيه', deliveryNote: 'حسب الحي',
      availabilityNote: 'نؤكد الطلب هاتفيًا', demoMode: false
    },
    stores: [{ id: '1', name: 'متجر دنقلا', open: true }], products,
    updatedAt: Timestamp.fromMillis(1), updatedBy: 'admin-1'
  };
}

function customerDb(uid = 'customer-1') {
  return env.authenticatedContext(uid, { firebase: { sign_in_provider: 'anonymous' } }).firestore();
}

function adminDb(claims = {}) {
  return env.authenticatedContext('admin-1', {
    email: adminEmail, email_verified: true, ...claims
  }).firestore();
}

function orderData({ uid = 'customer-1', requestId = id, count = 1 } = {}) {
  return {
    customer: { name: 'عميل دنقلا', phone: '+249912345678', address: 'دنقلا حي السوق المنزل ١' },
    notes: '', items: Object.entries(catalog().products).slice(0, count).map(([key, product]) => ({
      key, qty: 2, unitPrice: product.price, name: product.name, storeName: product.storeName, emoji: product.emoji
    })),
    deliveryFee: 500, catalogVersion: 1, createdAt: serverTimestamp(),
    createdBy: uid, status: 'pending', requestId
  };
}

function placeOrder({ db = customerDb(), order = orderData(), requestId = id, throttle = true } = {}) {
  const batch = writeBatch(db);
  batch.set(doc(db, 'orders', requestId), order);
  if (throttle) batch.set(doc(db, 'orderThrottle', order.createdBy), { orderId: requestId, createdAt: serverTimestamp() });
  return batch.commit();
}

async function seed(path, data) {
  await env.withSecurityRulesDisabled(context => setDoc(doc(context.firestore(), path), data));
}

async function patchCatalog(mutate) {
  const value = catalog();
  mutate(value);
  await seed('catalog/current', value);
}

function nextCatalog(mutate = () => {}) {
  const value = catalog();
  value.version = 2;
  value.updatedAt = serverTimestamp();
  mutate(value);
  return value;
}

before(async () => {
  env = await initializeTestEnvironment({
    projectId,
    firestore: { host, port: Number(portText), rules: await readFile(new URL('../firestore.rules', import.meta.url), 'utf8') }
  });
});

beforeEach(async () => {
  await env.clearFirestore();
  await seed('adminAccess/roster', {
    emails: [adminEmail], updatedAt: Timestamp.fromMillis(1), updatedBy: 'console-bootstrap'
  });
  await seed('catalog/current', catalog());
});

after(async () => { await env?.cleanup(); });

test('public catalog is readable without authentication, other arbitrary paths are private', async () => {
  const db = env.unauthenticatedContext().firestore();
  await assertSucceeds(getDoc(doc(db, 'catalog/current')));
  await assertFails(getDoc(doc(db, 'private/customer')));
  await assertFails(setDoc(doc(db, 'arbitrary/data'), { admin: true }));
});

test('anonymous customer creates a canonical order and throttle atomically', async () => {
  const db = customerDb();
  await assertSucceeds(placeOrder({ db }));
  const saved = (await assertSucceeds(getDoc(doc(db, 'orders', id)))).data();
  assert.equal(saved.createdBy, 'customer-1');
  assert.equal(saved.items[0].unitPrice, 100);
  assert.ok(saved.createdAt instanceof Timestamp);
  assert.equal(saved.total, undefined);
});

test('legacy orders accept canonical 01 customer numbers and reject wrong lengths or local storage format', async () => {
  for (const phone of ['0123456789', '+2490123456789', '+24912345678', '+2491234567890']) {
    const order = orderData(); order.customer.phone = phone;
    await assertFails(placeOrder({order}));
  }
  const order = orderData(); order.customer.phone = '+249123456789';
  await assertSucceeds(placeOrder({order}));
  assert.equal((await getDoc(doc(customerDb(), 'orders', id))).data().customer.phone, '+249123456789');
});

test('verified admin can store canonical 01 business phone and WhatsApp contacts', async () => {
  const value = nextCatalog(data => {
    data.settings.phone = '+249123456789';
    data.settings.whatsappNumber = '249123456789';
  });
  await assertSucceeds(setDoc(doc(adminDb(), 'catalog/current'), value));
});

test('all ten distinct canonical lines fit the Firestore evaluation budget', async () => {
  await assertSucceeds(placeOrder({ order: orderData({ count: 10 }) }));
});

for (const field of ['unitPrice', 'name', 'storeName', 'emoji']) {
  test(`canonical item ${field} cannot be spoofed`, async () => {
    const order = orderData();
    order.items[0][field] = field === 'unitPrice' ? 1 : 'spoofed';
    await assertFails(placeOrder({ order }));
  });
}

test('the tenth item is checked for canonical data', async () => {
  const order = orderData({ count: 10 });
  order.items[9].unitPrice = 1;
  await assertFails(placeOrder({ order }));
});

for (const qty of [0, -1, 100, 1.5, '2']) {
  test(`invalid quantity ${JSON.stringify(qty)} is denied`, async () => {
    const order = orderData();
    order.items[0].qty = qty;
    await assertFails(placeOrder({ order }));
  });
}

test('unknown product, empty cart, oversized cart, and extra item fields are denied', async () => {
  const unknown = orderData(); unknown.items[0].key = 'unknown_product';
  const empty = orderData(); empty.items = [];
  const oversized = orderData({ count: 10 }); oversized.items.push({ ...oversized.items[0] });
  const extra = orderData(); extra.items[0].discount = 100;
  for (const order of [unknown, empty, oversized, extra]) await assertFails(placeOrder({ order }));
});

for (const condition of ['stale version', 'demo mode', 'closed store', 'unavailable product', 'delivery fee']) {
  test(`${condition} rejects checkout`, async () => {
    const order = orderData();
    if (condition === 'stale version') order.catalogVersion = 0;
    if (condition === 'demo mode') await patchCatalog(value => { value.settings.demoMode = true; });
    if (condition === 'closed store') await patchCatalog(value => { value.products['1_1'].storeOpen = false; });
    if (condition === 'unavailable product') await patchCatalog(value => { value.products['1_1'].available = false; });
    if (condition === 'delivery fee') order.deliveryFee = 0;
    await assertFails(placeOrder({ order }));
  });
}

test('missing catalog denies checkout', async () => {
  await env.withSecurityRulesDisabled(context => deleteDoc(doc(context.firestore(), 'catalog/current')));
  await assertFails(placeOrder());
});

test('invalid phone, customer field shape, address and notes are denied', async () => {
  for (const mutate of [
    value => { value.customer.phone = '0912345678'; },
    value => { value.customer.phone = '+249812345678'; },
    value => { value.customer.name = 'x'; },
    value => { value.customer.address = 'abc'; },
    value => { value.customer.role = 'admin'; },
    value => { value.notes = 'a'.repeat(1001); }
  ]) {
    const order = orderData(); mutate(order);
    await assertFails(placeOrder({ order }));
  }
});

test('supplied totals, false creation time, wrong creator/status/request ID are denied', async () => {
  for (const patch of [
    { total: 1 }, { subtotal: 1 }, { createdAt: Timestamp.fromMillis(1) },
    { createdBy: 'victim' }, { status: 'completed' }, { requestId: 'another-order-000001' }
  ]) await assertFails(placeOrder({ order: { ...orderData(), ...patch } }));
  await assertFails(placeOrder({ requestId: 'short', order: orderData({ requestId: 'short' }) }));
});

test('unauthenticated customers cannot create orders', async () => {
  await assertFails(placeOrder({ db: env.unauthenticatedContext().firestore() }));
});

test('checkout requires its matching atomic throttle write', async () => {
  await assertFails(placeOrder({ throttle: false }));
  await assertFails(setDoc(doc(customerDb(), 'orderThrottle/customer-1'), { orderId: id, createdAt: serverTimestamp() }));
  const db = customerDb();
  const batch = writeBatch(db);
  batch.set(doc(db, 'orders', id), orderData());
  batch.set(doc(db, 'orderThrottle/customer-1'), { orderId: 'different-request-001', createdAt: serverTimestamp() });
  await assertFails(batch.commit());
});

test('throttle blocks immediate next checkout and permits it after 30 seconds', async () => {
  await assertSucceeds(placeOrder());
  const nextId = 'order-request-000002';
  await assertFails(placeOrder({ requestId: nextId, order: orderData({ requestId: nextId }) }));
  await seed('orderThrottle/customer-1', { orderId: id, createdAt: Timestamp.fromMillis(Date.now() - 31000) });
  await assertSucceeds(placeOrder({ requestId: nextId, order: orderData({ requestId: nextId }) }));
});

test('one throttle cannot authorize two orders in the same batch', async () => {
  const db = customerDb();
  const secondId = 'order-request-000002';
  const batch = writeBatch(db);
  batch.set(doc(db, 'orders', id), orderData());
  batch.set(doc(db, 'orders', secondId), orderData({ requestId: secondId }));
  batch.set(doc(db, 'orderThrottle/customer-1'), { orderId: id, createdAt: serverTimestamp() });
  await assertFails(batch.commit());
  assert.equal((await getDoc(doc(db, 'orders', id))).exists(), false);
});

test('a standalone throttle update cannot replay a previously saved order', async () => {
  await assertSucceeds(placeOrder());
  await seed('orderThrottle/customer-1', { orderId: id, createdAt: Timestamp.fromMillis(1) });
  await assertFails(setDoc(doc(customerDb(), 'orderThrottle/customer-1'), { orderId: id, createdAt: serverTimestamp() }));
});

test('only the owner reads throttle; no user can list, delete, or add fields', async () => {
  const own = customerDb();
  await assertSucceeds(getDoc(doc(own, 'orderThrottle/customer-1')));
  await assertSucceeds(placeOrder({ db: own }));
  await assertSucceeds(getDoc(doc(own, 'orderThrottle/customer-1')));
  await assertFails(getDoc(doc(customerDb('other'), 'orderThrottle/customer-1')));
  await assertFails(getDocs(collection(own, 'orderThrottle')));
  await assertFails(deleteDoc(doc(own, 'orderThrottle/customer-1')));
  await seed('orderThrottle/customer-1', { orderId: id, createdAt: Timestamp.fromMillis(1) });
  const secondId = 'order-request-000002';
  const batch = writeBatch(own);
  batch.set(doc(own, 'orders', secondId), orderData({ requestId: secondId }));
  batch.set(doc(own, 'orderThrottle/customer-1'), { orderId: secondId, createdAt: serverTimestamp(), role: 'admin' });
  await assertFails(batch.commit());
});

test('order PII is private; own reads and missing-document idempotency reads succeed', async () => {
  const own = customerDb();
  await assertSucceeds(getDoc(doc(own, 'orders', id)));
  await assertSucceeds(placeOrder({ db: own }));
  await assertSucceeds(getDoc(doc(own, 'orders', id)));
  await assertFails(getDoc(doc(customerDb('other'), 'orders', id)));
  await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), 'orders', id)));
  await assertFails(getDocs(collection(own, 'orders')));
  await assertFails(getDocs(collection(env.unauthenticatedContext().firestore(), 'orders')));
  await assertSucceeds(getDocs(collection(adminDb(), 'orders')));
  await assertSucceeds(getDoc(doc(adminDb(), 'orders', id)));
});

test('customer retries do not duplicate or overwrite existing orders', async () => {
  await assertSucceeds(placeOrder());
  await assertFails(placeOrder());
  await assertFails(updateDoc(doc(customerDb(), 'orders', id), { status: 'cancelled' }));
  await assertFails(deleteDoc(doc(customerDb(), 'orders', id)));
});

test('verified normalized roster membership is the only administrative source', async () => {
  await assertSucceeds(getDoc(doc(adminDb({ email: 'OWNER@EXAMPLE.COM' }), 'adminAccess/roster')));
  for (const db of [
    adminDb({ email_verified: false }),
    env.authenticatedContext('claim-admin', { email: 'intruder@example.com', email_verified: true, admin: true, role: 'admin' }).firestore(),
    customerDb(), env.unauthenticatedContext().firestore()
  ]) {
    await assertFails(getDoc(doc(db, 'adminAccess/roster')));
    await assertFails(getDocs(collection(db, 'orders')));
    await assertFails(setDoc(doc(db, 'catalog/current'), nextCatalog()));
  }
});

test('roster is never listable; client bootstrap and deletion are denied', async () => {
  const db = adminDb();
  await assertFails(getDocs(collection(db, 'adminAccess')));
  await assertFails(deleteDoc(doc(db, 'adminAccess/roster')));
  await assertFails(setDoc(doc(db, 'adminAccess/another'), { emails: [adminEmail] }));
  await env.withSecurityRulesDisabled(context => deleteDoc(doc(context.firestore(), 'adminAccess/roster')));
  await assertFails(setDoc(doc(db, 'adminAccess/roster'), { emails: [adminEmail], updatedAt: serverTimestamp(), updatedBy: 'admin-1' }));
});

test('admin can update normalized unique roster while retaining themselves', async () => {
  const db = adminDb();
  await assertSucceeds(setDoc(doc(db, 'adminAccess/roster'), {
    emails: [adminEmail, 'second@example.com', 'third@example.com'], updatedAt: serverTimestamp(), updatedBy: 'admin-1'
  }));
  const added = env.authenticatedContext('admin-2', { email: 'second@example.com', email_verified: true }).firestore();
  await assertSucceeds(getDoc(doc(added, 'adminAccess/roster')));
});

test('roster rejects duplicates, malformed or unnormalized emails, excessive members and self-removal', async () => {
  const db = adminDb();
  for (const emails of [
    [], ['other@example.com'], [adminEmail, adminEmail], [adminEmail, 'INVALID@EXAMPLE.COM'],
    [adminEmail, 'invalid'], [adminEmail, ' second@example.com'],
    [adminEmail, 'two@example.com', 'three@example.com', 'four@example.com']
  ]) await assertFails(setDoc(doc(db, 'adminAccess/roster'), { emails, updatedAt: serverTimestamp(), updatedBy: 'admin-1' }));
  await assertFails(updateDoc(doc(db, 'adminAccess/roster'), { updatedAt: serverTimestamp(), updatedBy: 'forged' }));
  await assertFails(updateDoc(doc(db, 'adminAccess/roster'), { admin: true, updatedAt: serverTimestamp(), updatedBy: 'admin-1' }));
});

test('verified admin saves next catalog version and settings', async () => {
  const next = nextCatalog(value => { value.settings.deliveryFee = 700; });
  await assertSucceeds(setDoc(doc(adminDb(), 'catalog/current'), next));
  assert.equal((await getDoc(doc(customerDb(), 'catalog/current'))).data().settings.deliveryFee, 700);
});

test('catalog creation starts at version one and records server time/current actor', async () => {
  await env.withSecurityRulesDisabled(context => deleteDoc(doc(context.firestore(), 'catalog/current')));
  const value = nextCatalog();
  await assertFails(setDoc(doc(adminDb(), 'catalog/current'), value));
  value.version = 1;
  await assertSucceeds(setDoc(doc(adminDb(), 'catalog/current'), value));
});

test('catalog rejects stale version, wrong actor/time, extra public role fields and deletion', async () => {
  for (const mutate of [
    value => { value.version = 1; }, value => { value.version = 3; },
    value => { value.updatedBy = 'forged'; }, value => { value.updatedAt = Timestamp.fromMillis(1); },
    value => { value.adminEmails = [adminEmail]; }, value => { value.settings.role = 'admin'; },
    value => { delete value.settings.demoMode; }
  ]) await assertFails(setDoc(doc(adminDb(), 'catalog/current'), nextCatalog(mutate)));
  await assertFails(deleteDoc(doc(adminDb(), 'catalog/current')));
});

test('catalog enforces settings types, contact schemas and collection bounds', async () => {
  for (const mutate of [
    value => { value.settings.deliveryFee = -1; }, value => { value.settings.deliveryFee = 0.5; },
    value => { value.settings.deliveryFee = 1000000001; }, value => { value.settings.demoMode = 'false'; },
    value => { value.settings.phone = '0912345678'; }, value => { value.settings.whatsappNumber = '+249991974489'; },
    value => { value.settings.facebookUrl = 'https://facebook.com.evil.test/profile'; },
    value => { value.settings.siteName = ''; }, value => { value.stores = Array(101).fill({}); },
    value => { value.products = Object.fromEntries(Array.from({ length: 1001 }, (_, i) => [`key_${i}`, {}])); }
  ]) await assertFails(setDoc(doc(adminDb(), 'catalog/current'), nextCatalog(mutate)));
});

test('admin updates only status and audit fields; immutable order details remain protected', async () => {
  await assertSucceeds(placeOrder());
  const ref = doc(adminDb(), 'orders', id);
  for (const status of ['confirmed', 'delivering', 'completed', 'cancelled', 'pending']) {
    await assertSucceeds(updateDoc(ref, { status, updatedAt: serverTimestamp(), updatedBy: 'admin-1' }));
  }
  for (const patch of [
    { status: 'refunded' }, { deliveryFee: 0 }, { customer: { name: 'changed' } }, { items: [] },
    { createdBy: 'other' }, { createdAt: serverTimestamp() }, { catalogVersion: 2 },
    { requestId: 'changed-request-0001' }, { notes: 'changed' }, { total: 1 },
    { status: 'confirmed', updatedBy: 'forged' }, { status: 'confirmed', updatedAt: Timestamp.fromMillis(1) }
  ]) await assertFails(updateDoc(ref, { status: 'confirmed', updatedAt: serverTimestamp(), updatedBy: 'admin-1', ...patch }));
  await assertFails(deleteDoc(ref));
});

test('unverified roster email cannot read PII or change order status', async () => {
  await assertSucceeds(placeOrder());
  const db = adminDb({ email_verified: false });
  await assertFails(getDoc(doc(db, 'orders', id)));
  await assertFails(updateDoc(doc(db, 'orders', id), { status: 'confirmed', updatedAt: serverTimestamp(), updatedBy: 'admin-1' }));
});
