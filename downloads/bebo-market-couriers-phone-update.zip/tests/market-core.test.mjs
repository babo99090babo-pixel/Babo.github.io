import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addCartItems, cartSummary, escapeHtml, filterCatalog, normalizeSudanPhone,
  parseCart, reconcileCart, resolveSavedCart, safeWhatsAppUrl, sanitizeCatalog, serializeCart, validateCustomer,
} from '../public/js/market-core.js';

const fixture = () => sanitizeCatalog({version: 4, settings: {deliveryFee: 500}, stores: [
  {id: 1, name: 'بقالة النيل', category: 'grocery', isOpen: true, products: [
    {id: 1, name: 'سُكّر', price: 900, available: true},
    {id: 2, name: 'أرز', price: 700, available: false},
  ]},
  {id: 2, name: 'مطعم أم درمان', category: 'restaurants', isOpen: true, products: [
    {id: 1, name: 'فول', price: 500, available: true},
  ]},
  {id: 3, name: 'متجر مغلق', category: 'other', isOpen: false, products: [{id: 1, name: 'ماء', price: 100}]},
  {id: 4, name: 'متجر مخفي', category: 'other', enabled: false, isOpen: true, products: []},
]});

test('normalizes local, international and Arabic Sudanese mobile digits', () => {
  for (const value of ['0991974489', '+249991974489', '249991974489', '٠٩٩١٩٧٤٤٨٩', '۰۹۹۱۹۷۴۴۸۹']) {
    assert.equal(normalizeSudanPhone(value), '+249991974489');
  }
  assert.equal(normalizeSudanPhone('123'), null);
  assert.equal(normalizeSudanPhone('+201001234567'), null);
  assert.equal(normalizeSudanPhone('099197448900'), null);
});

test('customer validation trims text and rejects missing or oversized values', () => {
  const good = validateCustomer({name: '  محمد علي  ', phone: '٠٩٩١٩٧٤٤٨٩', address: '  دنقلا - حي النيل  ', notes: 'بدون أكياس'});
  assert.deepEqual(good.errors, {});
  assert.equal(good.customer.name, 'محمد علي');
  assert.equal(good.customer.phone, '+249991974489');
  const bad = validateCustomer({name: 'م', phone: '123', address: 'بيت', notes: 'x'.repeat(1001)});
  assert.deepEqual(Object.keys(bad.errors).sort(), ['address', 'name', 'notes', 'phone']);
});

test('01 numbers accept exactly ten local digits and their international and Arabic equivalents', () => {
  for (const value of ['0123456789', '٠١٢٣٤٥٦٧٨٩', '۰۱۲۳۴۵۶۷۸۹', '+249123456789', '249123456789', '00249123456789', '01 2345-6789']) {
    assert.equal(normalizeSudanPhone(value), '+249123456789', value);
    const result = validateCustomer({name: 'عميل الاختبار', phone: value, address: 'دنقلا حي السوق'});
    assert.equal(result.valid, true, value);
    assert.equal(result.customer.phone, '+249123456789');
  }
  for (const value of ['012345678', '01234567890', '123456789', '0812345678', '+2490123456789', '+24912345678', '+2491234567890', '+20123456789', '01abcdefgh']) {
    assert.equal(normalizeSudanPhone(value), null, value);
    assert.equal(validateCustomer({name: 'عميل الاختبار', phone: value, address: 'دنقلا حي السوق'}).valid, false, value);
  }
});

test('01 business contacts survive catalog normalization and preserve strict WhatsApp destinations', () => {
  const settings = sanitizeCatalog({settings: {phone: '0123456789', whatsappNumber: '٠١٢٣٤٥٦٧٨٩'}}).settings;
  assert.equal(settings.phone, '+249123456789');
  assert.equal(settings.whatsappNumber, '249123456789');
  assert.equal(safeWhatsAppUrl('https://wa.me/249123456789?text=hello', settings.whatsappNumber), 'https://wa.me/249123456789?text=hello');
  assert.equal(safeWhatsAppUrl('https://wa.me/249123456780', settings.whatsappNumber), null);
  assert.equal(safeWhatsAppUrl('https://wa.me.evil.test/249123456789', settings.whatsappNumber), null);
});

test('corrupt and unexpected saved carts recover to an empty safe cart', () => {
  for (const raw of ['{', '{}', 'null', '42', '"hello"', '{"version":99,"items":[]}', '{"version":1,"items":{}}']) {
    assert.deepEqual(parseCart(raw), []);
  }
  assert.deepEqual(parseCart('[{"storeId":1,"productId":1,"qty":2,"name":"<img onerror=alert(1)>"}]'), [{storeId: 1, productId: 1, qty: 2}]);
  assert.deepEqual(parseCart('[{"storeId":1,"productId":1,"qty":-1},{"storeId":1,"productId":2,"qty":1.2}]'), []);
  assert.doesNotThrow(() => reconcileCart([null, {storeId: 1, productId: 1, qty: 1}], fixture()));
  assert.doesNotThrow(() => addCartItems([], [null]));
});

test('cart migration preserves separate products with the same ID in two stores', () => {
  const cart = parseCart(JSON.stringify([
    {storeId: 1, productId: 1, qty: 2}, {storeId: 2, productId: 1, qty: 3}, {storeId: 1, productId: 1, qty: 1},
  ]));
  assert.equal(cart.length, 2);
  assert.equal(cart[0].qty, 3);
  assert.equal(cart[1].qty, 3);
  const serialized = serializeCart([{...cart[0], name: 'لا تخزنني', price: 1, customerPhone: 'private'}]);
  assert.deepEqual(JSON.parse(serialized), {version: 1, items: [{storeId: 1, productId: 1, qty: 3}]});
});

test('catalog reconciliation uses current prices and removes unavailable or closed products', () => {
  const result = reconcileCart([
    {storeId: 1, productId: 1, qty: 2, price: 1, name: '<script>'},
    {storeId: 1, productId: 2, qty: 1},
    {storeId: 3, productId: 1, qty: 1},
    {storeId: 4, productId: 1, qty: 1},
  ], fixture());
  assert.equal(result.items.length, 1);
  assert.equal(result.items[0].price, 900);
  assert.equal(result.items[0].name, 'سُكّر');
  assert.equal(result.changes.filter(change => change.type === 'unavailable').length, 3);
  assert.equal(result.changes.filter(change => change.type === 'price').length, 1);
  assert.deepEqual(cartSummary(result.items, 500), {subtotal: 1800, deliveryFee: 500, total: 2300, count: 2});
});

test('search and category filters combine with Arabic normalization', () => {
  const catalog = fixture();
  assert.equal(filterCatalog(catalog.stores, 'grocery', 'سكر').length, 1);
  assert.equal(filterCatalog(catalog.stores, 'restaurants', 'سكر').length, 0);
  assert.equal(filterCatalog(catalog.stores, 'restaurants', 'ام درمان').length, 1);
  assert.equal(filterCatalog(catalog.stores, 'all', 'متجر مخفي').length, 0);
});

test('adding items is atomic at ten distinct products and quantities are capped at 99', () => {
  const ten = Array.from({length: 10}, (_, i) => ({storeId: 1, productId: i + 1, qty: 1}));
  const refused = addCartItems(ten, [{storeId: 2, productId: 1, qty: 1}]);
  assert.equal(refused.error, 'item-limit');
  assert.deepEqual(refused.items, ten);
  const merged = addCartItems(ten, [{storeId: 1, productId: 1, qty: 98}]);
  assert.equal(merged.items[0].qty, 99);
  assert.equal(addCartItems(merged.items, [{storeId: 1, productId: 1, qty: 1}]).error, 'quantity-limit');
  assert.equal(addCartItems([], [...ten, {storeId: 2, productId: 1, qty: 1}]).error, 'item-limit');
});

test('stored catalog values remain text and contacts cannot use unsafe destinations', () => {
  assert.equal(escapeHtml('<img src=x onerror="alert(1)">'), '&lt;img src=x onerror=&quot;alert(1)&quot;&gt;');
  const catalog = sanitizeCatalog({stores: [{id: 'bad" onclick=x', name: 'bad', products: []}, {id: 8, category: '" onclick=x', isOpen: true, products: [{id: 1, price: -20}, {id: 2, price: 100}]}]});
  assert.equal(catalog.stores.length, 1);
  assert.equal(catalog.stores[0].category, 'other');
  assert.equal(catalog.stores[0].products.length, 1);
  assert.equal(safeWhatsAppUrl('javascript:alert(1)'), null);
  assert.equal(safeWhatsAppUrl('https://wa.me.evil.test/249991974489'), null);
  assert.equal(safeWhatsAppUrl('https://wa.me/249900000000'), null);
  assert.equal(safeWhatsAppUrl('https://wa.me/249991974489?text=hello'), 'https://wa.me/249991974489?text=hello');
  assert.equal(safeWhatsAppUrl('https://wa.me/249912345678?text=hi', '249912345678'), 'https://wa.me/249912345678?text=hi');
  assert.equal(sanitizeCatalog({stores: [{id: 'under_score', products: []}]}).stores.length, 0);
});

test('validated administrator contact updates propagate while unsafe contact URLs fall back', () => {
  const good = sanitizeCatalog({settings: {phone: '0912345678', whatsappNumber: '249922334455', facebookUrl: 'https://www.facebook.com/CollegeMarket'}});
  assert.equal(good.settings.phone, '+249912345678');
  assert.equal(good.settings.whatsappNumber, '249922334455');
  assert.equal(good.settings.facebookUrl, 'https://www.facebook.com/CollegeMarket');
  assert.equal(sanitizeCatalog({settings:{facebookUrl:'https://m.facebook.com/Babo0Nasir'}}).settings.facebookUrl, 'https://www.facebook.com/Babo0Nasir');
  const bad = sanitizeCatalog({settings: {phone: '123', facebookUrl: 'https://facebook.com.evil.test/me'}});
  assert.equal(bad.settings.phone, '+249991974489');
  assert.equal(bad.settings.facebookUrl, 'https://www.facebook.com/Babo0Nasir');
});

test('saved live IDs survive fallback catalogs and restore against the first authoritative catalog', () => {
  const saved = parseCart('{"version":1,"items":[{"storeId":99,"productId":99,"qty":3}]}');
  const offlineSeed = {...fixture(), source: 'offline', configured: true};
  const held = resolveSavedCart(saved, offlineSeed);
  assert.deepEqual(held.unresolved, saved);
  assert.deepEqual(held.items, []);
  assert.deepEqual(held.changes, []);
  assert.equal(serializeCart(held.unresolved), serializeCart(saved));

  const live = sanitizeCatalog({version: 5, source: 'firebase', configured: true, settings: {demoMode: false}, stores: [
    {id: 99, name: 'المتجر الحقيقي', isOpen: true, products: [{id: 99, name: 'المنتج الحقيقي', price: 1200, available: true}]},
  ]});
  const restored = resolveSavedCart(held.unresolved, live);
  assert.deepEqual(restored.unresolved, []);
  assert.equal(restored.items[0].qty, 3);
  assert.equal(restored.items[0].price, 1200);
  assert.equal(restored.items[0].name, 'المنتج الحقيقي');

  // A seed ID collision also cannot replace the meaning or price of a saved live item.
  const collidingSeed = {...live, source: 'demo'};
  assert.deepEqual(resolveSavedCart(saved, collidingSeed).unresolved, saved);
  assert.deepEqual(resolveSavedCart(saved, collidingSeed).items, []);
});
