const SDK_VERSION = '12.19.0';
let initialized;

export function usingEmulator() {
  const location = globalThis.location;
  if (!location || !['localhost', '127.0.0.1', '[::1]'].includes(location.hostname)) return false;
  const params = new URLSearchParams(location.search);
  let enabled = params.get('emulator') === '1';
  try {
    if (params.has('emulator')) globalThis.sessionStorage?.setItem('bebo.useEmulator', enabled ? '1' : '0');
    else enabled = globalThis.sessionStorage?.getItem('bebo.useEmulator') === '1';
  } catch { /* An explicit local URL flag still works when browser storage is blocked. */ }
  return enabled;
}

export function isConfigured() {
  if (usingEmulator()) return true;
  const config = globalThis.BEBO_FIREBASE_CONFIG;
  return Boolean(config && ['apiKey', 'authDomain', 'projectId', 'appId'].every(key =>
    typeof config[key] === 'string' && config[key].trim() && !/^(YOUR_|REPLACE_|PASTE_)/i.test(config[key])));
}

export async function getFirebase() {
  if (!isConfigured()) {
    const error = new Error('لم يتم ربط الموقع بمشروع Firebase بعد. يمكنك تصفح العرض التجريبي والتواصل معنا.');
    error.code = 'BEBO_NOT_CONFIGURED';
    throw error;
  }
  if (!initialized) {
    initialized = (async () => {
      const [appSDK, authSDK, firestoreSDK] = await Promise.all([
        import(`https://www.gstatic.com/firebasejs/${SDK_VERSION}/firebase-app.js`),
        import(`https://www.gstatic.com/firebasejs/${SDK_VERSION}/firebase-auth.js`),
        import(`https://www.gstatic.com/firebasejs/${SDK_VERSION}/firebase-firestore.js`)
      ]);
      const emulator = usingEmulator();
      const config = emulator ? {
        apiKey: 'demo-bebo-market-api-key',
        authDomain: 'demo-bebo-market.firebaseapp.com',
        projectId: 'demo-bebo-market',
        appId: '1:123456789:web:bebomarket'
      } : { ...globalThis.BEBO_FIREBASE_CONFIG };
      const app = appSDK.getApps().find(item => item.name === 'bebo-market')
        || appSDK.initializeApp(config, 'bebo-market');
      const auth = authSDK.getAuth(app);
      auth.languageCode = 'ar';
      const db = firestoreSDK.getFirestore(app);
      if (emulator) {
        authSDK.connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
        firestoreSDK.connectFirestoreEmulator(db, '127.0.0.1', 8080);
      }
      await auth.authStateReady();
      return { app, auth, db, authSDK, firestoreSDK, emulator };
    })().catch(error => { initialized = undefined; throw error; });
  }
  return initialized;
}
