// Navigation owns presentation only. Catalogs, cart and orders stay in app.js.
let initialized = false;
let tabbed = false;
let current = 'home';
let sections = [];
let pillControllers = [];
let measurementFrame = 0;
let scrollFrame = 0;
let locationFrame = 0;
const motion = window.matchMedia('(prefers-reduced-motion: reduce)');

function findSection(id) {
  return sections.find(section => section.id === id);
}

function hashSection() {
  try {
    const id = decodeURIComponent(location.hash.slice(1));
    return findSection(id) ? id : null;
  } catch { return null; }
}

function closeMenu() {
  document.getElementById('navLinks')?.classList.remove('active');
  document.getElementById('menuToggle')?.setAttribute('aria-expanded', 'false');
}

function selectSection(id) {
  current = id;
  document.querySelectorAll('.nav-tab-link, [data-nav-section]').forEach(control => {
    const selected = control.dataset.navSection === id || control.getAttribute('href') === `#${id}`;
    control.classList.toggle('active', selected);
    if (selected) control.setAttribute('aria-current', tabbed ? 'page' : 'location');
    else control.removeAttribute('aria-current');
  });
  refreshPills();
}

function showSections() {
  sections.forEach(section => {
    const visible = !tabbed || section.id === current;
    section.hidden = !visible;
    section.classList.toggle('active-section', visible);
  });
}

function focusHeading(section) {
  const heading = section.querySelector('h1, h2') || section;
  if (!heading.hasAttribute('tabindex')) heading.setAttribute('tabindex', '-1');
  heading.focus({preventScroll: true});
}

export function navigateToSection(id, options = {}) {
  const section = findSection(id);
  if (!section) return false;
  const {updateHistory = true, scroll = true, focus = false, focusSearch = false, instant = false} = options;
  selectSection(id);
  showSections();
  closeMenu();
  if (updateHistory && location.hash !== `#${id}`) history.pushState(null, '', `#${id}`);
  if (scroll) {
    const behavior = instant || motion.matches ? 'instant' : 'smooth';
    if (tabbed) window.scrollTo({top: 0, behavior});
    else section.scrollIntoView({behavior, block: 'start'});
  }
  if (focusSearch) document.getElementById('searchInput')?.focus({preventScroll: true});
  else if (focus) focusHeading(section);
  return true;
}

function updateModeButton() {
  const button = document.getElementById('viewModeBtn');
  if (!button) return;
  button.classList.toggle('active-mode', tabbed);
  button.setAttribute('aria-pressed', String(tabbed));
  const action = tabbed ? 'عرض التمرير' : 'وضع التطبيق';
  const label = button.querySelector('.mode-label');
  if (label) label.textContent = action;
  const icon = button.querySelector('span:not(.mode-label)');
  if (icon) icon.textContent = tabbed ? '📜' : '🗂️';
  button.setAttribute('aria-label', tabbed ? 'التبديل إلى عرض التمرير الكامل' : 'التبديل إلى عرض الأقسام كتطبيق');
  button.title = button.getAttribute('aria-label');
}

function toggleView() {
  tabbed = !tabbed;
  document.body.classList.toggle('tabbed-mode', tabbed);
  updateModeButton();
  // Reopening the full document changes section positions. Align immediately so
  // scrollspy cannot select intermediate sections during a mode round trip.
  navigateToSection(current, {updateHistory: false, focus: true, instant: true});
}

function syncMirror(controller) {
  const items = [...controller.box.querySelectorAll(controller.selector)];
  controller.layer.setAttribute('aria-hidden', 'true');
  let mirrors = [...controller.layer.querySelectorAll('.pill-mirror-item')];
  if (items.length !== mirrors.length) {
    mirrors = items.map(() => {
      const mirror = document.createElement('span');
      mirror.className = 'pill-mirror-item';
      return mirror;
    });
    controller.layer.replaceChildren(...mirrors);
  }
  items.forEach((item, index) => {
    const mirror = mirrors[index];
    if (mirror.innerHTML !== item.innerHTML) {
      mirror.replaceChildren(...[...item.childNodes].map(node => node.cloneNode(true)));
      mirror.querySelectorAll('[id]').forEach(node => node.removeAttribute('id'));
    }
    const rect = item.getBoundingClientRect();
    mirror.style.boxSizing = 'border-box';
    mirror.style.flex = `0 0 ${rect.width}px`;
    mirror.style.height = `${rect.height}px`;
  });
}

function drawPill(controller, target, animate = false) {
  if (!target || !target.getClientRects().length) return;
  const layerRect = controller.layer.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  if (!layerRect.width || !layerRect.height) return;
  const left = Math.max(0, targetRect.left - layerRect.left);
  const top = Math.max(0, targetRect.top - layerRect.top);
  const right = Math.max(0, layerRect.right - targetRect.right);
  const bottom = Math.max(0, layerRect.bottom - targetRect.bottom);
  controller.layer.style.transition = animate && !motion.matches
    ? 'clip-path 400ms cubic-bezier(.22,1,.36,1)' : 'none';
  controller.layer.style.clipPath = `inset(${top}px ${right}px ${bottom}px ${left}px round 999px)`;
  controller.box.classList.add('pill-ready');
}

function activePill(controller) {
  return controller.box.querySelector(`${controller.selector}.active`)
    || controller.box.querySelector(controller.selector);
}

export function refreshPills() {
  if (measurementFrame) return;
  measurementFrame = requestAnimationFrame(() => {
    measurementFrame = 0;
    pillControllers.forEach(controller => {
      syncMirror(controller);
      const target = activePill(controller);
      const changed = Boolean(controller.lastActive && controller.lastActive !== target);
      drawPill(controller, target, changed);
      controller.lastActive = target;
    });
  });
}

function setupPill(boxId, layerId, selector) {
  const box = document.getElementById(boxId);
  const layer = document.getElementById(layerId);
  if (!box || !layer) return;
  const controller = {box, layer, selector};
  pillControllers.push(controller);
  const preview = event => {
    if (!(event.target instanceof Element)) return;
    const target = event.target.closest(selector);
    if (target && box.contains(target)) drawPill(controller, target, true);
  };
  box.addEventListener('pointerover', preview);
  box.addEventListener('focusin', preview);
  box.addEventListener('pointerleave', () => drawPill(controller, activePill(controller), true));
  box.addEventListener('focusout', () => {
    queueMicrotask(() => {
      if (!box.contains(document.activeElement)) drawPill(controller, activePill(controller), true);
    });
  });
  if ('ResizeObserver' in window) new ResizeObserver(refreshPills).observe(box);
}

function updateScroll() {
  scrollFrame = 0;
  const header = document.getElementById('navbar');
  header?.classList.toggle('scrolled', window.scrollY > 40);
  if (tabbed) return;
  const scrollPadding = parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0;
  const threshold = Math.max((header?.getBoundingClientRect().bottom || 80) + 24, scrollPadding) + 1;
  const visible = sections.filter(section => !section.hidden && section.getClientRects().length);
  let id = visible[0]?.id || 'home';
  if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2) {
    // A short final section cannot always reach the header alignment at max scroll.
    id = visible.at(-1)?.id || id;
  } else {
    visible.forEach(section => {
      if (section.getBoundingClientRect().top <= threshold) id = section.id;
    });
  }
  if (id !== current) selectSection(id);
}

function handleClick(event) {
  if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
  if (!(event.target instanceof Element)) return;
  const action = event.target.closest('[data-nav-action]');
  if (action && !action.disabled) {
    if (action.dataset.navAction === 'toggle-view') {
      event.preventDefault();
      toggleView();
      return;
    }
    if (action.dataset.navAction === 'focus-search') {
      event.preventDefault();
      navigateToSection('stores', {focusSearch: true});
      return;
    }
  }
  const control = event.target.closest('[data-nav-section]');
  if (control && !control.disabled && !control.hasAttribute('data-category')) {
    if (navigateToSection(control.dataset.navSection, {focus: event.detail === 0})) event.preventDefault();
    return;
  }
  const link = event.target.closest('a[href^="#"]');
  if (!link || link.target === '_blank') return;
  let id;
  try { id = decodeURIComponent(link.hash.slice(1)); } catch { return; }
  if (navigateToSection(id, {focus: event.detail === 0})) event.preventDefault();
}

export function initNavigation() {
  if (initialized) return;
  initialized = true;
  sections = [...document.querySelectorAll('section.page-section[id]')];
  if (!sections.length) return;
  current = hashSection() || sections[0].id;
  tabbed = false;
  document.body.classList.remove('tabbed-mode');
  setupPill('navPillBox', 'navPillLayer', '.nav-tab-link');
  setupPill('filterPillBox', 'filterPillLayer', '.filter-pill-btn');
  updateModeButton();
  selectSection(current);
  showSections();
  document.addEventListener('click', handleClick);
  window.addEventListener('scroll', () => {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(updateScroll);
  }, {passive: true});
  const restoreLocation = () => {
    if (locationFrame) return;
    locationFrame = requestAnimationFrame(() => {
      locationFrame = 0;
      navigateToSection(hashSection() || sections[0].id, {updateHistory: false});
    });
  };
  window.addEventListener('hashchange', restoreLocation);
  window.addEventListener('popstate', restoreLocation);
  window.addEventListener('resize', refreshPills);
  motion.addEventListener('change', refreshPills);
  document.fonts?.ready.then(refreshPills);
  refreshPills();
  if (hashSection()) requestAnimationFrame(() => navigateToSection(current, {updateHistory: false}));
}
