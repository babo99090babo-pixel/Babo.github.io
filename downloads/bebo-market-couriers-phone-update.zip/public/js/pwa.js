(() => {
  const button = document.getElementById('installApp');
  let installation = null;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); installation = event;
    if (button) button.hidden = false;
  });
  button?.addEventListener('click', async () => {
    if (!installation) return;
    await installation.prompt();
    const result = await installation.userChoice;
    if (result.outcome === 'accepted') button.hidden = true;
    installation = null;
  });
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register(new URL('../sw.js', document.currentScript?.src || new URL('js/pwa.js', location.href)).href);
      registration.addEventListener('updatefound', () => {
        const worker = registration.installing;
        worker?.addEventListener('statechange', () => {
          if (worker.state !== 'installed' || !navigator.serviceWorker.controller || document.getElementById('updateApp')) return;
          const update = document.createElement('button');
          update.id = 'updateApp'; update.type = 'button'; update.className = 'app-update';
          update.textContent = 'يتوفر تحديث للموقع — إعادة تحميل';
          update.addEventListener('click', () => location.reload());
          document.body.append(update);
        });
      });
    } catch { /* Browsing and contact actions remain usable if offline support is unavailable. */ }
  });
})();
