import { getFirebase, isConfigured } from './firebase-init.js';

export { isConfigured };

const CACHE_KEY = 'bebo.public.catalog.v1';
const CACHE_TTL = 24 * 60 * 60 * 1000;
const BUSINESS_PHONE = '249991974489';
const STATUSES = new Set(['pending', 'confirmed', 'delivering', 'completed', 'cancelled']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const JPEG_DATA_URL = /^data:image\/jpeg;base64,\/9j\/(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
const MAX_PHOTO_LENGTH = 180000;
let catalogInMemory;
let anonymousSignIn;

function fail(message, code = 'BEBO_INVALID_INPUT') {
  const error = new Error(message);
  error.code = code;
  return error;
}

function safeError(error) {
  if (String(error?.code || '').startsWith('BEBO_')) return error;
  const code = String(error?.code || '');
  const messages = {
    'auth/invalid-email': 'عنوان البريد الإلكتروني غير صحيح.',
    'auth/invalid-credential': 'تعذّر تسجيل الدخول. راجع البريد وكلمة المرور.',
    'auth/wrong-password': 'تعذّر تسجيل الدخول. راجع البريد وكلمة المرور.',
    'auth/user-not-found': 'تعذّر تسجيل الدخول. راجع البريد وكلمة المرور.',
    'auth/email-already-in-use': 'هذا البريد مسجل بالفعل. سجّل الدخول أو استخدم استعادة كلمة المرور.',
    'auth/weak-password': 'اختر كلمة مرور قوية لا تقل عن 8 أحرف.',
    'auth/popup-closed-by-user': 'أُغلقت نافذة تسجيل الدخول قبل اكتماله. يمكنك المحاولة مجددًا.',
    'auth/popup-blocked': 'المتصفح منع نافذة Google. اسمح بالنوافذ المنبثقة ثم حاول مجددًا.',
    'auth/cancelled-popup-request': 'توجد محاولة تسجيل دخول أخرى. أكملها أولًا.',
    'auth/account-exists-with-different-credential': 'البريد مسجل بطريقة دخول أخرى. استخدم البريد وكلمة المرور لربط حسابك.',
    'auth/operation-not-allowed': 'طريقة الدخول هذه غير مفعّلة في إعدادات Firebase للموقع.',
    'auth/unauthorized-domain': 'نطاق الموقع غير مضاف إلى النطاقات المسموح بها في Firebase Authentication.',
    'auth/user-disabled': 'هذا الحساب موقوف. تواصل مع إدارة الموقع.',
    'auth/requires-recent-login': 'سجّل الدخول مجددًا لإتمام هذه الخطوة.',
    'auth/too-many-requests': 'محاولات كثيرة خلال وقت قصير. انتظر قليلًا ثم حاول مجددًا.',
    'auth/network-request-failed': 'تعذّر الاتصال. تحقق من الإنترنت ثم حاول مجددًا.',
    'permission-denied': 'ليس لديك إذن لإتمام العملية. تحقق من حسابك وصلاحياتك.',
    'unauthenticated': 'سجّل الدخول مجددًا لإتمام العملية.',
    'unavailable': 'الخدمة غير متاحة الآن. تحقق من اتصالك وحاول مجددًا.',
    'deadline-exceeded': 'انتهت مهلة الاتصال. حاول مجددًا بنفس الطلب لتجنب تكراره.',
    'resource-exhausted': 'الخدمة مشغولة الآن. انتظر قليلًا ثم حاول مجددًا.',
    'aborted': 'تغيرت البيانات أثناء الحفظ. حدّث الصفحة ثم أعد المحاولة.',
    'failed-precondition': 'تحتاج إعدادات قاعدة البيانات إلى المراجعة قبل إتمام العملية.'
  };
  return fail(messages[code] || 'تعذّر إتمام العملية الآن. تحقق من الاتصال والإعدادات ثم حاول مجددًا.', 'BEBO_SERVICE_ERROR');
}

async function action(callback) {
  try { return await callback(); } catch (error) { throw safeError(error); }
}

function plain(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function text(value, label, min = 0, max = 300) {
  if (typeof value !== 'string') throw fail(`يرجى إدخال ${label} بصورة صحيحة.`);
  const trimmed = value.trim();
  if (trimmed.length < min || trimmed.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(trimmed)) {
    throw fail(`يرجى مراجعة ${label} وطوله المسموح.`);
  }
  return trimmed;
}

function money(value, label) {
  if (!Number.isSafeInteger(value) || value < 0 || value > 1000000000) {
    throw fail(`يرجى إدخال ${label} بالجنيه كعدد صحيح من 0 إلى 1,000,000,000 دون كسور.`);
  }
  return value;
}

function identifier(value) {
  if (Number.isSafeInteger(value) && value > 0) return value;
  if (typeof value === 'string' && /^[a-zA-Z0-9-]{1,64}$/.test(value)) return value;
  throw fail('معرّف المتجر أو المنتج غير صحيح.');
}

function normalizeCatalog(value) {
  if (!plain(value) || !plain(value.settings) || !Array.isArray(value.stores)
    || !Number.isSafeInteger(value.version) || value.version < 1 || value.stores.length > 100) {
    throw fail('بيانات قائمة المتاجر غير صالحة.', 'BEBO_BAD_CATALOG');
  }
  const source = value.settings;
  const whatsapp = normalizePhone(source.whatsappNumber || source.phone || BUSINESS_PHONE).slice(1);
  if (!/^\d{8,15}$/.test(whatsapp)) throw fail('رقم واتساب المتجر غير صحيح.', 'BEBO_BAD_CATALOG');
  const facebookUrl = text(source.facebookUrl || 'https://www.facebook.com/Babo0Nasir', 'رابط فيسبوك', 1, 300).replace(/^https:\/\/m\.facebook\.com\//i, 'https://www.facebook.com/');
  if (!/^https:\/\/(www\.)?facebook\.com\/[^\s]*$/i.test(facebookUrl)) {
    throw fail('رابط فيسبوك غير صحيح.', 'BEBO_BAD_CATALOG');
  }
  const settings = {
    siteName: text(source.siteName || 'ببو ماركت', 'اسم الموقع', 1, 100),
    city: text(source.city || 'دنقلا، السودان', 'المدينة', 1, 100),
    phone: normalizePhone(source.phone || '+249991974489'),
    whatsappNumber: whatsapp,
    facebookUrl,
    deliveryFee: money(source.deliveryFee, 'رسوم التوصيل'),
    currency: text(source.currency || 'جنيه', 'العملة', 1, 30),
    deliveryNote: text(source.deliveryNote || '', 'ملاحظة التوصيل', 0, 500),
    availabilityNote: text(source.availabilityNote || '', 'ملاحظة التوفر', 0, 500),
    demoMode: source.demoMode !== false
  };
  const products = {};
  const storeIds = new Set();
  let productCount = 0;
  const stores = value.stores.map(input => {
    if (!plain(input) || !Array.isArray(input.products) || input.products.length > 200) {
      throw fail('بيانات أحد المتاجر غير صالحة.', 'BEBO_BAD_CATALOG');
    }
    const id = identifier(input.id);
    if (storeIds.has(String(id))) throw fail('يوجد متجر مكرر في القائمة.', 'BEBO_BAD_CATALOG');
    storeIds.add(String(id));
    const store = {
      id,
      name: text(input.name, 'اسم المتجر', 1, 100),
      category: text(input.category, 'تصنيف المتجر', 1, 50),
      icon: text(input.icon || '🛍️', 'رمز المتجر', 1, 40),
      description: text(input.description || '', 'وصف المتجر', 0, 500),
      deliveryTime: text(input.deliveryTime || '', 'مدة التوصيل', 0, 100),
      isOpen: input.isOpen === true,
      enabled: input.enabled !== false,
      products: []
    };
    const productIds = new Set();
    store.products = input.products.map(item => {
      if (!plain(item)) throw fail('بيانات أحد المنتجات غير صالحة.', 'BEBO_BAD_CATALOG');
      const product = {
        id: identifier(item.id),
        name: text(item.name, 'اسم المنتج', 1, 150),
        emoji: text(item.emoji || '🛍️', 'رمز المنتج', 1, 40),
        price: money(item.price, 'السعر'),
        available: item.available !== false,
        enabled: item.enabled !== false
      };
      if (productIds.has(String(product.id))) throw fail('يوجد منتج مكرر داخل المتجر.', 'BEBO_BAD_CATALOG');
      productIds.add(String(product.id));
      products[`${id}_${product.id}`] = {
        storeId: id,
        productId: product.id,
        storeName: store.name,
        name: product.name,
        emoji: product.emoji,
        price: product.price,
        available: product.available && product.enabled,
        storeOpen: store.isOpen && store.enabled
      };
      productCount += 1;
      return product;
    });
    return store;
  });
  if (productCount > 1000) throw fail('عدد المنتجات أكبر من الحد المسموح.', 'BEBO_BAD_CATALOG');
  const catalog = { version: value.version, settings, stores, products };
  if (JSON.stringify(catalog).length > 700000) throw fail('حجم قائمة المتاجر كبير جدًا.', 'BEBO_BAD_CATALOG');
  return catalog;
}

function publicCatalog(catalog, source, configured = isConfigured()) {
  return {
    version: catalog.version,
    settings: { ...catalog.settings },
    stores: catalog.stores.map(store => ({ ...store, products: store.products.map(product => ({ ...product })) })),
    source,
    configured
  };
}

function cacheCatalog(catalog) {
  try {
    const clean = publicCatalog(catalog, 'firebase', true);
    const projectId = globalThis.BEBO_FIREBASE_CONFIG?.projectId || 'local';
    globalThis.localStorage?.setItem(`${CACHE_KEY}:${projectId}`, JSON.stringify({ savedAt: Date.now(), catalog: clean }));
  } catch { /* Browsing still works when browser storage is unavailable. */ }
}

function readCache() {
  try {
    const projectId = globalThis.BEBO_FIREBASE_CONFIG?.projectId || 'local';
    const raw = globalThis.localStorage?.getItem(`${CACHE_KEY}:${projectId}`);
    if (!raw || raw.length > 750000) return null;
    const cached = JSON.parse(raw);
    if (!plain(cached) || !Number.isFinite(cached.savedAt) || cached.savedAt > Date.now()
      || Date.now() - cached.savedAt > CACHE_TTL) return null;
    return normalizeCatalog(cached.catalog);
  } catch { return null; }
}

async function fallbackCatalog(configured, missing = false) {
  let catalog = configured && !missing ? readCache() : null;
  if (!catalog) {
    try {
      const response = await fetch(new URL('../data/default-catalog.json', import.meta.url), { cache: 'no-store' });
      if (!response.ok) throw fail('تعذّر تحميل قائمة العرض التجريبي.');
      catalog = normalizeCatalog(await response.json());
    } catch (error) {
      throw fail('تعذّر تحميل المتاجر. تحقق من اتصال الإنترنت ثم أعد تحميل الصفحة.', 'BEBO_CATALOG_UNAVAILABLE');
    }
  }
  catalog.settings.demoMode = true;
  return publicCatalog(catalog, configured && !missing ? 'offline' : 'demo', configured);
}

export async function getCatalog({ fresh = false } = {}) {
  const configured = isConfigured();
  if (!configured) return fallbackCatalog(false);
  if (!fresh && catalogInMemory) return publicCatalog(catalogInMemory, 'firebase', true);
  try {
    const { db, firestoreSDK: F } = await getFirebase();
    const snapshot = await F.getDocFromServer(F.doc(db, 'catalog', 'current'));
    if (!snapshot.exists()) return fallbackCatalog(true, true);
    const catalog = normalizeCatalog(snapshot.data());
    catalogInMemory = catalog;
    cacheCatalog(catalog);
    return publicCatalog(catalog, 'firebase', true);
  } catch { return fallbackCatalog(true); }
}

function emailAddress(value) {
  const email = text(value, 'البريد الإلكتروني', 3, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw fail('عنوان البريد الإلكتروني غير صحيح.');
  return email;
}

function passwordValue(value, registering = false) {
  if (typeof value !== 'string' || value.length < (registering ? 8 : 1) || value.length > 4096) {
    throw fail(registering ? 'اختر كلمة مرور قوية لا تقل عن 8 أحرف.' : 'يرجى إدخال كلمة المرور.');
  }
  return value;
}

export async function watchAuth(callback) {
  if (typeof callback !== 'function') throw fail('تعذّر متابعة جلسة الدخول.');
  if (!isConfigured()) { callback(null); return () => {}; }
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    return A.onAuthStateChanged(auth, callback);
  });
}

export async function signInEmail(email, password) {
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    return (await A.signInWithEmailAndPassword(auth, emailAddress(email), passwordValue(password))).user;
  });
}

export async function signInGoogle() {
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    const provider = new A.GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    return (await A.signInWithPopup(auth, provider)).user;
  });
}

export async function registerEmail(email, password) {
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    const result = await A.createUserWithEmailAndPassword(auth, emailAddress(email), passwordValue(password, true));
    await A.sendEmailVerification(result.user);
    return result.user;
  });
}

export async function sendVerification() {
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    if (!auth.currentUser || auth.currentUser.isAnonymous) throw fail('سجّل الدخول بالبريد الإلكتروني أولًا.');
    if (!auth.currentUser.emailVerified) await A.sendEmailVerification(auth.currentUser);
    return auth.currentUser;
  });
}

export async function reloadUser() {
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    if (!auth.currentUser) return null;
    await A.reload(auth.currentUser);
    await auth.currentUser.getIdToken(true);
    return auth.currentUser;
  });
}

export async function resetPassword(email) {
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    try { await A.sendPasswordResetEmail(auth, emailAddress(email)); }
    catch (error) { if (error?.code !== 'auth/user-not-found') throw error; }
  });
}

export async function signOutUser() {
  if (!isConfigured()) return;
  return action(async () => {
    const { auth, authSDK: A } = await getFirebase();
    await A.signOut(auth);
  });
}

export async function checkAdmin() {
  if (!isConfigured()) return { user: null, isAdmin: false };
  return action(async () => {
    const { auth, db, firestoreSDK: F } = await getFirebase();
    const user = auth.currentUser;
    if (!user || user.isAnonymous || !user.emailVerified || !user.email) return { user, isAdmin: false };
    try {
      const roster = await F.getDocFromServer(F.doc(db, 'adminAccess', 'roster'));
      const emails = roster.exists() ? roster.data().emails : null;
      const isAdmin = Array.isArray(emails) && emails.length >= 1 && emails.length <= 3
        && emails.every(email => typeof email === 'string') && emails.includes(user.email.toLowerCase());
      return { user, isAdmin };
    } catch (error) {
      if (error?.code === 'permission-denied') return { user, isAdmin: false };
      throw error;
    }
  });
}

export async function watchAdminAccess(callback) {
  if (typeof callback !== 'function') throw fail('تعذّر متابعة صلاحيات الإدارة.');
  if (!isConfigured()) { callback({ user: null, isAdmin: false }); return () => {}; }
  return action(async () => {
    const { auth, db, authSDK: A, firestoreSDK: F } = await getFirebase();
    let stopped = false;
    let generation = 0;
    let watchedIdentity;
    let stopRoster = () => {};
    const notify = (user, isAdmin) => {
      if (!stopped) callback({ user, isAdmin });
    };
    const stopAuth = A.onIdTokenChanged(auth, user => {
      const identity = user ? `${user.uid}|${user.email || ''}|${user.emailVerified}|${user.isAnonymous}` : 'signed-out';
      if (identity === watchedIdentity) return;
      watchedIdentity = identity;
      const currentGeneration = ++generation;
      stopRoster();
      stopRoster = () => {};
      notify(user, false);
      if (!user || user.isAnonymous || !user.emailVerified || !user.email) return;
      stopRoster = F.onSnapshot(F.doc(db, 'adminAccess', 'roster'), { includeMetadataChanges: true }, snapshot => {
        if (stopped || currentGeneration !== generation || auth.currentUser?.uid !== user.uid) return;
        const emails = snapshot.exists() ? snapshot.data().emails : null;
        const isAdmin = !snapshot.metadata.fromCache && Array.isArray(emails)
          && emails.length >= 1 && emails.length <= 3 && emails.every(email => typeof email === 'string')
          && emails.includes(user.email.toLowerCase());
        notify(user, isAdmin);
      }, () => {
        if (currentGeneration === generation) notify(user, false);
      });
    }, () => notify(auth.currentUser, false));
    return () => {
      stopped = true;
      generation += 1;
      stopAuth();
      stopRoster();
    };
  });
}

async function requireAdmin() {
  const role = await checkAdmin();
  if (!role.isAdmin) throw fail('هذه العملية متاحة فقط لحساب إداري موثّق ومسموح له.', 'BEBO_ADMIN_REQUIRED');
  return role.user;
}

function isoDate(value) {
  try {
    const date = value?.toDate ? value.toDate() : value instanceof Date ? value
      : typeof value === 'string' ? new Date(value) : null;
    return date && Number.isFinite(date.getTime()) ? date.toISOString() : null;
  } catch { return null; }
}

function orderRow(id, data) {
  if (data.kind === 'custom') {
    return {
      id, kind: 'custom',
      customer: { name: data.customer?.name || '', phone: data.customer?.phone || '', address: data.customer?.address || '' },
      notes: data.notes || '',
      items: (Array.isArray(data.items) ? data.items : []).map(item => ({
        description: item.description, quantity: item.quantity, storeName: item.storeName, photoId: item.photoId
      })),
      subtotal: null, deliveryFee: null, total: null,
      status: data.status, requestId: data.requestId,
      createdBy: data.createdBy, createdAt: isoDate(data.createdAt),
      updatedAt: isoDate(data.updatedAt), updatedBy: data.updatedBy || null
    };
  }
  const items = (Array.isArray(data.items) ? data.items : []).map(item => ({
    key: item.key, qty: item.qty, unitPrice: item.unitPrice, name: item.name,
    storeName: item.storeName, emoji: item.emoji
  }));
  const subtotal = Math.round(items.reduce((sum, item) => sum + item.qty * item.unitPrice, 0) * 100) / 100;
  return {
    id,
    customer: { name: data.customer?.name || '', phone: data.customer?.phone || '', address: data.customer?.address || '' },
    notes: data.notes || '', items, subtotal, deliveryFee: data.deliveryFee,
    total: Math.round((subtotal + data.deliveryFee) * 100) / 100,
    status: data.status, catalogVersion: data.catalogVersion, requestId: data.requestId,
    createdBy: data.createdBy, createdAt: isoDate(data.createdAt),
    updatedAt: isoDate(data.updatedAt), updatedBy: data.updatedBy || null
  };
}

export async function getOrders() {
  return action(async () => {
    await requireAdmin();
    const { db, firestoreSDK: F } = await getFirebase();
    const query = F.query(F.collection(db, 'orders'), F.orderBy('createdAt', 'desc'), F.limit(200));
    const result = await F.getDocsFromServer(query);
    return result.docs.map(snapshot => orderRow(snapshot.id, snapshot.data()));
  });
}

function validPhoto(value) {
  return typeof value === 'string' && value.length <= MAX_PHOTO_LENGTH && JPEG_DATA_URL.test(value) && !/\s/.test(value);
}

function orderPhotoIds(order) {
  if (order.kind !== 'custom' || !Array.isArray(order.items) || order.items.length > 5) return [];
  return order.items.flatMap((item, index) => item?.photoId === `photo-${index}` ? [item.photoId] : []);
}

export async function getOrderPhotos(id) {
  return action(async () => {
    if (typeof id !== 'string' || !UUID.test(id)) throw fail('معرّف الطلب غير صالح.');
    const { auth, db, firestoreSDK: F } = await getFirebase();
    if (!auth.currentUser) throw fail('سجّل الدخول لعرض صور الطلب.', 'BEBO_AUTH_REQUIRED');
    // Firestore checks ownership or verified allowlisted administration for both reads.
    const snapshot = await F.getDocFromServer(F.doc(db, 'orders', id));
    if (!snapshot.exists()) throw fail('الطلب غير موجود أو لم يعد متاحًا.', 'BEBO_ORDER_NOT_FOUND');
    const photos = {};
    await Promise.all(orderPhotoIds(snapshot.data()).map(async photoId => {
      const attachment = await F.getDocFromServer(F.doc(db, 'orders', id, 'attachments', photoId));
      if (attachment.exists() && validPhoto(attachment.data().dataUrl)) photos[photoId] = attachment.data().dataUrl;
    }));
    return photos;
  });
}

export async function saveCatalog(input, expectedVersion) {
  return action(async () => {
    const user = await requireAdmin();
    if (!Number.isSafeInteger(expectedVersion) || expectedVersion < 0) throw fail('رقم نسخة المتاجر غير صحيح.');
    const catalog = normalizeCatalog({ ...input, version: Math.max(1, input?.version || 1) });
    const { db, firestoreSDK: F } = await getFirebase();
    await F.runTransaction(db, async transaction => {
      const reference = F.doc(db, 'catalog', 'current');
      const previous = await transaction.get(reference);
      if (previous.exists() && previous.data().version !== expectedVersion) {
        throw fail('حفظ إداري آخر تغييرات على المتاجر. حدّث البيانات ثم أعد تعديلاتك لتجنب استبدالها.', 'BEBO_VERSION_CONFLICT');
      }
      if (!previous.exists() && expectedVersion > 1) {
        throw fail('قائمة المتاجر غير موجودة. أعد تحميل لوحة الإدارة قبل نشرها.', 'BEBO_VERSION_CONFLICT');
      }
      transaction.set(reference, {
        ...catalog,
        version: previous.exists() ? previous.data().version + 1 : 1,
        updatedAt: F.serverTimestamp(),
        updatedBy: user.uid
      });
    });
    catalogInMemory = undefined;
    const saved = await getCatalog({ fresh: true });
    if (saved.source !== 'firebase') throw fail('تم الحفظ لكن تعذّر جلب النسخة المنشورة. حدّث البيانات للتحقق.', 'BEBO_REFRESH_REQUIRED');
    return saved;
  });
}

export async function changeOrderStatus(id, status) {
  return action(async () => {
    const user = await requireAdmin();
    if (typeof id !== 'string' || !UUID.test(id) || !STATUSES.has(status)) throw fail('معرّف الطلب أو حالته غير صالح.');
    const { db, firestoreSDK: F } = await getFirebase();
    await F.updateDoc(F.doc(db, 'orders', id), { status, updatedAt: F.serverTimestamp(), updatedBy: user.uid });
    return { id, status };
  });
}

export async function exportBackup() {
  return action(async () => {
    await requireAdmin();
    const { db, firestoreSDK: F } = await getFirebase();
    const catalog = await getCatalog({ fresh: true });
    if (catalog.source !== 'firebase') throw fail('لا يمكن تصدير نسخة موثوقة دون اتصال بقاعدة البيانات.');
    const orders = [];
    let cursor;
    while (true) {
      const constraints = [F.orderBy('createdAt', 'desc'), F.limit(200)];
      if (cursor) constraints.push(F.startAfter(cursor));
      const page = await F.getDocsFromServer(F.query(F.collection(db, 'orders'), ...constraints));
      orders.push(...page.docs.map(snapshot => orderRow(snapshot.id, snapshot.data())));
      if (page.docs.length < 200) break;
      cursor = page.docs.at(-1);
    }
    return { catalog, orders, attachmentsIncluded: false, exportedAt: new Date().toISOString() };
  });
}

function normalizePhone(value) {
  let phone = text(value, 'رقم الهاتف', 8, 40)
    .replace(/[٠-٩]/g, digit => String(digit.charCodeAt(0) - 0x660))
    .replace(/[۰-۹]/g, digit => String(digit.charCodeAt(0) - 0x6f0))
    .replace(/[\s()-]/g, '');
  if (phone.startsWith('00')) phone = `+${phone.slice(2)}`;
  if (/^0[19]\d{8}$/.test(phone)) phone = `+249${phone.slice(1)}`;
  if (/^249[19]\d{8}$/.test(phone)) phone = `+${phone}`;
  if (!/^\+249[19]\d{8}$/.test(phone)) throw fail('أدخل رقمًا سودانيًا من 10 أرقام يبدأ بـ 01 أو 09، أو بصيغته الدولية +249.');
  return phone;
}

function normalizeRequest(input) {
  if (!plain(input) || !plain(input.customer) || !Array.isArray(input.items) || input.items.length < 1 || input.items.length > 10) {
    throw fail('اختر من منتج واحد إلى 10 منتجات مختلفة لإتمام الطلب.');
  }
  const requestId = String(input.requestId || '');
  if (!UUID.test(requestId)) throw fail('معرّف محاولة الطلب غير صحيح. أعد فتح نموذج الطلب.');
  if (!Number.isSafeInteger(input.catalogVersion) || input.catalogVersion < 1) throw fail('نسخة الأسعار غير صحيحة. حدّث المتاجر أولًا.');
  const keys = new Set();
  const items = input.items.map(item => {
    if (!plain(item) || !Number.isSafeInteger(item.qty) || item.qty < 1 || item.qty > 99) throw fail('كمية المنتج يجب أن تكون من 1 إلى 99.');
    const key = `${identifier(item.storeId)}_${identifier(item.productId)}`;
    if (keys.has(key)) throw fail('يوجد منتج مكرر في الطلب. حدّث السلة ثم أعد المحاولة.');
    keys.add(key);
    return { key, qty: item.qty };
  });
  return {
    customer: { name: text(input.customer.name, 'الاسم', 2, 100), phone: normalizePhone(input.customer.phone), address: text(input.customer.address, 'العنوان بالتفصيل', 5, 300) },
    notes: text(input.notes || '', 'الملاحظات', 0, 1000),
    items, catalogVersion: input.catalogVersion, requestId
  };
}

function normalizeCustomRequest(input) {
  if (!plain(input) || !plain(input.customer) || !Array.isArray(input.items)
    || input.items.length < 1 || input.items.length > 5 || !plain(input.photos)) {
    throw fail('أضف من منتج واحد إلى 5 منتجات مع تفاصيل الطلب.');
  }
  const requestId = String(input.requestId || '');
  if (!UUID.test(requestId)) throw fail('معرّف محاولة الطلب غير صحيح. أعد فتح نموذج الطلب.');
  const photos = {};
  const items = input.items.map((item, index) => {
    if (!plain(item)) throw fail('يرجى مراجعة تفاصيل المنتج.');
    const description = text(item.description ?? '', 'وصف المنتج', 0, 1000);
    const quantity = text(item.quantity, 'الكمية المطلوبة', 1, 80);
    const storeName = text(item.storeName ?? '', 'المتجر المفضّل', 0, 100);
    const photoId = item.photoId ?? '';
    if (photoId !== '' && photoId !== `photo-${index}`) throw fail('صورة المنتج غير مرتبطة بطلبك بصورة صحيحة. أعد اختيارها.');
    if (description.length < 2 && !photoId) throw fail('اكتب وصفًا للمنتج من حرفين على الأقل أو أرفق صورته.');
    if (photoId) {
      if (!Object.hasOwn(input.photos, photoId) || !validPhoto(input.photos[photoId])) {
        throw fail('صورة المنتج غير صالحة أو كبيرة جدًا. اختر صورة JPEG أصغر ثم حاول مجددًا.');
      }
      photos[photoId] = input.photos[photoId];
    }
    return { description, quantity, storeName, photoId };
  });
  if (Object.keys(input.photos).length !== Object.keys(photos).length) {
    throw fail('توجد صورة غير مرتبطة بمنتج. راجع صور الطلب ثم حاول مجددًا.');
  }
  return {
    customer: { name: text(input.customer.name, 'الاسم', 2, 100), phone: normalizePhone(input.customer.phone), address: text(input.customer.address, 'العنوان بالتفصيل', 5, 300) },
    notes: text(input.notes || '', 'الملاحظات', 0, 1000),
    items, photos, requestId
  };
}

async function ensureOrderUser(firebase) {
  if (firebase.auth.currentUser) return firebase.auth.currentUser;
  if (!anonymousSignIn) {
    anonymousSignIn = firebase.authSDK.signInAnonymously(firebase.auth)
      .then(result => result.user).finally(() => { anonymousSignIn = undefined; });
  }
  return anonymousSignIn;
}

function sameRequest(existing, request) {
  return existing.requestId === request.requestId && existing.catalogVersion === request.catalogVersion
    && existing.notes === request.notes && existing.customer?.name === request.customer.name
    && existing.customer?.phone === request.customer.phone && existing.customer?.address === request.customer.address
    && Array.isArray(existing.items) && existing.items.length === request.items.length
    && existing.items.every((item, index) => item.key === request.items[index].key && item.qty === request.items[index].qty);
}

function sameCustomRequest(existing, request) {
  return existing.kind === 'custom' && existing.requestId === request.requestId
    && existing.notes === request.notes && existing.customer?.name === request.customer.name
    && existing.customer?.phone === request.customer.phone && existing.customer?.address === request.customer.address
    && Array.isArray(existing.items) && existing.items.length === request.items.length
    && existing.items.every((item, index) => plain(item) && Object.keys(item).length === 4
      && ['description', 'quantity', 'storeName', 'photoId'].every(key => item[key] === request.items[index][key]));
}

async function verifyCustomRetry(snapshot, request, user, db, F) {
  const existing = snapshot.data();
  if (existing.createdBy !== user.uid || !sameCustomRequest(existing, request)) {
    throw fail('معرّف الطلب مستخدم لبيانات مختلفة. ابدأ محاولة طلب جديدة.', 'BEBO_REQUEST_CONFLICT');
  }
  await Promise.all(Object.entries(request.photos).map(async ([photoId, dataUrl]) => {
    const attachment = await F.getDocFromServer(F.doc(db, 'orders', request.requestId, 'attachments', photoId));
    if (!attachment.exists() || attachment.data().createdBy !== user.uid || attachment.data().dataUrl !== dataUrl) {
      throw fail('الصورة المحفوظة تختلف عن هذه المحاولة. ابدأ طلبًا جديدًا للحفاظ على طلبك السابق.', 'BEBO_REQUEST_CONFLICT');
    }
  }));
  return orderRow(snapshot.id, existing);
}

function whatsappResult(order, settings) {
  if (order.kind === 'custom') {
    const lines = [
      `طلب من ${settings.siteName || 'ببو ماركت'}`,
      `رقم الطلب: ${order.id}`,
      order.status === 'pending' ? 'الطلب بانتظار تأكيد التوفر والتكلفة وموعد التوصيل.' : 'متابعة الطلب المحفوظ سابقًا؛ يرجى مراجعة حالته مع الإدارة.',
      '',
      ...order.items.flatMap((item, index) => [
        `${index + 1}. ${item.description || 'منتج موضّح بالصورة'}`,
        `الكمية: ${item.quantity}`,
        ...(item.storeName ? [`المتجر المفضّل: ${item.storeName}`] : []),
        ...(item.photoId ? ['صورة المنتج محفوظة بشكل خاص مع الطلب وتعرضها الإدارة.'] : [])
      ]),
      '',
      'تُؤكَّد الأسعار ورسوم التوصيل مع الإدارة بعد مراجعة الطلب.',
      `الاسم: ${order.customer.name}`,
      `الهاتف: ${order.customer.phone}`,
      `العنوان: ${order.customer.address}`,
      ...(order.notes ? [`ملاحظات: ${order.notes}`] : [])
    ];
    const message = lines.join('\n');
    return { order, message, whatsappUrl: `https://wa.me/${settings.whatsappNumber || BUSINESS_PHONE}?text=${encodeURIComponent(message)}` };
  }
  const currency = settings.currency || 'جنيه';
  const amount = value => new Intl.NumberFormat('ar-SD', { maximumFractionDigits: 2 }).format(value);
  const lines = [
    `طلب من ${settings.siteName || 'ببو ماركت'}`,
    `رقم الطلب: ${order.id}`,
    order.status === 'pending' ? 'الطلب بانتظار تأكيد التوفر والتكلفة وموعد التوصيل.' : 'متابعة الطلب المحفوظ سابقًا؛ يرجى مراجعة حالته مع الإدارة.',
    '',
    ...order.items.map(item => `${item.emoji} ${item.name} — ${item.storeName} × ${item.qty}: ${amount(item.unitPrice * item.qty)} ${currency}`),
    '',
    `قيمة المنتجات: ${amount(order.subtotal)} ${currency}`,
    `رسوم التوصيل الأساسية: ${amount(order.deliveryFee)} ${currency}`,
    `الإجمالي المبدئي: ${amount(order.total)} ${currency}`,
    `الاسم: ${order.customer.name}`,
    `الهاتف: ${order.customer.phone}`,
    `العنوان: ${order.customer.address}`,
    ...(order.notes ? [`ملاحظات: ${order.notes}`] : [])
  ];
  const message = lines.join('\n');
  return { order, message, whatsappUrl: `https://wa.me/${settings.whatsappNumber || BUSINESS_PHONE}?text=${encodeURIComponent(message)}` };
}

export async function createCustomOrder(input) {
  return action(async () => {
    const request = normalizeCustomRequest(input);
    const firebase = await getFirebase();
    const { db, firestoreSDK: F } = firebase;
    const user = await ensureOrderUser(firebase);
    const reference = F.doc(db, 'orders', request.requestId);
    const existing = await F.getDocFromServer(reference);
    if (existing.exists()) {
      const order = await verifyCustomRetry(existing, request, user, db, F);
      const catalog = await getCatalog({ fresh: true });
      return whatsappResult(order, catalog.settings);
    }
    const catalogSnapshot = await F.getDocFromServer(F.doc(db, 'catalog', 'current'));
    if (!catalogSnapshot.exists()) throw fail('المتاجر لم تُنشر بعد. تواصل معنا مباشرة لإتمام طلبك.', 'BEBO_DEMO_MODE');
    const catalog = normalizeCatalog(catalogSnapshot.data());
    if (catalog.settings.demoMode) throw fail('الموقع في الوضع التجريبي. تواصل معنا مباشرة قبل تقديم طلب.', 'BEBO_DEMO_MODE');
    const throttleRef = F.doc(db, 'orderThrottle', user.uid);
    const previous = await F.getDocFromServer(throttleRef);
    const previousTime = previous.exists() ? previous.data().createdAt?.toMillis?.() : null;
    if (Number.isFinite(previousTime) && Date.now() - previousTime < 30000) {
      throw fail('يرجى الانتظار 30 ثانية بين طلب وآخر. طلبك السابق محفوظ.', 'BEBO_ORDER_THROTTLED');
    }
    const stored = {
      kind: 'custom', customer: request.customer, notes: request.notes, items: request.items,
      createdAt: F.serverTimestamp(), createdBy: user.uid, status: 'pending', requestId: request.requestId
    };
    const batch = F.writeBatch(db);
    batch.set(reference, stored);
    for (const [photoId, dataUrl] of Object.entries(request.photos)) {
      batch.set(F.doc(db, 'orders', request.requestId, 'attachments', photoId), {
        dataUrl, createdAt: F.serverTimestamp(), createdBy: user.uid
      });
    }
    batch.set(throttleRef, { orderId: request.requestId, createdAt: F.serverTimestamp() });
    try { await batch.commit(); }
    catch (error) {
      // A response can be lost after the complete batch has committed.
      try {
        const committed = await F.getDocFromServer(reference);
        if (committed.exists()) {
          const order = await verifyCustomRetry(committed, request, user, db, F);
          return whatsappResult(order, catalog.settings);
        }
        if (error?.code === 'permission-denied') {
          const latest = await F.getDocFromServer(throttleRef);
          const time = latest.exists() ? latest.data().createdAt?.toMillis?.() : null;
          if (Number.isFinite(time) && Date.now() - time < 30000) {
            throw fail('يرجى الانتظار 30 ثانية بين طلب وآخر ثم أعد المحاولة.', 'BEBO_ORDER_THROTTLED');
          }
        }
      } catch (lookupError) {
        if (String(lookupError?.code || '').startsWith('BEBO_')) throw lookupError;
      }
      throw error;
    }
    const saved = await F.getDocFromServer(reference);
    if (!saved.exists()) throw fail('تعذّر تأكيد حفظ الطلب. أعد المحاولة بنفس الطلب للتحقق.', 'BEBO_REFRESH_REQUIRED');
    return whatsappResult(await verifyCustomRetry(saved, request, user, db, F), catalog.settings);
  });
}

export async function createOrder(input) {
  return action(async () => {
    const request = normalizeRequest(input);
    const firebase = await getFirebase();
    const { db, firestoreSDK: F } = firebase;
    const user = await ensureOrderUser(firebase);
    const reference = F.doc(db, 'orders', request.requestId);
    const existing = await F.getDocFromServer(reference);
    if (existing.exists()) {
      const data = existing.data();
      if (data.createdBy !== user.uid || !sameRequest(data, request)) {
        throw fail('معرّف الطلب مستخدم لبيانات مختلفة. ابدأ محاولة طلب جديدة.', 'BEBO_REQUEST_CONFLICT');
      }
      const catalog = await getCatalog({ fresh: true });
      return whatsappResult(orderRow(existing.id, data), catalog.settings);
    }
    const catalogSnapshot = await F.getDocFromServer(F.doc(db, 'catalog', 'current'));
    if (!catalogSnapshot.exists()) throw fail('المتاجر لم تُنشر بعد. تواصل معنا مباشرة لإتمام طلبك.', 'BEBO_DEMO_MODE');
    const catalog = normalizeCatalog(catalogSnapshot.data());
    if (catalog.settings.demoMode) throw fail('هذه قائمة تجريبية. تواصل معنا مباشرة قبل تقديم طلب.', 'BEBO_DEMO_MODE');
    if (catalog.version !== request.catalogVersion) throw fail('تحدّثت الأسعار أو المتاجر. حدّث السلة وراجع الإجمالي ثم أعد الطلب.', 'BEBO_VERSION_CONFLICT');
    const flatProducts = catalogSnapshot.data().products;
    const items = request.items.map(item => {
      const product = plain(flatProducts) ? flatProducts[item.key] : null;
      const canonical = catalog.products[item.key];
      if (!plain(product) || !canonical || Object.keys(canonical).some(key => product[key] !== canonical[key])) {
        throw fail('تعذّر التحقق من أحد المنتجات. حدّث السلة أو تواصل معنا.', 'BEBO_BAD_CATALOG');
      }
      if (!product.available || !product.storeOpen) throw fail(`المنتج «${product.name}» أو متجره غير متاح الآن. راجع السلة.`, 'BEBO_PRODUCT_UNAVAILABLE');
      return { key: item.key, qty: item.qty, unitPrice: money(product.price, 'السعر'), name: product.name, storeName: product.storeName, emoji: product.emoji };
    });
    const throttleRef = F.doc(db, 'orderThrottle', user.uid);
    const previous = await F.getDocFromServer(throttleRef);
    const previousTime = previous.exists() ? previous.data().createdAt?.toMillis?.() : null;
    if (Number.isFinite(previousTime) && Date.now() - previousTime < 30000) {
      throw fail('يرجى الانتظار 30 ثانية بين طلب وآخر. طلبك السابق محفوظ.', 'BEBO_ORDER_THROTTLED');
    }
    const stored = {
      customer: request.customer,
      notes: request.notes,
      items,
      deliveryFee: catalog.settings.deliveryFee,
      catalogVersion: catalog.version,
      createdAt: F.serverTimestamp(),
      createdBy: user.uid,
      status: 'pending',
      requestId: request.requestId
    };
    const batch = F.writeBatch(db);
    batch.set(reference, stored);
    batch.set(throttleRef, { orderId: request.requestId, createdAt: F.serverTimestamp() });
    try { await batch.commit(); }
    catch (error) {
      // A repeated attempt can have committed even when its response was lost.
      try {
        const committed = await F.getDocFromServer(reference);
        if (committed.exists() && committed.data().createdBy === user.uid && sameRequest(committed.data(), request)) {
          return whatsappResult(orderRow(committed.id, committed.data()), catalog.settings);
        }
        if (error?.code === 'permission-denied') {
          const latest = await F.getDocFromServer(throttleRef);
          const time = latest.exists() ? latest.data().createdAt?.toMillis?.() : null;
          if (Number.isFinite(time) && Date.now() - time < 30000) {
            throw fail('يرجى الانتظار 30 ثانية بين طلب وآخر ثم أعد المحاولة.', 'BEBO_ORDER_THROTTLED');
          }
        }
      } catch (lookupError) {
        if (String(lookupError?.code || '').startsWith('BEBO_')) throw lookupError;
      }
      throw error;
    }
    const saved = await F.getDocFromServer(reference);
    if (!saved.exists()) throw fail('تعذّر تأكيد حفظ الطلب. أعد المحاولة بنفس الطلب للتحقق.', 'BEBO_REFRESH_REQUIRED');
    return whatsappResult(orderRow(saved.id, saved.data()), catalog.settings);
  });
}
