export const MAX_PHOTO_DATA_URL = 180000;
const MAX_FILE_BYTES = 12 * 1024 * 1024;

function readDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('تعذّر تجهيز الصورة. جرّب صورة أخرى.'));
    reader.readAsDataURL(blob);
  });
}

export async function prepareProductPhoto(file) {
  if (!(file instanceof File) || !file.size) throw new Error('اختر صورة واضحة للمنتج.');
  if (file.size > MAX_FILE_BYTES) throw new Error('الصورة كبيرة جدًا. اختر صورة أقل من 12 ميجابايت.');
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('اختر صورة بصيغة JPG أو PNG أو WebP.');
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    try { await image.decode(); } catch { throw new Error('تعذّر قراءة الصورة. اختر صورة أخرى بصيغة JPG أو PNG أو WebP.'); }
    if (!image.naturalWidth || !image.naturalHeight || image.naturalWidth * image.naturalHeight > 40000000) throw new Error('دقّة الصورة كبيرة جدًا. اختر نسخة أصغر من الصورة.');
    const canvas = document.createElement('canvas');
    let edge = 1280;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const scale = Math.min(1, edge / Math.max(image.naturalWidth, image.naturalHeight));
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext('2d');
      if (!context) throw new Error('تجهيز الصور غير متاح في هذا المتصفح. جرّب متصفحًا آخر.');
      context.fillStyle = '#fff'; context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      for (const quality of [.82, .68, .54]) {
        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
        if (!blob) throw new Error('تعذّر تجهيز الصورة. جرّب صورة أخرى.');
        if (blob.size > 134000) continue;
        const dataUrl = await readDataUrl(blob);
        if (dataUrl.length <= MAX_PHOTO_DATA_URL) return dataUrl;
      }
      edge = Math.round(edge * .75);
    }
    throw new Error('تعذّر تصغير الصورة للإرسال. اختر صورة أوضح وأصغر حجمًا.');
  } finally { URL.revokeObjectURL(url); }
}
