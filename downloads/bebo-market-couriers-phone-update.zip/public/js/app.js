import {getCatalog, createCustomOrder, isConfigured} from './backend.js';
import {escapeHtml, sanitizeCatalog, validateCustomer, safeWhatsAppUrl} from './market-core.js';
import {initNavigation, navigateToSection, refreshPills} from './navigation.js';
import {prepareProductPhoto} from './product-photos.js';

const $ = id => document.getElementById(id);
const html = escapeHtml;
const MAX_ITEMS = 5;
let catalog = sanitizeCatalog(null);
let items = [];
let filter = 'all';
let editing = -1;
let editorPhoto = '';
let photoGeneration = 0;
let preparingPhoto = false;
let returnToCart = false;
let dialog = null;
let opener = null;
let inertElements = [];
let request = null;
let saved = null;
let submitting = false;
let toastTimer;

function locked() { return submitting || Boolean(request); }
function canSend() { return isConfigured() && catalog.source === 'firebase' && !catalog.settings.demoMode && navigator.onLine !== false; }
function text(id, value) { if ($(id)) $(id).textContent = value; }
function toast(message) {
  let element = $('appToast');
  if (!element) { element = document.createElement('div'); element.id = 'appToast'; element.className = 'toast'; element.setAttribute('role', 'status'); document.body.append(element); }
  clearTimeout(toastTimer); element.textContent = message; element.hidden = false;
  toastTimer = setTimeout(() => { element.hidden = true; }, 6000);
}
function menu(open) { $('navLinks')?.classList.toggle('active', open); $('menuToggle')?.setAttribute('aria-expanded', String(open)); if (open) refreshPills(); }
function focusable(element) {
  return [...element.querySelectorAll('a[href],button:not(:disabled),input:not(:disabled),textarea:not(:disabled),[tabindex="0"]')]
    .filter(node => !node.closest('[hidden]') && node.getClientRects().length);
}
function closeDialog({restore = true} = {}) {
  if (!dialog) return;
  if (dialog.id === 'storeModal') { photoGeneration += 1; preparingPhoto = false; }
  dialog.classList.remove('active'); dialog.setAttribute('aria-hidden', 'true'); dialog.inert = true;
  $('cartOverlay').classList.remove('active'); $('cartBtn').setAttribute('aria-expanded', 'false');
  inertElements.forEach(([element, previous]) => { element.inert = previous; }); inertElements = [];
  dialog = null; document.body.style.overflow = '';
  if (restore && opener?.isConnected && !opener.closest('[inert]')) opener.focus();
  opener = null;
}
function openDialog(id, {cartOpener = false} = {}) {
  const target = $(id); if (!target) return;
  const active = document.activeElement; closeDialog({restore: false});
  opener = cartOpener ? $('cartBtn') : active; dialog = target;
  target.inert = false; target.classList.add('active'); target.setAttribute('aria-hidden', 'false');
  if (id === 'cartSidebar') { $('cartOverlay').classList.add('active'); $('cartBtn').setAttribute('aria-expanded', 'true'); }
  menu(false); document.body.style.overflow = 'hidden';
  for (const element of document.body.children) {
    if (element === target || element.contains(target) || element === $('cartOverlay') || ['SCRIPT','STYLE'].includes(element.tagName)) continue;
    inertElements.push([element, element.inert]); element.inert = true;
  }
  (focusable(target)[0] || target).focus();
}
function closeEditor() {
  const back = returnToCart; closeDialog();
  if (back) openDialog('cartSidebar', {cartOpener: true});
}
function showPhoto() {
  $('productPhotoPreview').hidden = !editorPhoto;
  if (editorPhoto) $('productPhotoImage').src = editorPhoto; else $('productPhotoImage').removeAttribute('src');
}
function openEditor(storeName = '', index = -1) {
  if (locked()) { openDialog('cartSidebar', {cartOpener: true}); return; }
  if (index < 0 && items.length >= MAX_ITEMS) { toast('الطلب الواحد يتسع إلى خمسة منتجات. عدّل أحد المنتجات أو احذفه لإضافة غيره.'); return; }
  returnToCart = dialog?.id === 'cartSidebar';
  const item = index >= 0 ? items[index] : null;
  if (index >= 0 && !item) return;
  editing = index; editorPhoto = item?.dataUrl || ''; preparingPhoto = false; photoGeneration += 1;
  $('productRequestForm').reset();
  $('productDescription').value = item?.description || '';
  $('productQuantity').value = item?.quantity || '1';
  $('productStore').value = item?.storeName || storeName;
  $('saveProductButton').disabled = false;
  text('modalStoreName', index >= 0 ? 'تعديل تفاصيل المنتج' : 'تفاصيل المنتج');
  text('saveProductButton', index >= 0 ? 'حفظ تفاصيل المنتج' : 'إضافة إلى الطلب');
  text('productError', ''); text('photoStatus', editorPhoto ? 'صورة المنتج جاهزة.' : '');
  showPhoto(); openDialog('storeModal', {cartOpener: returnToCart});
}
async function choosePhoto() {
  const file = $('productPhoto').files?.[0]; if (!file || locked()) return;
  const version = ++photoGeneration;
  preparingPhoto = true; editorPhoto = ''; showPhoto(); $('saveProductButton').disabled = true;
  text('productError', ''); text('photoStatus', 'جارٍ تجهيز الصورة للإرسال…');
  try {
    const dataUrl = await prepareProductPhoto(file);
    if (version !== photoGeneration || dialog?.id !== 'storeModal') return;
    editorPhoto = dataUrl; showPhoto(); text('photoStatus', 'الصورة جاهزة. يمكنك إضافة المنتج إلى الطلب.');
  } catch (error) {
    if (version !== photoGeneration || dialog?.id !== 'storeModal') return;
    $('productPhoto').value = ''; text('photoStatus', ''); text('productError', error.message);
  } finally {
    if (version === photoGeneration) { preparingPhoto = false; $('saveProductButton').disabled = false; }
  }
}
function saveProduct(event) {
  event.preventDefault(); if (locked() || preparingPhoto) return;
  const description = $('productDescription').value.trim();
  const quantity = $('productQuantity').value.trim();
  const storeName = $('productStore').value.trim();
  if (description.length < 2 && !editorPhoto) { text('productError', 'اكتب تفاصيل المنتج أو أرفق صورة توضّحه.'); $('productDescription').focus(); return; }
  if (!quantity) { text('productError', 'حدّد الكمية أو الحجم المطلوب.'); $('productQuantity').focus(); return; }
  if (description.length > 1000 || quantity.length > 80 || storeName.length > 100) { text('productError', 'اختصر التفاصيل أو الكمية أو اسم المتجر.'); return; }
  const value = {description, quantity, storeName, dataUrl: editorPhoto};
  if (editing >= 0) items[editing] = value; else if (items.length < MAX_ITEMS) items.push(value); else return;
  closeDialog({restore: false}); renderCart(); openDialog('cartSidebar', {cartOpener: true});
  toast(editing >= 0 ? 'حُفظت تفاصيل المنتج.' : 'أُضيف المنتج إلى طلبك.');
}
function renderStores() {
  const query = ($('searchInput').value || '').trim().toLocaleLowerCase('ar');
  const stores = catalog.stores.filter(store => store.enabled && (filter === 'all' || store.category === filter)
    && `${store.name} ${store.description}`.toLocaleLowerCase('ar').includes(query));
  $('storesGrid').innerHTML = stores.length ? stores.map(store => `<button type="button" class="store-card" data-action="open-store" data-store-id="${html(store.id)}" aria-label="كتابة طلب من ${html(store.name)}"><span class="store-card-image ${html(store.category)}"><span aria-hidden="true">${html(store.icon)}</span><span class="store-status ${store.isOpen ? 'open' : 'closed'}">${store.isOpen ? 'متاح' : 'مغلق حاليًا'}</span></span><span class="store-card-body"><strong class="store-name">${html(store.name)}</strong><span class="store-desc">${html(store.description)}</span><span class="store-meta">اكتب تفاصيل طلبك أو أرفق صورة المنتج</span></span></button>`).join('') : '<div class="store-empty"><h3>لا توجد متاجر مطابقة</h3><p>يمكنك تسجيل طلبك بالوصف أو الصورة وسنراجع المتجر المناسب معك.</p><button type="button" class="btn btn-primary" data-action="start-request">إضافة منتج للطلب</button></div>';
}
function setFilter(value, navigate = false, focus = false) {
  filter = ['all','restaurants','grocery','pharmacy','butcher','vegetables','other'].includes(value) ? value : 'all';
  document.querySelectorAll('[data-filter]').forEach(button => { const selected = button.dataset.filter === filter; button.classList.toggle('active', selected); button.setAttribute('aria-pressed', String(selected)); });
  renderStores(); refreshPills(); if (navigate) navigateToSection('stores', {focus});
}
function applySettings() {
  const settings = catalog.settings; const stores = catalog.stores.filter(store => store.enabled);
  document.title = `${settings.siteName} | طلبات بالوصف والصورة`;
  document.querySelectorAll('[data-site-name]').forEach(node => { node.textContent = settings.siteName; });
  document.querySelectorAll('[data-city]').forEach(node => { node.textContent = settings.city; });
  document.querySelectorAll('[data-count-stores]').forEach(node => { node.textContent = stores.length.toLocaleString('ar-SD'); });
  document.querySelectorAll('[data-category-count],[data-count-category]').forEach(node => { const count = stores.filter(store => store.category === (node.dataset.categoryCount || node.dataset.countCategory)).length.toLocaleString('ar-SD'); node.textContent = node.hasAttribute('data-category-count') ? `${count} متجر` : count; });
  text('storeCount', `${stores.length.toLocaleString('ar-SD')} متجر في القائمة`);
  text('availabilityNote', 'اختر متجرًا مفضّلًا أو أرسل تفاصيل المنتج وصورته لنراجع التوفّر معك.');
  $('storeSuggestions').innerHTML = stores.map(store => `<option value="${html(store.name)}"></option>`).join('');
  $('phonePreviewStores').innerHTML = stores.slice(0,4).map(store => `<button type="button" class="app-item" data-action="open-store" data-store-id="${html(store.id)}">${html(store.icon)} ${html(store.name)}</button>`).join('');
  document.querySelectorAll('[data-contact]').forEach(link => {
    const kind = link.dataset.contact;
    if (kind === 'phone') link.href = `tel:${settings.phone}`;
    if (kind === 'facebook') link.href = settings.facebookUrl;
    if (kind === 'whatsapp') { let message = ''; try { message = new URL(link.href).searchParams.get('text') || ''; } catch {} link.href = `https://wa.me/${settings.whatsappNumber}${message ? `?text=${encodeURIComponent(message)}` : ''}`; }
    const detail = link.matches('.contact-card') && link.querySelector('p');
    if (detail) detail.textContent = kind === 'phone' ? settings.phone : kind === 'whatsapp' ? `+${settings.whatsappNumber}` : new URL(settings.facebookUrl).pathname.replace(/^\//, '@');
  });
  refreshPills(); notices();
}
function notices() {
  const unavailable = catalog.source !== 'firebase' || catalog.settings.demoMode;
  $('catalogNotice').hidden = !unavailable;
  text('catalogNotice', unavailable ? 'عرض تجريبي أو اتصال غير متاح. يمكنك تجربة كتابة الطلب؛ حفظه للمراجعة يحتاج اتصالًا بالموقع المفعّل.' : '');
  $('connectionNotice').hidden = navigator.onLine !== false;
  text('connectionNotice', 'أنت غير متصل بالإنترنت. التفاصيل والصور باقية في هذه الصفحة؛ أعد الاتصال قبل تسجيل الطلب.');
  updateControls();
}
async function loadCatalog(fresh = false) {
  try { catalog = sanitizeCatalog(await getCatalog({fresh})); }
  catch { catalog = sanitizeCatalog({source: 'offline'}); }
  applySettings(); renderStores(); renderCart();
}
function updateControls() {
  const waiting = locked();
  ['customerName','customerPhone','customerAddress','orderNotes'].forEach(id => { $(id).disabled = waiting; });
  $('addAnotherProduct').disabled = waiting || items.length >= MAX_ITEMS;
  document.querySelectorAll('[data-action="clear-cart"]').forEach(button => { button.disabled = submitting || Boolean(request && !saved); });
  const button = document.querySelector('[data-action="prepare-order"]');
  button.disabled = submitting || !items.length || !canSend() || Boolean(saved);
  button.setAttribute('aria-busy', String(submitting));
  button.textContent = submitting ? 'جارٍ حفظ الطلب والصور…' : saved ? 'الطلب محفوظ للمراجعة' : request ? 'إعادة المحاولة للتحقق من نفس الطلب' : 'تسجيل الطلب للمراجعة';
}
function renderCart() {
  text('cartCount', items.length.toLocaleString('ar-SD'));
  $('cartBtn').setAttribute('aria-label', `تفاصيل طلبك، ${items.length} منتجات`);
  $('cartItems').innerHTML = items.length ? items.map((item,index) => `<article class="request-line"><div><h4>${html(item.description || 'منتج موضّح بالصورة')}</h4><p>الكمية: ${html(item.quantity)}</p>${item.storeName ? `<p>المتجر المفضّل: ${html(item.storeName)}</p>` : ''}${item.dataUrl ? `<img src="${item.dataUrl}" alt="صورة توضيحية للمنتج رقم ${index+1}">` : ''}</div><div class="request-line-actions"><button type="button" data-action="edit-request-item" data-index="${index}" ${locked() ? 'disabled' : ''}>تعديل</button><button type="button" data-action="remove-request-item" data-index="${index}" ${locked() ? 'disabled' : ''}>حذف</button></div></article>`).join('') : '<div class="cart-empty"><span class="cart-empty-icon" aria-hidden="true">📷</span><p>ابدأ بتفاصيل المنتج أو صورته</p><small>يمكنك إضافة خمسة منتجات إلى الطلب.</small></div>';
  $('cartFooter').style.display = items.length ? 'block' : 'none';
  updateControls();
}
function fieldErrors(errors = {}) {
  for (const [key,id] of Object.entries({name:'customerName',phone:'customerPhone',address:'customerAddress',notes:'orderNotes'})) {
    let element = $(`${id}Error`);
    if (!element) { element = document.createElement('small'); element.id = `${id}Error`; element.className = 'field-error'; $(id).insertAdjacentElement('afterend',element); }
    element.textContent = errors[key] || ''; element.hidden = !errors[key]; $(id).setAttribute('aria-invalid', String(Boolean(errors[key]))); $(id).setAttribute('aria-describedby',element.id);
  }
}
function resetDraft() {
  items = []; request = null; saved = null; editorPhoto = ''; photoGeneration += 1;
  $('productRequestForm').reset(); showPhoto(); text('photoStatus',''); text('productError','');
  for (const id of ['customerName','customerPhone','customerAddress','orderNotes']) $(id).value = '';
  text('orderError',''); $('orderResult').hidden = true; $('orderResult').replaceChildren();
  fieldErrors(); renderCart(); closeDialog();
}
function renderResult() {
  const panel = $('orderResult'); panel.hidden = false;
  panel.setAttribute('tabindex','-1'); panel.dataset.state = 'saved';
  const url = safeWhatsAppUrl(saved.whatsappUrl, catalog.settings.whatsappNumber);
  panel.innerHTML = `<h4>سُجّل طلبك للمراجعة</h4><p>رقم الطلب: <bdi>${html(saved.order.id)}</bdi></p><p>سنراجع التفاصيل والصور ونؤكد معك التوفّر والسعر ورسوم التوصيل قبل التنفيذ.</p>${items.some(item => item.dataUrl) ? '<p>الصور محفوظة مع الطلب ويطلع عليها المسؤول. رابط واتساب يجهّز رسالة المتابعة النصية.</p>' : ''}${url ? `<a class="btn btn-whatsapp btn-block" href="${html(url)}" target="_blank" rel="noopener noreferrer">متابعة الطلب في واتساب</a>` : ''}<a class="btn btn-outline btn-block" href="tel:${catalog.settings.phone}">اتصل بنا</a><p class="field-hint">لبدء طلب آخر يمكنك تفريغ هذه التفاصيل؛ الطلب المحفوظ يبقى لدى المسؤول.</p>`;
  updateControls(); panel.focus();
}
async function submitOrder() {
  if (submitting || saved || !items.length) return;
  if (!canSend()) { toast('تسجيل الطلب يحتاج اتصالًا والموقع خارج وضع المعاينة. تواصل معنا للاستفسار.'); return; }
  if (!request) {
    const checked = validateCustomer({name:$('customerName').value,phone:$('customerPhone').value,address:$('customerAddress').value,notes:$('orderNotes').value});
    fieldErrors(checked.errors);
    if (!checked.valid) { const id = {name:'customerName',phone:'customerPhone',address:'customerAddress',notes:'orderNotes'}[Object.keys(checked.errors)[0]]; $(id)?.focus(); return; }
    const photos = {};
    const lines = items.map((item,index) => { const photoId = item.dataUrl ? `photo-${index}` : ''; if (photoId) photos[photoId] = item.dataUrl; return {description:item.description,quantity:item.quantity,storeName:item.storeName,photoId}; });
    request = {requestId:crypto.randomUUID(),customer:checked.customer,notes:checked.notes,items:lines,photos};
  }
  submitting = true; text('orderError',''); renderCart();
  try {
    const result = await createCustomOrder(request);
    if (!result?.order?.id) throw new Error('تعذّر تأكيد حفظ الطلب. أعد المحاولة بنفس التفاصيل.');
    saved = result; renderResult(); toast('حُفظ الطلب للمراجعة. افتح واتساب وأرسل رسالة المتابعة إذا رغبت.');
  } catch (error) {
    text('orderError', error.message || 'تعذّر تأكيد الحفظ. أعد المحاولة بنفس الطلب للتحقق.');
    const panel = $('orderResult'); panel.hidden = false; panel.dataset.state = 'retry';
    const inquiry = `أريد التحقق من تسجيل الطلب رقم ${request.requestId} قبل تكراره.`;
    panel.innerHTML = `<p>التفاصيل والصور محفوظة في هذه الصفحة. أعد المحاولة للتحقّق من نفس الطلب.</p><div class="request-support"><a href="https://wa.me/${catalog.settings.whatsappNumber}?text=${encodeURIComponent(inquiry)}" target="_blank" rel="noopener noreferrer">استفسر عن الطلب في واتساب</a><a href="tel:${catalog.settings.phone}">اتصل بنا</a></div>`;
  } finally { submitting = false; renderCart(); if (saved) renderResult(); }
}
function init() {
  initNavigation();
  for (const id of ['storeModal','cartSidebar','confirmModal']) $(id).inert = true;
  $('productRequestForm').addEventListener('submit',saveProduct);
  $('productPhoto').addEventListener('change',() => void choosePhoto());
  $('searchInput').addEventListener('input',renderStores);
  for (const id of ['customerName','customerPhone','customerAddress','orderNotes']) $(id).addEventListener('input', () => { if (!request) { fieldErrors(); text('orderError',''); } });
  document.addEventListener('click',event => {
    if (!(event.target instanceof Element)) return;
    if (event.target === $('storeModal')) return closeEditor();
    if (event.target === $('confirmModal')) return closeDialog();
    if (event.target.closest('#navLinks a')) menu(false);
    const category = event.target.closest('[data-filter],[data-category]');
    if (category) return setFilter(category.dataset.filter || category.dataset.category, Boolean(category.dataset.category),event.detail===0);
    const control = event.target.closest('[data-action]'); if (!control || control.disabled) return;
    const action = control.dataset.action;
    if (action==='toggle-menu') menu(!$('navLinks').classList.contains('active'));
    if (action==='toggle-cart') dialog?.id==='cartSidebar' ? closeDialog() : openDialog('cartSidebar',{cartOpener:true});
    if (action==='start-request') openEditor();
    if (action==='open-store') { const store=catalog.stores.find(item=>String(item.id)===control.dataset.storeId); if (store) openEditor(store.name); }
    if (action==='close-modal') closeEditor();
    if (action==='remove-photo' && !locked()) { photoGeneration+=1; preparingPhoto=false; editorPhoto=''; $('productPhoto').value=''; $('saveProductButton').disabled=false; text('photoStatus',''); text('productError',''); showPhoto(); }
    if (action==='edit-request-item') openEditor('',Number(control.dataset.index));
    if (action==='remove-request-item' && !locked()) { items.splice(Number(control.dataset.index),1); renderCart(); }
    if (action==='clear-cart' && !submitting && (!request || saved)) { openDialog('confirmModal',{cartOpener:true}); }
    if (action==='cancel-clear-cart') openDialog('cartSidebar',{cartOpener:true});
    if (action==='confirm-clear-cart' && !submitting && (!request || saved)) resetDraft();
    if (action==='prepare-order') void submitOrder();
  });
  document.addEventListener('keydown',event => {
    if (event.key==='Escape') { if (dialog?.id==='storeModal') closeEditor(); else closeDialog(); menu(false); return; }
    if (event.key!=='Tab' || !dialog) return;
    const nodes=focusable(dialog), first=nodes[0],last=nodes.at(-1);
    if (!nodes.length) { event.preventDefault();dialog.focus(); }
    else if (event.shiftKey && (document.activeElement===first || !dialog.contains(document.activeElement))) { event.preventDefault();last.focus(); }
    else if (!event.shiftKey && (document.activeElement===last || !dialog.contains(document.activeElement))) { event.preventDefault();first.focus(); }
  });
  window.addEventListener('offline',notices);
  window.addEventListener('online',() => { notices(); void loadCatalog(true); });
  window.BeboMarket=Object.freeze({getCatalog:()=>structuredClone(catalog),getCart:()=>items.map((item,index)=>({index,hasPhoto:Boolean(item.dataUrl)}))});
  renderCart(); void loadCatalog();
}
if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true});else init();
