@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto failed
where node >nul 2>nul
if errorlevel 1 goto missing_node
if not exist "package.json" goto wrong_folder
if not exist "tools\publish-photo-update.mjs" goto wrong_folder
if not exist "tools\config-lib.mjs" goto wrong_folder
if not exist "public\index.html" goto wrong_folder
if not exist "public\js\navigation.js" goto wrong_folder
if not exist "public\js\product-photos.js" goto wrong_folder
if not exist "public\js\backend.js" goto wrong_folder
if not exist "firestore.rules" goto wrong_folder
if not exist "node_modules\firebase-tools\lib\bin\firebase.js" goto missing_tools
call node "tools\publish-photo-update.mjs"
if errorlevel 1 goto failed
pause
exit /b 0
:missing_node
echo Install Node.js LTS, then reopen this file.
pause
exit /b 1
:wrong_folder
echo Merge this update into your original Bebo Market project folder first.
echo Keep its existing public, tools and Firebase configuration files.
pause
exit /b 1
:missing_tools
echo Firebase CLI is missing from this folder.
echo Run setup-firebase.bat in the original market folder, then reopen publish-photo-update.bat.
pause
exit /b 1
:failed
echo Publishing stopped. Read the error above before trying again.
pause
exit /b 1
