import assert from 'node:assert/strict';
import { after, before, beforeEach, test } from 'node:test';
import { readFile } from 'node:fs/promises';
import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import {
  collection, collectionGroup, deleteDoc, doc, getDoc, getDocs, serverTimestamp,
  setDoc, setLogLevel, Timestamp, updateDoc, writeBatch
} from 'firebase/firestore';

setLogLevel('silent');

// These fixtures may only clear their own demo project, never the UI QA project.
const projectId = 'demo-bebo-photo-rules';
const [host, portText] = (process.env.FIRESTORE_EMULATOR_HOST || '127.0.0.1:8080').split(':');
const adminEmail = 'owner@example.com';
const id = 'f47ac10b-58cc-4372-a567-0e02b2c3d479';
const secondId = 'f47ac10b-58cc-4372-a567-0e02b2c3d480';
// A small JPEG fixture: rules validate its MIME prefix, JPEG magic and base64 syntax.
const jpeg = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////2wBDAf//////////////////////////////////////////////////////////////////////////////////////wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAF//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABBQJ//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwF//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwF//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQAGPwJ//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPyF//9oADAMBAAIAAwAAABD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/EH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/EH//xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oACAEBAAE/EH//2Q==';
let env;

function catalog(demoMode = false) {
  return { version: 1, settings: { demoMode }, products: {} };
}

function buyer(uid = 'buyer-1') {
  return env.authenticatedContext(uid, { firebase: { sign_in_provider: 'anonymous' } }).firestore();
}

function admin(claims = {}) {
  return env.authenticatedContext('admin-1', { email: adminEmail, email_verified: true, ...claims }).firestore();
}

function item(index = 0, photo = false) {
  return { description: 'منتج من السوق', quantity: '٢ كيس', storeName: '', photoId: photo ? `photo-${index}` : '' };
}

function order({ uid = 'buyer-1', requestId = id, count = 1, photos = false } = {}) {
  return {
    kind: 'custom', customer: { name: 'عميل دنقلا', phone: '+249912345678', address: 'دنقلا حي السوق المنزل ١' },
    notes: '', items: Array.from({ length: count }, (_, index) => item(index, photos)),
    createdAt: serverTimestamp(), createdBy: uid, status: 'pending', requestId
  };
}

function attachment(patch = {}) {
  return { dataUrl: jpeg, createdAt: serverTimestamp(), createdBy: 'buyer-1', ...patch };
}

function place({ db = buyer(), value = order(), requestId = id, photos, throttle = true } = {}) {
  const batch = writeBatch(db);
  batch.set(doc(db, 'orders', requestId), value);
  if (throttle) batch.set(doc(db, 'orderThrottle', value.createdBy), { orderId: requestId, createdAt: serverTimestamp() });
  const entries = photos ?? value.items.filter(line => line.photoId).map(line => [line.photoId, attachment({ createdBy: value.createdBy })]);
  for (const [photoId, photo] of entries) batch.set(doc(db, 'orders', requestId, 'attachments', photoId), photo);
  return batch.commit();
}

async function seed(path, data) {
  await env.withSecurityRulesDisabled(context => setDoc(doc(context.firestore(), path), data));
}

before(async () => {
  const rulesFile = process.env.CUSTOM_ORDER_RULES_FILE || new URL('../firestore.rules', import.meta.url);
  env = await initializeTestEnvironment({
    projectId, firestore: { host, port: Number(portText), rules: await readFile(rulesFile, 'utf8') }
  });
});

beforeEach(async () => {
  await env.clearFirestore();
  await seed('catalog/current', catalog());
  await seed('adminAccess/roster', { emails: [adminEmail], updatedAt: Timestamp.fromMillis(1), updatedBy: 'console-bootstrap' });
});

after(async () => { await env?.cleanup(); });

test('custom text-only request creates exact unpriced data with its atomic throttle', async () => {
  const db = buyer();
  await assertSucceeds(place({ db }));
  const saved = (await getDoc(doc(db, 'orders', id))).data();
  assert.equal(saved.kind, 'custom');
  assert.equal(saved.items[0].quantity, '٢ كيس');
  assert.ok(saved.createdAt instanceof Timestamp);
  for (const key of ['deliveryFee', 'catalogVersion', 'subtotal', 'total', 'price']) assert.equal(saved[key], undefined);
});

test('photo-only request accepts empty description and a same-commit JPEG', async () => {
  const value = order({ photos: true }); value.items[0].description = '';
  await assertSucceeds(place({ value }));
  const saved = (await getDoc(doc(buyer(), 'orders', id, 'attachments', 'photo-0'))).data();
  assert.equal(saved.dataUrl, jpeg);
});

test('five text-only lines fit the evaluation budget and every slot is accepted', async () => {
  await assertSucceeds(place({ value: order({ count: 5 }) }));
});

test('all five photos and five items commit within document-access and expression budgets', async () => {
  await assertSucceeds(place({ value: order({ count: 5, photos: true }) }));
  for (let index = 0; index < 5; index++) {
    await assertSucceeds(getDoc(doc(buyer(), 'orders', id, 'attachments', `photo-${index}`)));
  }
});

test('mixed photo and text lines accept the fixed photo slot IDs', async () => {
  const value = order({ count: 5 }); value.items[4] = item(4, true); value.items[2] = item(2, true);
  await assertSucceeds(place({ value }));
});

test('maximum permitted text lengths and minimum customer lengths are accepted', async () => {
  const value = order();
  value.customer = { name: 'عم', phone: '+249912345678', address: 'منزل١' };
  value.notes = 'ن'.repeat(1000);
  value.items[0] = { description: 'ن'.repeat(1000), quantity: 'ن'.repeat(80), storeName: 'ن'.repeat(100), photoId: '' };
  await assertSucceeds(place({ value }));
});

test('owner and verified allowlisted admin get photos; other callers and unverified admins cannot', async () => {
  await assertSucceeds(place({ value: order({ photos: true }) }));
  for (const db of [buyer(), admin(), admin({ email: 'OWNER@EXAMPLE.COM' })]) {
    await assertSucceeds(getDoc(doc(db, 'orders', id, 'attachments', 'photo-0')));
  }
  for (const db of [buyer('other'), env.unauthenticatedContext().firestore(), admin({ email_verified: false }), admin({ email: 'intruder@example.com' })]) {
    await assertFails(getDoc(doc(db, 'orders', id, 'attachments', 'photo-0')));
  }
});

test('photos cannot be listed by owner, admin, strangers, public, or collection group', async () => {
  await assertSucceeds(place({ value: order({ photos: true }) }));
  for (const db of [buyer(), admin(), buyer('other'), env.unauthenticatedContext().firestore()]) {
    await assertFails(getDocs(collection(db, 'orders', id, 'attachments')));
    await assertFails(getDocs(collectionGroup(db, 'attachments')));
  }
});

test('custom order PII keeps existing owner/admin reads and admin-only listing', async () => {
  await assertSucceeds(place());
  for (const db of [buyer(), admin()]) await assertSucceeds(getDoc(doc(db, 'orders', id)));
  for (const db of [buyer('other'), env.unauthenticatedContext().firestore()]) await assertFails(getDoc(doc(db, 'orders', id)));
  await assertSucceeds(getDocs(collection(admin(), 'orders')));
  await assertFails(getDocs(collection(buyer(), 'orders')));
});

test('custom status changes preserve existing immutable order/admin policy', async () => {
  await assertSucceeds(place({ value: order({ photos: true }) }));
  const ref = doc(admin(), 'orders', id);
  await assertSucceeds(updateDoc(ref, { status: 'confirmed', updatedAt: serverTimestamp(), updatedBy: 'admin-1' }));
  for (const patch of [{ kind: 'priced' }, { items: [] }, { notes: 'changed' }, { customer: {} }, { total: 1 }]) {
    await assertFails(updateDoc(ref, { status: 'confirmed', updatedAt: serverTimestamp(), updatedBy: 'admin-1', ...patch }));
  }
  await assertFails(updateDoc(doc(buyer(), 'orders', id), { status: 'cancelled' }));
  await assertFails(deleteDoc(ref));
});

for (const field of ['price', 'unitPrice', 'subtotal', 'deliveryFee', 'total', 'catalogVersion', 'quote']) {
  test(`custom top-level caller-supplied ${field} is denied`, async () => {
    await assertFails(place({ value: { ...order(), [field]: 1 } }));
  });
}

test('custom items require exact four-key shape and reject every price field', async () => {
  for (const field of ['price', 'unitPrice', 'qty', 'total', 'deliveryFee', 'productId', 'extra']) {
    const value = order(); value.items[0][field] = 1;
    await assertFails(place({ value }));
  }
  for (const field of ['description', 'quantity', 'storeName', 'photoId']) {
    const value = order(); delete value.items[0][field];
    await assertFails(place({ value }));
  }
});

test('empty, malformed, and more than five item lists are denied', async () => {
  for (const items of [[], {}, 'text', Array.from({ length: 6 }, (_, index) => item(index))]) {
    await assertFails(place({ value: { ...order(), items }, photos: [] }));
  }
});

test('every item slot validates text types and bounds', async () => {
  for (let index = 0; index < 5; index++) {
    for (const patch of [{ description: '' }, { description: 'x' }, { description: 12 }, { description: 'x'.repeat(1001) }, { quantity: '' }, { quantity: 2 }, { quantity: 'x'.repeat(81) }, { storeName: 1 }, { storeName: 'x'.repeat(101) }, { photoId: null }]) {
      const value = order({ count: 5 }); Object.assign(value.items[index], patch);
      await assertFails(place({ value, photos: [] }));
    }
  }
});

test('one-character description is allowed when an image supplies the detail', async () => {
  const value = order({ photos: true }); value.items[0].description = '؟';
  await assertSucceeds(place({ value }));
});

test('custom customer exact shape, Sudan phone, name/address/notes bounds and types are enforced', async () => {
  for (const mutate of [
    value => { value.customer.name = 'x'; }, value => { value.customer.name = 'x'.repeat(101); },
    value => { value.customer.address = '1234'; }, value => { value.customer.address = 'x'.repeat(301); },
    value => { value.customer.phone = '0912345678'; }, value => { value.customer.phone = '+249812345678'; },
    value => { value.customer.extra = true; }, value => { delete value.customer.phone; },
    value => { value.notes = 'x'.repeat(1001); }, value => { value.notes = 1; }
  ]) {
    const value = order(); mutate(value); await assertFails(place({ value }));
  }
});

test('custom kind, actor, server time, pending status and matching requestId are enforced', async () => {
  for (const patch of [
    { kind: 'priced' }, { kind: null }, { createdBy: 'victim' }, { createdAt: Timestamp.fromMillis(1) },
    { status: 'confirmed' }, { requestId: secondId }, { extra: true }
  ]) await assertFails(place({ value: { ...order(), ...patch } }));
  for (const field of ['kind', 'customer', 'notes', 'createdAt', 'createdBy', 'status', 'requestId']) {
    const value = order(); delete value[field];
    await assertFails(place({ value, throttle: field !== 'createdBy' }));
  }
  await assertFails(place({ db: env.unauthenticatedContext().firestore() }));
});

test('custom order IDs require UUID shape, version and variant bits', async () => {
  for (const requestId of ['order-request-000001', 'short', 'f47ac10b-58cc-0372-a567-0e02b2c3d479', 'f47ac10b-58cc-4372-0567-0e02b2c3d479']) {
    await assertFails(place({ requestId, value: order({ requestId }) }));
  }
  const upper = id.toUpperCase();
  await assertSucceeds(place({ requestId: upper, value: order({ requestId: upper }) }));
});

test('demo mode or missing catalog denies custom requests', async () => {
  await seed('catalog/current', catalog(true));
  await assertFails(place());
  await env.withSecurityRulesDisabled(context => deleteDoc(doc(context.firestore(), 'catalog/current')));
  await assertFails(place());
});

test('custom requests require their own matching atomic throttle', async () => {
  await assertFails(place({ throttle: false }));
  const db = buyer(); const batch = writeBatch(db);
  batch.set(doc(db, 'orders', id), order());
  batch.set(doc(db, 'orderThrottle', 'buyer-1'), { orderId: secondId, createdAt: serverTimestamp() });
  await assertFails(batch.commit());
  await assertFails(setDoc(doc(db, 'orderThrottle', 'buyer-1'), { orderId: id, createdAt: serverTimestamp() }));
});

test('custom requests share the 30-second throttle and accept a later request', async () => {
  await assertSucceeds(place());
  await assertFails(place({ requestId: secondId, value: order({ requestId: secondId }) }));
  await seed('orderThrottle/buyer-1', { orderId: id, createdAt: Timestamp.fromMillis(Date.now() - 31000) });
  await assertSucceeds(place({ requestId: secondId, value: order({ requestId: secondId }) }));
});

test('one throttle cannot authorize two custom requests in one commit', async () => {
  const db = buyer(); const batch = writeBatch(db);
  batch.set(doc(db, 'orders', id), order());
  batch.set(doc(db, 'orders', secondId), order({ requestId: secondId }));
  batch.set(doc(db, 'orderThrottle', 'buyer-1'), { orderId: id, createdAt: serverTimestamp() });
  await assertFails(batch.commit());
});

test('a referenced photo must be present in the same atomic batch', async () => {
  await assertFails(place({ value: order({ photos: true }), photos: [] }));
  assert.equal((await getDoc(doc(buyer(), 'orders', id))).exists(), false);
});

test('all five referenced photos are required, including the last slot', async () => {
  const value = order({ count: 5, photos: true });
  const photos = value.items.slice(0, 4).map(line => [line.photoId, attachment()]);
  await assertFails(place({ value, photos }));
});

test('photo IDs cannot refer to another slot, another order, paths, or arbitrary names', async () => {
  for (const photoId of ['photo-1', 'photo-5', '../photo-0', `${secondId}/photo-0`, 'image', 0]) {
    const value = order(); value.items[0].photoId = photoId;
    await assertFails(place({ value, photos: [] }));
  }
});

test('extra and unreferenced photo slots are denied atomically', async () => {
  for (const photoId of ['photo-0', 'photo-1', 'photo-5', 'image']) {
    await assertFails(place({ photos: [[photoId, attachment()]] }));
  }
  const value = order({ photos: true });
  await assertFails(place({ value, photos: [['photo-0', attachment()], ['photo-1', attachment()]] }));
});

test('orphan photos cannot be created by buyer or admin', async () => {
  for (const db of [buyer(), admin()]) await assertFails(setDoc(doc(db, 'orders', id, 'attachments', 'photo-0'), attachment()));
});

test('late photo creation cannot attach to an already-saved request', async () => {
  await assertSucceeds(place());
  await assertFails(setDoc(doc(buyer(), 'orders', id, 'attachments', 'photo-0'), attachment()));
  // Even a seeded parent that references a missing image does not permit repair via client writes.
  await seed(`orders/${secondId}`, { ...order({ requestId: secondId, photos: true }), createdAt: Timestamp.fromMillis(1) });
  await assertFails(setDoc(doc(buyer(), 'orders', secondId, 'attachments', 'photo-0'), attachment()));
});

test('old preexisting photos cannot satisfy a new custom request', async () => {
  await seed(`orders/${id}/attachments/photo-0`, attachment({ createdAt: Timestamp.fromMillis(1) }));
  await assertFails(place({ value: order({ photos: true }), photos: [] }));
});

test('photo owner, timestamp and exact three-field shape are enforced', async () => {
  for (const patch of [{ createdBy: 'other' }, { createdAt: Timestamp.fromMillis(1) }, { extra: true }, { contentType: 'image/jpeg' }]) {
    await assertFails(place({ value: order({ photos: true }), photos: [['photo-0', attachment(patch)]] }));
  }
  for (const field of ['createdBy', 'createdAt', 'dataUrl']) {
    const photo = attachment(); delete photo[field];
    await assertFails(place({ value: order({ photos: true }), photos: [['photo-0', photo]] }));
  }
});

test('non-JPEG, forged JPEG MIME, malformed base64 and oversized photos are denied', async () => {
  for (const dataUrl of [
    '', 1, jpeg.replace('image/jpeg', 'image/png'), 'data:image/jpeg;base64,iVBORw0KGgo=',
    'data:image/jpeg;base64,/9j/not valid!', 'data:image/jpeg;base64,/9j/A',
    'data:image/jpeg;base64,/9j/====', 'data:image/jpeg;base64,/9j/AA===',
    `data:image/jpeg;base64,/9j/${'A'.repeat(180000)}`
  ]) await assertFails(place({ value: order({ photos: true }), photos: [['photo-0', attachment({ dataUrl })]] }));
});

test('all five near-limit JPEG-pattern photos fit one atomic request', async () => {
  const dataUrl = `data:image/jpeg;base64,/9j/${'A'.repeat(179972)}`;
  assert.equal(dataUrl.length, 179999);
  const value = order({ count: 5, photos: true });
  const photos = value.items.map(line => [line.photoId, attachment({ dataUrl })]);
  await assertSucceeds(place({ value, photos }));
});

test('customers and admins cannot rewrite or delete saved photos', async () => {
  await assertSucceeds(place({ value: order({ photos: true }) }));
  for (const db of [buyer(), admin(), buyer('other')]) {
    const ref = doc(db, 'orders', id, 'attachments', 'photo-0');
    await assertFails(setDoc(ref, attachment()));
    await assertFails(updateDoc(ref, { dataUrl: jpeg }));
    await assertFails(deleteDoc(ref));
  }
});

test('customers cannot overwrite a saved custom request or replay its photos', async () => {
  await assertSucceeds(place({ value: order({ photos: true }) }));
  await assertFails(place({ value: order({ photos: true }) }));
});
