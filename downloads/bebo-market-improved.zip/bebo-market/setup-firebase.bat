@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto missing
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed
call npx firebase login
if errorlevel 1 goto failed
call npm run configure
if errorlevel 1 goto failed
echo Setup saved. Continue with README-AR.md to enable providers and authorize the owner.
pause
exit /b 0
:missing
echo Install Node.js LTS, then reopen this file.
pause
exit /b 1
:failed
echo Setup stopped. Read the error above.
pause
exit /b 1
