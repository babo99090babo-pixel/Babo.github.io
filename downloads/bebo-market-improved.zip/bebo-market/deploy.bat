@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto missing
if exist node_modules\firebase-tools\lib\bin\firebase.js goto deploy
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed
:deploy
call npm run deploy
if errorlevel 1 goto failed
pause
exit /b 0
:missing
echo Install Node.js LTS, then reopen this file.
pause
exit /b 1
:failed
echo Publishing stopped. Read the error above.
pause
exit /b 1
