// Shared, side-effect-free storefront validation. Persist only product IDs and quantities.
export const MAX_DISTINCT_ITEMS = 10;
export const MAX_QUANTITY = 99;
export const CONTACT = Object.freeze({
  phone: '+249991974489',
  whatsappNumber: '249991974489',
  facebookUrl: 'https://www.facebook.com/Babo0Nasir',
});
export const CATEGORY_NAMES = Object.freeze({
  restaurants: 'مطاعم', grocery: 'بقالات', pharmacy: 'صيدليات',
  butcher: 'ملاحم', vegetables: 'خضار وفواكه', other: 'أخرى',
});

const plainObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value, limit = 300) => typeof value === 'string' ? value.trim().slice(0, limit) : '';
const validId = value => (Number.isSafeInteger(value) && value > 0)
  || (typeof value === 'string' && /^[A-Za-z0-9-]{1,64}$/.test(value));
const money = value => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value <= 1000000000;
export const itemKey = item => `${String(item.storeId)}:${String(item.productId)}`;

export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[char]));
}

export function normalizeText(value) {
  return String(value ?? '').toLocaleLowerCase('ar').normalize('NFKC')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').trim();
}

export function normalizeSudanPhone(value) {
  let normalized = String(value ?? '').trim()
    .replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
    .replace(/[\s()-]/g, '');
  if (/^09\d{8}$/.test(normalized)) normalized = `+249${normalized.slice(1)}`;
  else if (/^2499\d{8}$/.test(normalized)) normalized = `+${normalized}`;
  else if (/^002499\d{8}$/.test(normalized)) normalized = `+${normalized.slice(2)}`;
  return /^\+2499\d{8}$/.test(normalized) ? normalized : null;
}

export function validateCustomer(input = {}) {
  const name = typeof input.name === 'string' ? input.name.trim() : '';
  const address = typeof input.address === 'string' ? input.address.trim() : '';
  const notes = typeof input.notes === 'string' ? input.notes.trim() : '';
  const phone = normalizeSudanPhone(input.phone);
  const errors = {};
  if (name.length < 2 || name.length > 100) errors.name = 'اكتب اسمًا من حرفين إلى 100 حرف.';
  if (!phone) errors.phone = 'اكتب رقم موبايل سوداني صحيحًا، مثل 0991974489.';
  if (address.length < 5 || address.length > 300) errors.address = 'اكتب الحي والعنوان بوضوح، من 5 إلى 300 حرف.';
  if (notes.length > 1000) errors.notes = 'الملاحظات لا تزيد عن 1000 حرف.';
  return {customer: {name, phone: phone || '', address}, notes, errors, valid: Object.keys(errors).length === 0};
}

export function sanitizeCatalog(input) {
  const source = plainObject(input) ? input : {};
  const settings = plainObject(source.settings) ? source.settings : {};
  const stores = [];
  const storeIds = new Set();
  let totalProducts = 0;
  for (const row of (Array.isArray(source.stores) ? source.stores : []).slice(0, 100)) {
    if (!plainObject(row) || !validId(row.id) || storeIds.has(String(row.id))) continue;
    storeIds.add(String(row.id));
    const products = [];
    const productIds = new Set();
    for (const product of (Array.isArray(row.products) ? row.products : []).slice(0, 200)) {
      if (totalProducts >= 1000) break;
      if (!plainObject(product) || !validId(product.id) || !money(product.price) || productIds.has(String(product.id))) continue;
      productIds.add(String(product.id));
      products.push({id: product.id, name: text(product.name, 150) || 'منتج', price: product.price,
        emoji: text(product.emoji, 16), available: product.available !== false, enabled: product.enabled !== false});
      totalProducts += 1;
    }
    stores.push({id: row.id, name: text(row.name, 150) || 'متجر', description: text(row.description, 500),
      category: Object.hasOwn(CATEGORY_NAMES, row.category) ? row.category : 'other', icon: text(row.icon, 16),
      deliveryTime: text(row.deliveryTime, 80), isOpen: row.isOpen === true,
      enabled: row.enabled !== false, products});
  }
  const phone = normalizeSudanPhone(settings.phone) || CONTACT.phone;
  const whatsappPhone = normalizeSudanPhone(settings.whatsappNumber) || phone;
  let facebookUrl = CONTACT.facebookUrl;
  try {
    const url = new URL(settings.facebookUrl);
    if (url.protocol === 'https:' && ['facebook.com', 'www.facebook.com', 'm.facebook.com'].includes(url.hostname)
      && !url.port && !url.username && !url.password) {
      if (url.hostname === 'm.facebook.com') url.hostname = 'www.facebook.com';
      facebookUrl = url.href;
    }
  } catch { /* Keep the approved default if the stored URL is invalid. */ }
  return {
    version: Number.isSafeInteger(source.version) && source.version > 0 ? source.version : 1,
    settings: {
      siteName: text(settings.siteName, 100) || 'ببو ماركت', city: text(settings.city, 100) || 'دنقلا، السودان',
      phone, whatsappNumber: whatsappPhone.slice(1), facebookUrl,
      deliveryFee: money(settings.deliveryFee) ? settings.deliveryFee : 500,
      currency: text(settings.currency, 20) || 'جنيه', demoMode: settings.demoMode !== false,
      deliveryNote: text(settings.deliveryNote, 500) || 'نؤكد رسوم التوصيل حسب الحي قبل تنفيذ الطلب.',
      availabilityNote: text(settings.availabilityNote, 500) || 'الطلب قيد المراجعة؛ نؤكد التوفّر والأسعار ووقت التوصيل معك.',
    },
    stores,
    source: ['firebase', 'demo', 'offline'].includes(source.source) ? source.source : 'demo',
    configured: source.configured === true,
  };
}

function cleanCart(items) {
  if (!Array.isArray(items)) return [];
  const result = [];
  const byKey = new Map();
  for (const item of items.slice(0, 500)) {
    if (!plainObject(item) || !validId(item.storeId) || !validId(item.productId)
      || !Number.isInteger(item.qty) || item.qty < 1 || item.qty > MAX_QUANTITY) continue;
    const key = itemKey(item);
    if (byKey.has(key)) byKey.get(key).qty = Math.min(MAX_QUANTITY, byKey.get(key).qty + item.qty);
    else if (result.length < MAX_DISTINCT_ITEMS) {
      const clean = {storeId: item.storeId, productId: item.productId, qty: item.qty};
      result.push(clean);
      byKey.set(key, clean);
    }
  }
  return result;
}

export function parseCart(raw) {
  if (typeof raw !== 'string' || raw.length > 100000) return [];
  try {
    const value = JSON.parse(raw);
    if (Array.isArray(value)) return cleanCart(value); // Original site's cart format.
    return plainObject(value) && value.version === 1 ? cleanCart(value.items) : [];
  } catch {
    return [];
  }
}

export function serializeCart(items) {
  return JSON.stringify({version: 1, items: cleanCart(items)});
}

export function reconcileCart(items, catalog) {
  const changes = [];
  const result = [];
  for (const item of cleanCart(items)) {
    const previous = items.find(row => plainObject(row) && itemKey(row) === itemKey(item));
    const store = catalog.stores.find(row => String(row.id) === String(item.storeId));
    const product = store?.products.find(row => String(row.id) === String(item.productId));
    if (!store || !store.enabled || !store.isOpen || !product || !product.enabled || !product.available) {
      changes.push({type: 'unavailable', storeId: item.storeId, productId: item.productId});
      continue;
    }
    result.push({storeId: store.id, productId: product.id, qty: item.qty,
      name: product.name, storeName: store.name, emoji: product.emoji, price: product.price});
    if (typeof previous?.price === 'number' && previous.price !== product.price) changes.push({type: 'price', productId: item.productId});
  }
  return {items: result, changes};
}

export function resolveSavedCart(items, catalog) {
  // Bundled examples and offline caches cannot establish that a saved live ID
  // has disappeared. Hold its ID/quantity until the live catalog can verify it.
  if (catalog.source !== 'firebase') return {items: [], unresolved: cleanCart(items), changes: []};
  return {...reconcileCart(items, catalog), unresolved: []};
}

export function addCartItems(items, additions) {
  const result = cleanCart(items);
  if (!Array.isArray(additions)) return {items: result, error: 'invalid-items'};
  const additionKeys = new Set(additions.filter(item => plainObject(item) && validId(item.storeId) && validId(item.productId)).map(itemKey));
  if (additionKeys.size > MAX_DISTINCT_ITEMS) return {items: result, error: 'item-limit'};
  for (const item of cleanCart(additions)) {
    const existing = result.find(row => itemKey(row) === itemKey(item));
    if (existing) {
      if (existing.qty + item.qty > MAX_QUANTITY) return {items: cleanCart(items), error: 'quantity-limit'};
      existing.qty += item.qty;
    } else {
      if (result.length >= MAX_DISTINCT_ITEMS) return {items: cleanCart(items), error: 'item-limit'};
      result.push({...item});
    }
  }
  return {items: result, error: null};
}

export function filterCatalog(stores, category = 'all', query = '') {
  const needle = normalizeText(query);
  return stores.filter(store => store.enabled !== false
    && (category === 'all' || store.category === category)
    && (!needle || normalizeText([store.name, store.description,
      ...store.products.filter(product => product.enabled !== false).map(product => product.name)].join(' ')).includes(needle)));
}

export function cartSummary(items, deliveryFee = 0) {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.qty, 0);
  const fee = items.length && money(deliveryFee) ? deliveryFee : 0;
  return {subtotal, deliveryFee: fee, total: subtotal + fee, count: items.reduce((sum, item) => sum + item.qty, 0)};
}

export function safeWhatsAppUrl(value, expectedNumber = CONTACT.whatsappNumber) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === 'wa.me' && !url.port && !url.username && !url.password
      && /^2499\d{8}$/.test(expectedNumber) && url.pathname === `/${expectedNumber}` ? url.href : null;
  } catch {
    return null;
  }
}
