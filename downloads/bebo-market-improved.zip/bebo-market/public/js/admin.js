import {
  isConfigured, watchAuth, watchAdminAccess, signInEmail, signInGoogle, registerEmail,
  sendVerification, reloadUser, resetPassword, signOutUser, checkAdmin,
  getCatalog, getOrders, saveCatalog, changeOrderStatus, exportBackup
} from './backend.js';

const $ = id => document.getElementById(id);
const clone = value => JSON.parse(JSON.stringify(value));
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const statusLabels = { pending: 'جديد', confirmed: 'تم التأكيد', delivering: 'قيد التوصيل', completed: 'مكتمل', cancelled: 'ملغي' };
const pageLabels = { dashboard: 'نظرة عامة', orders: 'الطلبات', stores: 'المتاجر والمنتجات', settings: 'إعدادات الموقع' };
const categoryLabels = { restaurants: 'مطاعم', grocery: 'بقالات', pharmacy: 'صيدليات', butcher: 'ملاحم', vegetables: 'خضار وفواكه', other: 'أخرى' };
const numberFormat = new Intl.NumberFormat('ar-SD', { maximumFractionDigits: 2 });
const dateFormat = new Intl.DateTimeFormat('ar-SD', { dateStyle: 'medium', timeStyle: 'short' });
const state = { user: null, isAdmin: false, catalog: null, orders: null, page: 'dashboard', storeDraft: null, previewDirty: false, mutation: false };
let sessionVersion = 0;
let accessVersion = 0;
let stopAccessWatch = () => {};
let noticeTimer;
let loadingVersion = 0;

function notify(message, error = false) {
  clearTimeout(noticeTimer);
  $('notice').textContent = message;
  $('notice').classList.toggle('error', error);
  $('notice').hidden = false;
  noticeTimer = setTimeout(() => { $('notice').hidden = true; }, error ? 12000 : 7000);
}

function errorMessage(error) { return error?.message || 'تعذّر إتمام العملية. تحقق من الاتصال وحاول مجددًا.'; }
function money(amount) { return `${numberFormat.format(Number.isFinite(Number(amount)) ? Number(amount) : 0)} ${state.catalog?.settings?.currency || 'جنيه'}`; }
function date(value) { const parsed = value ? new Date(value) : null; return parsed && Number.isFinite(parsed.getTime()) ? dateFormat.format(parsed) : 'الوقت غير متاح'; }
function safePhone(value) {
  const digits = String(value || '').replace(/[٠-٩]/g, character => String(character.charCodeAt(0) - 1632)).replace(/[۰-۹]/g, character => String(character.charCodeAt(0) - 1776)).replace(/[^0-9]/g, '').replace(/^00/, '');
  return /^[1-9]\d{7,14}$/.test(digits) ? digits : '';
}
function empty(message) { return `<div class="empty-state"><p>${escapeHTML(message)}</p></div>`; }
function badge(status) { const known = Object.hasOwn(statusLabels, status); return `<span class="badge ${known ? status : ''}">${escapeHTML(known ? statusLabels[status] : 'حالة غير معروفة')}</span>`; }

async function run(button, operation) {
  if (button?.disabled) return;
  if (button) button.disabled = true;
  try { await operation(); } catch (error) { notify(errorMessage(error), true); }
  finally { if (button) button.disabled = false; }
}

function showGate(mode, user = null) {
  $('admin-shell').hidden = true;
  $('access-screen').hidden = false;
  for (const panel of ['config-help', 'login-panel', 'verification-panel', 'denied-panel']) $(panel).hidden = true;
  $('gate-signout').hidden = !user || user.isAnonymous;
  const titles = { loading: 'جارٍ التحقق من الدخول…', config: 'يلزم ربط Firebase أولًا', login: 'مرحبًا، سجّل الدخول', verify: 'تحقّق من بريدك الإلكتروني', denied: 'هذا الحساب لا يملك صلاحية الإدارة', error: 'تعذّر التحقق من الصلاحية' };
  $('access-title').textContent = titles[mode] || titles.error;
  $('access-description').textContent = user?.email ? user.email : 'تُعرض بيانات الطلبات بعد التأكد من حسابك وصلاحيتك.';
  $('access-description').dir = user?.email ? 'ltr' : 'rtl';
  $('denied-description').textContent = mode === 'error' ? 'تعذّر الاتصال للتحقق من صلاحيتك. راجع الإنترنت وإعدادات Firebase، ثم أعد المحاولة.' : 'هذا الحساب غير مدرج في قائمة الإداريين، أو تعذّر تأكيد الصلاحية الآن. يضيف مالك المشروع البريد الموثّق إلى adminAccess/roster من Firebase Console. يمكنك إعادة التحقق.';
  const panel = { config: 'config-help', login: 'login-panel', verify: 'verification-panel', denied: 'denied-panel', error: 'denied-panel' }[mode];
  if (panel) $(panel).hidden = false;
}

function clearPrivateData() {
  accessVersion += 1;
  state.isAdmin = false;
  state.catalog = null;
  state.orders = null;
  state.storeDraft = null;
  state.previewDirty = false;
  state.mutation = false;
  for (const id of ['stats', 'recent-orders', 'orders-list', 'stores-list', 'order-details', 'product-editor', 'account-email', 'orders-count', 'data-status']) $(id).replaceChildren();
  $('order-search').value = '';
  $('order-status-filter').value = 'all';
  $('settings-form').reset();
  $('store-form').reset();
  $('catalog-banner').hidden = true;
  $('login-password').value = '';
  for (const dialog of document.querySelectorAll('dialog[open]')) dialog.close();
}

async function handleAuth(user) {
  const token = ++sessionVersion;
  stopAccessWatch();
  stopAccessWatch = () => {};
  state.user = user;
  clearPrivateData();
  showGate('loading', user);
  if (!user || user.isAnonymous) { showGate('login'); return; }
  if (!user.emailVerified) { showGate('verify', user); return; }
  try {
    const role = await checkAdmin();
    if (token !== sessionVersion) return;
    if (!role.isAdmin) { showGate('denied', user); return; }
    const unsubscribe = await watchAdminAccess(access => {
      if (token !== sessionVersion) return;
      if (!access.isAdmin || access.user?.uid !== user.uid) {
        clearPrivateData();
        showGate('denied', user);
        return;
      }
      if (state.isAdmin) return;
      state.isAdmin = true;
      $('account-email').textContent = user.email || '';
      $('access-screen').hidden = true;
      $('admin-shell').hidden = false;
      selectPage('dashboard', false);
      renderOrders();
      renderDashboard();
      loadData().catch(error => { if (token === sessionVersion) notify(errorMessage(error), true); });
    });
    if (token !== sessionVersion) unsubscribe(); else stopAccessWatch = unsubscribe;
  } catch (error) {
    if (token !== sessionVersion) return;
    showGate('error', user);
    notify(errorMessage(error), true);
  }
}

function selectPage(page, focus = true) {
  if (!state.isAdmin || !Object.hasOwn(pageLabels, page)) return;
  state.page = page;
  for (const section of document.querySelectorAll('.page')) section.hidden = section.id !== `page-${page}`;
  for (const button of document.querySelectorAll('[data-page]')) {
    const selected = button.dataset.page === page;
    button.classList.toggle('active', selected);
    if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
  }
  $('page-title').textContent = pageLabels[page];
  if (focus) $('main-content').focus();
}

async function loadData() {
  if (!state.isAdmin) return;
  const token = accessVersion;
  const request = ++loadingVersion;
  $('data-status').textContent = 'جارٍ جلب البيانات المحفوظة…';
  $('data-status').classList.remove('error');
  const results = await Promise.allSettled([getCatalog({ fresh: true }), getOrders()]);
  if (token !== accessVersion || request !== loadingVersion || !state.isAdmin) return;
  const messages = [];
  if (results[0].status === 'fulfilled') {
    state.catalog = results[0].value;
    state.previewDirty = false;
    if (state.catalog.source === 'offline') messages.push('تعذّر الوصول إلى الكتالوج المنشور. المعروض نسخة احتياطية للقراءة فقط؛ أعد التحديث قبل التعديل.');
  } else { state.catalog = null; messages.push(errorMessage(results[0].reason)); }
  if (results[1].status === 'fulfilled') state.orders = results[1].value;
  else { state.orders = null; messages.push(`لم تُحمّل الطلبات: ${errorMessage(results[1].reason)}`); }
  renderCatalog();
  renderOrders();
  renderDashboard();
  $('data-status').textContent = messages.length ? messages.join(' ') : `آخر تحديث: ${date(new Date().toISOString())}`;
  $('data-status').classList.toggle('error', messages.length > 0);
}

function renderDashboard() {
  if (!state.isAdmin) return;
  const orders = state.orders;
  const stats = [
    ['إجمالي الطلبات المحمّلة', orders?.length],
    ['طلبات جديدة', orders?.filter(order => order.status === 'pending').length],
    ['طلبات قيد التوصيل', orders?.filter(order => order.status === 'delivering').length],
    ['إيراد الطلبات المكتملة', orders ? money(orders.filter(order => order.status === 'completed').reduce((sum, order) => sum + (Number(order.total) || 0), 0)) : null]
  ];
  $('stats').innerHTML = stats.map(([label, value], index) => `<article class="stat-card${index === 3 ? ' revenue' : ''}"><span>${label}</span><strong>${value == null ? '—' : escapeHTML(typeof value === 'number' ? numberFormat.format(value) : value)}</strong></article>`).join('');
  if (!orders) { $('recent-orders').innerHTML = empty('لم تُحمّل الطلبات بعد. استخدم تحديث البيانات.'); return; }
  $('recent-orders').innerHTML = orders.length ? orders.slice(0, 5).map(order => `<div class="recent-row"><div><strong>${escapeHTML(order.customer?.name || 'عميل')}</strong><small>${escapeHTML(date(order.createdAt))} · ${escapeHTML(money(order.total))}</small></div><div>${badge(order.status)} <button class="text-button" data-view-order="${escapeHTML(order.id)}" type="button">عرض</button></div></div>`).join('') : empty('لا توجد طلبات محفوظة حتى الآن.');
}

function renderOrders() {
  if (!state.isAdmin) return;
  if (!state.orders) { $('orders-list').innerHTML = empty('تعذّر تحميل الطلبات أو لم يكتمل التحميل. حدّث البيانات للمحاولة.'); $('orders-count').textContent = ''; return; }
  const search = $('order-search').value.trim().toLocaleLowerCase('ar');
  const filter = $('order-status-filter').value;
  const orders = state.orders.filter(order => (filter === 'all' || order.status === filter) && `${order.id} ${order.customer?.name} ${order.customer?.phone}`.toLocaleLowerCase('ar').includes(search));
  $('orders-count').textContent = `عرض ${numberFormat.format(orders.length)} من ${numberFormat.format(state.orders.length)} طلب محمّل`;
  $('orders-list').innerHTML = orders.length ? orders.map(order => {
    const id = escapeHTML(order.id);
    return `<article class="order-card"><div class="order-top"><p class="order-id"><bdi>${id}</bdi></p>${badge(order.status)}</div><p class="order-customer"><strong>${escapeHTML(order.customer?.name)}</strong> · <bdi>${escapeHTML(order.customer?.phone)}</bdi></p><p class="small muted">${escapeHTML(date(order.createdAt))} · ${numberFormat.format((order.items || []).length)} منتجات</p><div class="order-bottom"><span class="order-total">${escapeHTML(money(order.total))}</span><div class="order-actions"><button class="button secondary" data-view-order="${id}" type="button">التفاصيل</button><select data-order-status="${id}" aria-label="حالة الطلب ${id}">${Object.entries(statusLabels).map(([key, value]) => `<option value="${key}"${order.status === key ? ' selected' : ''}>${value}</option>`).join('')}</select><button class="button primary" data-save-status="${id}" type="button">حفظ الحالة</button></div></div></article>`;
  }).join('') : empty(state.orders.length ? 'لا توجد طلبات تطابق البحث أو الحالة المختارة.' : 'لا توجد طلبات محفوظة حتى الآن.');
}

function showOrder(id) {
  if (!state.isAdmin) return;
  const order = state.orders?.find(item => item.id === id);
  if (!order) return;
  const phone = safePhone(order.customer?.phone);
  $('order-dialog-title').textContent = 'تفاصيل الطلب';
  $('order-details').innerHTML = `<p class="order-id"><bdi>${escapeHTML(order.id)}</bdi></p>${badge(order.status)}<dl class="detail-grid"><dt>العميل</dt><dd>${escapeHTML(order.customer?.name)}</dd><dt>الهاتف</dt><dd><bdi>${escapeHTML(order.customer?.phone)}</bdi></dd><dt>العنوان</dt><dd class="notes">${escapeHTML(order.customer?.address)}</dd><dt>التاريخ</dt><dd>${escapeHTML(date(order.createdAt))}</dd></dl>${phone ? `<div class="button-row"><a class="button secondary" href="tel:+${phone}">اتصال بالعميل</a><a class="button secondary" href="https://wa.me/${phone}" target="_blank" rel="noopener noreferrer">فتح واتساب ↗</a></div>` : ''}<h3>المنتجات</h3><ul class="detail-items">${(order.items || []).map(item => `<li><div>${escapeHTML(item.emoji)} ${escapeHTML(item.name)}<small>${escapeHTML(item.storeName)} · ${numberFormat.format(item.qty)} × ${escapeHTML(money(item.unitPrice))}</small></div><strong>${escapeHTML(money(item.qty * item.unitPrice))}</strong></li>`).join('')}</ul><div class="totals"><p><span>المنتجات</span><span>${escapeHTML(money(order.subtotal))}</span></p><p><span>التوصيل الأساسي</span><span>${escapeHTML(money(order.deliveryFee))}</span></p><p class="grand-total"><span>الإجمالي المسجل</span><span>${escapeHTML(money(order.total))}</span></p></div>${order.notes ? `<h3>ملاحظات العميل</h3><p class="notes">${escapeHTML(order.notes)}</p>` : ''}<p class="small muted">أكد التوفّر والسعر ورسوم التوصيل مع العميل قبل التنفيذ.</p>`;
  $('order-dialog').showModal();
}

function renderCatalog() {
  if (!state.isAdmin) return;
  const catalog = state.catalog;
  $('add-store').disabled = !catalog || catalog.source === 'offline';
  $('save-settings').disabled = !catalog || catalog.source === 'offline';
  $('catalog-banner').hidden = !catalog || (catalog.source === 'firebase' && !catalog.settings.demoMode);
  $('publish-catalog').hidden = catalog?.source !== 'demo';
  if (catalog) {
    const preview = catalog.source === 'demo';
    $('catalog-banner-title').textContent = catalog.source === 'offline' ? 'نسخة للقراءة فقط بسبب تعذّر الاتصال' : preview ? 'الكتالوج الأولي لم يُنشر بعد' : 'وضع المعاينة مفعّل';
    $('catalog-banner-description').textContent = catalog.source === 'offline' ? 'لا تعدّل هذه النسخة. أعد تحديث البيانات لاسترجاع النسخة المحفوظة قبل الحفظ.' : preview ? `المتاجر والأسعار الحالية أمثلة للتجهيز. عدّلها ثم انشر الكتالوج الأولي؛ التعديلات قبل النشر تبقى في هذه الجلسة فقط.${state.previewDirty ? ' لديك تغييرات لم تُنشر.' : ''} يبقى استقبال الطلبات متوقفًا ما دام وضع المعاينة مفعّلًا.` : 'الكتالوج محفوظ، لكن استقبال الطلبات متوقف. راجع بيانات المتاجر والأسعار، ثم ألغِ وضع المعاينة من الإعدادات عندما تصبح جاهزًا.';
  }
  renderStores();
  fillSettings();
}

function renderStores() {
  const catalog = state.catalog;
  if (!catalog) { $('stores-list').innerHTML = empty('لم يُحمّل الكتالوج. حدّث البيانات للمحاولة.'); return; }
  const disabled = catalog.source === 'offline' ? ' disabled' : '';
  $('stores-list').innerHTML = catalog.stores.length ? catalog.stores.map(store => `<article class="store-card"><h2><span class="store-icon" aria-hidden="true">${escapeHTML(store.icon)}</span>${escapeHTML(store.name)}</h2><p class="store-description">${escapeHTML(store.description || 'لا يوجد وصف بعد.')}</p><div class="store-meta"><span class="badge ${store.isOpen ? 'open' : 'closed'}">${store.isOpen ? 'متاح' : 'مغلق'}</span><span>${escapeHTML(categoryLabels[store.category] || store.category)}</span><span>${numberFormat.format(store.products?.length || 0)} منتج</span></div><div class="button-row"><button class="button secondary" data-edit-store="${escapeHTML(store.id)}" type="button"${disabled}>تعديل المنتجات والمتجر</button><button class="button danger" data-delete-store="${escapeHTML(store.id)}" type="button"${disabled}>حذف</button></div></article>`).join('') : empty('لا توجد متاجر في الكتالوج. أضف أول متجر ومنتجاته.');
}

function fillSettings() {
  const settings = state.catalog?.settings;
  if (!settings) { $('settings-form').reset(); return; }
  for (const [key, value] of Object.entries(settings)) {
    const input = $('settings-form').elements.namedItem(key);
    if (!input) continue;
    if (input.type === 'checkbox') input.checked = value === true; else input.value = value ?? '';
  }
  $('save-settings').textContent = state.catalog.source === 'demo' ? 'حفظ الإعدادات في المعاينة' : 'حفظ الإعدادات';
}

function editable() {
  if (!state.isAdmin || !state.catalog) throw new Error('سجّل الدخول وحمّل الكتالوج أولًا.');
  if (state.catalog.source === 'offline') throw new Error('هذه نسخة للقراءة فقط. حدّث البيانات لاسترجاع الكتالوج المنشور قبل التعديل.');
  if (state.mutation) throw new Error('انتظر اكتمال الحفظ الحالي.');
}

async function commitCatalog(next, message) {
  editable();
  const token = accessVersion;
  if (state.catalog.source === 'demo') {
    state.catalog = { ...next, source: 'demo', configured: true };
    state.previewDirty = true;
    renderCatalog();
    notify('حُفظ التعديل في معاينة هذه الجلسة. اضغط «نشر الكتالوج الأولي» لحفظه في Firebase.');
    return;
  }
  state.mutation = true;
  try {
    const saved = await saveCatalog(next, state.catalog.version);
    if (token !== accessVersion || !state.isAdmin) return;
    state.catalog = saved;
    renderCatalog();
    notify(message);
  } finally { if (token === accessVersion) state.mutation = false; }
}

function nextNumericId(values) {
  const existing = new Set(values.map(String));
  const numbers = values.map(value => Number(value)).filter(value => Number.isSafeInteger(value) && value > 0);
  let next = Math.max(0, ...numbers) + 1;
  if (!Number.isSafeInteger(next)) throw new Error('تعذّر توليد معرّف جديد؛ راجع معرّفات الكتالوج.');
  while (existing.has(String(next))) next += 1;
  return next;
}

function showStore(id = null) {
  try { editable(); } catch (error) { notify(errorMessage(error), true); return; }
  if (id == null && state.catalog.stores.length >= 100) { notify('الحد الأقصى 100 متجر في الكتالوج.', true); return; }
  const original = id == null ? null : state.catalog.stores.find(store => String(store.id) === String(id));
  if (id != null && !original) return;
  state.storeDraft = original ? clone(original) : { id: nextNumericId(state.catalog.stores.map(store => store.id)), name: '', category: 'restaurants', icon: '🛍️', description: '', deliveryTime: '', isOpen: true, products: [] };
  const form = $('store-form');
  form.reset();
  for (const [key, value] of Object.entries(state.storeDraft)) {
    const input = form.elements.namedItem(key);
    if (!input) continue;
    if (input.type === 'checkbox') input.checked = value === true; else input.value = value;
  }
  $('store-dialog-title').textContent = original ? 'تعديل المتجر ومنتجاته' : 'إضافة متجر';
  $('store-form-error').hidden = true;
  renderProductEditor();
  $('store-dialog').showModal();
  $('store-name').focus();
}

function renderProductEditor() {
  if (!state.storeDraft) return;
  $('product-editor').innerHTML = state.storeDraft.products.length ? state.storeDraft.products.map((product, index) => `<fieldset class="product-row" data-product-index="${index}"><legend class="small">المنتج ${numberFormat.format(index + 1)}</legend><div class="product-fields"><div class="field"><label for="product-name-${index}">اسم المنتج</label><input id="product-name-${index}" data-product-field="name" value="${escapeHTML(product.name)}" required maxlength="150"></div><div class="field"><label for="product-price-${index}">السعر</label><input id="product-price-${index}" data-product-field="price" type="number" min="0" max="1000000000" step="1" value="${escapeHTML(product.price)}" required></div><div class="field"><label for="product-emoji-${index}">الرمز</label><input id="product-emoji-${index}" data-product-field="emoji" value="${escapeHTML(product.emoji)}" maxlength="20"></div></div><div class="product-bottom"><label class="checkbox-row" for="product-available-${index}"><input id="product-available-${index}" data-product-field="available" type="checkbox"${product.available !== false ? ' checked' : ''}><span>متاح</span></label><button class="text-button" data-remove-product="${index}" type="button">حذف المنتج</button></div></fieldset>`).join('') : empty('لا توجد منتجات بعد. استخدم «إضافة منتج».');
}

function collectProducts() {
  if (!state.storeDraft) return;
  for (const row of $('product-editor').querySelectorAll('[data-product-index]')) {
    const product = state.storeDraft.products[Number(row.dataset.productIndex)];
    if (!product) continue;
    for (const input of row.querySelectorAll('[data-product-field]')) {
      const key = input.dataset.productField;
      product[key] = key === 'available' ? input.checked : key === 'price' ? Number(input.value) : input.value.trim();
    }
  }
}

async function saveStore(event) {
  event.preventDefault();
  await run($('save-store'), async () => {
    editable();
    if (!state.storeDraft) return;
    collectProducts();
    const form = new FormData($('store-form'));
    const store = { ...state.storeDraft, name: String(form.get('name')).trim(), category: String(form.get('category')), icon: String(form.get('icon')).trim() || '🛍️', description: String(form.get('description')).trim(), deliveryTime: String(form.get('deliveryTime')).trim(), isOpen: form.has('isOpen') };
    if (!store.name || store.products.some(product => !product.name || !Number.isSafeInteger(product.price) || product.price < 0 || product.price > 1000000000)) throw new Error('راجع اسم المتجر وأسماء المنتجات، وأدخل الأسعار أعدادًا صحيحة من صفر إلى مليار.');
    const next = clone(state.catalog);
    const index = next.stores.findIndex(item => String(item.id) === String(store.id));
    if (index < 0) next.stores.push(store); else next.stores[index] = store;
    const token = accessVersion;
    try {
      await commitCatalog(next, 'حُفظ المتجر ومنتجاته في الكتالوج.');
      if (token === accessVersion && state.isAdmin) $('store-dialog').close();
    } catch (error) {
      if (token === accessVersion && state.isAdmin) {
        $('store-form-error').textContent = errorMessage(error);
        $('store-form-error').hidden = false;
      }
      throw error;
    }
  });
}

async function deleteStore(button) {
  await run(button, async () => {
    editable();
    const store = state.catalog.stores.find(item => String(item.id) === button.dataset.deleteStore);
    if (!store || !window.confirm(`حذف «${store.name}» وجميع منتجاته من الكتالوج؟ ستبقى الطلبات السابقة محفوظة.`)) return;
    const next = clone(state.catalog);
    next.stores = next.stores.filter(item => String(item.id) !== String(store.id));
    await commitCatalog(next, 'حُذف المتجر من الكتالوج.');
  });
}

async function saveSettings(event) {
  event.preventDefault();
  await run($('save-settings'), async () => {
    editable();
    const form = new FormData($('settings-form'));
    const next = clone(state.catalog);
    for (const key of ['siteName', 'city', 'phone', 'facebookUrl', 'currency', 'deliveryNote', 'availabilityNote']) next.settings[key] = String(form.get(key) || '').trim();
    next.settings.phone = `+${safePhone(next.settings.phone)}`;
    next.settings.whatsappNumber = safePhone(form.get('whatsappNumber'));
    if (next.settings.phone === '+' || !next.settings.whatsappNumber) throw new Error('أدخل رقم الهاتف وواتساب مع مفتاح البلد، مثل +249991974489.');
    if (!/^https:\/\/(www\.)?facebook\.com\/[^\s]+$/i.test(next.settings.facebookUrl)) throw new Error('أدخل رابط Facebook صحيحًا يبدأ بـ https://www.facebook.com/');
    next.settings.deliveryFee = Number(form.get('deliveryFee'));
    if (!Number.isSafeInteger(next.settings.deliveryFee) || next.settings.deliveryFee < 0 || next.settings.deliveryFee > 1000000000) throw new Error('أدخل رسوم توصيل صحيحة من صفر إلى مليار.');
    next.settings.demoMode = form.has('demoMode');
    if (state.catalog.settings.demoMode && !next.settings.demoMode && !window.confirm('هل راجعت أسماء المتاجر والمنتجات والأسعار وبيانات التواصل وأصبحت حقيقية؟ إيقاف المعاينة يتيح للعملاء إرسال الطلبات بعد الحفظ.')) return;
    await commitCatalog(next, 'حُفظت إعدادات الموقع.');
    renderDashboard();
    renderOrders();
  });
}

async function publishInitialCatalog() {
  await run($('publish-catalog'), async () => {
    editable();
    if (state.catalog.source !== 'demo') return;
    if (!window.confirm('سيُحفظ الكتالوج الحالي وإعداداته في Firebase. راجع البيانات النموذجية أولًا. يبقى استقبال الطلبات متوقفًا إذا كان وضع المعاينة مفعّلًا. هل تريد نشر الكتالوج الأولي؟')) return;
    const token = accessVersion;
    state.mutation = true;
    try {
      const saved = await saveCatalog(state.catalog, 0);
      if (token !== accessVersion || !state.isAdmin) return;
      state.catalog = saved;
      state.previewDirty = false;
      renderCatalog();
      notify('نُشر الكتالوج الأولي وحُفظ في Firebase.');
    } finally { if (token === accessVersion) state.mutation = false; }
  });
}

async function updateOrderStatus(button) {
  await run(button, async () => {
    if (!state.isAdmin) return;
    const id = button.dataset.saveStatus;
    const order = state.orders?.find(item => item.id === id);
    const select = [...document.querySelectorAll('[data-order-status]')].find(item => item.dataset.orderStatus === id);
    if (!order || !select || !Object.hasOwn(statusLabels, select.value)) return;
    const status = select.value;
    if (status === order.status) { notify('حالة الطلب محفوظة بالفعل.'); return; }
    if (status === 'cancelled' && !window.confirm('تأكيد إلغاء هذا الطلب؟ تواصل مع العميل لتوضيح الإلغاء.')) return;
    const token = accessVersion;
    await changeOrderStatus(id, status);
    if (token !== accessVersion || !state.isAdmin) return;
    order.status = status;
    renderOrders();
    renderDashboard();
    notify('حُفظت حالة الطلب.');
  });
}

async function downloadBackup() {
  await run($('export-backup'), async () => {
    if (!state.isAdmin) return;
    const token = accessVersion;
    const backup = await exportBackup();
    if (token !== accessVersion || !state.isAdmin) return;
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bebo-market-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    notify('جُهّزت النسخة للتنزيل. احفظ الملف في مكان خاص لأنه يتضمن بيانات العملاء.');
  });
}

function bindEvents() {
  $('login-form').addEventListener('submit', event => {
    event.preventDefault();
    run(event.submitter, async () => { await signInEmail($('login-email').value, $('login-password').value); $('login-password').value = ''; });
  });
  $('google-login').addEventListener('click', event => run(event.currentTarget, signInGoogle));
  $('register-account').addEventListener('click', event => run(event.currentTarget, async () => {
    if (!$('login-email').reportValidity() || !$('login-password').reportValidity()) return;
    if ($('login-password').value.length < 8) throw new Error('اختر كلمة مرور خاصة بالموقع لا تقل عن 8 أحرف.');
    await registerEmail($('login-email').value, $('login-password').value);
    $('login-password').value = '';
    notify('أُنشئ الحساب وأُرسل رابط التحقق إلى بريدك. إنشاء الحساب وحده لا يمنح صلاحية الإدارة.');
  }));
  $('reset-password').addEventListener('click', event => run(event.currentTarget, async () => {
    if (!$('login-email').reportValidity()) return;
    await resetPassword($('login-email').value);
    notify('إذا كان البريد مسجّلًا فستصلك رسالة لتعيين كلمة مرور جديدة.');
  }));
  $('send-verification').addEventListener('click', event => run(event.currentTarget, async () => { await sendVerification(); notify('أُرسل رابط التحقق. راجع بريدك وصندوق الرسائل غير المرغوب فيها.'); }));
  $('reload-user').addEventListener('click', event => run(event.currentTarget, async () => handleAuth(await reloadUser())));
  $('retry-access').addEventListener('click', event => run(event.currentTarget, async () => handleAuth(await reloadUser())));
  for (const id of ['logout', 'gate-signout']) $(id).addEventListener('click', event => run(event.currentTarget, async () => {
    if (state.previewDirty && !window.confirm('لديك تعديلات أولية لم تُنشر. تسجيل الخروج يفقد هذه التعديلات. هل تريد الخروج؟')) return;
    await signOutUser();
  }));
  document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button || button.disabled) return;
    if (button.dataset.page) selectPage(button.dataset.page);
    if (button.dataset.openPage) selectPage(button.dataset.openPage);
    if (button.dataset.closeDialog) $(button.dataset.closeDialog)?.close();
    if (button.dataset.viewOrder) showOrder(button.dataset.viewOrder);
    if (button.dataset.editStore) showStore(button.dataset.editStore);
    if (button.dataset.deleteStore) deleteStore(button);
    if (button.dataset.saveStatus) updateOrderStatus(button);
    if (button.hasAttribute('data-remove-product') && state.storeDraft) {
      collectProducts();
      const index = Number(button.dataset.removeProduct);
      const product = state.storeDraft.products[index];
      if (product && (product.name || product.price) && !window.confirm(`حذف المنتج «${product.name || 'بلا اسم'}» من هذا المتجر؟`)) return;
      state.storeDraft.products.splice(index, 1);
      renderProductEditor();
      $('add-product').focus();
    }
  });
  $('refresh-data').addEventListener('click', event => run(event.currentTarget, async () => {
    if (state.mutation) throw new Error('انتظر اكتمال الحفظ قبل التحديث.');
    if (state.previewDirty && !window.confirm('تحديث البيانات يتجاهل التعديلات الأولية غير المنشورة. هل تريد المتابعة؟')) return;
    await handleAuth(await reloadUser());
  }));
  $('order-search').addEventListener('input', renderOrders);
  $('order-status-filter').addEventListener('change', renderOrders);
  $('add-store').addEventListener('click', () => showStore());
  $('store-form').addEventListener('submit', saveStore);
  $('add-product').addEventListener('click', () => {
    if (!state.isAdmin || !state.storeDraft) return;
    collectProducts();
    if (state.storeDraft.products.length >= 200) { notify('الحد الأقصى 200 منتج لكل متجر.', true); return; }
    const otherProducts = state.catalog.stores.filter(store => String(store.id) !== String(state.storeDraft.id)).reduce((sum, store) => sum + store.products.length, 0);
    if (otherProducts + state.storeDraft.products.length >= 1000) { notify('الحد الأقصى 1000 منتج في الكتالوج كله.', true); return; }
    const ids = [...state.catalog.stores.flatMap(store => store.products.map(product => product.id)), ...state.storeDraft.products.map(product => product.id)];
    state.storeDraft.products.push({ id: nextNumericId(ids), name: '', price: 0, emoji: '🛍️', available: true });
    renderProductEditor();
    $(`product-name-${state.storeDraft.products.length - 1}`).focus();
  });
  $('settings-form').addEventListener('submit', saveSettings);
  $('publish-catalog').addEventListener('click', publishInitialCatalog);
  $('export-backup').addEventListener('click', downloadBackup);
  window.addEventListener('beforeunload', event => { if (state.previewDirty) { event.preventDefault(); event.returnValue = ''; } });
}

bindEvents();
if (!isConfigured()) showGate('config');
else {
  watchAuth(user => { handleAuth(user); }).catch(error => {
    clearPrivateData();
    showGate('config');
    $('config-help').replaceChildren(document.createTextNode(`${errorMessage(error)} راجع إعدادات Firebase واتصال الإنترنت ثم أعد تحميل الصفحة.`));
  });
}
