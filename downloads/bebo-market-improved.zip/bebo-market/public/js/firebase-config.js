/* Public Firebase Web configuration; never put a service-account key here. */
window.BEBO_FIREBASE_CONFIG = {
  "apiKey": "",
  "authDomain": "",
  "projectId": "",
  "appId": ""
};
