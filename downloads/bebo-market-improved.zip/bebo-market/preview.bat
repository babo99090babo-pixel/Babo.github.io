@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto missing
node tools/preview.mjs
pause
exit /b 0
:missing
echo Install Node.js LTS, then reopen this file.
pause
exit /b 1
