import {loadConfig,writeConfigOutputs} from './config-lib.mjs';
const {config,configured}=await loadConfig();
await writeConfigOutputs(config);
console.log(configured ? 'إعداد تطبيق الويب جاهز. نفّذ npm run check قبل النشر.' : 'نسخة معاينة جاهزة. اربط مشروع Firebase مستقلًا قبل استقبال الطلبات.');
