import {readFile,readdir,stat,access} from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {ROOT,loadConfig} from './config-lib.mjs';
const publicRoot=path.join(ROOT,'public');
const files=[];const issues=[];
async function walk(dir) {for(const name of await readdir(dir)){const p=path.join(dir,name);(await stat(p)).isDirectory()?await walk(p):files.push(p);}}
await walk(publicRoot);
for(const file of files){
 const relative=path.relative(publicRoot,file);
 if(/\.(json|html|js|css|svg|txt)$/.test(file)){
  const text=await readFile(file,'utf8');
  if(/BEGIN (?:RSA )?PRIVATE KEY|"private_key"\s*:|"type"\s*:\s*"service_account"/.test(text))issues.push(relative+': private server credentials inside public/');
  if(/249XXXXXXXXX|0XXXXXXXXX/.test(text))issues.push(relative+': placeholder contact number');
  if(file.endsWith('.html')){
   if(!/<html[^>]*lang="ar"[^>]*dir="rtl"/.test(text))issues.push(relative+': missing Arabic/RTL');
   if(!/<meta[^>]*name="viewport"/.test(text))issues.push(relative+': missing viewport');
   if(/\son[a-z]+\s*=/i.test(text))issues.push(relative+': inline script event handler');
   for(const match of text.matchAll(/(?:href|src)="([^"]+)"/g)){
    const url=match[1];if(/^(?:https?:|tel:|mailto:|data:|#)/i.test(url))continue;
    const bare=url.split(/[?#]/)[0];if(!bare)continue;
    const target=path.resolve(path.dirname(file),bare);
    if(!target.startsWith(publicRoot+path.sep))issues.push(relative+': link escapes public/');
    else try{await access(target);}catch{issues.push(relative+': missing '+bare);}
   }
  }
  if(file.endsWith('.js')){const r=spawnSync(process.execPath,['--check',file],{encoding:'utf8'});if(r.status!==0)issues.push(relative+': JavaScript syntax error');}
 }
}
const {configured}=await loadConfig();
const catalog=JSON.parse(await readFile(path.join(publicRoot,'data/default-catalog.json'),'utf8'));
if(catalog.settings.phone!=='+249991974489'||catalog.settings.whatsappNumber!=='249991974489'||catalog.settings.facebookUrl!=='https://www.facebook.com/Babo0Nasir')issues.push('Approved business contacts do not match the default catalog.');
if(!catalog.settings.demoMode)issues.push('The example catalog must stay in demo mode by default.');
const manifest=JSON.parse(await readFile(path.join(publicRoot,'manifest.json'),'utf8'));
for(const icon of manifest.icons){try{await access(path.join(publicRoot,icon.src));}catch{issues.push('Missing install icon '+icon.src);}}
if(issues.length){console.error(issues.join('\n'));process.exitCode=1;}
else{console.log(`فحص ${files.length} ملفًا: الروابط وJavaScript وبيانات التواصل والملفات العامة سليمة.`);console.log(configured?'إعداد Firebase مكتمل.':'الموقع في وضع المعاينة حتى ربط مشروع Firebase مستقل.');}
