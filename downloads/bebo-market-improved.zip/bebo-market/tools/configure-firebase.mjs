import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {spawnSync} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {ROOT,validateFirebaseConfig,writeConfigOutputs,CONFIG_KEYS} from './config-lib.mjs';
const rl=createInterface({input:stdin,output:stdout});
try {
  console.log('اربط مشروع Firebase مستقلًا لببو ماركت. أنشئ تطبيق Web من Console أولًا.');
  const projectId=(await rl.question('Project ID: ')).trim();
  if(projectId==='dongola-eng') throw new Error('هذا مشروع الكلية. أنشئ مشروعًا مستقلًا للسوق.');
  if(!/^[a-z][a-z0-9-]{4,28}[a-z0-9]$/.test(projectId) || projectId.startsWith('demo-')) throw new Error('اكتب معرّف المشروع الحقيقي الصحيح.');
  const appId=(await rl.question('Web App ID (Enter if the project has only one Web app): ')).trim();
  const args=[path.join(ROOT,'node_modules/firebase-tools/lib/bin/firebase.js'),'apps:sdkconfig','WEB'];
  if(appId) args.push(appId);
  args.push('--project',projectId,'--json','--non-interactive');
  const result=spawnSync(process.execPath,args,{encoding:'utf8',cwd:ROOT,maxBuffer:2*1024*1024});
  if(result.status!==0) throw new Error('تعذّر قراءة إعداد التطبيق. نفّذ npx firebase login بالحساب الذي يملك المشروع، وتأكد من إنشاء تطبيق Web.');
  let parsed;
  try {parsed=JSON.parse(result.stdout);} catch {throw new Error('لم يرجع Firebase إعدادًا صالحًا. راجع معرّف المشروع وتطبيق Web.');}
  const raw=parsed.result?.sdkConfig;
  validateFirebaseConfig(raw,{required:true});
  if(raw.projectId!==projectId) throw new Error('إعداد التطبيق لا يخص المشروع المحدد.');
  const config=Object.fromEntries(CONFIG_KEYS.filter(key=>typeof raw[key]==='string').map(key=>[key,raw[key]]));
  await writeFile(path.join(ROOT,'firebase.config.json'),JSON.stringify(config,null,2)+'\n');
  await writeFile(path.join(ROOT,'.firebaserc'),JSON.stringify({projects:{default:projectId}},null,2)+'\n');
  await writeConfigOutputs(config);
  console.log('تم حفظ إعداد الويب العام. فعّل Google وEmail/Password وAnonymous، وهيّئ adminAccess/roster من Console حسب README-AR.md.');
} catch(error) {console.error(error.message);process.exitCode=1;} finally {rl.close();}
