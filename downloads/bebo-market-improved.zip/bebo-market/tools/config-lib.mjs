import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const CONFIG_KEYS = ['apiKey','authDomain','projectId','appId','storageBucket','messagingSenderId','measurementId'];
export function validateFirebaseConfig(config, {required=false}={}) {
  if (!config || typeof config !== 'object' || Array.isArray(config)) throw new Error('إعداد Firebase غير صحيح.');
  if ('private_key' in config || 'client_email' in config || config.type === 'service_account') throw new Error('هذا مفتاح خادم. لا تضعه في الموقع؛ استخدم إعداد تطبيق الويب العام فقط.');
  const keys=['apiKey','authDomain','projectId','appId'];
  const present=keys.filter(key=>typeof config[key]==='string' && config[key].trim());
  if (!present.length && !required) return false;
  if (present.length!==keys.length) throw new Error('أكمل apiKey وauthDomain وprojectId وappId من إعداد تطبيق Firebase Web.');
  if (!/^[a-z][a-z0-9-]{4,28}[a-z0-9]$/.test(config.projectId)) throw new Error('معرّف مشروع Firebase غير صحيح.');
  if (config.projectId==='dongola-eng') throw new Error('مشروع dongola-eng خاص بموقع الكلية. استخدم مشروعًا مستقلاً لببو ماركت حتى تبقى بيانات الكلية وصلاحياتها آمنة.');
  if (!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/i.test(config.authDomain) || !config.authDomain.includes('.')) throw new Error('authDomain يجب أن يكون اسم نطاق فقط دون https أو مسار.');
  if (config.apiKey.length>256 || config.appId.length>256) throw new Error('إعداد تطبيق الويب غير صحيح.');
  return true;
}
export async function loadConfig(options={}) {
  const config=JSON.parse(await readFile(path.join(ROOT,'firebase.config.json'),'utf8'));
  const configured=validateFirebaseConfig(config,options);
  return {config:Object.fromEntries(CONFIG_KEYS.filter(key=>typeof config[key]==='string').map(key=>[key,config[key].trim()])),configured};
}
export function hostingConfig(config={}, emulator=false) {
  const frame=config.authDomain ? 'https://'+config.authDomain : 'https://*.firebaseapp.com';
  const local=emulator ? ' http://127.0.0.1:9099 http://127.0.0.1:8080 ws://127.0.0.1:8080' : '';
  const csp=`default-src 'self'; script-src 'self' https://www.gstatic.com https://apis.google.com; style-src 'self' 'unsafe-inline'; font-src 'self'; img-src 'self' data: blob:; connect-src 'self' https://firestore.googleapis.com https://identitytoolkit.googleapis.com https://securetoken.googleapis.com https://www.googleapis.com https://www.gstatic.com${local}; frame-src ${frame}${emulator?' http://127.0.0.1:9099':''}; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'${emulator?'':'; upgrade-insecure-requests'}`;
  return {
    hosting:{public:'public',ignore:['firebase.json','**/.*','**/node_modules/**'],headers:[
      {source:'**',headers:[{key:'Content-Security-Policy',value:csp},{key:'X-Content-Type-Options',value:'nosniff'},{key:'Referrer-Policy',value:'strict-origin-when-cross-origin'},{key:'X-Frame-Options',value:'DENY'},{key:'Cross-Origin-Opener-Policy',value:'same-origin-allow-popups'},{key:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'},{key:'Cache-Control',value:'no-cache'}]},
      {source:'admin/**',headers:[{key:'Cache-Control',value:'no-store'},{key:'X-Robots-Tag',value:'noindex, nofollow'}]}
    ]},
    firestore:{rules:'firestore.rules',indexes:'firestore.indexes.json'},
    emulators:{singleProjectMode:true,auth:{host:'127.0.0.1',port:9099},firestore:{host:'127.0.0.1',port:8080},hosting:{host:'127.0.0.1',port:8012},ui:{enabled:false}}
  };
}
export async function writeConfigOutputs(config) {
  const safe=JSON.stringify(config,null,2).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');
  await writeFile(path.join(ROOT,'public/js/firebase-config.js'),'/* Public Firebase Web configuration; never put a service-account key here. */\nwindow.BEBO_FIREBASE_CONFIG = '+safe+';\n');
  await writeFile(path.join(ROOT,'firebase.json'),JSON.stringify(hostingConfig(config),null,2)+'\n');
  await writeFile(path.join(ROOT,'firebase.emulator.json'),JSON.stringify(hostingConfig(config,true),null,2)+'\n');
}
