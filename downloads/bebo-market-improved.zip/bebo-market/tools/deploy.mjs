import {createInterface} from 'node:readline/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {ROOT,loadConfig,writeConfigOutputs} from './config-lib.mjs';
function firebase(args) {
  const r=spawnSync(process.execPath,[path.join(ROOT,'node_modules/firebase-tools/lib/bin/firebase.js'),...args],{cwd:ROOT,stdio:'inherit'});
  if(r.status!==0) throw new Error('توقف الأمر. راجع رسالة Firebase أعلاه قبل المحاولة مجددًا.');
}
try {
  const {config}=await loadConfig({required:true});
  if(config.projectId.startsWith('demo-')) throw new Error('لا يمكن نشر مشروع المحاكي.');
  await writeConfigOutputs(config);
  const checked=spawnSync(process.execPath,[path.join(ROOT,'tools/check-site.mjs')],{cwd:ROOT,stdio:'inherit'});
  if(checked.status!==0) throw new Error('أصلح فحص الملفات قبل النشر.');
  const rl=createInterface({input:process.stdin,output:process.stdout});
  console.log('سيتم نشر موقع ببو ماركت وقواعده إلى: '+config.projectId);
  const answer=(await rl.question('Type PUBLISH to continue: ')).trim();rl.close();
  if(answer!=='PUBLISH') {console.log('أُلغي النشر.');process.exitCode=0;}
  else {firebase(['login']);firebase(['deploy','--project',config.projectId,'--only','firestore:rules,firestore:indexes,hosting']);console.log('اكتمل النشر. اختبر الدخول والحفظ من رابط Hosting الذي ظهر.');}
} catch(error) {console.error(error.message);process.exitCode=1;}
