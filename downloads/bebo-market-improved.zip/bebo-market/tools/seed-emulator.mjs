import {readFile} from 'node:fs/promises';
import {initializeApp,deleteApp} from 'firebase-admin/app';
import {getFirestore,FieldValue} from 'firebase-admin/firestore';
import {getAuth} from 'firebase-admin/auth';
if(process.env.GCLOUD_PROJECT && !process.env.GCLOUD_PROJECT.startsWith('demo-')) throw new Error('هذا الأمر للمحاكي فقط.');
process.env.FIRESTORE_EMULATOR_HOST ||= '127.0.0.1:8080';
process.env.FIREBASE_AUTH_EMULATOR_HOST ||= '127.0.0.1:9099';
for(const key of ['FIRESTORE_EMULATOR_HOST','FIREBASE_AUTH_EMULATOR_HOST'])if(!/^(127\.0\.0\.1|localhost):[0-9]{1,5}$/.test(process.env[key]))throw new Error('المحاكي يجب أن يكون على جهازك فقط.');
const app=initializeApp({projectId:'demo-bebo-market'});
try{
 const auth=getAuth(app);let user;
 try{user=await auth.getUserByEmail('owner@example.test');}catch(error){if(error.code!=='auth/user-not-found')throw error;}
 user=user?await auth.updateUser(user.uid,{password:'Bebo-Local-Test-2026!',emailVerified:true}):await auth.createUser({email:'owner@example.test',password:'Bebo-Local-Test-2026!',emailVerified:true});
 const raw=JSON.parse(await readFile(new URL('../data/default-catalog.json',import.meta.url),'utf8'));
 raw.products={};
 for(const store of raw.stores)for(const product of store.products)raw.products[`${store.id}_${product.id}`]={storeId:store.id,productId:product.id,storeName:store.name,name:product.name,emoji:product.emoji||'',price:product.price,available:product.available!==false&&product.enabled!==false,storeOpen:store.isOpen===true&&store.enabled!==false};
 const db=getFirestore(app);
 await db.doc('catalog/current').set({...raw,updatedAt:FieldValue.serverTimestamp(),updatedBy:user.uid});
 await db.doc('adminAccess/roster').set({emails:['owner@example.test'],updatedAt:FieldValue.serverTimestamp(),updatedBy:'emulator-seed'});
 console.log('حساب محلي تجريبي: owner@example.test / Bebo-Local-Test-2026!');
 console.log('هذه القيم للمحاكي فقط. الكتالوج باقٍ في وضع العرض التجريبي. افتح /admin/?emulator=1.');
}finally{await deleteApp(app);}
