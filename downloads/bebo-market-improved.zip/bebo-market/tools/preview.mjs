import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {ROOT} from './config-lib.mjs';
const base=path.join(ROOT,'public');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8'};
http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');let relative=decodeURIComponent(url.pathname);
  if(relative.endsWith('/'))relative+='index.html';
  const target=path.resolve(base,'.'+relative);
  if(!target.startsWith(base+path.sep)||relative.split('/').some(part=>part.startsWith('.'))){res.writeHead(404).end();return;}
  const info=await stat(target);if(!info.isFile())throw new Error('not-file');
  res.writeHead(200,{'Content-Type':types[path.extname(target)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  if(req.method==='HEAD')res.end();else res.end(await readFile(target));
 }catch{res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'}).end('الصفحة غير موجودة.');}
}).listen(4173,'127.0.0.1',()=>console.log('معاينة محلية: http://127.0.0.1:4173 — استخدم Ctrl+C للإيقاف. ربط Firebase مطلوب لاستقبال الطلبات.'));
