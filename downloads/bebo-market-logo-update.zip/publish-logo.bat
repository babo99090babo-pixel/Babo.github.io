@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto failed

where node >nul 2>nul
if errorlevel 1 goto missing_node
if not exist "firebase.config.json" goto wrong_folder
if not exist "public\js\firebase-config.js" goto wrong_folder
if not exist "tools\check-site.mjs" goto wrong_folder
if not exist "node_modules\firebase-tools\lib\bin\firebase.js" goto missing_tools

node -e "const fs=require('node:fs');try{const config=JSON.parse(fs.readFileSync('firebase.config.json','utf8'));process.exit(config.projectId==='babo-market'?0:1);}catch{process.exit(1);}"
if errorlevel 1 goto wrong_project

call node "tools\check-site.mjs"
if errorlevel 1 goto failed

echo.
echo This update publishes website files only to: babo-market
echo Existing Firebase settings and Firestore data are preserved.
set "BEBO_LOGO_CONFIRM="
set /p "BEBO_LOGO_CONFIRM=Type PUBLISH to continue: "
node -e "process.exit(process.env.BEBO_LOGO_CONFIRM==='PUBLISH'?0:1)"
if errorlevel 1 goto cancelled

call node "node_modules\firebase-tools\lib\bin\firebase.js" deploy --only hosting --project babo-market
if errorlevel 1 goto failed

echo.
echo Logo update published successfully.
echo Open https://babo-market.web.app and press Ctrl+F5.
pause
exit /b 0

:cancelled
echo Publishing cancelled. No deployment was started.
pause
exit /b 0

:missing_node
echo Node.js is missing. Install Node.js LTS, then reopen this file.
pause
exit /b 1

:wrong_folder
echo Copy this update into your original configured Bebo Market folder.
echo Keep its existing Firebase configuration and tools.
pause
exit /b 1

:missing_tools
echo Firebase CLI is missing from this folder.
echo Use your original Bebo Market folder with its installed node_modules.
pause
exit /b 1

:wrong_project
echo Stopped: firebase.config.json must have projectId babo-market.
echo Use the original configured market folder. Do not change the project.
pause
exit /b 1

:failed
echo Publishing stopped. Read the error above before trying again.
pause
exit /b 1
