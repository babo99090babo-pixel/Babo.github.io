'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import BookCard from '@/components/BookCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import EmptyState from '@/components/EmptyState';
import api from '@/lib/api';
import { HiBookOpen, HiSearch, HiRefresh } from 'react-icons/hi';

function LibraryContent() {
  const searchParams = useSearchParams();

  const [books, setBooks] = useState([]);
  const [stages, setStages] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [loading, setLoading] = useState(true);

  // Filters
  const [stageFilter, setStageFilter] = useState(searchParams.get('stage') || '');
  const [gradeFilter, setGradeFilter] = useState(searchParams.get('grade') || '');
  const [subjectFilter, setSubjectFilter] = useState(searchParams.get('subject') || '');
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1);

  // Load stages & subjects
  useEffect(() => {
    async function loadOptions() {
      try {
        const [stagesRes, subjectsRes] = await Promise.allSettled([
          api.get('/stages'),
          api.get('/subjects'),
        ]);
        if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data || []);
        if (subjectsRes.status === 'fulfilled') setSubjects(subjectsRes.value.data || []);
      } catch (err) {
        console.error('Failed to load filter options:', err);
      }
    }
    loadOptions();
  }, []);

  // Fetch books
  useEffect(() => {
    async function fetchBooks() {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (stageFilter) params.append('stage', stageFilter);
        if (gradeFilter) params.append('grade', gradeFilter);
        if (subjectFilter) params.append('subject', subjectFilter);
        if (searchTerm) params.append('search', searchTerm);
        params.append('page', page);
        params.append('limit', 12);

        const res = await api.get(`/books?${params.toString()}`);
        setBooks(res.data.books || []);
        setPagination(res.data.pagination || { page: 1, totalPages: 1, total: 0 });
      } catch (err) {
        console.error('Failed to fetch books:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchBooks();
  }, [stageFilter, gradeFilter, subjectFilter, searchTerm, page]);

  const selectedStageObj = stages.find((s) => s.id === Number(stageFilter));
  const availableGrades = selectedStageObj?.grades || [];

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 text-xs font-bold mb-3">
            <HiBookOpen className="w-4 h-4" />
            <span>المكتبة التعليمية الرقمية</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-3 font-cairo">
            الكتب والمذكرات وامتحانات الشهادة
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
            كتب دراسية ومذكرات ملخصة بصيغة PDF لجميع المواد والصفوف والمراحل في السودان.
          </p>
        </div>

        {/* Filter bar */}
        <div className="p-5 rounded-2xl bg-gray-50 dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                البحث
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setPage(1);
                  }}
                  placeholder="ابحث بعنوان الكتاب أو المذكرة..."
                  className="w-full px-3 py-2 pr-9 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <HiSearch className="w-4 h-4 text-gray-400 absolute right-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                المرحلة
              </label>
              <select
                value={stageFilter}
                onChange={(e) => {
                  setStageFilter(e.target.value);
                  setGradeFilter('');
                  setPage(1);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">كل المراحل</option>
                {stages.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                الصف
              </label>
              <select
                value={gradeFilter}
                onChange={(e) => {
                  setGradeFilter(e.target.value);
                  setPage(1);
                }}
                disabled={!stageFilter && stages.length > 0}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50"
              >
                <option value="">كل الصفوف</option>
                {availableGrades.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                المادة
              </label>
              <select
                value={subjectFilter}
                onChange={(e) => {
                  setSubjectFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">كل المواد</option>
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-gray-200 dark:border-indigo-950/60">
            <span className="text-xs font-medium text-gray-500">
              عدد الكتب: {pagination.total}
            </span>
            <button
              onClick={() => {
                setStageFilter('');
                setGradeFilter('');
                setSubjectFilter('');
                setSearchTerm('');
                setPage(1);
              }}
              className="inline-flex items-center gap-1 text-xs font-bold text-orange-500 hover:text-orange-600"
            >
              <HiRefresh className="w-3.5 h-3.5" />
              <span>إعادة ضبط التصفية</span>
            </button>
          </div>
        </div>

        {/* Books Grid */}
        {loading ? (
          <LoadingSpinner text="جاري تحميل الكتب..." />
        ) : books.length > 0 ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 mb-10">
              {books.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 pt-6">
                <button
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page <= 1}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950 disabled:opacity-40"
                >
                  السابق
                </button>
                <span className="text-xs font-bold px-3">
                  صفحة {pagination.page} من {pagination.totalPages}
                </span>
                <button
                  onClick={() => setPage(Math.min(pagination.totalPages, page + 1))}
                  disabled={page >= pagination.totalPages}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950 disabled:opacity-40"
                >
                  التالي
                </button>
              </div>
            )}
          </>
        ) : (
          <EmptyState
            title="لا توجد كتب مطابقة لبحثك"
            description="جرب إزالة بعض الفلاتر، أو تواصل مع الإدارة لطلب رفع مذكرة أو كتاب محدد."
            actionText="عرض كل الكتب"
            actionHref="/library"
          />
        )}
      </main>

      <Footer />
    </div>
  );
}

export default function LibraryPage() {
  return (
    <Suspense fallback={<LoadingSpinner text="جاري التحميل..." />}>
      <LibraryContent />
    </Suspense>
  );
}
