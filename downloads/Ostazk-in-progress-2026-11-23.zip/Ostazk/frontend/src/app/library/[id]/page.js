'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useAuthStore } from '@/lib/store';
import api from '@/lib/api';
import RequestError from '@/components/RequestError';
import toast from 'react-hot-toast';
import {
  HiDocumentText,
  HiDownload,
  HiBookmark,
  HiLockClosed,
  HiShieldCheck,
  HiArrowSmRight,
} from 'react-icons/hi';

export default function BookDetailsPage() {
  const { id } = useParams();
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();

  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [bookmarkLoading, setBookmarkLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [previewUrl, setPreviewUrl] = useState('');
  const [fileError, setFileError] = useState('');
  const [fileStatus, setFileStatus] = useState(null);
  const [fileLoading, setFileLoading] = useState(false);
  const objectUrl = useRef(null);
  useEffect(() => () => { if (objectUrl.current) URL.revokeObjectURL(objectUrl.current); }, []);
  const loadFile = async (download = false) => {
    setFileLoading(true); setFileError(''); setFileStatus(null);
    try {
      const { data } = await api.get(`/books/${id}/${download ? 'download' : 'preview'}`, { responseType: 'blob' });
      const url = URL.createObjectURL(data);
      if (download) {
        const link = document.createElement('a'); link.href = url; link.download = `${book.title}.pdf`;
        document.body.appendChild(link); link.click(); link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 10000);
      } else {
        if (objectUrl.current) URL.revokeObjectURL(objectUrl.current);
        objectUrl.current = url; setPreviewUrl(url);
      }
    } catch (err) { setFileError(err.friendlyMessage); setFileStatus(err.status); }
    finally { setFileLoading(false); }
  };

  useEffect(() => {
    async function fetchBook() {
      setLoading(true); setError('');
      try {
        const res = await api.get(`/books/${id}`);
        setBook(res.data);
      } catch (err) {
        setError(err.friendlyMessage);
      } finally {
        setLoading(false);
      }
    }
    if (id) fetchBook();
  }, [id, attempt]);

  const handleBookmarkToggle = async () => {
    if (!isAuthenticated) {
      toast.error('سجّل دخولك لحفظ الكتاب في مكتبتك الخاصة');
      router.push(`/login?redirect=/library/${id}`);
      return;
    }

    setBookmarkLoading(true);
    try {
      const res = await api.post(`/student/bookmarks/${id}`);
      setIsBookmarked(res.data.bookmarked);
      toast.success(res.data.message);
    } catch (err) {
      toast.error(err.friendlyMessage || 'حصل خطأ في حفظ الكتاب');
    } finally {
      setBookmarkLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner text="جاري فتح تفاصيل الكتاب..." />
        </main>
        <Footer />
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex flex-col items-center justify-center p-6 text-center">
          <RequestError message={error || "الكتاب غير متوفر"} onRetry={() => setAttempt(a => a+1)} />
          <Link href="/library" className="text-sm font-bold text-orange-500 hover:underline">
            الرجوع للمكتبة
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  const accessText = {
    PUBLIC: 'متاح للعامة مجاناً',
    REGISTERED: 'متاح للحسابات المسجلة فقط',
    SUBSCRIBER: 'خاص بالطلاب المشتركين في الكورس',
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400 mb-6">
          <Link href="/library" className="hover:text-purple-600">
            المكتبة
          </Link>
          <span>/</span>
          <span>{book.grade?.stage?.name}</span>
          <span>/</span>
          <span>{book.grade?.name}</span>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold truncate">
            {book.title}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Book Details & Preview (2 cols) */}
          <div className="lg:col-span-2 space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-500/10 text-purple-600 dark:text-purple-400">
                  {book.subject?.name}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-gray-100 dark:bg-navy-800 text-gray-700 dark:text-gray-300">
                  {book.grade?.name}
                </span>
                {book.year && (
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 dark:bg-navy-800 text-gray-600">
                    طبعة {book.year}
                  </span>
                )}
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mb-4 font-cairo">
                {book.title}
              </h1>

              {book.description && (
                <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                  {book.description}
                </p>
              )}

              {/* PDF Preview Frame */}
              <div className="mt-6 border border-gray-200 dark:border-indigo-950/80 rounded-2xl overflow-hidden bg-gray-100 dark:bg-navy-950">
                <div className="p-3 bg-gray-200 dark:bg-navy-800 flex items-center justify-between text-xs font-bold">
                  <span>معاينة المستند المباشرة</span>
                  <span className="text-gray-500">PDF Viewer</span>
                </div>
                {previewUrl ? <>
                  <iframe src={previewUrl} title={book.title} className="w-full h-[600px] border-0" />
                  <a href={previewUrl} target="_blank" rel="noopener noreferrer" className="block p-3 text-purple-600 dark:text-purple-400 text-sm">فتح القارئ في نافذة جديدة</a>
                </> : <div className="p-6 text-center space-y-3">
                  <p className="text-sm">افتح المعاينة عندما تكون جاهزًا لقراءة الملف.</p>
                  <button disabled={fileLoading} onClick={() => loadFile()} className="px-5 py-3 rounded-xl bg-purple-600 text-white disabled:opacity-50">{fileLoading ? 'جاري تحميل الملف...' : 'فتح معاينة الكتاب'}</button>
                </div>}
                <div className="px-4"><RequestError message={fileError} onRetry={() => loadFile()} />
                  {fileStatus === 401 && <Link className="block pb-4 text-purple-500 font-bold" href={`/login?redirect=${encodeURIComponent(`/library/${id}`)}`}>سجّل دخولك للمتابعة</Link>}
                  {fileStatus === 403 && book.courseId && <Link className="block pb-4 text-purple-500 font-bold" href={`/courses/${book.courseId}`}>عرض الكورس والاشتراك</Link>}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar Action Card */}
          <div className="space-y-6">
            <div className="p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-xl">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                خيارات الكتاب
              </h3>

              <div className="space-y-3 mb-6 text-xs">
                <div className="flex justify-between py-2 border-b border-gray-100 dark:border-indigo-950/60">
                  <span className="text-gray-500">مستوى الوصول:</span>
                  <span className="font-bold text-purple-600 dark:text-purple-400">
                    {accessText[book.accessLevel] || 'عام'}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100 dark:border-indigo-950/60">
                  <span className="text-gray-500">نوع الملف:</span>
                  <span className="font-bold uppercase text-gray-700 dark:text-gray-300">
                    {book.fileType || 'PDF'}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100 dark:border-indigo-950/60">
                  <span className="text-gray-500">حجم الملف:</span>
                  <span className="font-bold text-gray-700 dark:text-gray-300">
                    {book.fileSize > 0 ? `${(book.fileSize / (1024 * 1024)).toFixed(1)} ميجابايت` : 'غير محدد'}
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-gray-500">إمكانية التنزيل:</span>
                  <span className={`font-bold ${book.allowDownload ? 'text-emerald-500' : 'text-red-500'}`}>
                    {book.allowDownload ? 'متاح للتنزيل' : 'معاينة فقط'}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-3">
                {book.allowDownload ? (
                  <button
                    type="button"
                    onClick={() => loadFile(true)}
                    disabled={fileLoading}
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-md shadow-orange-500/25 transition-all text-sm"
                  >
                    <HiDownload className="w-5 h-5" />
                    <span>{fileLoading ? 'جاري التحميل...' : 'تنزيل نسخة PDF'}</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-600 dark:text-orange-400 text-xs flex items-center gap-2">
                    <HiLockClosed className="w-5 h-5 flex-shrink-0" />
                    <span>هذا المستند متاح للقراءة فقط بطلب من الإدارة أو المؤلف.</span>
                  </div>
                )}

                <button
                  onClick={handleBookmarkToggle}
                  disabled={bookmarkLoading}
                  className={`w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl font-bold text-xs border transition-all ${
                    isBookmarked
                      ? 'border-purple-600 bg-purple-600 text-white'
                      : 'border-purple-600 text-purple-600 dark:text-purple-400 hover:bg-purple-600/10'
                  }`}
                >
                  <HiBookmark className="w-4 h-4" />
                  <span>{isBookmarked ? 'محفوظ في كتبي' : 'حفظ في المفضلة'}</span>
                </button>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-100 dark:border-indigo-950/60 flex items-center gap-2 text-[11px] text-gray-500">
                <HiShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>حماية الملكية الفكرية لمناهج ومذكرات السودان التعليمية</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
