'use client';

import { useContact } from '@/lib/contact';
import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import { HiPhone, HiChevronDown, HiChevronUp, HiQuestionMarkCircle, HiChatAlt } from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function ContactPage() {
  const contact = useContact();
  const [openFaq, setOpenFaq] = useState(null);

  const faqs = [
    {
      q: 'كيف بقدر أسجل في كورس أو درس خصوصي؟',
      a: 'الموضوع بسيط شديد: ١) اختار صفك ومادتك والكورس المناسب ليك، ٢) اضغط «احجز الآن»، ٣) تواصل مع الإدارة على واتساب أو اتصال لتأكيد الحجز والدفع واستلام رمز التفعيل، ٤) فعّل رمزك في صفحة «دروسي» وتبدأ فوراً.',
    },
    {
      q: 'هل بحتاج لبريد إلكتروني أو رسالة SMS عشان أعمل حساب؟',
      a: 'لا، ما بنطلب أي بريد إلكتروني من الطالب ولا بنشترط رسالة SMS أو OTP. الحساب بيتسجل بالاسم الرباعي ورقم هاتفك ورقم ولي أمرك وبيكون جاهز للاستخدام مباشرة.',
    },
    {
      q: 'شنو هو رمز التفعيل وكيف بشتغل؟',
      a: 'رمز التفعيل دا كود خاص بيك بعد مراجعة حجزك مع الإدارة. الرمز بيكون مرتبط بحسابك وبالكورس المحدد فقط، وبمجرد كتابته في خانة «فعّل رمزك»، بيتفعل اشتراكك وتقدر تدخل لكل الحصص والكتب المقررة.',
    },
    {
      q: 'هل ممكن أخوي يستخدم نفس رقم هاتف ولي الأمر؟',
      a: 'أيوه بكل تأكيد، وفرنا إمكانية اشتراك الإخوة في نفس رقم هاتف ولي الأمر مع شرط أن يكون لكل طالب رقم هاتف مستقل لحسابه الخاص.',
    },
    {
      q: 'الدروس الحضورية بتكون وين بالضبط؟',
      a: 'في صفحة الكورس بنعرض ليك الولاية والمدينة والمنطقة العامة واسم المركز. وبمجرد تأكيد حجزك مع الإدارة بيظهر ليك العنوان التفصيلي الدقيق.',
    },
    {
      q: 'كيف بيتم الدفع؟',
      a: 'في المرحلة الحالية، تأكيد الحجوزات والدفع بيتم يدوياً بالتنسيق المباشر مع إدارة المنصة عبر بنكك أو وسائل الدفع المعتمدة لدى الإدارة.',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 text-xs font-bold mb-3">
            <HiChatAlt className="w-4 h-4" />
            <span>خدمة الطلاب وأولياء الأمور</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-3 font-cairo">
            تواصل معنا والأسئلة الشائعة
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
            «ما لقيت المادة البتفتش عنها؟ كلمنا». فريق إدارة أستاذك جاهز للرد على كل استفساراتكم وترتيب الحصص المناسبة.
          </p>
        </div>

        {/* Contact Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-16">
          <a
            href={contact.whatsappBase}
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 hover:border-emerald-500/50 hover:shadow-xl transition-all flex items-center gap-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center flex-shrink-0">
              <FaWhatsapp className="w-7 h-7" />
            </div>
            <div>
              <span className="text-xs text-gray-500 dark:text-gray-400">تواصل فوري</span>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">
                واتساب الإدارة المباشر
              </h3>
              <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5" dir="ltr">
                +249 99 197 4489
              </p>
            </div>
          </a>

          <a
            href={contact.telephone}
            className="p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 hover:border-orange-500/50 hover:shadow-xl transition-all flex items-center gap-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center flex-shrink-0">
              <HiPhone className="w-7 h-7" />
            </div>
            <div>
              <span className="text-xs text-gray-500 dark:text-gray-400">مكالمات هاتفية</span>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">
                هاتف الإدارة والدعم
              </h3>
              <p className="text-xs font-bold text-orange-500 mt-0.5" dir="ltr">
                {contact.phone}
              </p>
            </div>
          </a>
        </div>

        {/* FAQs */}
        <div className="p-6 sm:p-10 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 flex items-center justify-center">
              <HiQuestionMarkCircle className="w-6 h-6" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              الأسئلة الأكثر تكراراً
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-2xl border border-gray-200 dark:border-indigo-950/70 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full p-4 text-right flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-navy-800 transition-colors"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <HiChevronUp className="w-5 h-5 text-purple-600 flex-shrink-0" />
                    ) : (
                      <HiChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="p-4 pt-1 text-xs text-gray-600 dark:text-gray-300 leading-relaxed bg-gray-50/50 dark:bg-navy-950/50 border-t border-gray-100 dark:border-indigo-950/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
