'use client';

import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LoadingSpinner from '@/components/LoadingSpinner';
import api from '@/lib/api';
import { passwordError } from '@/lib/password';
import toast from 'react-hot-toast';
import { HiLockClosed, HiEye, HiEyeOff } from 'react-icons/hi';

function ResetPasswordForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const id = searchParams.get('id');

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token || !id) {
      toast.error('رابط الاستعادة غير صالح أو منتهي');
      return;
    }

    const validationError = passwordError(newPassword);
    if (validationError) {
      toast.error(validationError);
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('كلمتي السر غير متطابقتين');
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/reset-password', {
        token,
        id,
        newPassword,
      });
      toast.success(res.data.message || 'تم تحديث كلمة السر بنجاح!');
      router.push('/login');
    } catch (err) {
      toast.error(err.friendlyMessage || 'الرابط غير صالح أو انتهت صلاحيته');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-2xl">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-black text-gray-900 dark:text-white font-cairo">
          تعيين كلمة سر جديدة
        </h1>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
          أدخل كلمة السر الجديدة لحسابك
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
            كلمة السر الجديدة
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              required
              minLength={8}
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="٨ خانات على الأقل"
              className="w-full px-4 py-2.5 pr-10 pl-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <HiLockClosed className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-3.5 top-3 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <HiEyeOff className="w-4 h-4" /> : <HiEye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
            تأكيد كلمة السر الجديدة
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="أعد إدخال كلمة السر"
              className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <HiLockClosed className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 transition-all disabled:opacity-50 text-sm"
        >
          {loading ? 'جاري الحفظ...' : 'حفظ كلمة السر والدخول'}
        </button>
      </form>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <main className="flex-grow flex items-center justify-center py-12 px-4">
        <Suspense fallback={<LoadingSpinner text="جاري التحميل..." />}>
          <ResetPasswordForm />
        </Suspense>
      </main>
      <Footer />
    </div>
  );
}
