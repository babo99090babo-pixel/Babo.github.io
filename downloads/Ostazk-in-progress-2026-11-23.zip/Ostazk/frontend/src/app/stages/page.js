'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import LoadingSpinner from '@/components/LoadingSpinner';
import api from '@/lib/api';
import { HiAcademicCap, HiArrowSmLeft, HiBookOpen } from 'react-icons/hi';

export default function StagesPage() {
  const [stages, setStages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStages() {
      try {
        const res = await api.get('/stages');
        setStages(res.data || []);
      } catch (err) {
        console.error('Failed to load stages:', err);
      } finally {
        setLoading(false);
      }
    }
    loadStages();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Page Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 text-xs font-bold mb-3">
            <HiAcademicCap className="w-4 h-4" />
            <span>المسار التعليمي</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-3 font-cairo">
            المراحل والصفوف الدراسية
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
            تصفح مناهج التعليم في السودان بالترتيب المعتمد. اختار صفك للوصول إلى المواد والمدرسين والدروس والمذكرات.
          </p>
        </div>

        {loading ? (
          <LoadingSpinner text="جاري تحميل المراحل والصفوف..." />
        ) : (
          <div className="space-y-10">
            {stages.map((stage) => (
              <div
                key={stage.id}
                className="rounded-3xl p-6 sm:p-8 border border-gray-200 dark:border-indigo-950/80 bg-gray-50/50 dark:bg-navy-900/40 shadow-sm"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-6 border-b border-gray-200 dark:border-indigo-950/60 gap-4">
                  <div>
                    <h2 className="text-2xl font-black text-gray-900 dark:text-white">
                      {stage.name}
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      اختار الصف الدراسي المطلوب للدخول إلى مواده ومدرسيه
                    </p>
                  </div>
                  <Link
                    href={`/courses?stage=${stage.id}`}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-orange-600 dark:text-orange-400 bg-orange-500/10 hover:bg-orange-500/20 transition-all self-start sm:self-auto"
                  >
                    <span>عرض كل دروس المرحلة</span>
                    <HiArrowSmLeft className="w-4 h-4" />
                  </Link>
                </div>

                {/* Grade Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {stage.grades?.map((grade) => (
                    <Link
                      key={grade.id}
                      href={`/stages/${stage.slug}/${grade.slug}`}
                      className="group p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/60 hover:border-purple-500/50 hover:shadow-lg transition-all flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold text-sm group-hover:scale-105 transition-transform">
                          <HiBookOpen className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-base font-bold text-gray-900 dark:text-white group-hover:text-orange-500 transition-colors">
                            {grade.name}
                          </h3>
                          <span className="text-[11px] text-gray-500 dark:text-gray-400">
                            استكشف المواد والدروس
                          </span>
                        </div>
                      </div>
                      <HiArrowSmLeft className="w-5 h-5 text-gray-400 group-hover:text-orange-500 group-hover:-translate-x-1 transition-all" />
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
