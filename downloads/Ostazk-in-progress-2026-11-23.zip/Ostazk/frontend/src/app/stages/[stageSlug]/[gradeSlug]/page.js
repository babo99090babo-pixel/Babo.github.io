'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import LoadingSpinner from '@/components/LoadingSpinner';
import CourseCard from '@/components/CourseCard';
import BookCard from '@/components/BookCard';
import api from '@/lib/api';
import { HiArrowSmRight, HiBookOpen, HiAcademicCap } from 'react-icons/hi';

export default function GradeDetailsPage() {
  const { stageSlug, gradeSlug } = useParams();
  const [grade, setGrade] = useState(null);
  const [courses, setCourses] = useState([]);
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchGradeData() {
      try {
        const gradeRes = await api.get(`/grades/${gradeSlug}`);
        const gradeData = gradeRes.data;
        setGrade(gradeData);

        if (gradeData?.id) {
          const [coursesRes, booksRes] = await Promise.allSettled([
            api.get(`/courses?grade=${gradeData.id}&limit=6`),
            api.get(`/books?grade=${gradeData.id}&limit=4`),
          ]);

          if (coursesRes.status === 'fulfilled') setCourses(coursesRes.value.data.courses || []);
          if (booksRes.status === 'fulfilled') setBooks(booksRes.value.data.books || []);
        }
      } catch (err) {
        console.error('Error fetching grade data:', err);
      } finally {
        setLoading(false);
      }
    }

    if (gradeSlug) {
      fetchGradeData();
    }
  }, [gradeSlug]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner text="جاري تحميل محتوى الصف..." />
        </main>
        <Footer />
      </div>
    );
  }

  if (!grade) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex flex-col items-center justify-center p-6 text-center">
          <h2 className="text-xl font-bold mb-2">الصف الدراسي ما موجود</h2>
          <Link href="/stages" className="text-sm font-bold text-orange-500 hover:underline">
            الرجوع للمراحل والصفوف
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400 mb-6">
          <Link href="/stages" className="hover:text-purple-600">
            المراحل والصفوف
          </Link>
          <span>/</span>
          <span className="text-purple-600 dark:text-purple-400">{grade.stage?.name}</span>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold">{grade.name}</span>
        </div>

        {/* Grade Banner */}
        <div className="p-8 rounded-3xl bg-gradient-to-r from-purple-900/90 via-navy-900 to-indigo-900 text-white shadow-xl mb-12 border border-purple-800/40">
          <span className="text-xs font-bold px-3 py-1 rounded-full bg-white/10 text-orange-400 mb-3 inline-block">
            {grade.stage?.name}
          </span>
          <h1 className="text-3xl sm:text-4xl font-black mb-3 font-cairo">
            مواد ودروس {grade.name}
          </h1>
          <p className="text-sm text-gray-200 max-w-2xl leading-relaxed">
            لقى أساتذتك المعتمدين والمجموعات الدراسية المتاحة والمذكرات الخاصة بهذا الصف.
          </p>
        </div>

        {/* Subjects Grid */}
        <div className="mb-14">
          <h2 className="text-xl sm:text-2xl font-bold mb-6 text-gray-900 dark:text-white">
            المواد الدراسية المقررة
          </h2>

          {grade.subjects?.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {grade.subjects.map((item) => {
                const sub = item.subject;
                return (
                  <Link
                    key={sub.id}
                    href={`/courses?grade=${grade.id}&subject=${sub.id}`}
                    className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 hover:border-orange-500/50 hover:shadow-lg transition-all text-center flex flex-col items-center justify-center group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <HiBookOpen className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-bold text-gray-900 dark:text-white group-hover:text-orange-500 transition-colors">
                      {sub.name}
                    </h3>
                    <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      عرض الدروس والمدرسين
                    </span>
                  </Link>
                );
              })}
            </div>
          ) : (
            <div className="p-8 rounded-2xl border border-dashed border-gray-300 dark:border-indigo-950 text-center text-sm text-gray-500">
              لم يتم تعيين مواد لهذا الصف بعد من قبل الإدارة.
            </div>
          )}
        </div>

        {/* Courses for this grade */}
        <div className="mb-14">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              الدروس والكورسات المتاحة لـ {grade.name}
            </h2>
            <Link
              href={`/courses?grade=${grade.id}`}
              className="text-xs font-bold text-orange-500 hover:underline"
            >
              عرض الكل
            </Link>
          </div>

          {courses.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl border border-dashed border-gray-300 dark:border-indigo-950 text-center text-sm text-gray-500">
              لا توجد كورسات معلنة حالياً لهذا الصف. تواصل مع الإدارة لحجز درس خاص.
            </div>
          )}
        </div>

        {/* Books for this grade */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              الكتب والمذكرات لـ {grade.name}
            </h2>
            <Link
              href={`/library?grade=${grade.id}`}
              className="text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline"
            >
              عرض المكتبة
            </Link>
          </div>

          {books.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {books.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl border border-dashed border-gray-300 dark:border-indigo-950 text-center text-sm text-gray-500">
              لا توجد كتب مرفوعة حالياً لهذا الصف.
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
