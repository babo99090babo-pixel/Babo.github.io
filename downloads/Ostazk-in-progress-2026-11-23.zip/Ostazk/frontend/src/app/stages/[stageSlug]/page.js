"use client";
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MobileNav from '@/components/MobileNav';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import LoadingSpinner from '@/components/LoadingSpinner';
import RequestError from '@/components/RequestError';
import api from '@/lib/api';

export default function StagePage() {
  const { stageSlug } = useParams();
  const [stage, setStage] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true); setError('');
    api.get(`/stages/${encodeURIComponent(stageSlug)}`).then(({data}) => { if(active) setStage(data); })
      .catch(err => { if(active) setError(err.friendlyMessage); }).finally(() => { if(active) setLoading(false); });
    return () => { active = false; };
  }, [stageSlug, attempt]);
  return <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-white">
    <Header /><MobileNav /><WhatsAppFAB />
    <main className="flex-grow max-w-6xl mx-auto w-full px-4 py-12">
      <Link href="/stages" className="text-purple-500">كل المراحل</Link>
      {loading ? <LoadingSpinner /> : error ? <RequestError message={error} onRetry={() => setAttempt(a => a+1)} /> : stage && <>
        <h1 className="text-3xl font-black my-6">{stage.name}</h1>
        <p className="mb-6 text-gray-500">اختار صفّك للوصول للمواد والدروس والكتب.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{stage.grades.map(grade => <Link key={grade.id} href={`/stages/${stage.slug}/${grade.slug}`} className="p-6 rounded-2xl border border-purple-500/20 bg-gray-50 dark:bg-navy-900 hover:border-orange-500 font-bold">{grade.name}</Link>)}</div>
        <Link href={`/courses?stage=${stage.id}`} className="inline-block mt-8 px-6 py-3 rounded-xl bg-orange-600 text-white font-bold">شوف دروس المرحلة</Link>
      </>}
    </main><Footer />
  </div>;
}
