'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import TeacherCard from '@/components/TeacherCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import EmptyState from '@/components/EmptyState';
import api from '@/lib/api';
import Pagination from '@/components/Pagination';
import RequestError from '@/components/RequestError';
import { HiAcademicCap, HiSearch } from 'react-icons/hi';

export default function TeachersPage() {
  const [teachers, setTeachers] = useState([]);
  const [cityFilter, setCityFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    const timer = setTimeout(async () => {
      setLoading(true); setError('');
      try {
        const { data } = await api.get('/teachers', { params: { city: cityFilter, search: searchTerm, page, limit: 12 } });
        if (active) { setTeachers(data.teachers || []); setPagination(data.pagination); }
      } catch (err) { if (active) setError(err.friendlyMessage); }
      finally { if (active) setLoading(false); }
    }, 250);
    return () => { active = false; clearTimeout(timer); };
  }, [cityFilter, searchTerm, page, attempt]);

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 text-xs font-bold mb-3">
            <HiAcademicCap className="w-4 h-4" />
            <span>نخبة المعلمين في السودان</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-3 font-cairo">
            المدرسون المعتمدون
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
            تعرف على نخبة الأساتذة المتخصصين، مؤهلاتهم، والدروس الخاصة والمجموعات الحضورية والأونلاين المتاحة لديهم.
          </p>
        </div>

        {/* Filter bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/60 mb-8">
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setPage(1); }}
              placeholder="ابحث باسم المدرس أو المادة..."
              className="w-full px-4 py-2 pr-9 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <HiSearch className="w-4 h-4 text-gray-400 absolute right-3 top-2.5" />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <label className="text-xs font-bold text-gray-600 dark:text-gray-400 whitespace-nowrap">
              المدينة:
            </label>
            <select
              value={cityFilter}
              onChange={(e) => { setCityFilter(e.target.value); setPage(1); }}
              className="w-full sm:w-48 px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <option value="">كل المدن</option>
              <option value="دنقلا">دنقلا</option>
              <option value="الخرطوم">الخرطوم</option>
              <option value="أم درمان">أم درمان</option>
              <option value="بحري">بحري</option>
              <option value="بورتسودان">بورتسودان</option>
              <option value="ود مدني">ود مدني</option>
              <option value="كسلا">كسلا</option>
              <option value="القضارف">القضارف</option>
              <option value="عطبرة">عطبرة</option>
            </select>
          </div>
        </div>

        {loading ? (
          <LoadingSpinner text="جاري تحميل دليل المدرسين..." />
        ) : error ? <RequestError message={error} onRetry={() => setAttempt(a => a+1)} /> : teachers.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {teachers.map((teacher) => (
              <TeacherCard key={teacher.id} teacher={teacher} />
            ))}
          </div>
        ) : (
          <EmptyState
            title="ما في مدرسين مطابقين لبحثك حالياً"
            description="جرب إزالة فلتر المدينة، أو تواصل مع إدارة المنصة لترشيح أستاذ مناسب لمادتك."
            actionText="عرض كل المدرسين"
            actionHref="/teachers"
          />
        )}
        {!error && <Pagination pagination={pagination} onPage={setPage} disabled={loading} />}
      </main>

      <Footer />
    </div>
  );
}
