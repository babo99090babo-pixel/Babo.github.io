'use client';

import { useContact } from '@/lib/contact';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import CourseCard from '@/components/CourseCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import api from '@/lib/api';
import { HiUser, HiLocationMarker, HiAcademicCap, HiArrowSmRight } from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function TeacherProfilePage() {
  const contact = useContact();
  const { id } = useParams();
  const [teacher, setTeacher] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchTeacher() {
      try {
        const res = await api.get(`/teachers/${id}`);
        setTeacher(res.data);
      } catch (err) {
        console.error('Failed to load teacher:', err);
      } finally {
        setLoading(false);
      }
    }
    if (id) fetchTeacher();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner text="جاري تحميل ملف الأستاذ..." />
        </main>
        <Footer />
      </div>
    );
  }

  if (!teacher) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex flex-col items-center justify-center p-6 text-center">
          <h2 className="text-xl font-bold mb-2">الأستاذ غير متوفر</h2>
          <Link href="/teachers" className="text-sm font-bold text-orange-500 hover:underline">
            الرجوع لدليل المدرسين
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400 mb-6">
          <Link href="/teachers" className="hover:text-purple-600">
            دليل المدرسين
          </Link>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold">{teacher.name}</span>
        </div>

        {/* Profile Card */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm mb-10">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 text-center sm:text-right">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-orange-500 flex items-center justify-center text-white text-3xl font-black shadow-lg shadow-purple-900/30 flex-shrink-0">
              {teacher.name.charAt(0)}
            </div>
            <div className="flex-grow space-y-2">
              <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white font-cairo">
                {teacher.name}
              </h1>

              {teacher.qualifications && (
                <p className="text-sm text-purple-600 dark:text-purple-400 font-semibold flex items-center justify-center sm:justify-start gap-1.5">
                  <HiAcademicCap className="w-4 h-4" />
                  <span>{teacher.qualifications}</span>
                </p>
              )}

              {teacher.city && (
                <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center justify-center sm:justify-start gap-1">
                  <HiLocationMarker className="w-3.5 h-3.5 text-orange-500" />
                  <span>المدينة: {teacher.city}</span>
                </p>
              )}

              {teacher.bio && (
                <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed pt-2 max-w-2xl">
                  {teacher.bio}
                </p>
              )}

              <div className="pt-4 flex flex-wrap items-center justify-center sm:justify-start gap-3">
                <a
                  href={`${contact.whatsappBase}?text=${encodeURIComponent(
                    `السلام عليكم إدارة أستاذك، داير أحجز درس خاص مع الأستاذ: ${teacher.name}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm"
                >
                  <FaWhatsapp className="w-4 h-4" />
                  <span>طلب حجز مع الأستاذ عبر الإدارة</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Teacher's courses */}
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-6">
            الكورسات والدروس المتاحة مع {teacher.name}
          </h2>

          {teacher.courses?.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {teacher.courses.map((course) => (
                <CourseCard
                  key={course.id}
                  course={{ ...course, teacher: { name: teacher.name, city: teacher.city } }}
                />
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl border border-dashed border-gray-300 dark:border-indigo-950 text-center text-sm text-gray-500">
              لا توجد كورسات مجدولة حالياً لهذا الأستاذ. تواصل مع الإدارة لترتيب درس فردي.
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
