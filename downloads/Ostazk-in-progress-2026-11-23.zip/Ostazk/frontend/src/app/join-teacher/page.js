'use client';

import { useContact } from '@/lib/contact';
import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import api from '@/lib/api';
import toast from 'react-hot-toast';
import {
  HiAcademicCap,
  HiPhone,
  HiCheckCircle,
  HiInformationCircle,
  HiShieldCheck,
} from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function JoinTeacherPage() {
  const contact = useContact();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: '',
    stage: 'المرحلة الثانوية',
    city: 'الخرطوم',
    message: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const whatsappMessage =
    'السلام عليكم، أنا أستاذ وداير أنضم لمنصة أستاذك. اسمي: … المادة: … المرحلة: … المدينة: …';
  const whatsappUrl = `${contact.whatsappBase}?text=${encodeURIComponent(whatsappMessage)}`;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await api.post('/teacher-applications', formData);
      toast.success(res.data.message || 'تم إرسال طلبك بنجاح!');
      setSubmitted(true);
    } catch (err) {
      toast.error(err.friendlyMessage || 'حصل خطأ في إرسال الطلب');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Hero Section */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 text-xs font-bold mb-3">
            <HiAcademicCap className="w-4 h-4" />
            <span>للأساتذة والمعلمين</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-3 font-cairo">
            انضم لينا كأستاذ في منصة «أستاذك»
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
            نسعد بانضمام نخبة المعلمين في كل مدن السودان. نوفر لك أدوات متكاملة لإدارة دروسك الخاصة والمجموعات الحضورية والأونلاين.
          </p>
        </div>

        {/* Quick Contact Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-12">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-3 text-sm font-bold"
          >
            <FaWhatsapp className="w-6 h-6" />
            <span>اتواصل معانا في واتساب (رسالة جاهزة)</span>
          </a>

          <a
            href={contact.telephone}
            className="p-5 rounded-2xl border-2 border-orange-500 text-orange-600 dark:text-orange-400 hover:bg-orange-500/10 transition-all flex items-center justify-center gap-3 text-sm font-bold"
          >
            <HiPhone className="w-6 h-6" />
            <span dir="ltr">اتصل بالإدارة مباشرة ({contact.phone})</span>
          </a>
        </div>

        {/* Teacher Application Form */}
        <div className="p-6 sm:p-10 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-xl">
          <div className="mb-6 pb-6 border-b border-gray-200 dark:border-indigo-950/60">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">
              أو سجّل بيانات طلب الانضمام هنا
            </h2>
            <p className="text-xs text-gray-500 mt-1">
              سيتم مراجعة طلبك بواسطة الإدارة واعتماد حسابك وتحديد المواد والصفوف قبل نشره.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-center space-y-3">
              <HiCheckCircle className="w-12 h-12 text-emerald-500 mx-auto" />
              <h3 className="text-lg font-bold text-emerald-800 dark:text-emerald-300">
                تم استلام طلب انضمامك بنجاح!
              </h3>
              <p className="text-xs text-gray-600 dark:text-gray-300 max-w-md mx-auto leading-relaxed">
                سيتواصل معك فريق إدارة أستاذك قريباً عبر واتساب لاستكمال تفعيل ملفك وإدراج حصصك.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold mb-1">الاسم الكامل للأستاذ *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="مثال: أستاذ عثمان أحمد"
                    className="w-full px-3 py-2.5 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">رقم الهاتف والواتساب *</label>
                  <input
                    type="text"
                    required
                    dir="ltr"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="0991974489"
                    className="w-full px-3 py-2.5 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 text-right"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">المادة الدراسية *</label>
                  <input
                    type="text"
                    required
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="مثال: الرياضيات، الفيزياء، اللغة الإنجليزية..."
                    className="w-full px-3 py-2.5 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">المرحلة الدراسية *</label>
                  <select
                    value={formData.stage}
                    onChange={(e) => setFormData({ ...formData, stage: e.target.value })}
                    className="w-full px-3 py-2.5 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="المرحلة الابتدائية">المرحلة الابتدائية</option>
                    <option value="المرحلة المتوسطة">المرحلة المتوسطة</option>
                    <option value="المرحلة الثانوية">المرحلة الثانوية</option>
                    <option value="جميع المراحل">جميع المراحل</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">المدينة الحالية *</label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="مثال: الخرطوم، بورتسودان، ود مدني..."
                    className="w-full px-3 py-2.5 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">البريد الإلكتروني (اختياري)</label>
                  <input
                    type="email"
                    dir="ltr"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@example.com"
                    className="w-full px-3 py-2.5 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 text-right"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">نبذة عن خبراتك ومؤهلاتك (اختياري)</label>
                <textarea
                  rows="3"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="سنوات الخبرة، المدارس والمراكز السابقة، طرق التدريس المفضلة..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                ></textarea>
              </div>

              <div className="p-3 rounded-xl bg-purple-500/10 text-purple-700 dark:text-purple-300 text-xs flex items-center gap-2">
                <HiInformationCircle className="w-5 h-5 flex-shrink-0" />
                <span>
                  إرسال هذا النموذج يحفظ طلبك بحالة «بانتظار المراجعة». سيتم التدقيق والتواصل معك قبل تفعيل الحساب رسمياً.
                </span>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-md shadow-orange-500/25 transition-all text-xs sm:text-sm disabled:opacity-50"
              >
                {submitting ? 'جاري إرسال الطلب...' : 'إرسال طلب الانضمام للإدارة'}
              </button>
            </form>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
