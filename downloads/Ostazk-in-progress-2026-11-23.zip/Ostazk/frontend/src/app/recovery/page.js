'use client';

import { useContact } from '@/lib/contact';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import { HiShieldExclamation, HiPhone, HiArrowSmRight } from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function PasswordRecoveryPage() {
  const contact = useContact();
  const whatsappUrl =
    contact.whatsappBase + '?text=' +
    encodeURIComponent(
      'السلام عليكم إدارة منصة أستاذك، نسيت كلمة السر لحسابي.\nاسمي الرباعي: ...\nرقم الهاتف المسجل: ...\nرقم هاتف ولي الأمر: ...'
    );

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-lg p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center mx-auto mb-4">
            <HiShieldExclamation className="w-8 h-8" />
          </div>

          <h1 className="text-2xl font-black text-center text-gray-900 dark:text-white mb-2 font-cairo">
            استعادة كلمة السر لحساب الطالب
          </h1>

          <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-xs sm:text-sm text-purple-900 dark:text-purple-200 leading-relaxed mb-6 space-y-2">
            <p className="font-bold">حفاظاً على أمان وسرية بياناتك الأكاديمية:</p>
            <ul className="list-disc list-inside space-y-1 text-xs text-gray-700 dark:text-gray-300">
              <li>استعادة كلمة السر تتم يدوياً بالتحقق من هوية الطالب عبر الإدارة.</li>
              <li>لا تقم بإرسال أي كلمة سر قديمة عبر واتساب نهائياً.</li>
              <li>ستصدر الإدارة رابط استعادة مؤقت خاص بك، صالح للاستخدام مرة واحدة فقط لمدة ٣٠ دقيقة.</li>
            </ul>
          </div>

          <div className="space-y-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 px-4 rounded-2xl font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-600/25 transition-all text-xs sm:text-sm flex items-center justify-center gap-2"
            >
              <FaWhatsapp className="w-5 h-5" />
              <span>مراسلة الإدارة عبر واتساب لاستعادة الحساب</span>
            </a>

            <a
              href={contact.telephone}
              className="w-full py-3 px-4 rounded-2xl font-bold border border-gray-300 dark:border-indigo-950 text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-navy-800 transition-all text-xs sm:text-sm flex items-center justify-center gap-2"
            >
              <HiPhone className="w-4 h-4 text-orange-500" />
              <span dir="ltr">الاتصال الهاتفي بالإدارة ({contact.phone})</span>
            </a>
          </div>

          <div className="mt-8 pt-4 border-t border-gray-200 dark:border-indigo-950/60 text-center">
            <Link
              href="/login"
              className="inline-flex items-center gap-1 text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline"
            >
              <span>الرجوع لصفحة تسجيل الدخول</span>
              <HiArrowSmRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
