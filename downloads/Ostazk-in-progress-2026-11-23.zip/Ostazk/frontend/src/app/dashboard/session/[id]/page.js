'use client';

import { useContact } from '@/lib/contact';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useAuthStore } from '@/lib/store';
import api from '@/lib/api';
import toast from 'react-hot-toast';
import {
  HiVideoCamera,
  HiClock,
  HiExclamationCircle,
  HiCheckCircle,
  HiArrowSmRight,
  HiInformationCircle,
} from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function OnlineSessionPage() {
  const contact = useContact();
  const { id } = useParams();
  const router = useRouter();
  const { isAuthenticated, checkAuth, authError } = useAuthStore();

  const [loading, setLoading] = useState(true);
  const [streamData, setStreamData] = useState(null);
  const [inCall, setInCall] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');


  const handleJoin = async () => {
    setLoading(true);
    const std = await checkAuth(true);
    if (!std) {
      if (std === null) router.replace(`/login?redirect=${encodeURIComponent(`/dashboard/session/${id}`)}`);
      else setStatusMessage('تعذر التحقق من حسابك. حاول تاني بعد استعادة الاتصال.');
      setLoading(false); return;
    }
    try {
      const res = await api.post(`/student/sessions/${id}/join`);
      setStreamData(res.data);
      if (res.data.streamConfigured) {
        setInCall(true);
      } else {
        setStatusMessage(res.data.message || 'خدمة البث غير مُعدّة حالياً');
      }
    } catch (err) {
      toast.error(err.friendlyMessage || 'تعذر دخول الحصة حالياً');
      setStatusMessage(err.friendlyMessage || 'تعذر الدخول');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    setStreamData(null); setInCall(false); setLoading(true);
    checkAuth().then((std) => {
      if (!active) return;
      if (std === null) { router.replace(`/login?redirect=${encodeURIComponent(`/dashboard/session/${id}`)}`); return; }
      if (std) handleJoin();
      else { setStatusMessage('تعذر التحقق من حسابك. تأكد من الاتصال وحاول تاني.'); setLoading(false); }
    });
    return () => { active = false; };
  }, [id, checkAuth, router]);

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 mb-6">
          <Link href="/dashboard" className="hover:text-purple-600">
            لوحة الطالب
          </Link>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold">قاعة الحصة المباشرة</span>
        </div>

        {loading ? (
          <LoadingSpinner text="جاري التحقق من صلاحية الاشتراك وموعد الحصة..." />
        ) : inCall && streamData?.streamConfigured ? (
          /* Live call frame */
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-2xl bg-purple-950 text-white">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                <h1 className="text-sm sm:text-base font-bold">
                  {streamData.sessionInfo?.title || 'الحصة المباشرة'}
                </h1>
              </div>
              <button
                onClick={() => setInCall(false)}
                className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold"
              >
                مغادرة القاعة
              </button>
            </div>

            {/* Jitsi Meet iframe integration */}
            <div className="w-full h-[650px] rounded-3xl overflow-hidden shadow-2xl border border-gray-200 dark:border-indigo-950 bg-black">
              <iframe
                src={`https://${streamData.domain}/${encodeURIComponent(streamData.roomName)}?jwt=${encodeURIComponent(streamData.meetingToken)}#userInfo.displayName=${encodeURIComponent(streamData.studentName || 'طالب أستاذك')}`}
                allow="camera; microphone; fullscreen; display-capture; autoplay"
                title="قاعة الدرس المباشر"
                className="w-full h-full border-0"
              />
            </div>
          </div>
        ) : (
          /* Pre-call or setup notice card */
          <div className="max-w-2xl mx-auto p-6 sm:p-10 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-2xl text-center space-y-6">
            <div className="w-16 h-16 rounded-3xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center mx-auto">
              <HiVideoCamera className="w-8 h-8" />
            </div>

            <div>
              <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-2 font-cairo">
                {streamData?.sessionInfo?.title || 'قاعة الدرس الأونلاين'}
              </h1>
              <p className="text-xs text-gray-500">
                منصة أستاذك للبث المباشر الموثق
              </p>
            </div>

            {statusMessage && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-300 text-xs text-right leading-relaxed flex items-start gap-2.5">
                <HiInformationCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold mb-1">حالة البث:</p>
                  <p>{statusMessage}</p>
                </div>
              </div>
            )}

            {!streamData?.streamConfigured && <p className="text-sm text-gray-600 dark:text-gray-300">إذا حان موعد الحصة ولم تتمكن من الدخول، تواصل مع الإدارة لمساعدتك.</p>}

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleJoin}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-md text-xs sm:text-sm"
              >
                إعادة محاولة الدخول
              </button>

              <a
                href={`${contact.whatsappBase}?text=${encodeURIComponent(
                  `السلام عليكم إدارة أستاذك، داير مساعدة بخصوص دخول حصة أونلاين برقم: ${id}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-5 py-3 rounded-2xl font-bold border border-emerald-600/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-600/10 text-xs sm:text-sm flex items-center justify-center gap-2"
              >
                <FaWhatsapp className="w-4 h-4" />
                <span>طلب مساعدة من الإدارة على واتساب</span>
              </a>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
