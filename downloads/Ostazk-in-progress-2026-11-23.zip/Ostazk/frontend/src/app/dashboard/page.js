'use client';

import { useContact } from '@/lib/contact';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import LoadingSpinner from '@/components/LoadingSpinner';
import BookCard from '@/components/BookCard';
import { useAuthStore } from '@/lib/store';
import api from '@/lib/api';
import RequestError from '@/components/RequestError';
import { passwordError } from '@/lib/password';
import toast from 'react-hot-toast';
import {
  HiAcademicCap,
  HiClock,
  HiKey,
  HiBookOpen,
  HiBookmark,
  HiUser,
  HiVideoCamera,
  HiLocationMarker,
  HiCheckCircle,
  HiExclamationCircle,
} from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function StudentDashboardPage() {
  const contact = useContact();
  const router = useRouter();
  const { student, isAuthenticated, isLoading, checkAuth, authError } = useAuthStore();

  const [activeTab, setActiveTab] = useState('courses'); // courses, sessions, bookings, books, activate, profile
  const [subscriptions, setSubscriptions] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [bookmarks, setBookmarks] = useState([]);
  const [stages, setStages] = useState([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [dataErrors, setDataErrors] = useState({});
  const [attempt, setAttempt] = useState(0);
  const reloadData = () => setAttempt(value => value + 1);

  // Activation code form
  const [activationCode, setActivationCode] = useState('');
  const [activating, setActivating] = useState(false);

  // Profile edit form
  const [profileStageId, setProfileStageId] = useState('');
  const [profileGradeId, setProfileGradeId] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Change password form
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);

  useEffect(() => {
    checkAuth().then((std) => {
      if (std === null) {
        router.push('/login?redirect=/dashboard');
      }
    });
  }, [checkAuth, router]);

  useEffect(() => {
    if (student) {
      setProfileStageId(student.stageId || '');
      setProfileGradeId(student.gradeId || '');
    }
  }, [student]);

  useEffect(() => {
    async function loadDashboardData() {
      if (!isAuthenticated) return;
      setDataLoading(true);
      setDataErrors({});
      try {
        const [subsRes, sessRes, bookRes, bkmkRes, stagesRes] = await Promise.allSettled([
          api.get('/student/subscriptions'),
          api.get('/student/sessions'),
          api.get('/student/bookings'),
          api.get('/student/bookmarks'),
          api.get('/stages'),
        ]);

        if (subsRes.status === 'fulfilled') setSubscriptions(subsRes.value.data || []);
        if (sessRes.status === 'fulfilled') setSessions(sessRes.value.data || []);
        if (bookRes.status === 'fulfilled') setBookings(bookRes.value.data || []);
        if (bkmkRes.status === 'fulfilled') setBookmarks(bkmkRes.value.data || []);
        if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data || []);
        const errors = {};
        for (const [key, result] of [['courses', subsRes], ['sessions', sessRes], ['bookings', bookRes], ['books', bkmkRes], ['profile', stagesRes]]) {
          if (result.status === 'rejected') errors[key] = result.reason.friendlyMessage;
        }
        setDataErrors(errors);
      } catch (err) {
        console.error('Error loading dashboard:', err);
      } finally {
        setDataLoading(false);
      }
    }

    if (isAuthenticated) {
      loadDashboardData();
    }
  }, [isAuthenticated, attempt]);

  const handleActivateCode = async (e) => {
    e.preventDefault();
    if (!activationCode.trim()) {
      toast.error('اكتب رمز التفعيل');
      return;
    }

    setActivating(true);
    try {
      const res = await api.post('/student/activate', { code: activationCode.trim() });
      toast.success(res.data.message || 'تم تفعيل اشتراكك بنجاح!');
      setActivationCode('');
      reloadData();
      setActiveTab('courses');
    } catch (err) {
      toast.error(err.friendlyMessage || 'الرمز ما صالح للحساب دا أو انتهت صلاحيته.');
    } finally {
      setActivating(false);
    }
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const res = await api.put('/auth/profile', {
        stageId: profileStageId || null,
        gradeId: profileGradeId || null,
      });
      toast.success(res.data.message || 'تم تحديث بياناتك');
      checkAuth(true);
    } catch (err) {
      toast.error(err.friendlyMessage || 'حصل خطأ في التحديث');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    const validationError = passwordError(newPassword);
    if (validationError) { toast.error(validationError); return; }
    if (newPassword !== confirmNewPassword) {
      toast.error('كلمتي السر غير متطابقتين');
      return;
    }
    setChangingPassword(true);
    try {
      const res = await api.post('/auth/change-password', {
        currentPassword,
        newPassword,
        confirmNewPassword,
      });
      toast.success(res.data.message || 'تم تغيير كلمة السر بنجاح');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      await checkAuth(true);
    } catch (err) {
      toast.error(err.friendlyMessage || 'حصل خطأ في تغيير كلمة السر');
    } finally {
      setChangingPassword(false);
    }
  };

  if (authError) {
    return <div className="min-h-screen bg-white dark:bg-navy-950"><Header/><main className="max-w-3xl mx-auto p-6"><RequestError message={authError} onRetry={() => checkAuth(true).then(result => { if (result === null) router.replace('/login?redirect=/dashboard'); })}/></main><Footer/></div>;
  }

  if (isLoading || !student) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner text="جاري تحميل لوحة الطالب..." />
        </main>
        <Footer />
      </div>
    );
  }

  const selectedStage = stages.find((s) => s.id === Number(profileStageId));
  const gradesForStage = selectedStage?.grades || [];

  const bookingStatusLabels = {
    PENDING_CONTACT: { label: 'بانتظار التواصل', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400' },
    PENDING_CONFIRMATION: { label: 'بانتظار التأكيد', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400' },
    CONFIRMED: { label: 'حجز مؤكد', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
    CANCELLED: { label: 'ملغي', color: 'bg-red-500/10 text-red-600 dark:text-red-400' },
    WAITLISTED: { label: 'في قائمة الانتظار', color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Student Banner */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-900 via-navy-900 to-indigo-900 text-white shadow-xl mb-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center sm:text-right">
            <div className="w-16 h-16 rounded-2xl bg-orange-500 flex items-center justify-center text-2xl font-black text-white shadow-lg shadow-orange-500/30 flex-shrink-0">
              {student.fullName ? student.fullName.charAt(0) : 'ط'}
            </div>
            <div>
              <span className="text-xs font-semibold text-purple-300 block">أهلاً بيك يا</span>
              <h1 className="text-xl sm:text-2xl font-black font-cairo">
                {student.fullName}
              </h1>
              <p className="text-xs text-gray-300 mt-0.5">
                {student.grade?.name ? `${student.grade.name} (${student.stage?.name})` : 'لم يتم تحديد الصف بعد'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('activate')}
              className="px-4 py-2.5 rounded-xl font-bold text-xs bg-orange-500 hover:bg-orange-600 text-white shadow-md shadow-orange-500/25 transition-all flex items-center gap-2"
            >
              <HiKey className="w-4 h-4" />
              <span>فعّل رمز درسك</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex overflow-x-auto no-scrollbar gap-2 pb-2 mb-8 border-b border-gray-200 dark:border-indigo-950/70">
          {[
            { id: 'courses', label: 'دروسي واشتراكاتي', icon: HiAcademicCap, count: subscriptions.length },
            { id: 'sessions', label: 'حصصي الجاية', icon: HiClock, count: sessions.length },
            { id: 'bookings', label: 'حجوزاتي', icon: HiCheckCircle, count: bookings.length },
            { id: 'books', label: 'كتبي المحفوظة', icon: HiBookmark, count: bookmarks.length },
            { id: 'activate', label: 'فعّل رمزك', icon: HiKey },
            { id: 'profile', label: 'حسابي وبياناتي', icon: HiUser },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-navy-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full ${
                      isActive ? 'bg-white/20 text-white' : 'bg-gray-200 dark:bg-navy-800 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <RequestError message={dataErrors[activeTab]} onRetry={reloadData}/>

        {/* Tab 1: Subscriptions (دروسي) */}
        {activeTab === 'courses' && !dataErrors.courses && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg sm:text-xl font-bold">الدروس والكورسات المشترك فيها</h2>
              <Link href="/courses" className="text-xs font-bold text-orange-500 hover:underline">
                استكشف كورسات جديدة
              </Link>
            </div>

            {dataLoading ? (
              <LoadingSpinner />
            ) : subscriptions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {subscriptions.map((sub) => {
                  const course = sub.courseGroup?.course;
                  return (
                    <div
                      key={sub.id}
                      className="p-5 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                            {sub.status === 'ACTIVE' && new Date(sub.endDate) > new Date() ? 'اشتراك فعّال' : 'اشتراك غير فعّال'}
                          </span>
                          <span className="text-xs text-gray-500">
                            ينتهي: {new Date(sub.endDate).toLocaleDateString('ar-SD')}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-gray-900 dark:text-white mb-2">
                          {course?.title}
                        </h3>
                        <p className="text-xs text-gray-500 mb-3">
                          المجموعة: {sub.courseGroup?.name} • الأستاذ: {course?.teacher?.name}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-gray-100 dark:border-indigo-950/50 flex items-center gap-2">
                        <Link
                          href={`/courses/${course?.id}`}
                          className="w-full text-center py-2 px-3 rounded-xl text-xs font-bold bg-purple-600/10 text-purple-600 dark:text-purple-400 hover:bg-purple-600/20 transition-colors"
                        >
                          تفاصيل الكورس والمواعيد
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-10 rounded-3xl bg-gray-50 dark:bg-navy-900/40 border border-dashed border-gray-300 dark:border-indigo-950 text-center max-w-lg mx-auto">
                <p className="text-sm font-bold text-gray-800 dark:text-gray-200 mb-2">
                  لسه ما عندك اشتراكات مفعلة!
                </p>
                <p className="text-xs text-gray-500 mb-6">
                  احجز درسك، أو لو الإدارة أرسلت ليك رمز تفعيل على واتساب، اضغط على «فعّل رمزك» تحت.
                </p>
                <div className="flex justify-center gap-3">
                  <button
                    onClick={() => setActiveTab('activate')}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-orange-500"
                  >
                    تفعيل رمز الاشتراك
                  </button>
                  <Link
                    href="/courses"
                    className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950 text-gray-700 dark:text-gray-300"
                  >
                    تصفح الدروس
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Upcoming Sessions (حصصي الجاية) */}
        {activeTab === 'sessions' && !dataErrors.sessions && (
          <div>
            <h2 className="text-lg sm:text-xl font-bold mb-6">الحصص القادمة المجدولة</h2>

            {dataLoading ? (
              <LoadingSpinner />
            ) : sessions.length > 0 ? (
              <div className="space-y-4">
                {sessions.map((sess) => {
                  const isOnline = sess.courseGroup?.course?.teachingMethod?.includes('ONLINE');
                  return (
                    <div
                      key={sess.id}
                      className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                              isOnline
                                ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400'
                                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                            }`}
                          >
                            {isOnline ? 'أونلاين عبر المنصة' : 'حضوري'}
                          </span>
                          <span className="text-xs font-semibold text-gray-500">
                            الحصة رقم {sess.sessionNumber}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-gray-900 dark:text-white">
                          {sess.courseGroup?.course?.title}
                        </h3>
                        <p className="text-xs text-gray-500 flex items-center gap-1.5">
                          <HiClock className="w-4 h-4 text-orange-500" />
                          <span>
                            {new Date(sess.date).toLocaleDateString('ar-SD')} من {sess.startTime} إلى {sess.endTime} (بتوقيت السودان)
                          </span>
                        </p>
                        {!isOnline && sess.location?.location && (
                          <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-1">
                            <HiLocationMarker className="w-4 h-4 flex-shrink-0" />
                            <span>
                              {sess.location.location.venueName} - {sess.location.location.area}، {sess.location.location.address}
                            </span>
                          </p>
                        )}
                      </div>

                      <div>
                        {isOnline ? (
                          <Link
                            href={`/dashboard/session/${sess.id}`}
                            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-sm"
                          >
                            <HiVideoCamera className="w-4 h-4" />
                            <span>دخول قاعة الحصة</span>
                          </Link>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-bold bg-gray-100 dark:bg-navy-800 text-gray-700 dark:text-gray-300">
                            <HiCheckCircle className="w-4 h-4 text-emerald-500" />
                            <span>حضور في المركز</span>
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-gray-500 text-center py-8">
                ما عندك حصص قادمة مجدولة حالياً.
              </p>
            )}
          </div>
        )}

        {/* Tab 3: Bookings (حجوزاتي) */}
        {activeTab === 'bookings' && !dataErrors.bookings && (
          <div>
            <h2 className="text-lg sm:text-xl font-bold mb-6">سجل طلبات الحجز</h2>

            {dataLoading ? (
              <LoadingSpinner />
            ) : bookings.length > 0 ? (
              <div className="space-y-4">
                {bookings.map((booking) => {
                  const statusInfo =
                    bookingStatusLabels[booking.status] || {
                      label: booking.status,
                      color: 'bg-gray-500/10 text-gray-500',
                    };
                  const course = booking.courseGroup?.course;

                  return (
                    <div
                      key={booking.id}
                      className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${statusInfo.color}`}>
                            {statusInfo.label}
                          </span>
                          <span className="text-[11px] text-gray-400">
                            بتاريخ {new Date(booking.createdAt).toLocaleDateString('ar-SD')}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-gray-900 dark:text-white">
                          {course?.title}
                        </h3>
                        <p className="text-xs text-gray-500">
                          المجموعة: {booking.courseGroup?.name} • المدرس: {course?.teacher?.name}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        {booking.status === 'PENDING_CONTACT' && (
                          <a
                            href={`${contact.whatsappBase}?text=${encodeURIComponent(
                              `السلام عليكم إدارة أستاذك، أنا الطالب: ${student.fullName}\nرقم الحجز: ${booking.id}\nوداير أكد حجزي في كورس: "${course?.title}"`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                          >
                            <FaWhatsapp className="w-4 h-4" />
                            <span>تأكيد الحجز عبر واتساب</span>
                          </a>
                        )}
                        <Link
                          href={`/courses/${course?.id}`}
                          className="px-3 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950 text-gray-700 dark:text-gray-300"
                        >
                          تفاصيل
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-gray-500 text-center py-8">
                ما عملت أي طلب حجز حتى الآن.
              </p>
            )}
          </div>
        )}

        {/* Tab 4: Bookmarks (كتبي المحفوظة) */}
        {activeTab === 'books' && !dataErrors.books && (
          <div>
            <h2 className="text-lg sm:text-xl font-bold mb-6">المذكرات والكتب المحفوظة في مفضلتي</h2>

            {dataLoading ? (
              <LoadingSpinner />
            ) : bookmarks.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {bookmarks.map((b) => (
                  <BookCard key={b.book.id} book={b.book} />
                ))}
              </div>
            ) : (
              <p className="text-xs text-gray-500 text-center py-8">
                ما حفظت أي كتاب في مفضلتك. تصفح المكتبة واضغط «حفظ في المفضلة».
              </p>
            )}
          </div>
        )}

        {/* Tab 5: Code Activation (فعّل رمزك) */}
        {activeTab === 'activate' && (
          <div className="max-w-xl mx-auto p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center mx-auto mb-4">
              <HiKey className="w-7 h-7" />
            </div>

            <h2 className="text-2xl font-black text-center text-gray-900 dark:text-white mb-2 font-cairo">
              عندك رمز اشتراك؟ فعّله هنا
            </h2>
            <p className="text-xs text-center text-gray-500 dark:text-gray-400 mb-6 leading-relaxed">
              اكتب رمز التفعيل المرسل ليك من إدارة أستاذك على واتساب لتفعيل اشتراكك في الكورس فوراً.
            </p>

            <form onSubmit={handleActivateCode} className="space-y-4">
              <div>
                <input
                  type="text"
                  required
                  value={activationCode}
                  onChange={(e) => setActivationCode(e.target.value)}
                  placeholder="مثال: ABCD-EFGH-JKLM"
                  dir="ltr"
                  className="w-full px-4 py-3.5 text-center text-lg font-black tracking-widest rounded-2xl border-2 border-purple-500/40 dark:border-indigo-900 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:border-orange-500 uppercase"
                />
              </div>

              <button
                type="submit"
                disabled={activating}
                className="w-full py-3.5 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 transition-all disabled:opacity-50 text-sm"
              >
                {activating ? 'جاري التحقق والتفعيل...' : 'تفعيل الاشتراك الآن'}
              </button>
            </form>

            <div className="mt-8 pt-6 border-t border-gray-100 dark:border-indigo-950/60 text-center">
              <p className="text-xs text-gray-500 mb-2">لسه ما عندك رمز؟ أو حجزت وما استلمت الرمز؟</p>
              <a
                href={`${contact.whatsappBase}?text=السلام%20عليكم،%20داير%20استلم%20رمز%20تفعيل%20اشتراكي%20في%20أستاذك`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
              >
                <FaWhatsapp className="w-4 h-4" />
                <span>اتواصل مع الإدارة على واتساب للحصول على رمزك</span>
              </a>
            </div>
          </div>
        )}

        {/* Tab 6: Profile & Settings (حسابي) */}
        {activeTab === 'profile' && (
          <div className="max-w-2xl mx-auto space-y-8">
            {/* Academic Grade Customization */}
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                تخصيص المرحلة والصف الدراسي
              </h2>
              <p className="text-xs text-gray-500 mb-6">
                اختيار صفك بيساعدنا نخصص ليك الصفحة الرئيسية والدروس والكتب المناسبة ليك تلقائياً.
              </p>

              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold mb-1">المرحلة الدراسية</label>
                    <select
                      value={profileStageId}
                      onChange={(e) => {
                        setProfileStageId(e.target.value);
                        setProfileGradeId('');
                      }}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-800 dark:text-gray-200"
                    >
                      <option value="">اختار المرحلة</option>
                      {stages.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold mb-1">الصف الدراسي</label>
                    <select
                      value={profileGradeId}
                      onChange={(e) => setProfileGradeId(e.target.value)}
                      disabled={!profileStageId}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-800 dark:text-gray-200 disabled:opacity-50"
                    >
                      <option value="">اختار الصف</option>
                      {gradesForStage.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={savingProfile}
                  className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-purple-600 hover:bg-purple-700 transition-colors"
                >
                  {savingProfile ? 'جاري الحفظ...' : 'حفظ التخصيص'}
                </button>
              </form>
            </div>

            {/* Account Contact Info (read-only verification) */}
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm space-y-3 text-xs">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                بيانات الحساب المسجلة
              </h2>
              <div className="flex justify-between py-2 border-b border-gray-100 dark:border-indigo-950/60">
                <span className="text-gray-500">الاسم الرباعي:</span>
                <span className="font-bold text-gray-900 dark:text-white">{student.fullName}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100 dark:border-indigo-950/60">
                <span className="text-gray-500">رقم هاتف الطالب:</span>
                <span className="font-bold text-gray-900 dark:text-white" dir="ltr">{student.phone}</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-gray-500">رقم هاتف ولي الأمر:</span>
                <span className="font-bold text-gray-900 dark:text-white" dir="ltr">{student.parentPhone}</span>
              </div>
            </div>

            {/* Change Password */}
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                تغيير كلمة السر
              </h2>

              <form onSubmit={handleChangePassword} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold mb-1">كلمة السر الحالية</label>
                  <input
                    type="password"
                    required
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-800 dark:text-gray-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">كلمة السر الجديدة</label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="٨ أحرف على الأقل"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-800 dark:text-gray-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">تأكيد كلمة السر الجديدة</label>
                  <input
                    type="password"
                    required
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-800 dark:text-gray-200"
                  />
                </div>

                <button
                  type="submit"
                  disabled={changingPassword}
                  className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-orange-500 hover:bg-orange-600 transition-colors"
                >
                  {changingPassword ? 'جاري التحديث...' : 'تحديث كلمة السر'}
                </button>
              </form>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
