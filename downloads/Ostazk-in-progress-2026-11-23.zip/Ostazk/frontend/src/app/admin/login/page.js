'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAdminAuthStore } from '@/lib/store';
import api from '@/lib/api';
import toast from 'react-hot-toast';
import { HiShieldCheck, HiMail, HiLockClosed, HiEye, HiEyeOff } from 'react-icons/hi';

export default function AdminLoginPage() {
  const router = useRouter();
  const { setAdmin } = useAdminAuthStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('أدخل البريد الإلكتروني وكلمة السر');
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/admin/auth/login', { email, password });
      setAdmin(res.data.admin);
      toast.success(res.data.message || 'تم تسجيل دخول المدير بنجاح');
      router.push('/admin/dashboard');
    } catch (err) {
      toast.error(err.friendlyMessage || 'البريد أو كلمة السر غير صحيحة');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-navy-950 text-white font-cairo" dir="rtl">
      <div className="w-full max-w-md p-8 rounded-3xl bg-navy-900 border border-indigo-950 shadow-2xl">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center mx-auto mb-3">
            <HiShieldCheck className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white">
            لوحة إدارة أستاذك
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            تسجيل دخول مصرح لمدراء المنصة فقط
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">
              البريد الإلكتروني للمدير
            </label>
            <div className="relative">
              <input
                type="email"
                required
                dir="ltr"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="babo99090babo@gmail.com"
                className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-indigo-950 bg-navy-950 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 text-right"
              />
              <HiMail className="w-4 h-4 text-gray-500 absolute right-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">
              كلمة السر
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل كلمة السر"
                className="w-full px-4 py-2.5 pr-10 pl-10 text-xs sm:text-sm rounded-xl border border-indigo-950 bg-navy-950 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <HiLockClosed className="w-4 h-4 text-gray-500 absolute right-3.5 top-3" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-3.5 top-3 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <HiEyeOff className="w-4 h-4" /> : <HiEye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 transition-all text-xs sm:text-sm disabled:opacity-50 mt-2 shadow-lg shadow-purple-600/30"
          >
            {loading ? 'جاري التحقق...' : 'دخول لوحة التحكم'}
          </button>
        </form>

        <div className="mt-8 pt-4 border-t border-indigo-950/70 text-center">
          <Link href="/" className="text-xs text-gray-400 hover:text-white transition-colors">
            ← الرجوع للموقع الرئيسي
          </Link>
        </div>
      </div>
    </div>
  );
}
