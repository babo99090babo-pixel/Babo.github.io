'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAdminAuthStore } from '@/lib/store';
import api from '@/lib/api';
import toast from 'react-hot-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
import RequestError from '@/components/RequestError';
import Pagination from '@/components/Pagination';
import AdminTeacherForm from '@/components/AdminTeacherForm';
import AdminCourseGroups from '@/components/AdminCourseGroups';
import AdminEntitySelect from '@/components/AdminEntitySelect';
import AdminBookingSelect from '@/components/AdminBookingSelect';
import {
  HiUsers,
  HiAcademicCap,
  HiBookOpen,
  HiKey,
  HiClipboardList,
  HiCog,
  HiChartBar,
  HiLogout,
  HiPlus,
  HiCheck,
  HiX,
  HiSearch,
  HiShieldCheck,
  HiDocumentDownload,
  HiRefresh,
} from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function AdminDashboardPage() {
  const router = useRouter();
  const { admin, isAdminAuthenticated, isAdminLoading, adminAuthError, checkAdminAuth, adminLogout } =
    useAdminAuthStore();

  const [activeTab, setActiveTab] = useState('overview'); // overview, students, teachers, courses, bookings, codes, books, settings, reports
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  // Data lists
  const [students, setStudents] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [teacherApps, setTeacherApps] = useState([]);
  const [courses, setCourses] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [activationCodes, setActivationCodes] = useState([]);
  const [books, setBooks] = useState([]);
  const [stages, setStages] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [settings, setSettings] = useState({});

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [pages, setPages] = useState({});
  const [pagination, setPagination] = useState({});
  const [listErrors, setListErrors] = useState({});
  const [listBusy, setListBusy] = useState({});
  const [reloadVersion, setReloadVersion] = useState(0);
  const [dashboardError, setDashboardError] = useState('');
  const [saving, setSaving] = useState('');
  const [formError, setFormError] = useState('');
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [codeTargetBooking, setCodeTargetBooking] = useState(null);
  const reloadLists = () => setReloadVersion(version => version + 1);
  const setListPage = (key, page) => setPages(previous => ({ ...previous, [key]: page }));
  const listFooter = key => <div>
    {listBusy[key] && <p role="status" className="text-sm text-gray-500 py-3">جاري تحميل البيانات...</p>}
    <RequestError message={listErrors[key]} onRetry={reloadLists}/>
    <Pagination pagination={pagination[key]} onPage={page => setListPage(key, page)} disabled={listBusy[key]} label={`صفحات ${key}`}/>
  </div>;

  // Modals & form states
  const [showNewCodeModal, setShowNewCodeModal] = useState(false);
  const [codeTargetStudentId, setCodeTargetStudentId] = useState('');
  const [codeTargetBookingId, setCodeTargetBookingId] = useState('');
  const [generatedCodes, setGeneratedCodes] = useState([]);

  // New Course modal state
  const [showNewCourseModal, setShowNewCourseModal] = useState(false);
  const [newCourse, setNewCourse] = useState({
    title: '',
    description: '',
    subjectId: '',
    gradeId: '',
    teacherId: '',
    teachingMethod: 'GROUP_ONLINE',
    totalSessions: 8,
    sessionDurationMinutes: 60,
  });

  // New Book modal state
  const [showNewBookModal, setShowNewBookModal] = useState(false);
  const [newBook, setNewBook] = useState({
    title: '',
    description: '',
    subjectId: '',
    gradeId: '',
    year: '2025/2026',
    edition: 'الأولى',
    accessLevel: 'PUBLIC',
    courseId: '',
    allowDownload: true,
    status: 'PUBLISHED',
  });
  const [bookFile, setBookFile] = useState(null);

  // Settings state
  const [contactPhone, setContactPhone] = useState('0991974489');
  const [contactWhatsapp, setContactWhatsapp] = useState('https://wa.me/249991974489');
  const [platformSlogan, setPlatformSlogan] = useState('أستاذك معاك… تعلّم بالطريقة البتناسبك');

  useEffect(() => {
    checkAdminAuth().then((adm) => {
      if (adm === null) {
        router.push('/admin/login');
      }
    });
  }, [checkAdminAuth, router]);

  // Load Dashboard statistics
  const loadDashboardData = async () => {
    setLoading(true);
    setDashboardError('');
    try {
      const [dashRes, stagesRes, subjectsRes, settingsRes] = await Promise.allSettled([
        api.get('/admin/dashboard'),
        api.get('/admin/stages'),
        api.get('/admin/subjects'),
        api.get('/admin/settings'),
      ]);

      const failed = [dashRes, stagesRes, subjectsRes, settingsRes].filter(result => result.status === 'rejected');
      if (failed.length) setDashboardError(failed[0].reason.friendlyMessage || 'تعذر تحميل بعض بيانات الإدارة. أعد المحاولة.');
      if (dashRes.status === 'fulfilled') setStats(dashRes.value.data.stats);
      if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data || []);
      if (subjectsRes.status === 'fulfilled') setSubjects(subjectsRes.value.data || []);
      if (settingsRes.status === 'fulfilled') {
        const s = settingsRes.value.data || {};
        setSettings(s);
        if (s.contact_phone) setContactPhone(s.contact_phone);
        if (s.contact_whatsapp) setContactWhatsapp(s.contact_whatsapp);
        if (s.platform_slogan) setPlatformSlogan(s.platform_slogan);
      }
    } catch (err) {
      setDashboardError(err.friendlyMessage || 'تعذر تحميل بيانات الإدارة');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdminAuthenticated) {
      loadDashboardData();
    }
  }, [isAdminAuthenticated]);

  // Keep independent page state for every list, including teacher applications.
  useEffect(() => {
    if (!isAdminAuthenticated) return;
    let active = true;
    const resources = {
      students: ['/admin/students', 'students', setStudents],
      teachers: ['/admin/teachers', 'teachers', setTeachers],
      teacherApps: ['/admin/teacher-applications', 'applications', setTeacherApps],
      courses: ['/admin/courses', 'courses', setCourses],
      bookings: ['/admin/bookings', 'bookings', setBookings],
      codes: ['/admin/activation-codes', 'codes', setActivationCodes],
      books: ['/admin/books', 'books', setBooks],
    };
    const keys = activeTab === 'teachers' ? ['teachers', 'teacherApps'] : resources[activeTab] ? [activeTab] : [];
    const timer = setTimeout(() => {
      keys.forEach(async key => {
        const [endpoint, responseKey, setRows] = resources[key];
        setListBusy(previous => ({ ...previous, [key]: true }));
        setListErrors(previous => ({ ...previous, [key]: '' }));
        try {
          const { data } = await api.get(endpoint, { params: { page: pages[key] || 1, limit: 20, ...(key === 'students' ? { search: searchTerm } : {}) } });
          if (active) {
            setRows(data[responseKey] || []);
            setPagination(previous => ({ ...previous, [key]: data.pagination }));
          }
        } catch (error) {
          if (active) {
            setListErrors(previous => ({ ...previous, [key]: error.friendlyMessage }));
            if (error.status === 401) checkAdminAuth(true).then(result => { if (result === null) router.replace('/admin/login'); });
          }
        } finally {
          if (active) setListBusy(previous => ({ ...previous, [key]: false }));
        }
      });
    }, activeTab === 'students' ? 250 : 0);
    return () => { active = false; clearTimeout(timer); };
  }, [activeTab, isAdminAuthenticated, searchTerm, pages, reloadVersion, checkAdminAuth, router]);

  // Student toggle active
  const handleToggleStudent = async (id) => {
    try {
      const res = await api.put(`/admin/students/${id}/toggle-active`);
      toast.success(res.data.message);
      setStudents(students.map((s) => (s.id === id ? { ...s, isActive: res.data.student.isActive } : s)));
    } catch (err) {
      toast.error('فشل تغيير حالة الطالب');
    }
  };

  // Student reset password link
  const handleResetPasswordLink = async (id) => {
    try {
      const res = await api.post(`/admin/students/${id}/reset-password-link`);
      await navigator.clipboard.writeText(res.data.resetUrl);
      toast.success('تم نسخ رابط الاستعادة المؤقت! صالح لـ ٣٠ دقيقة.');
      if (res.data.whatsappMessage) {
        window.open(`https://wa.me/?text=${encodeURIComponent(res.data.whatsappMessage)}`, '_blank', 'noopener,noreferrer');
      }
    } catch (err) {
      toast.error('فشل إنشاء رابط الاستعادة');
    }
  };

  // Teacher app approve/reject
  const handleApproveTeacher = async (appId) => {
    try {
      await api.put(`/admin/teacher-applications/${appId}/approve`);
      toast.success('تمت الموافقة على الطلب. أضف ملف المدرس المعتمد ليظهر في الدليل.');
      setTeacherApps(teacherApps.map((a) => (a.id === appId ? { ...a, status: 'APPROVED' } : a)));
    } catch (err) {
      toast.error('فشل اعتماد الطلب');
    }
  };

  const handleRejectTeacher = async (appId) => {
    try {
      await api.put(`/admin/teacher-applications/${appId}/reject`);
      toast.success('تم رفض الطلب');
      setTeacherApps(teacherApps.map((a) => (a.id === appId ? { ...a, status: 'REJECTED' } : a)));
    } catch (err) {
      toast.error('فشل رفض الطلب');
    }
  };

  // Booking confirm / cancel
  const handleConfirmBooking = async (bId) => {
    try {
      await api.put(`/admin/bookings/${bId}/confirm`);
      toast.success('تم تأكيد الحجز');
      setBookings(bookings.map((b) => (b.id === bId ? { ...b, status: 'CONFIRMED' } : b)));
    } catch (err) {
      toast.error(err.friendlyMessage || 'فشل تأكيد الحجز');
    }
  };

  const handleCancelBooking = async (bId) => {
    if (!window.confirm('إلغاء الحجز يوقف رموزه واشتراكه ويحرر المقعد. هل تريد المتابعة؟')) return;
    try {
      await api.put(`/admin/bookings/${bId}/cancel`);
      toast.success('تم إلغاء الحجز');
      setBookings(bookings.map((b) => (b.id === bId ? { ...b, status: 'CANCELLED' } : b)));
    } catch (err) {
      toast.error('فشل إلغاء الحجز');
    }
  };

  // Only show returned plaintext codes when generation actually succeeded.
  const handleGenerateCode = async e => {
    e.preventDefault();
    if (saving) return;
    if (!codeTargetStudentId || !codeTargetBookingId) { setFormError('اختر حجزاً مؤكداً أولاً'); return; }
    setSaving('code'); setFormError('');
    try {
      const { data } = await api.post('/admin/activation-codes', {
        items: [{ studentId: codeTargetStudentId, bookingId: codeTargetBookingId }],
      });
      const results = Array.isArray(data.results) ? data.results : [];
      const codes = results.filter(item => item?.code && !item.error);
      const errors = results.filter(item => item?.error).map(item => item.error);
      if (codes.length) {
        setGeneratedCodes(codes); setShowNewCodeModal(false); reloadLists();
        toast.success(`تم إنشاء ${codes.length} رمز. احفظه أو شاركه الآن.`);
      }
      if (errors.length || !codes.length) setFormError(errors.join(' · ') || 'لم يتم إنشاء رمز؛ راجع الحجز وحاول مرة أخرى.');
    } catch (err) { setFormError(err.friendlyMessage || 'فشل توليد الرمز'); }
    finally { setSaving(''); }
  };

  // Cancel Code
  const handleCancelCode = async (cId) => {
    try {
      await api.put(`/admin/activation-codes/${cId}/cancel`);
      toast.success('تم إلغاء الرمز');
      setActivationCodes(activationCodes.map((c) => (c.id === cId ? { ...c, status: 'CANCELLED' } : c)));
    } catch (err) {
      toast.error('فشل إلغاء الرمز');
    }
  };

  // Create Course
  const handleCreateCourse = async (e) => {
    e.preventDefault();
    if (saving) return;
    setSaving('course'); setFormError('');
    try {
      const res = await api.post('/admin/courses', newCourse);
      toast.success('تمت إضافة الكورس بنجاح!');
      setShowNewCourseModal(false);
      setListPage('courses', 1); reloadLists();
      setSelectedCourse(res.data.course || res.data);
    } catch (err) {
      setFormError(err.friendlyMessage || 'فشل إنشاء الكورس');
    } finally { setSaving(''); }
  };

  // Upload Book
  const handleUploadBook = async (e) => {
    e.preventDefault();
    if (saving) return;
    if (newBook.accessLevel === 'SUBSCRIBER' && !newBook.courseId) { setFormError('اختر الكورس الذي يتيح الوصول إلى الكتاب'); return; }
    if (!bookFile) {
      toast.error('يرجى اختيار ملف PDF للكتاب');
      return;
    }

    setSaving('book'); setFormError('');
    const form = new FormData();
    form.append('bookFile', bookFile);
    Object.keys(newBook).forEach(k => { if (k !== 'courseId' || newBook.accessLevel === 'SUBSCRIBER') form.append(k, newBook[k]); });

    try {
      await api.post('/admin/books', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('تم رفع الكتاب بنجاح!');
      setShowNewBookModal(false);
      setBookFile(null);
      setListPage('books', 1); reloadLists();
    } catch (err) {
      setFormError(err.friendlyMessage || 'فشل رفع الكتاب');
    } finally { setSaving(''); }
  };

  // Save Settings
  const handleSaveSettings = async (e) => {
    e.preventDefault();
    try {
      await api.put('/admin/settings', {
        contact_phone: contactPhone,
        contact_whatsapp: contactWhatsapp,
        platform_slogan: platformSlogan,
      });
      toast.success('تم حفظ إعدادات وبيانات التواصل بنجاح');
      loadDashboardData();
    } catch (err) {
      toast.error('فشل حفظ الإعدادات');
    }
  };

  if (adminAuthError) return <div className="min-h-screen bg-gray-50 dark:bg-navy-950 p-8"><RequestError message={adminAuthError} onRetry={() => checkAdminAuth(true).then(result => { if (result === null) router.replace('/admin/login'); })}/></div>;

  if (isAdminLoading || !admin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-950 text-white">
        <LoadingSpinner text="جاري الدخول إلى لوحة الإدارة..." />
      </div>
    );
  }

  const allGrades = stages.flatMap((s) => s.grades || []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-gray-100 font-cairo" dir="rtl">
      {/* Top Admin Navbar */}
      <nav className="sticky top-0 z-40 bg-white dark:bg-navy-900 border-b border-gray-200 dark:border-indigo-950 px-4 sm:px-8 py-3.5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold">
            <HiShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-base font-black leading-tight text-gray-900 dark:text-white">
              لوحة إدارة «أستاذك»
            </h1>
            <span className="text-[11px] text-purple-600 dark:text-purple-400 font-semibold">
              {admin.name} ({admin.role === 'SUPER_ADMIN' ? 'المدير الرئيسي' : 'مشرف'})
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/"
            target="_blank"
            className="px-3 py-1.5 rounded-xl border border-gray-300 dark:border-indigo-950 text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-navy-800 transition-colors"
          >
            عرض الموقع
          </Link>
          <button
            onClick={() => adminLogout().catch(error => toast.error(error.friendlyMessage))}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 text-xs font-bold transition-colors"
          >
            <HiLogout className="w-4 h-4" />
            <span>خروج</span>
          </button>
        </div>
      </nav>

      {/* Main Container */}
      <div className="flex-grow flex flex-col md:flex-row max-w-7xl mx-auto w-full p-4 sm:p-6 gap-6">
        {/* Sidebar Nav */}
        <aside className="w-full md:w-64 flex-shrink-0 space-y-1 bg-white dark:bg-navy-900 p-4 rounded-3xl border border-gray-200 dark:border-indigo-950/70 shadow-sm self-start">
          {[
            { id: 'overview', label: 'المؤشرات والنشاط', icon: HiChartBar },
            { id: 'students', label: 'إدارة الطلاب', icon: HiUsers },
            { id: 'teachers', label: 'المدرسون والطلبات', icon: HiAcademicCap },
            { id: 'courses', label: 'الكورسات والمجموعات', icon: HiBookOpen },
            { id: 'bookings', label: 'الحجوزات والتأكيدات', icon: HiClipboardList },
            { id: 'codes', label: 'رموز التفعيل والاشتراكات', icon: HiKey },
            { id: 'books', label: 'المكتبة والكتب', icon: HiBookOpen },
            { id: 'settings', label: 'بيانات التواصل والإعدادات', icon: HiCog },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all text-right ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-navy-800'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Content Area */}
        <main className="flex-grow min-w-0 space-y-6">
          <RequestError message={dashboardError} onRetry={loadDashboardData}/>
          {loading && <p role="status" className="text-sm text-gray-500">جاري تحميل بيانات الإدارة...</p>}
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <h2 className="text-xl font-black">المؤشرات والإحصائيات الحقيقية</h2>

              {/* Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
                  <span className="text-xs text-gray-500 block mb-1">الطلاب المسجلين</span>
                  <span className="text-2xl font-black text-purple-600 dark:text-purple-400">
                    {stats?.students ?? '—'}
                  </span>
                </div>
                <div className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
                  <span className="text-xs text-gray-500 block mb-1">الأساتذة المعتمدين</span>
                  <span className="text-2xl font-black text-blue-600 dark:text-blue-400">
                    {stats?.teachers ?? '—'}
                  </span>
                </div>
                <div className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
                  <span className="text-xs text-gray-500 block mb-1">إجمالي الحجوزات</span>
                  <span className="text-2xl font-black text-orange-500">
                    {stats?.bookings ?? '—'}
                  </span>
                </div>
                <div className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
                  <span className="text-xs text-gray-500 block mb-1">الاشتراكات الفعّالة</span>
                  <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                    {stats?.activeSubscriptions ?? '—'}
                  </span>
                </div>
              </div>

              {/* Quick Action shortcuts */}
              <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-900/40 via-navy-900 to-indigo-900/40 border border-purple-900/40 space-y-3">
                <h3 className="text-sm font-bold text-white">إجراءات سريعة للإدارة:</h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      setActiveTab('codes');
                      setFormError(''); setShowNewCodeModal(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs"
                  >
                    + توليد رمز تفعيل لطالب
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('courses');
                      setShowNewCourseModal(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs"
                  >
                    + إضافة كورس جديد
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('books');
                      setShowNewBookModal(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs"
                  >
                    + رفع مذكرة أو كتاب PDF
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: STUDENTS */}
          {activeTab === 'students' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <h2 className="text-xl font-black">إدارة حسابات الطلاب</h2>
                <div className="relative w-full sm:w-72">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => { setSearchTerm(e.target.value); setListPage('students', 1); }}
                    placeholder="ابحث بالاسم أو رقم الهاتف..."
                    className="w-full px-3 py-2 pr-9 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-900 text-gray-900 dark:text-white"
                  />
                  <HiSearch className="w-4 h-4 text-gray-400 absolute right-3 top-2.5" />
                </div>
              </div>

              <div className="bg-white dark:bg-navy-900 rounded-3xl border border-gray-200 dark:border-indigo-950/70 overflow-x-auto shadow-sm">
                <table className="w-full text-right text-xs">
                  <thead className="bg-gray-100 dark:bg-navy-950 text-gray-600 dark:text-gray-400 font-bold border-b border-gray-200 dark:border-indigo-950">
                    <tr>
                      <th className="p-3.5">الاسم الرباعي</th>
                      <th className="p-3.5">رقم الهاتف</th>
                      <th className="p-3.5">هاتف ولي الأمر</th>
                      <th className="p-3.5">الصف والمرحلة</th>
                      <th className="p-3.5">الحالة</th>
                      <th className="p-3.5 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-indigo-950/50">
                    {students.map((std) => (
                      <tr key={std.id} className="hover:bg-gray-50 dark:hover:bg-navy-800/40">
                        <td className="p-3.5 font-bold text-gray-900 dark:text-white">{std.fullName}</td>
                        <td className="p-3.5" dir="ltr">{std.phone}</td>
                        <td className="p-3.5" dir="ltr">{std.parentPhone}</td>
                        <td className="p-3.5 text-gray-500">
                          {std.grade?.name ? `${std.grade.name} (${std.stage?.name})` : '-'}
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              std.isActive ? 'bg-emerald-500/10 text-emerald-600' : 'bg-red-500/10 text-red-600'
                            }`}
                          >
                            {std.isActive ? 'نشط' : 'معطل'}
                          </span>
                        </td>
                        <td className="p-3.5 text-center space-x-1 space-x-reverse">
                          <button
                            onClick={() => handleResetPasswordLink(std.id)}
                            className="px-2.5 py-1 rounded-lg bg-purple-600/10 text-purple-600 hover:bg-purple-600/20 text-[11px] font-bold"
                            title="إصدار رابط استعادة كلمة السر ونسخه"
                          >
                            رابط استعادة
                          </button>
                          <button
                            onClick={() => handleToggleStudent(std.id)}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                              std.isActive
                                ? 'bg-red-500/10 text-red-600 hover:bg-red-500/20'
                                : 'bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20'
                            }`}
                          >
                            {std.isActive ? 'تعطيل' : 'تفعيل'}
                          </button>
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && !listBusy.students && !listErrors.students && (
                      <tr>
                        <td colSpan="6" className="p-6 text-center text-gray-500">
                          لا يوجد طلاب مطابقين للبحث.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'students' && listFooter('students')}

          {/* TAB 3: TEACHERS & APPLICATIONS */}
          {activeTab === 'teachers' && (
            <div className="space-y-6">
              <AdminTeacherForm onCreated={reloadLists}/>
              <p className="text-sm text-gray-500">بعد مراجعة طلب الانضمام، استخدم «إضافة مدرس معتمد» لإنشاء ملف المدرس ونشره في الدليل.</p>
              {/* Teacher Applications */}
              <div className="space-y-3">
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                  طلبات انضمام الأساتذة ({pagination.teacherApps?.total ?? '—'})
                </h2>
                <div className="bg-white dark:bg-navy-900 rounded-3xl border border-gray-200 dark:border-indigo-950/70 overflow-x-auto shadow-sm">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-gray-100 dark:bg-navy-950 text-gray-600 dark:text-gray-400 font-bold border-b border-gray-200 dark:border-indigo-950">
                      <tr>
                        <th className="p-3">اسم الأستاذ</th>
                        <th className="p-3">الهاتف</th>
                        <th className="p-3">المادة</th>
                        <th className="p-3">المرحلة</th>
                        <th className="p-3">المدينة</th>
                        <th className="p-3">الحالة</th>
                        <th className="p-3 text-center">الإجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-indigo-950/50">
                      {teacherApps.map((app) => (
                        <tr key={app.id}>
                          <td className="p-3 font-bold">{app.name}</td>
                          <td className="p-3" dir="ltr">{app.phone}</td>
                          <td className="p-3">{app.subject}</td>
                          <td className="p-3">{app.stage}</td>
                          <td className="p-3">{app.city}</td>
                          <td className="p-3 font-bold">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] ${
                                app.status === 'PENDING'
                                  ? 'bg-amber-500/10 text-amber-600'
                                  : app.status === 'APPROVED'
                                  ? 'bg-emerald-500/10 text-emerald-600'
                                  : 'bg-red-500/10 text-red-600'
                              }`}
                            >
                              {app.status === 'PENDING' ? 'قيد المراجعة' : app.status === 'APPROVED' ? 'معتمد' : 'مرفوض'}
                            </span>
                          </td>
                          <td className="p-3 text-center space-x-1 space-x-reverse">
                            {app.status === 'PENDING' && (
                              <>
                                <button
                                  onClick={() => handleApproveTeacher(app.id)}
                                  className="px-2 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px]"
                                >
                                  قبول
                                </button>
                                <button
                                  onClick={() => handleRejectTeacher(app.id)}
                                  className="px-2 py-1 rounded-lg bg-red-600 text-white font-bold text-[10px]"
                                >
                                  رفض
                                </button>
                              </>
                            )}
                          </td>
                        </tr>
                      ))}
                      {teacherApps.length === 0 && !listBusy.teacherApps && !listErrors.teacherApps && (
                        <tr>
                          <td colSpan="7" className="p-4 text-center text-gray-500">
                            لا توجد طلبات انضمام جديدة.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {listFooter('teacherApps')}

              {/* Approved Teachers */}
              <div className="space-y-3">
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                  ملفات المدرسين في المنصة ({pagination.teachers?.total ?? '—'})
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {teachers.map((t) => (
                    <div
                      key={t.id}
                      className="p-4 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70"
                    >
                      <h4 className="font-bold text-sm">{t.name}</h4>
                      <p className="text-xs text-gray-500">{t.city} • {t.qualifications || 'أستاذ معتمد'}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'teachers' && listFooter('teachers')}

          {/* TAB 4: COURSES */}
          {activeTab === 'courses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black">إدارة الكورسات والمجموعات</h2>
                <button
                  onClick={() => { setFormError(''); setShowNewCourseModal(true); }}
                  className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <HiPlus className="w-4 h-4" />
                  <span>إضافة كورس جديد</span>
                </button>
              </div>

              <div className="bg-white dark:bg-navy-900 rounded-3xl border border-gray-200 dark:border-indigo-950/70 overflow-x-auto shadow-sm">
                <table className="w-full text-right text-xs">
                  <thead className="bg-gray-100 dark:bg-navy-950 text-gray-600 dark:text-gray-400 font-bold border-b border-gray-200 dark:border-indigo-950">
                    <tr>
                      <th className="p-3.5">عنوان الكورس</th>
                      <th className="p-3.5">المادة والصف</th>
                      <th className="p-3.5">المدرس</th>
                      <th className="p-3.5">نوع التدريس</th>
                      <th className="p-3.5">الحصص</th>
                      <th className="p-3.5">المجموعات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-indigo-950/50">
                    {courses.map((c) => (
                      <tr key={c.id}>
                        <td className="p-3.5 font-bold text-gray-900 dark:text-white">{c.title}</td>
                        <td className="p-3.5">{c.subject?.name} • {c.grade?.name}</td>
                        <td className="p-3.5">{c.teacher?.name}</td>
                        <td className="p-3.5 font-medium text-purple-600 dark:text-purple-400">{c.teachingMethod}</td>
                        <td className="p-3.5">{c.totalSessions} حصص</td>
                        <td className="p-3.5"><button type="button" onClick={() => setSelectedCourse(c)} className="px-3 py-2 rounded-xl bg-purple-600/10 text-purple-600 dark:text-purple-300 font-bold">إدارة المجموعات والحصص ({c._count?.groups || 0})</button></td>
                      </tr>
                    ))}
                    {courses.length === 0 && !listBusy.courses && !listErrors.courses && (
                      <tr>
                        <td colSpan="6" className="p-6 text-center text-gray-500">
                          لا توجد كورسات مضافة بعد. اضغط «إضافة كورس جديد».
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'courses' && <>{listFooter('courses')}{selectedCourse && <AdminCourseGroups course={selectedCourse} onClose={() => setSelectedCourse(null)} onChanged={reloadLists}/>}</>}

          {/* TAB 5: BOOKINGS */}
          {activeTab === 'bookings' && (
            <div className="space-y-4">
              <h2 className="text-xl font-black">إدارة طلبات الحجز والتأكيد</h2>
              <div className="bg-white dark:bg-navy-900 rounded-3xl border border-gray-200 dark:border-indigo-950/70 overflow-x-auto shadow-sm">
                <table className="w-full text-right text-xs">
                  <thead className="bg-gray-100 dark:bg-navy-950 text-gray-600 dark:text-gray-400 font-bold border-b border-gray-200 dark:border-indigo-950">
                    <tr>
                      <th className="p-3.5">الطالب</th>
                      <th className="p-3.5">رقم الهاتف</th>
                      <th className="p-3.5">الكورس والمجموعة</th>
                      <th className="p-3.5">الحالة</th>
                      <th className="p-3.5">التاريخ</th>
                      <th className="p-3.5 text-center">إجراءات الإدارة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-indigo-950/50">
                    {bookings.map((b) => (
                      <tr key={b.id}>
                        <td className="p-3.5 font-bold">{b.student?.fullName}</td>
                        <td className="p-3.5" dir="ltr">{b.student?.phone}</td>
                        <td className="p-3.5">{b.courseGroup?.course?.title} ({b.courseGroup?.name})</td>
                        <td className="p-3.5 font-bold">
                          <span className="px-2 py-0.5 rounded-full text-[10px] bg-purple-500/10 text-purple-600">
                            {b.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-gray-400">{new Date(b.createdAt).toLocaleDateString('ar-SD')}</td>
                        <td className="p-3.5 text-center space-x-1 space-x-reverse">
                          {!['CONFIRMED', 'CANCELLED'].includes(b.status) && (
                            <button
                              onClick={() => handleConfirmBooking(b.id)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px]"
                            >
                              تأكيد الحجز
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setCodeTargetBooking(b);
                              setFormError('');
                              setCodeTargetStudentId(b.student?.id);
                              setCodeTargetBookingId(b.id);
                              setFormError(''); setShowNewCodeModal(true);
                              setActiveTab('codes');
                            }}
                            disabled={b.status !== 'CONFIRMED'}
                            title={b.status === 'CONFIRMED' ? 'توليد رمز لهذا الحجز' : 'أكد الحجز أولاً'}
                            className="px-2.5 py-1 rounded-lg bg-orange-500 text-white font-bold text-[10px] disabled:opacity-40"
                          >
                            توليد رمز
                          </button>
                          {b.status !== 'CANCELLED' && (
                            <button
                              onClick={() => handleCancelBooking(b.id)}
                              className="px-2.5 py-1 rounded-lg bg-gray-200 dark:bg-navy-800 text-red-600 font-bold text-[10px]"
                            >
                              إلغاء
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {bookings.length === 0 && !listBusy.bookings && !listErrors.bookings && (
                      <tr>
                        <td colSpan="6" className="p-6 text-center text-gray-500">
                          لا توجد طلبات حجز مسجلة.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'bookings' && listFooter('bookings')}

          {/* TAB 6: ACTIVATION CODES */}
          {activeTab === 'codes' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black">رموز التفعيل والاشتراكات المحمية</h2>
                <button
                  onClick={() => { setFormError(''); setShowNewCodeModal(true); }}
                  className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <HiPlus className="w-4 h-4" />
                  <span>توليد رمز تفعيل جديد</span>
                </button>
              </div>

              {/* Newly generated codes notice with one-click WhatsApp share */}
              {generatedCodes.length > 0 && (
                <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-200 space-y-3">
                  <h3 className="font-bold text-sm">تم إنشاء الرمز بنجاح! شاركه مع الطالب الآن:</h3>
                  {generatedCodes.map((g) => (
                    <div key={g.id} className="p-3 bg-white dark:bg-navy-900 rounded-xl border border-emerald-500/20 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                      <div>
                        <span className="font-bold text-gray-900 dark:text-white">{g.studentName}</span>
                        <span className="text-gray-500 mx-2">•</span>
                        <span className="text-orange-500 font-black tracking-widest text-sm" dir="ltr">{g.code}</span>
                      </div>
                      <a
                        href={g.whatsappLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                      >
                        <FaWhatsapp className="w-4 h-4" />
                        <span>إرسال الرمز عبر واتساب</span>
                      </a>
                    </div>
                  ))}
                </div>
              )}

              <div className="bg-white dark:bg-navy-900 rounded-3xl border border-gray-200 dark:border-indigo-950/70 overflow-x-auto shadow-sm">
                <table className="w-full text-right text-xs">
                  <thead className="bg-gray-100 dark:bg-navy-950 text-gray-600 dark:text-gray-400 font-bold border-b border-gray-200 dark:border-indigo-950">
                    <tr>
                      <th className="p-3.5">الطالب</th>
                      <th className="p-3.5">الهاتف</th>
                      <th className="p-3.5">الكورس</th>
                      <th className="p-3.5">حالة الرمز</th>
                      <th className="p-3.5">صلاحية الرمز</th>
                      <th className="p-3.5">وقت الاستخدام</th>
                      <th className="p-3.5 text-center">إجراء</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-indigo-950/50">
                    {activationCodes.map((c) => (
                      <tr key={c.id}>
                        <td className="p-3.5 font-bold">{c.student?.fullName}</td>
                        <td className="p-3.5" dir="ltr">{c.student?.phone}</td>
                        <td className="p-3.5">{c.booking?.courseGroup?.course?.title}</td>
                        <td className="p-3.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              c.status === 'ACTIVE'
                                ? 'bg-emerald-500/10 text-emerald-600'
                                : c.status === 'USED'
                                ? 'bg-blue-500/10 text-blue-600'
                                : 'bg-red-500/10 text-red-600'
                            }`}
                          >
                            {c.status === 'ACTIVE' ? 'نشط وغير مسترد' : c.status === 'USED' ? 'تم التفعيل' : c.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-gray-400">{new Date(c.expiresAt).toLocaleDateString('ar-SD')}</td>
                        <td className="p-3.5 text-gray-400">
                          {c.usedAt ? new Date(c.usedAt).toLocaleDateString('ar-SD') : '-'}
                        </td>
                        <td className="p-3.5 text-center">
                          {c.status === 'ACTIVE' && (
                            <button
                              onClick={() => handleCancelCode(c.id)}
                              className="px-2 py-1 rounded bg-red-500/10 text-red-600 font-bold text-[10px]"
                            >
                              إلغاء الرمز
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {activationCodes.length === 0 && !listBusy.codes && !listErrors.codes && (
                      <tr>
                        <td colSpan="7" className="p-6 text-center text-gray-500">
                          لا توجد رموز تفعيل مصدرة.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'codes' && listFooter('codes')}

          {/* TAB 7: BOOKS */}
          {activeTab === 'books' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black">إدارة مكتبة الكتب والمذكرات</h2>
                <button
                  onClick={() => { setFormError(''); setShowNewBookModal(true); }}
                  className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <HiPlus className="w-4 h-4" />
                  <span>رفع كتاب PDF جديد</span>
                </button>
              </div>

              <div className="bg-white dark:bg-navy-900 rounded-3xl border border-gray-200 dark:border-indigo-950/70 overflow-x-auto shadow-sm">
                <table className="w-full text-right text-xs">
                  <thead className="bg-gray-100 dark:bg-navy-950 text-gray-600 dark:text-gray-400 font-bold border-b border-gray-200 dark:border-indigo-950">
                    <tr>
                      <th className="p-3.5">عنوان الكتاب</th>
                      <th className="p-3.5">المادة والصف</th>
                      <th className="p-3.5">الإصدار</th>
                      <th className="p-3.5">مستوى الوصول</th>
                      <th className="p-3.5">التنزيل</th>
                      <th className="p-3.5">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-indigo-950/50">
                    {books.map((b) => (
                      <tr key={b.id}>
                        <td className="p-3.5 font-bold text-gray-900 dark:text-white">{b.title}</td>
                        <td className="p-3.5">{b.subject?.name} • {b.grade?.name}</td>
                        <td className="p-3.5 text-gray-400">{b.year || '-'}</td>
                        <td className="p-3.5 font-medium">{b.accessLevel}</td>
                        <td className="p-3.5 font-bold text-emerald-600">
                          {b.allowDownload ? 'متاح' : 'معاينة فقط'}
                        </td>
                        <td className="p-3.5 font-bold">
                          <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/10 text-emerald-600">
                            {b.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {books.length === 0 && !listBusy.books && !listErrors.books && (
                      <tr>
                        <td colSpan="6" className="p-6 text-center text-gray-500">
                          لا توجد كتب مرفوعة. اضغط «رفع كتاب PDF جديد».
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'books' && listFooter('books')}

          {/* TAB 8: SETTINGS */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl bg-white dark:bg-navy-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-indigo-950/70 shadow-sm space-y-6">
              <h2 className="text-xl font-black">إعدادات المنصة وبيانات التواصل</h2>
              <form onSubmit={handleSaveSettings} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold mb-1">شعار المنصة (Slogan)</label>
                  <input
                    type="text"
                    value={platformSlogan}
                    onChange={(e) => setPlatformSlogan(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">رقم الإدارة للاتصال (محلي)</label>
                  <input
                    type="text"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">رابط واتساب الإدارة</label>
                  <input
                    type="text"
                    dir="ltr"
                    value={contactWhatsapp}
                    onChange={(e) => setContactWhatsapp(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white text-right"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!!saving}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-purple-600 hover:bg-purple-700 transition-colors shadow-sm"
                >
                  حفظ التعديلات
                </button>
              </form>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: Generate Code */}
      {showNewCodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950 shadow-2xl">
            <h3 className="text-lg font-bold mb-4">توليد رمز تفعيل جديد لطالب</h3>
            <form onSubmit={handleGenerateCode} className="space-y-4">
              <AdminBookingSelect selected={codeTargetBooking} onSelect={booking => {
                setCodeTargetBooking(booking);
                setCodeTargetBookingId(booking?.id || '');
                setCodeTargetStudentId(booking?.student?.id || '');
              }}/>
              <p className="text-xs text-gray-500">اختَر حجزاً مؤكداً. توليد رمز بديل يلغي أي رمز سابق غير مستخدم لنفس الحجز.</p>
              <RequestError message={formError}/>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewCodeModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={!!saving}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 disabled:opacity-50"
                >
                  {saving === 'code' ? 'جاري إنشاء الرمز...' : 'توليد الرمز'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: New Course */}
      {showNewCourseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-lg p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold mb-4">إضافة كورس تعليمي جديد</h3>
            <form onSubmit={handleCreateCourse} className="space-y-4">
              <div>
                <label className="block text-xs font-bold mb-1">عنوان الكورس *</label>
                <input
                  type="text"
                  required
                  value={newCourse.title}
                  onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })}
                  placeholder="مثال: كورس الرياضيات التأسيسي للشهادة الثانوية"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1">المادة *</label>
                  <select
                    required
                    value={newCourse.subjectId}
                    onChange={(e) => setNewCourse({ ...newCourse, subjectId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="">اختار المادة</option>
                    {subjects.map((sub) => (
                      <option key={sub.id} value={sub.id}>{sub.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">الصف *</label>
                  <select
                    required
                    value={newCourse.gradeId}
                    onChange={(e) => setNewCourse({ ...newCourse, gradeId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="">اختار الصف</option>
                    {allGrades.map((g) => (
                      <option key={g.id} value={g.id}>{g.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <AdminEntitySelect endpoint="/admin/teachers" listKey="teachers" value={newCourse.teacherId} onChange={teacherId => setNewCourse({ ...newCourse, teacherId })} label="المدرس"/>

                <div>
                  <label className="block text-xs font-bold mb-1">نوع الدرس *</label>
                  <select
                    value={newCourse.teachingMethod}
                    onChange={(e) => setNewCourse({ ...newCourse, teachingMethod: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="INDIVIDUAL_ONSITE">فردي حضوري</option>
                    <option value="GROUP_ONSITE">جماعي حضوري</option>
                    <option value="INDIVIDUAL_ONLINE">فردي أونلاين</option>
                    <option value="GROUP_ONLINE">جماعي أونلاين</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">الوصف</label>
                <textarea
                  rows="3"
                  value={newCourse.description}
                  onChange={(e) => setNewCourse({ ...newCourse, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                ></textarea>
              </div>

              <RequestError message={formError}/>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewCourseModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={!!saving}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50"
                >
                  {saving === 'course' ? 'جاري الحفظ...' : 'حفظ الكورس'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: New Book */}
      {showNewBookModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-lg p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold mb-4">رفع كتاب أو مذكرة PDF</h3>
            <form onSubmit={handleUploadBook} className="space-y-4">
              <div>
                <label className="block text-xs font-bold mb-1">عنوان الكتاب أو المذكرة *</label>
                <input
                  type="text"
                  required
                  value={newBook.title}
                  onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                  placeholder="مثال: مذكرة الكيمياء الشاملة للشهادة السودانية"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1">المادة *</label>
                  <select
                    required
                    value={newBook.subjectId}
                    onChange={(e) => setNewBook({ ...newBook, subjectId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="">اختار المادة</option>
                    {subjects.map((sub) => (
                      <option key={sub.id} value={sub.id}>{sub.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">الصف *</label>
                  <select
                    required
                    value={newBook.gradeId}
                    onChange={(e) => setNewBook({ ...newBook, gradeId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="">اختار الصف</option>
                    {allGrades.map((g) => (
                      <option key={g.id} value={g.id}>{g.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">ملف الـ PDF *</label>
                <input
                  type="file"
                  required
                  accept="application/pdf"
                  onChange={(e) => setBookFile(e.target.files[0])}
                  className="w-full text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1">مستوى الوصول</label>
                  <select
                    value={newBook.accessLevel}
                    onChange={(e) => setNewBook({ ...newBook, accessLevel: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="PUBLIC">متاح للعامة</option>
                    <option value="REGISTERED">للحسابات المسجلة</option>
                    <option value="SUBSCRIBER">للمشتركين فقط</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">السماح بالتنزيل</label>
                  <select
                    value={newBook.allowDownload}
                    onChange={(e) => setNewBook({ ...newBook, allowDownload: e.target.value === 'true' })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white"
                  >
                    <option value="true">نعم (متاح للتنزيل)</option>
                    <option value="false">لا (معاينة فقط)</option>
                  </select>
                </div>
              </div>

              {newBook.accessLevel === 'SUBSCRIBER' && <AdminEntitySelect endpoint="/admin/courses" listKey="courses" value={newBook.courseId} onChange={courseId => setNewBook({ ...newBook, courseId })} label="الكورس المرتبط بالكتاب"/>}
              <RequestError message={formError}/>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewBookModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={!!saving}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving === 'book' ? 'جاري الرفع...' : 'رفع ونشر الكتاب'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
