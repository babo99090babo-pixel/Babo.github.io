import localFont from 'next/font/local';
import { Toaster } from 'react-hot-toast';
import ThemeProvider from '@/components/ThemeProvider';
import './globals.css';

const cairo = localFont({
  src: './fonts/cairo-variable.woff2',
  weight: '200 1000',
  display: 'swap',
  variable: '--font-cairo',
});

export const metadata = {
  title: 'أستاذك - منصة تعليمية سودانية',
  description:
    'أستاذك هي منصة تعليمية سودانية بتوفر ليك دروس خصوصية ومجموعات وكتب إلكترونية لكل المراحل الدراسية. سجّل الحين وابدأ رحلتك التعليمية.',
  keywords: [
    'أستاذك',
    'تعليم',
    'سودان',
    'دروس خصوصية',
    'مدرسين',
    'كتب إلكترونية',
    'منصة تعليمية',
  ],
  authors: [{ name: 'أستاذك' }],
  openGraph: {
    title: 'أستاذك - منصة تعليمية سودانية',
    description:
      'منصة تعليمية سودانية بتوفر دروس خصوصية ومجموعات وكتب لكل المراحل.',
    type: 'website',
    locale: 'ar_SD',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable} suppressHydrationWarning>
      <body
        className={`${cairo.className} bg-[var(--color-bg-primary)] text-[var(--color-text-primary)] transition-theme min-h-screen antialiased`}
      >
        <ThemeProvider>
          {children}
          <Toaster
            position="top-center"
            toastOptions={{
              duration: 4000,
              style: {
                fontFamily: 'Cairo, sans-serif',
                direction: 'rtl',
                borderRadius: '12px',
                padding: '12px 16px',
                fontSize: '14px',
              },
              success: {
                style: {
                  background: '#065f46',
                  color: '#d1fae5',
                },
                iconTheme: {
                  primary: '#10b981',
                  secondary: '#d1fae5',
                },
              },
              error: {
                style: {
                  background: '#7f1d1d',
                  color: '#fecaca',
                },
                iconTheme: {
                  primary: '#ef4444',
                  secondary: '#fecaca',
                },
              },
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
