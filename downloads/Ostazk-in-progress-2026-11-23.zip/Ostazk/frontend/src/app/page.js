'use client';

import { useContact } from '@/lib/contact';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import CourseCard from '@/components/CourseCard';
import BookCard from '@/components/BookCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import api from '@/lib/api';
import {
  HiSearch,
  HiAcademicCap,
  HiSparkles,
  HiArrowSmLeft,
  HiBookOpen,
  HiUserGroup,
  HiCheckCircle,
  HiPhone,
} from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function HomePage() {
  const contact = useContact();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [stages, setStages] = useState([]);
  const [courses, setCourses] = useState([]);
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const [stagesRes, coursesRes, booksRes] = await Promise.allSettled([
          api.get('/stages'),
          api.get('/courses?limit=6'),
          api.get('/books?limit=4'),
        ]);

        if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data || []);
        if (coursesRes.status === 'fulfilled') setCourses(coursesRes.value.data.courses || []);
        if (booksRes.status === 'fulfilled') setBooks(booksRes.value.data.books || []);
      } catch (err) {
        console.error('Error fetching home data:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/courses?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const steps = [
    { num: '١', title: 'اعمل حسابك', desc: 'سجّل في دقيقة باسمك الرباعي ورقم هاتفك ورقم ولي أمرك بدون تعقيدات.' },
    { num: '٢', title: 'اختار درسك', desc: 'تصفح صفّك، اختار مادتك والمدرس المفضل وطريقة الدراسة البتناسبك.' },
    { num: '٣', title: 'اتواصل معانا', desc: 'تواصل مع الإدارة عبر واتساب أو الاتصال لتأكيد الحجز وترتيب الدفع.' },
    { num: '٤', title: 'فعّل رمزك', desc: 'استلم رمز التفعيل الخاص بيك وفعّله في ثانية وادخل حصصك وكتبك.' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100 transition-colors">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-28 bg-gradient-to-b from-gray-50 via-white to-gray-50 dark:from-navy-950 dark:via-navy-900 dark:to-navy-950 bg-grid-pattern border-b border-gray-200 dark:border-indigo-950/60">
        {/* Glow circles for background visual hierarchy */}
        <div className="absolute top-1/4 -right-20 w-80 h-80 rounded-full bg-purple-600/10 dark:bg-purple-600/20 blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 -left-20 w-80 h-80 rounded-full bg-orange-500/10 dark:bg-orange-500/15 blur-3xl pointer-events-none" />

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/10 dark:bg-purple-900/40 border border-purple-500/20 text-purple-700 dark:text-purple-300 text-xs font-bold mb-6">
            <HiSparkles className="w-4 h-4 text-orange-500 animate-pulse" />
            <span>المنصة التعليمية الشاملة للطلاب والمدرسين في السودان</span>
          </div>

          {/* Main Headings */}
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight leading-tight mb-4 font-cairo">
            أستاذك معاك… <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-purple-600 via-indigo-600 to-orange-500 bg-clip-text text-transparent">
              تعلّم بالطريقة البتناسبك
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-base sm:text-lg text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
            لقى أستاذك، اختار مادتك، واحجز درسك فردي أو مع مجموعة، أونلاين أو حضوري في مدينتك.
          </p>

          {/* Primary CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 mb-10">
            <Link
              href="/stages"
              className="px-6 sm:px-8 py-3.5 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 via-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transform hover:-translate-y-0.5 transition-all text-base"
            >
              اختار صفّك
            </Link>
            <Link
              href="/courses"
              className="px-6 sm:px-8 py-3.5 rounded-2xl font-bold text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-navy-800/80 hover:bg-gray-200 dark:hover:bg-navy-800 border border-gray-300 dark:border-indigo-900/60 shadow-sm transition-all text-base"
            >
              شوف الدروس المتاحة
            </Link>
          </div>

          {/* Prominent Search Bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="max-w-2xl mx-auto relative flex items-center shadow-xl rounded-2xl overflow-hidden border border-gray-200 dark:border-indigo-900/60 bg-white dark:bg-navy-900 focus-within:ring-2 focus-within:ring-purple-500"
          >
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مادة، كورس، أستاذ أو كتاب..."
              className="w-full px-5 py-4 text-sm sm:text-base text-gray-800 dark:text-gray-100 bg-transparent focus:outline-none placeholder:text-gray-400"
            />
            <button
              type="submit"
              className="px-5 sm:px-6 py-4 bg-purple-700 hover:bg-purple-800 text-white font-bold flex items-center gap-2 transition-colors flex-shrink-0"
            >
              <HiSearch className="w-5 h-5" />
              <span className="hidden sm:inline">بحث</span>
            </button>
          </form>
        </div>
      </section>

      {/* 3 Main Stages Section */}
      <section className="py-16 bg-gray-50/50 dark:bg-navy-900/40 border-b border-gray-200 dark:border-indigo-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mb-2">
              المراحل الدراسية في السودان
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              اختار مرحلتك وصفك لتصفح المناهج والدروس الخاصة والمدرسين المتخصصين
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Primary Stage */}
            <div className="card-base p-6 bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/80 hover:border-purple-500/50 hover:shadow-xl transition-all">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xl mb-4">
                ١
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                المرحلة الابتدائية
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                تأسيس قوي ومتابعة دراسية دقيقة من الصف الأول وحتى السادس الابتدائي.
              </p>
              <div className="flex flex-wrap gap-1.5 mb-6">
                {[
                  'الأول الابتدائي',
                  'الثاني الابتدائي',
                  'الثالث الابتدائي',
                  'الرابع الابتدائي',
                  'الخامس الابتدائي',
                  'السادس الابتدائي',
                ].map((gradeName) => (
                  <span
                    key={gradeName}
                    className="text-[11px] font-semibold px-2 py-1 rounded-md bg-gray-100 dark:bg-navy-800 text-gray-700 dark:text-gray-300"
                  >
                    {gradeName}
                  </span>
                ))}
              </div>
              <Link
                href="/stages/primary"
                className="inline-flex items-center gap-1.5 text-sm font-bold text-emerald-600 dark:text-emerald-400 hover:gap-2.5 transition-all"
              >
                <span>دخول المرحلة الابتدائية</span>
                <HiArrowSmLeft className="w-4 h-4" />
              </Link>
            </div>

            {/* Middle Stage */}
            <div className="card-base p-6 bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/80 hover:border-purple-500/50 hover:shadow-xl transition-all">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-xl mb-4">
                ٢
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                المرحلة المتوسطة
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                بناء المفاهيم المتقدمة والاستعداد لمرحلة الشهادة المتوسطة.
              </p>
              <div className="flex flex-wrap gap-1.5 mb-6">
                {['الأول المتوسط', 'الثاني المتوسط', 'الثالث المتوسط'].map((gradeName) => (
                  <span
                    key={gradeName}
                    className="text-[11px] font-semibold px-2 py-1 rounded-md bg-gray-100 dark:bg-navy-800 text-gray-700 dark:text-gray-300"
                  >
                    {gradeName}
                  </span>
                ))}
              </div>
              <Link
                href="/stages/middle"
                className="inline-flex items-center gap-1.5 text-sm font-bold text-blue-600 dark:text-blue-400 hover:gap-2.5 transition-all"
              >
                <span>دخول المرحلة المتوسطة</span>
                <HiArrowSmLeft className="w-4 h-4" />
              </Link>
            </div>

            {/* Secondary Stage */}
            <div className="card-base p-6 bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/80 hover:border-purple-500/50 hover:shadow-xl transition-all">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold text-xl mb-4">
                ٣
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                المرحلة الثانوية
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                تركيز عالي على مواد الشهادة الثانوية السودانية مع نخبة الأساتذة المتميزين.
              </p>
              <div className="flex flex-wrap gap-1.5 mb-6">
                {['الأول الثانوي', 'الثاني الثانوي', 'الثالث الثانوي'].map((gradeName) => (
                  <span
                    key={gradeName}
                    className="text-[11px] font-semibold px-2 py-1 rounded-md bg-gray-100 dark:bg-navy-800 text-gray-700 dark:text-gray-300"
                  >
                    {gradeName}
                  </span>
                ))}
              </div>
              <Link
                href="/stages/secondary"
                className="inline-flex items-center gap-1.5 text-sm font-bold text-purple-600 dark:text-purple-400 hover:gap-2.5 transition-all"
              >
                <span>دخول المرحلة الثانوية</span>
                <HiArrowSmLeft className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Available Courses Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mb-1">
                الدروس والكورسات المتاحة حالياً
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                دروس فردية ومجموعات حضورية في المدن وأونلاين بتوقيت السودان
              </p>
            </div>
            <Link
              href="/courses"
              className="inline-flex items-center gap-1 text-sm font-bold text-orange-500 hover:text-orange-600"
            >
              <span>عرض كل الكورسات ({courses.length})</span>
              <HiArrowSmLeft className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <LoadingSpinner text="جاري تحميل الدروس..." />
          ) : courses.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 p-6 rounded-2xl bg-gray-50 dark:bg-navy-900 border border-dashed border-gray-300 dark:border-indigo-950 text-gray-500">
              <p className="text-sm font-bold mb-2">جاري إضافة المجموعات والكورسات الجديدة بواسطة الإدارة.</p>
              <Link href="/contact" className="text-xs text-orange-500 hover:underline">
                اتواصل معانا لو بتفتش عن مادة معينة
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* How it Works Section */}
      <section className="py-16 bg-gray-50 dark:bg-navy-900/60 border-t border-b border-gray-200 dark:border-indigo-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold text-orange-500 uppercase tracking-widest">
              طريقة الاستخدام
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-1">
              كيف تبدأ في أستاذك بـ ٤ خطوات بسيطة؟
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step) => (
              <div
                key={step.num}
                className="relative p-6 rounded-2xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/80 shadow-sm"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-700 to-orange-500 text-white font-black text-xl flex items-center justify-center mb-4 shadow-md shadow-purple-900/20">
                  {step.num}
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                  {step.title}
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Books & Notes Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mb-1">
                أحدث الكتب والمذكرات التعليمية
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                مذكرات منسقة، امتحانات الشهادة، وكتب دراسية بصيغة PDF
              </p>
            </div>
            <Link
              href="/library"
              className="inline-flex items-center gap-1 text-sm font-bold text-purple-600 dark:text-purple-400 hover:text-purple-700"
            >
              <span>دخول المكتبة</span>
              <HiArrowSmLeft className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <LoadingSpinner text="جاري تحميل الكتب..." />
          ) : books.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {books.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10 rounded-2xl bg-gray-50 dark:bg-navy-900 border border-dashed border-gray-300 dark:border-indigo-950 text-gray-500 text-sm">
              المكتبة تحت التحديث المستمر لإضافة أحدث المذكرات.
            </div>
          )}
        </div>
      </section>

      {/* Teacher CTA Section */}
      <section className="py-16 bg-gradient-to-r from-purple-950 via-indigo-900 to-navy-950 text-white relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-orange-400 text-xs font-bold mb-4">
            <HiAcademicCap className="w-4 h-4" />
            <span>للأساتذة والمعلمين والمعلمات في كل مدن السودان</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black mb-4 font-cairo">
            أستاذ ومتميز في مادتك؟ انضم لأسرة منصة أستاذك
          </h2>
          <p className="max-w-2xl mx-auto text-sm sm:text-base text-gray-300 mb-8 leading-relaxed">
            المنصة بتسهل ليك تنظيم دروسك الخاصة ومجموعاتك الحضورية والأونلاين، ومتابعة اشتراكات طلابك ورموز التفعيل بكل يسر.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link
              href="/join-teacher"
              className="px-6 py-3 rounded-2xl font-bold text-white bg-orange-500 hover:bg-orange-600 shadow-lg shadow-orange-500/30 transition-all text-sm"
            >
              انضم لينا كأستاذ
            </Link>
            <a
              href={`${contact.whatsappBase}?text=السلام%20عليكم،%20أنا%20أستاذ%20وداير%20أنضم%20لمنصة%20أستاذك`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-2xl font-bold bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all text-sm flex items-center gap-2"
            >
              <FaWhatsapp className="w-4 h-4 text-emerald-400" />
              <span>تواصل مباشر مع الإدارة</span>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
