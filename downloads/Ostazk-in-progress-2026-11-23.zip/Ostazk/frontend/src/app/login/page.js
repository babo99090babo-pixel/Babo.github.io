'use client';

import { Suspense, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import { useAuthStore } from '@/lib/store';
import api from '@/lib/api';
import { safeRedirect } from '@/lib/navigation';
import LoadingSpinner from '@/components/LoadingSpinner';
import toast from 'react-hot-toast';
import { HiPhone, HiLockClosed, HiEye, HiEyeOff } from 'react-icons/hi';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectUrl = safeRedirect(searchParams.get('redirect'));
  const { setStudent } = useAuthStore();

  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!phone || !password) {
      toast.error('أدخل رقم هاتفك وكلمة السر');
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/auth/login', { phone, password });
      setStudent(res.data.student);
      toast.success(res.data.message || 'أهلاً بيك في أستاذك!');
      router.push(redirectUrl);
    } catch (err) {
      toast.error(err.friendlyMessage || 'رقم الهاتف أو كلمة السر غير صحيحة');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-2xl">
          <div className="text-center mb-6">
            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white font-cairo">
              تسجيل الدخول
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              ادخل برقم هاتفك المسجل لمتابعة حصصك واشتراكاتك
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                رقم هاتف الطالب
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0991974489 أو +249991974489"
                  className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 text-right"
                />
                <HiPhone className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                  كلمة السر
                </label>
                <Link
                  href="/recovery"
                  className="text-[11px] font-semibold text-purple-600 dark:text-purple-400 hover:underline"
                >
                  نسيت كلمة السر؟
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="اكتب كلمة السر"
                  className="w-full px-4 py-2.5 pr-10 pl-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <HiLockClosed className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3.5 top-3 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <HiEyeOff className="w-4 h-4" /> : <HiEye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 transition-all disabled:opacity-50 text-sm"
              >
                {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
              </button>
            </div>
          </form>

          <div className="mt-6 pt-4 border-t border-gray-200 dark:border-indigo-950/60 text-center text-xs">
            <span className="text-gray-500 dark:text-gray-400">طالب جديد وما عندك حساب؟ </span>
            <Link href="/register" className="font-bold text-purple-600 dark:text-purple-400 hover:underline">
              أنشئ حسابك الآن
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default function LoginPage() {
  return <Suspense fallback={<LoadingSpinner text="جاري التحميل..." />}><LoginForm /></Suspense>;
}
