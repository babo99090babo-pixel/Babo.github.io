'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import { useAuthStore } from '@/lib/store';
import api from '@/lib/api';
import { passwordError } from '@/lib/password';
import toast from 'react-hot-toast';
import {
  HiUser,
  HiPhone,
  HiLockClosed,
  HiEye,
  HiEyeOff,
  HiInformationCircle,
} from 'react-icons/hi';

export default function RegisterPage() {
  const router = useRouter();
  const { setStudent } = useAuthStore();

  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    parentPhone: '',
    password: '',
    confirmPassword: '',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // 1. Validate full name (at least 4 parts)
    const nameParts = formData.fullName.trim().split(/\s+/).filter(Boolean);
    if (nameParts.length < 4) {
      toast.error('اكتب اسمك الرباعي كامل (مثال: أحمد محمد عبدالله إبراهيم)');
      return;
    }

    // 2. Validate passwords match
    if (formData.password !== formData.confirmPassword) {
      toast.error('كلمتين السر ما متطابقات. اتأكد منهم.');
      return;
    }

    const validationError = passwordError(formData.password);
    if (validationError) {
      toast.error(validationError);
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/auth/register', formData);
      setStudent(res.data.student);
      toast.success(res.data.message || 'تم إنشاء حسابك بنجاح! أهلاً بيك في أستاذك');
      router.push('/dashboard');
    } catch (err) {
      toast.error(err.friendlyMessage || 'حصل خطأ في إنشاء الحساب. حاول تاني.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-6">
            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white font-cairo">
              إنشاء حساب طالب جديد
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              أهلاً بيك في أستاذك! سجّل بياناتك وابدأ رحلتك التعليمية فوراً.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                الاسم الرباعي للطالب *
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="fullName"
                  required
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="مثال: محمد أحمد علي عثمان"
                  className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <HiUser className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
              </div>
              <p className="text-[10px] text-gray-500 mt-1 flex items-center gap-1">
                <HiInformationCircle className="w-3.5 h-3.5 text-purple-500" />
                <span>اكتب الاسم من ٤ مقاطع زي ما مسجل في المدرسة أو الشهادة</span>
              </p>
            </div>

            {/* Student Phone */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                رقم هاتف الطالب (سوداني) *
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="phone"
                  inputMode="tel"
                  autoComplete="tel"
                  required
                  dir="ltr"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="0991974489 أو +249991974489"
                  className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 text-right"
                />
                <HiPhone className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
              </div>
              <p className="text-[10px] text-gray-500 mt-1">
                دا الرقم الحتدخل بيهو لحسابك، وممكن تكتبه محلي أو دولي
              </p>
            </div>

            {/* Parent Phone */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                رقم هاتف ولي الأمر *
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="parentPhone"
                  inputMode="tel"
                  required
                  dir="ltr"
                  value={formData.parentPhone}
                  onChange={handleChange}
                  placeholder="0912345678"
                  className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 text-right"
                />
                <HiPhone className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
              </div>
              <p className="text-[10px] text-gray-500 mt-1">
                يمكن استخدام نفس رقم ولي الأمر لعدة إخوة
              </p>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                كلمة السر *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  minLength={8}
                  autoComplete="new-password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="٨ أحرف أو أرقام على الأقل"
                  className="w-full px-4 py-2.5 pr-10 pl-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <HiLockClosed className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3.5 top-3 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <HiEyeOff className="w-4 h-4" /> : <HiEye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                تأكيد كلمة السر *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="confirmPassword"
                  required
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="أعد كتابة كلمة السر"
                  className="w-full px-4 py-2.5 pr-10 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <HiLockClosed className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
              </div>
            </div>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 transition-all disabled:opacity-50 text-sm"
              >
                {loading ? 'جاري إنشاء حسابك...' : 'إنشاء حسابي والبدء'}
              </button>
            </div>
          </form>

          {/* Footer note */}
          <div className="mt-6 pt-4 border-t border-gray-200 dark:border-indigo-950/60 text-center text-xs">
            <span className="text-gray-500 dark:text-gray-400">عندك حساب مسجل قبل كدا؟ </span>
            <Link href="/login" className="font-bold text-purple-600 dark:text-purple-400 hover:underline">
              تسجيل الدخول
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
