'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import { HiShieldCheck, HiDocumentText } from 'react-icons/hi';

export default function PrivacyAndTermsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold mb-3">
            <HiShieldCheck className="w-4 h-4" />
            <span>الأمان والموثوقية</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-3 font-cairo">
            الخصوصية وشروط الاستخدام وسياسات الحجز
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
            صيغت هذه السياسات بلغة واضحة ومفهومة لأولياء الأمور والطلاب لضمان حقوق الجميع.
          </p>
        </div>

        <div className="space-y-8">
          {/* Section 1: Privacy */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm space-y-4">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <HiDocumentText className="w-5 h-5 text-purple-600" />
              <span>١. سياسة الخصوصية وحماية بيانات الطلاب</span>
            </h2>
            <div className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 leading-relaxed space-y-2">
              <p>
                نلتزم في منصة «أستاذك» بحماية خصوصية كل طالب وولي أمر ومدرس.
              </p>
              <ul className="list-disc list-inside space-y-1.5 pr-2">
                <li>لا يتم عرض أرقام هواتف الطلاب أو أولياء أمورهم علناً في الموقع لأي جهة.</li>
                <li>يقتصر وصول المدرس على أسماء طلاب مجموعته المؤكدين فقط لمتابعة الحضور الأكاديمي.</li>
                <li>لا نطلب بريداً إلكترونياً من الطالب، ولا نخزن أي كلمات مرور أو رموز بصورة نصية مكشوفة.</li>
                <li>بيانات الحسابات تُعامل بمنتهى السرية وفق أعلى معايير التشفير والحماية.</li>
              </ul>
            </div>
          </div>

          {/* Section 2: Terms of Use */}
          <div id="terms" className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm space-y-4">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <HiDocumentText className="w-5 h-5 text-orange-500" />
              <span>٢. شروط الاستخدام وحضور الحصص</span>
            </h2>
            <div className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 leading-relaxed space-y-2">
              <ul className="list-disc list-inside space-y-1.5 pr-2">
                <li>الحساب الدراسي شخصي ومخصص للطالب المسجل فقط لمتابعة حصصه وكتبه المقررة.</li>
                <li>يمنع منعاً باتاً مشاركة روابط البث المباشر أو الرموز الخاصة مع أي أطراف خارج المجموعة.</li>
                <li>تطبق المنصة فحصاً أمنياً لحصر جلسة الحضور النشطة في جهاز واحد لكل حساب لمنع الانتحال وسوء الاستخدام.</li>
                <li>الاحترام المتبادل بين الطلاب والأساتذة أثناء الحصص الحضورية والأونلاين هو أساس استمرار الاشتراك.</li>
              </ul>
            </div>
          </div>

          {/* Section 3: Booking & Cancellation */}
          <div id="cancellation" className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm space-y-4">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <HiDocumentText className="w-5 h-5 text-emerald-500" />
              <span>٣. سياسة الحجز والتأكيد والإلغاء والتأجيل</span>
            </h2>
            <div className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 leading-relaxed space-y-2">
              <ul className="list-disc list-inside space-y-1.5 pr-2">
                <li>
                  <strong>تأكيد الحجز:</strong> الضغط على زر الحجز أو فتح واتساب لا يُعد إثبات دفع أو تفعيل اشتراك؛ يتم التأكيد فقط بعد مراجعة الإدارة وتوليد واستلام رمز التفعيل.
                </li>
                <li>
                  <strong>السعر المؤكد:</strong> لا يتغير السعر المؤكد على الطالب إذا تغير عدد الطلاب المسجلين في المجموعة لاحقاً.
                </li>
                <li>
                  <strong>التأجيل والاعتذار:</strong> في الحصص الفردية، يلزم إخطار الإدارة والأستاذ قبل موعد الحصة بـ ٢٤ ساعة على الأقل لترتيب موعد بديل.
                </li>
                <li>
                  <strong>الحصص الحضورية:</strong> يتم إرسال العنوان التفصيلي الدقيق لمكان الحصة بعد تأكيد الحجز مباشرة، والالتزام بالحضور في الموعد المحدد ضرورة لانتظام الدرس.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
