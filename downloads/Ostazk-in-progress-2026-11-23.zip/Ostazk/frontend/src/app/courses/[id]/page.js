'use client';

import { useContact } from '@/lib/contact';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useAuthStore } from '@/lib/store';
import api from '@/lib/api';
import toast from 'react-hot-toast';
import {
  HiAcademicCap,
  HiClock,
  HiLocationMarker,
  HiVideoCamera,
  HiUsers,
  HiCheckCircle,
  HiArrowSmRight,
  HiShieldCheck,
} from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function CourseDetailsPage() {
  const contact = useContact();
  const { id } = useParams();
  const router = useRouter();
  const { isAuthenticated, student } = useAuthStore();

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(null);

  useEffect(() => {
    async function fetchCourse() {
      try {
        const res = await api.get(`/courses/${id}`);
        const c = res.data;
        setCourse(c);
        if (c?.groups?.length > 0) {
          setSelectedGroup(c.groups[0]);
        }
      } catch (err) {
        console.error('Failed to load course details:', err);
      } finally {
        setLoading(false);
      }
    }
    if (id) fetchCourse();
  }, [id]);

  const handleBooking = async (group) => {
    if (!isAuthenticated) {
      toast.error('لازم تسجّل دخولك الأول عشان تحجز الدرس');
      router.push(`/login?redirect=/courses/${id}`);
      return;
    }

    setBookingLoading(true);
    try {
      const res = await api.post('/student/bookings', {
        courseGroupId: group.id,
      });
      setBookingSuccess(res.data);
      toast.success(res.data.message || 'تم حجزك بنجاح!');
    } catch (err) {
      toast.error(err.friendlyMessage || 'حصل خطأ في الحجز');
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner text="جاري تحميل بيانات الكورس..." />
        </main>
        <Footer />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950">
        <Header />
        <main className="flex-grow flex flex-col items-center justify-center p-6 text-center">
          <h2 className="text-xl font-bold mb-2">الكورس المطلوب غير متوفر</h2>
          <Link href="/courses" className="text-sm font-bold text-orange-500 hover:underline">
            تصفح الكورسات المتاحة
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  const methodLabels = {
    INDIVIDUAL_ONSITE: 'فردي حضوري',
    GROUP_ONSITE: 'جماعي حضوري',
    INDIVIDUAL_ONLINE: 'فردي أونلاين',
    GROUP_ONLINE: 'جماعي أونلاين',
  };

  const isOnline = course.teachingMethod?.includes('ONLINE');

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400 mb-6">
          <Link href="/courses" className="hover:text-purple-600">
            الكورسات
          </Link>
          <span>/</span>
          <span>{course.grade?.stage?.name}</span>
          <span>/</span>
          <span>{course.grade?.name}</span>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold truncate">
            {course.title}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Info (Left 2 cols in RTL) */}
          <div className="lg:col-span-2 space-y-8">
            {/* Hero info card */}
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-500/10 text-orange-600 dark:text-orange-400">
                  {methodLabels[course.teachingMethod] || 'متاح'}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-500/10 text-purple-600 dark:text-purple-400">
                  {course.subject?.name}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-gray-100 dark:bg-navy-800 text-gray-700 dark:text-gray-300">
                  {course.grade?.name}
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mb-4 font-cairo">
                {course.title}
              </h1>

              {course.description && (
                <div className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mb-6 whitespace-pre-line">
                  {course.description}
                </div>
              )}

              {/* Sessions metadata */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-navy-950 border border-gray-200 dark:border-indigo-950/60 text-xs">
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block mb-1">عدد الحصص</span>
                  <span className="font-bold text-gray-900 dark:text-white text-sm">
                    {course.totalSessions} حصة
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block mb-1">مدة الحصة</span>
                  <span className="font-bold text-gray-900 dark:text-white text-sm">
                    {course.sessionDurationMinutes} دقيقة
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block mb-1">طريقة الحضور</span>
                  <span className="font-bold text-gray-900 dark:text-white text-sm">
                    {isOnline ? 'أونلاين عبر المنصة' : 'حضوري في المركز/المكان'}
                  </span>
                </div>
              </div>
            </div>

            {/* Teacher Details */}
            {course.teacher && (
              <div className="p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
                <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                  معلومات الأستاذ
                </h2>
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-700 to-indigo-600 flex items-center justify-center text-white text-xl font-bold flex-shrink-0">
                    {course.teacher.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-gray-900 dark:text-white">
                      {course.teacher.name}
                    </h3>
                    {course.teacher.qualifications && (
                      <p className="text-xs text-purple-600 dark:text-purple-400 font-medium mt-0.5">
                        {course.teacher.qualifications}
                      </p>
                    )}
                    {course.teacher.city && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        المدينة: {course.teacher.city}
                      </p>
                    )}
                    {course.teacher.bio && (
                      <p className="text-xs text-gray-600 dark:text-gray-300 mt-2 leading-relaxed">
                        {course.teacher.bio}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Groups & Schedules */}
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-sm">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                المجموعات والمواعيد المتاحة
              </h2>

              {course.groups?.length > 0 ? (
                <div className="space-y-4">
                  {course.groups.map((group) => {
                    const isSelected = selectedGroup?.id === group.id;
                    const seatsLeft = group.maxStudents - group.enrolledCount;

                    return (
                      <div
                        key={group.id}
                        onClick={() => setSelectedGroup(group)}
                        className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'border-orange-500 bg-orange-500/5 ring-1 ring-orange-500/30'
                            : 'border-gray-200 dark:border-indigo-950/80 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                          <div>
                            <h3 className="text-base font-bold text-gray-900 dark:text-white">
                              {group.name}
                            </h3>
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              سعة المجموعة: {group.maxStudents} طلاب (متبقي {Math.max(0, seatsLeft)} مقعد)
                            </span>
                          </div>

                          <div className="text-left">
                            <span className="text-xl font-black text-orange-500 block">
                              {Number(group.priceAmount).toLocaleString()} SDG
                            </span>
                            <span className="text-[11px] text-gray-500">
                              {group.priceType === 'PER_STUDENT' ? 'للطالب' : 'للمجموعة كاملة'} •{' '}
                              {group.pricePer === 'PER_SESSION' ? 'للحصة' : 'للكورس كامل'}
                            </span>
                          </div>
                        </div>

                        {/* Sessions preview */}
                        {group.sessions?.length > 0 && (
                          <div className="mt-3 pt-3 border-t border-gray-100 dark:border-indigo-950/40 text-xs text-gray-600 dark:text-gray-300 space-y-1">
                            <p className="font-semibold text-gray-800 dark:text-gray-200">
                              مواعيد الحصص (بتوقيت السودان):
                            </p>
                            {group.sessions.map((sess) => (
                              <div key={sess.id} className="flex items-center gap-2 text-[11px]">
                                <HiClock className="w-3.5 h-3.5 text-purple-500" />
                                <span>
                                  {new Date(sess.date).toLocaleDateString('ar-SD')} من {sess.startTime} إلى {sess.endTime}
                                </span>
                                {sess.location?.location && (
                                  <span className="text-gray-500">
                                    • مكان الحضور: {sess.location.location.area} ({sess.location.location.venueName})
                                  </span>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-xs text-gray-500">لا توجد مجموعات مفتوحة للحجز حالياً.</p>
              )}
            </div>
          </div>

          {/* Booking Summary Box (Right Sidebar in RTL) */}
          <div className="space-y-6">
            <div className="sticky top-24 p-6 rounded-3xl bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 shadow-xl">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                تأكيد حجز الدرس
              </h3>

              {selectedGroup ? (
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-xs py-2 border-b border-gray-100 dark:border-indigo-950/60">
                    <span className="text-gray-500">المجموعة المختارة:</span>
                    <span className="font-bold text-gray-900 dark:text-white">{selectedGroup.name}</span>
                  </div>
                  <div className="flex justify-between text-xs py-2 border-b border-gray-100 dark:border-indigo-950/60">
                    <span className="text-gray-500">المبلغ المطلوب:</span>
                    <span className="font-bold text-orange-500 text-sm">
                      {Number(selectedGroup.priceAmount).toLocaleString()} SDG
                    </span>
                  </div>
                  <div className="flex justify-between text-xs py-2 border-b border-gray-100 dark:border-indigo-950/60">
                    <span className="text-gray-500">طريقة الحساب:</span>
                    <span className="font-medium text-gray-700 dark:text-gray-300">
                      {selectedGroup.priceType === 'PER_STUDENT' ? 'للطالب الواحد' : 'للمجموعة'}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs py-2">
                    <span className="text-gray-500">توقيت الحصص:</span>
                    <span className="font-medium text-purple-600 dark:text-purple-400">بتوقيت السودان</span>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-gray-500 mb-6">يرجى اختيار مجموعة من القائمة للحجز.</p>
              )}

              {/* Booking success notification */}
              {bookingSuccess && (
                <div className="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs space-y-2">
                  <div className="flex items-center gap-2 font-bold">
                    <HiCheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    <span>تم تسجيل طلب حجزك بنجاح!</span>
                  </div>
                  <p className="leading-relaxed">
                    اتواصل الآن مع إدارة أستاذك عبر واتساب لتأكيد الحجز والدفع واستلام رمز تفعيل الحصص.
                  </p>
                  <a
                    href={`${contact.whatsappBase}?text=${encodeURIComponent(
                      `السلام عليكم، أنا الطالب: ${student?.fullName || ''}\nرقم الهاتف: ${student?.phone || ''}\nحجزت كورس: "${course.title}" (${selectedGroup?.name})\nوداير أكد الحجز واستلم رمز التفعيل.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-colors mt-2"
                  >
                    <FaWhatsapp className="w-4 h-4" />
                    <span>مراسلة الإدارة لتأكيد الحجز</span>
                  </a>
                </div>
              )}

              {/* Action Button */}
              {!bookingSuccess && (
                <button
                  onClick={() => handleBooking(selectedGroup)}
                  disabled={!selectedGroup || bookingLoading}
                  className="w-full py-3.5 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 transition-all disabled:opacity-50 text-sm mb-3"
                >
                  {bookingLoading ? 'جاري تأكيد الحجز...' : 'احجز الآن'}
                </button>
              )}

              {/* WhatsApp direct contact */}
              <a
                href={`${contact.whatsappBase}?text=${encodeURIComponent(
                  `السلام عليكم، داير استفسر عن كورس: "${course.title}" مع الأستاذ: ${course.teacher?.name || ''}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-2xl font-bold border border-emerald-600/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-600/10 transition-all text-xs flex items-center justify-center gap-2 text-center"
              >
                <FaWhatsapp className="w-4 h-4" />
                <span>استفسار عبر واتساب الإدارة</span>
              </a>

              <div className="mt-6 pt-4 border-t border-gray-100 dark:border-indigo-950/60 flex items-center gap-2 text-[11px] text-gray-500">
                <HiShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>تأكيد الحجز والدفع واستلام الرمز يتم بأمان مع إدارة منصة أستاذك</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
