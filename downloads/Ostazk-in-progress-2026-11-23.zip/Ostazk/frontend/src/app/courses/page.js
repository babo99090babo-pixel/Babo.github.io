'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import MobileNav from '@/components/MobileNav';
import CourseCard from '@/components/CourseCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import EmptyState from '@/components/EmptyState';
import api from '@/lib/api';
import { HiFilter, HiSearch, HiX, HiRefresh } from 'react-icons/hi';

function CoursesContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [courses, setCourses] = useState([]);
  const [stages, setStages] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);

  // Filters state from query params
  const [stageFilter, setStageFilter] = useState(searchParams.get('stage') || '');
  const [gradeFilter, setGradeFilter] = useState(searchParams.get('grade') || '');
  const [subjectFilter, setSubjectFilter] = useState(searchParams.get('subject') || '');
  const [methodFilter, setMethodFilter] = useState(searchParams.get('method') || '');
  const [teacherFilter, setTeacherFilter] = useState(searchParams.get('teacher') || '');
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1);

  // Load filter options
  useEffect(() => {
    async function loadOptions() {
      try {
        const [stagesRes, subjectsRes, teachersRes] = await Promise.allSettled([
          api.get('/stages'),
          api.get('/subjects'),
          api.get('/teachers?limit=100'),
        ]);

        if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data || []);
        if (subjectsRes.status === 'fulfilled') setSubjects(subjectsRes.value.data || []);
        if (teachersRes.status === 'fulfilled') setTeachers(teachersRes.value.data.teachers || []);
      } catch (err) {
        console.error('Error loading options:', err);
      }
    }
    loadOptions();
  }, []);

  // Fetch courses on filter changes
  useEffect(() => {
    async function fetchCourses() {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (stageFilter) params.append('stage', stageFilter);
        if (gradeFilter) params.append('grade', gradeFilter);
        if (subjectFilter) params.append('subject', subjectFilter);
        if (methodFilter) params.append('method', methodFilter);
        if (teacherFilter) params.append('teacher', teacherFilter);
        if (searchTerm) params.append('search', searchTerm);
        params.append('page', page);
        params.append('limit', 12);

        const res = await api.get(`/courses?${params.toString()}`);
        setCourses(res.data.courses || []);
        setPagination(res.data.pagination || { page: 1, totalPages: 1, total: 0 });
      } catch (err) {
        console.error('Error fetching courses:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchCourses();
  }, [stageFilter, gradeFilter, subjectFilter, methodFilter, teacherFilter, searchTerm, page]);

  const handleResetFilters = () => {
    setStageFilter('');
    setGradeFilter('');
    setSubjectFilter('');
    setMethodFilter('');
    setTeacherFilter('');
    setSearchTerm('');
    setPage(1);
    router.push('/courses');
  };

  // Find grades for selected stage
  const selectedStageObj = stages.find((s) => s.id === Number(stageFilter));
  const availableGrades = selectedStageObj?.grades || [];

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-navy-950 text-gray-900 dark:text-gray-100">
      <Header />
      <WhatsAppFAB />
      <MobileNav />

      <main className="flex-grow py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Title */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white font-cairo">
              الكورسات والدروس الخصوصية
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
              لقى أستاذك، اختار مادتك، واحجز درسك فردي أو مع مجموعة، أونلاين أو حضوري.
            </p>
          </div>

          {/* Mobile Filter Toggle */}
          <button
            onClick={() => setShowFiltersMobile(!showFiltersMobile)}
            className="md:hidden flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-purple-600/10 text-purple-600 dark:text-purple-400 font-bold text-sm border border-purple-500/20"
          >
            <HiFilter className="w-4 h-4" />
            <span>خيارات التصفية والبحث</span>
          </button>
        </div>

        {/* Filters Box */}
        <div
          className={`p-5 rounded-2xl bg-gray-50 dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 mb-8 transition-all ${
            showFiltersMobile ? 'block' : 'hidden md:block'
          }`}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {/* Search */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                البحث
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setPage(1);
                  }}
                  placeholder="ابحث بالعنوان أو الوصف..."
                  className="w-full px-3 py-2 pr-9 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <HiSearch className="w-4 h-4 text-gray-400 absolute right-3 top-2.5" />
              </div>
            </div>

            {/* Stage */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                المرحلة الدراسية
              </label>
              <select
                value={stageFilter}
                onChange={(e) => {
                  setStageFilter(e.target.value);
                  setGradeFilter('');
                  setPage(1);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">كل المراحل</option>
                {stages.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Grade */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                الصف الدراسي
              </label>
              <select
                value={gradeFilter}
                onChange={(e) => {
                  setGradeFilter(e.target.value);
                  setPage(1);
                }}
                disabled={!stageFilter && stages.length > 0}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50"
              >
                <option value="">كل الصفوف</option>
                {availableGrades.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Subject */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                المادة
              </label>
              <select
                value={subjectFilter}
                onChange={(e) => {
                  setSubjectFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">كل المواد</option>
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Teaching Method (4 Types) */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                نوع الدرس
              </label>
              <select
                value={methodFilter}
                onChange={(e) => {
                  setMethodFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">كل الأنواع</option>
                <option value="INDIVIDUAL_ONSITE">فردي حضوري</option>
                <option value="GROUP_ONSITE">جماعي حضوري</option>
                <option value="INDIVIDUAL_ONLINE">فردي أونلاين</option>
                <option value="GROUP_ONLINE">جماعي أونلاين</option>
              </select>
            </div>

            {/* Teacher */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                المدرس
              </label>
              <select
                value={teacherFilter}
                onChange={(e) => {
                  setTeacherFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-indigo-950 bg-white dark:bg-navy-950 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">كل المدرسين</option>
                {teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-gray-200 dark:border-indigo-950/60">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              عدد الكورسات المعروضة: {pagination.total}
            </span>
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 text-xs font-bold text-orange-500 hover:text-orange-600"
            >
              <HiRefresh className="w-3.5 h-3.5" />
              <span>إعادة ضبط التصفية</span>
            </button>
          </div>
        </div>

        {/* Courses Grid */}
        {loading ? (
          <LoadingSpinner text="جاري تحميل الكورسات..." />
        ) : courses.length > 0 ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
              {courses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 pt-6">
                <button
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page <= 1}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950 disabled:opacity-40"
                >
                  السابق
                </button>
                <span className="text-xs font-bold px-3">
                  صفحة {pagination.page} من {pagination.totalPages}
                </span>
                <button
                  onClick={() => setPage(Math.min(pagination.totalPages, page + 1))}
                  disabled={page >= pagination.totalPages}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-indigo-950 disabled:opacity-40"
                >
                  التالي
                </button>
              </div>
            )}
          </>
        ) : (
          <EmptyState
            title="ما لقينا كورسات مطابقة لخياراتك"
            description="جرب إزالة بعض الفلاتر، أو تواصل مع إدارة أستاذك لمساعدتك في توفير المدرس المطلوب."
            actionText="إعادة ضبط الفلاتر"
            actionHref="/courses"
          />
        )}
      </main>

      <Footer />
    </div>
  );
}

export default function CoursesPage() {
  return (
    <Suspense fallback={<LoadingSpinner text="جاري التحميل..." />}>
      <CoursesContent />
    </Suspense>
  );
}
