'use client';
import { useContact } from '@/lib/contact';
import Link from 'next/link';
import { HiAcademicCap, HiPhone, HiClock, HiShieldCheck } from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';

export default function Footer() {
  const contact = useContact();
  return (
    <footer className="bg-gray-100 dark:bg-navy-950 border-t border-gray-200 dark:border-indigo-950/80 transition-colors pb-20 md:pb-10 pt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-orange-500 flex items-center justify-center text-white">
                <HiAcademicCap className="w-5 h-5" />
              </div>
              <span className="text-2xl font-black text-gray-900 dark:text-white font-cairo">
                أستاذك
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              {contact.slogan}
            </p>
            <div className="flex items-center gap-2 text-xs font-semibold text-purple-600 dark:text-purple-400">
              <HiClock className="w-4 h-4" />
              <span>كل المواعيد معروضة بتوقيت السودان (Africa/Khartoum)</span>
            </div>
          </div>

          {/* Quick links */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              روابط سريعة
            </h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li>
                <Link href="/stages" className="hover:text-orange-500 transition-colors">
                  المراحل والصفوف الدراسية
                </Link>
              </li>
              <li>
                <Link href="/courses" className="hover:text-orange-500 transition-colors">
                  الكورسات والحصص المتاحة
                </Link>
              </li>
              <li>
                <Link href="/teachers" className="hover:text-orange-500 transition-colors">
                  دليل المدرسين المعتمدين
                </Link>
              </li>
              <li>
                <Link href="/library" className="hover:text-orange-500 transition-colors">
                  مكتبة الكتب والمذكرات
                </Link>
              </li>
              <li>
                <Link href="/join-teacher" className="hover:text-orange-500 transition-colors">
                  انضم لينا كأستاذ
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact & Support */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              تواصل مع الإدارة
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              فريق الإدارة جاهز لمساعدتك في الحجز وتفعيل الرموز واستفسارات الدروس.
            </p>
            <div className="space-y-2 text-sm font-medium">
              <a
                href={contact.whatsappBase}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 hover:underline"
              >
                <FaWhatsapp className="w-4 h-4" />
                <span dir="ltr">{contact.phone} (واتساب)</span>
              </a>
              <a
                href={contact.telephone}
                className="flex items-center gap-2 text-gray-700 dark:text-gray-300 hover:text-orange-500"
              >
                <HiPhone className="w-4 h-4" />
                <span dir="ltr">{contact.phone} (اتصال مباشر)</span>
              </a>
            </div>
          </div>

          {/* Policies & Safety */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              الضمان والسياسات
            </h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li>
                <Link href="/privacy" className="hover:text-orange-500 transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link href="/privacy#terms" className="hover:text-orange-500 transition-colors">
                  شروط الاستخدام
                </Link>
              </li>
              <li>
                <Link href="/privacy#cancellation" className="hover:text-orange-500 transition-colors">
                  سياسات الحجز والتأجيل والإلغاء
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-orange-500 transition-colors">
                  الأسئلة الشائعة والدعم الفني
                </Link>
              </li>
              <li className="pt-2">
                <Link
                  href="/admin/login"
                  className="inline-flex items-center gap-1.5 text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  <HiShieldCheck className="w-3.5 h-3.5" />
                  <span>دخول الإدارة</span>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-gray-200 dark:border-indigo-950/60 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500 dark:text-gray-400 gap-2">
          <p>© {new Date().getFullYear()} منصة أستاذك التعليمية. جميع الحقوق محفوظة للسودان.</p>
          <p className="flex items-center gap-1">
            <span>العملة المعتمدة:</span>
            <span className="font-bold text-orange-500">الجنيه السوداني (SDG)</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
