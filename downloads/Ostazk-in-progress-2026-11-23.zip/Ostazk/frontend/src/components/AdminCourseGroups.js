'use client';
import { useEffect, useState } from 'react';
import api from '@/lib/api';
import RequestError from './RequestError';
import LoadingSpinner from './LoadingSpinner';
import toast from 'react-hot-toast';

const field = 'block w-full mt-1 px-3 py-2 rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-sm';
const groupStates = { WAITING_ENROLLMENT:'بانتظار اكتمال العدد', CONFIRMED:'مؤكدة', FULL:'مكتملة', POSTPONED:'مؤجلة', CANCELLED:'ملغية', FINISHED:'منتهية' };
const sessionStates = { SCHEDULED:'مجدولة', LIVE:'مباشرة', COMPLETED:'منتهية', CANCELLED:'ملغية' };

function SessionForm({ group, locations, onSaved }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ sessionNumber: Math.max(0,...(group.sessions || []).map(s=>s.sessionNumber))+1, date:'', startTime:'', endTime:'', locationId:'' });
  const save = async e => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      await api.post(`/admin/groups/${group.id}/sessions`, { sessions:[{ ...form, sessionNumber:Number(form.sessionNumber), locationId:form.locationId ? Number(form.locationId) : undefined }] });
      toast.success('تمت إضافة الحصة'); setOpen(false); onSaved();
    } catch (err) { setError(err.friendlyMessage); } finally { setBusy(false); }
  };
  const update = async (session, status) => {
    setBusy(true); setError('');
    try { await api.put(`/admin/sessions/${session.id}`, { status }); onSaved(); }
    catch(err) { setError(err.friendlyMessage); } finally { setBusy(false); }
  };
  return <div className="mt-4 space-y-3">
    {(group.sessions || []).map(s => <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 text-xs p-3 rounded-xl bg-gray-50 dark:bg-navy-950">
      <span>حصة {s.sessionNumber} · {s.date.slice(0,10)} · {s.startTime}–{s.endTime} (السودان)</span>
      <select aria-label={`حالة الحصة ${s.sessionNumber}`} disabled={busy} className="p-2 rounded-lg dark:bg-navy-900" value={s.status} onChange={e => update(s,e.target.value)}>{Object.entries(sessionStates).map(([key,value])=><option key={key} value={key}>{value}</option>)}</select>
    </div>)}
    <button type="button" className="text-purple-600 dark:text-purple-400 font-bold text-sm" onClick={()=>setOpen(!open)}>{open?'إغلاق':'+ إضافة حصة'}</button>
    {open && <form onSubmit={save} className="space-y-3"><p className="text-xs">الأوقات بتوقيت السودان؛ اختر نهاية بعد بداية الحصة في نفس اليوم.</p><div className="grid sm:grid-cols-2 gap-3">
      {[['sessionNumber','رقم الحصة','number'],['date','تاريخ الحصة','date'],['startTime','البداية','time'],['endTime','النهاية','time']].map(([key,label,type])=><label key={key} className="text-xs font-bold">{label}<input required min={type==='number'?1:undefined} type={type} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})} className={field}/></label>)}
      <label className="text-xs font-bold">مكان الحصة (مطلوب للحضوري)<select required={group.teachingMethod?.endsWith('ONSITE')} value={form.locationId} onChange={e=>setForm({...form,locationId:e.target.value})} className={field}><option value="">اختار المكان للحصة الحضورية</option>{locations.map(l=><option key={l.id} value={l.id}>{l.venueName || l.city} - {l.area}</option>)}</select></label>
    </div><button disabled={busy} className="px-4 py-2 rounded-xl bg-purple-600 text-white disabled:opacity-50">حفظ الحصة</button></form>}
    <RequestError message={error}/>
  </div>;
}

export default function AdminCourseGroups({ course, onClose, onChanged }) {
  const [groups,setGroups]=useState([]),[locations,setLocations]=useState([]),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(''),[attempt,setAttempt]=useState(0);
  const [form,setForm]=useState({name:'',minStudents:1,maxStudents:10,priceAmount:'',priceType:'PER_STUDENT',pricePer:'PER_COURSE'});
  const [location,setLocation]=useState({state:'',city:'',area:'',venueName:'',address:''});
  const reload=()=>{setAttempt(a=>a+1);onChanged?.();};
  useEffect(()=>{let active=true;setLoading(true);setError('');Promise.all([api.get(`/admin/courses/${course.id}/groups`),api.get('/admin/locations')]).then(([g,l])=>{if(active){setGroups(Array.isArray(g.data)?g.data:g.data.groups||[]);setLocations(l.data||[]);}}).catch(e=>{if(active)setError(e.friendlyMessage);}).finally(()=>{if(active)setLoading(false);});return()=>{active=false;};},[course.id,attempt]);
  const save=async e=>{e.preventDefault();setBusy(true);setError('');try{await api.post(`/admin/courses/${course.id}/groups`,form);toast.success('تم إنشاء المجموعة');setForm({...form,name:''});reload();}catch(e){setError(e.friendlyMessage);}finally{setBusy(false);}};
  const update=async (group,status)=>{if(status==='CANCELLED'&&!window.confirm('إلغاء المجموعة يوقف الاشتراكات والرموز المرتبطة بها. هل تريد المتابعة؟'))return;setBusy(true);try{await api.put(`/admin/groups/${group.id}`,{status});reload();}catch(e){setError(e.friendlyMessage);}finally{setBusy(false);}};
  const addLocation=async e=>{e.preventDefault();setBusy(true);try{await api.post('/admin/locations',location);toast.success('تم حفظ مكان الحصص');reload();}catch(e){setError(e.friendlyMessage);}finally{setBusy(false);}};
  return <section className="p-5 rounded-3xl border border-purple-500/30 bg-white dark:bg-navy-900 space-y-5">
    <div className="flex justify-between gap-3"><h3 className="font-bold">مجموعات وحصص: {course.title}</h3><button type="button" onClick={onClose} className="text-gray-500">إغلاق</button></div>
    <RequestError message={error} onRetry={reload}/>
    {loading?<LoadingSpinner/>:groups.map(group=><div key={group.id} className="p-4 rounded-2xl border border-gray-200 dark:border-indigo-950">
      <div className="flex flex-wrap justify-between items-center gap-2"><div><h4 className="font-bold">{group.name}</h4><p className="text-xs text-gray-500">{group.enrolledCount} / {group.maxStudents} مقعد · {group.priceAmount} SDG · {groupStates[group.status]}</p></div>
        <select aria-label={`حالة مجموعة ${group.name}`} disabled={busy||['CANCELLED','FINISHED'].includes(group.status)} value={group.status} onChange={e=>update(group,e.target.value)} className="p-2 rounded-xl dark:bg-navy-950 text-xs">{Object.entries(groupStates).map(([k,v])=><option key={k} value={k} disabled={['FULL','WAITING_ENROLLMENT'].includes(k)}>{v}</option>)}</select></div>
      <SessionForm group={{ ...group, teachingMethod: course.teachingMethod }} locations={locations} onSaved={reload}/>
    </div>)}
    <details className="rounded-2xl p-4 border border-orange-500/20" open={groups.length===0}><summary className="cursor-pointer font-bold text-orange-600">إضافة مجموعة جديدة</summary><form onSubmit={save} className="space-y-3 mt-4"><div className="grid sm:grid-cols-2 gap-3">
      {[['name','اسم المجموعة','text'],['minStudents','العدد الأدنى','number'],['maxStudents','عدد المقاعد الأقصى','number'],['priceAmount','السعر بالجنيه السوداني','number']].map(([key,label,type])=><label key={key} className="text-xs font-bold">{label}<input type={type} required min={type==='number'?(key==='priceAmount'?0:1):undefined} step={key==='priceAmount'?'0.01':undefined} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})} className={field}/></label>)}
      <label className="text-xs font-bold">حساب السعر<select value={form.priceType} onChange={e=>setForm({...form,priceType:e.target.value})} className={field}><option value="PER_STUDENT">لكل طالب</option><option value="PER_GROUP">للمجموعة كاملة</option></select></label>
      <label className="text-xs font-bold">مدة السعر<select value={form.pricePer} onChange={e=>setForm({...form,pricePer:e.target.value})} className={field}><option value="PER_COURSE">للكورس</option><option value="PER_SESSION">للحصة</option></select></label>
    </div><button disabled={busy} className="px-5 py-2 rounded-xl bg-orange-600 text-white disabled:opacity-50">إنشاء المجموعة</button></form></details>
    {course.teachingMethod?.endsWith('ONSITE')&&<details className="p-4 border rounded-2xl border-purple-500/20"><summary className="cursor-pointer font-bold">إضافة مكان للحصص الحضورية</summary><form onSubmit={addLocation} className="mt-4 space-y-3"><div className="grid sm:grid-cols-2 gap-3">{[['state','الولاية'],['city','المدينة'],['area','الحي'],['venueName','اسم المكان'],['address','العنوان التفصيلي']].map(([k,label])=><label key={k} className="text-xs">{label}<input required value={location[k]} onChange={e=>setLocation({...location,[k]:e.target.value})} className={field}/></label>)}</div><button disabled={busy} className="px-4 py-2 bg-purple-600 text-white rounded-xl">حفظ المكان</button></form></details>}
  </section>;
}
