'use client';

import { useThemeStore } from '@/lib/store';
import { HiSun, HiMoon } from 'react-icons/hi';

export default function ThemeToggle({ className = '' }) {
  const { isDark, toggleTheme } = useThemeStore();

  return (
    <button
      onClick={toggleTheme}
      type="button"
      className={`p-2.5 rounded-xl border border-gray-200 dark:border-indigo-900/60 bg-gray-100 dark:bg-navy-800/80 text-gray-700 dark:text-amber-300 hover:scale-105 transition-all shadow-sm ${className}`}
      aria-label="تبديل الوضع الليلي والنهاري"
      title={isDark ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}
    >
      {isDark ? (
        <HiSun className="w-5 h-5 text-amber-400" />
      ) : (
        <HiMoon className="w-5 h-5 text-indigo-700" />
      )}
    </button>
  );
}
