'use client';
import { useEffect, useState } from 'react';
import api from '@/lib/api';
import Pagination from './Pagination';
import RequestError from './RequestError';

export default function AdminBookingSelect({ selected, onSelect }) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true);
    const timer = setTimeout(() => {
      api.get('/admin/bookings', { params: { status: 'CONFIRMED', search, page, limit: 20 } })
        .then(({ data }) => { if (active) { setRows(data.bookings || []); setPagination(data.pagination); setError(''); } })
        .catch(err => { if (active) setError(err.friendlyMessage); })
        .finally(() => { if (active) setLoading(false); });
    }, 200);
    return () => { active = false; clearTimeout(timer); };
  }, [search, page, retry]);
  const options = selected && !rows.some(row => row.id === selected.id) ? [selected, ...rows] : rows;
  return <div className="space-y-3">
    <label className="block text-xs font-bold">ابحث باسم الطالب أو رقم هاتفه
      <input type="search" value={search} onChange={event => { setSearch(event.target.value); setPage(1); }} className="block w-full mt-2 px-3 py-2 rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950"/>
    </label>
    <label className="block text-xs font-bold">الحجز المؤكد
      <select required value={selected?.id || ''} onChange={event => onSelect(options.find(row => row.id === event.target.value) || null)} className="block w-full mt-2 px-3 py-2 rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950">
        <option value="">اختار الطالب والحجز</option>
        {options.map(row => <option key={row.id} value={row.id}>{row.student?.fullName} — {row.courseGroup?.course?.title} ({row.courseGroup?.name})</option>)}
      </select>
    </label>
    {loading && <p role="status" className="text-xs text-gray-500">جاري تحميل الحجوزات...</p>}
    <RequestError message={error} onRetry={() => setRetry(value => value + 1)}/>
    <Pagination pagination={pagination} onPage={setPage} disabled={loading} label="صفحات الحجوزات المؤكدة"/>
  </div>;
}
