'use client';

import { useContact } from '@/lib/contact';
import { FaWhatsapp } from 'react-icons/fa';

export default function WhatsAppFAB() {
  const contact = useContact();
  const whatsappUrl = contact.whatsappBase + '?text=' + encodeURIComponent('السلام عليكم، داير استفسر بخصوص منصة أستاذك.');

  return (
    <aside
      aria-label="تواصل عبر واتساب"
      className="fixed bottom-20 md:bottom-8 left-4 md:left-8 z-40"
    >
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium px-4 py-3 rounded-full shadow-lg hover:shadow-emerald-600/40 transition-all duration-300 transform hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-emerald-400/40"
      >
        <FaWhatsapp className="w-6 h-6 animate-pulse" />
        <span className="hidden sm:inline-block text-sm font-semibold">
          تواصل في واتساب
        </span>
      </a>
    </aside>
  );
}
