'use client';
import { useEffect, useState } from 'react';
import api from '@/lib/api';
import Pagination from './Pagination';
import RequestError from './RequestError';

export default function AdminEntitySelect({ endpoint, listKey, value, onChange, label, required = true }) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState([]);
  const [selected, setSelected] = useState(null);
  const [pagination, setPagination] = useState(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    const timer = setTimeout(() => {
      api.get(endpoint, { params: { search, page, limit: 20 } }).then(({ data }) => {
        if (active) { setRows(data[listKey] || []); setPagination(data.pagination); setError(''); }
      }).catch(err => { if (active) setError(err.friendlyMessage); });
    }, 250);
    return () => { active = false; clearTimeout(timer); };
  }, [endpoint, listKey, page, search, attempt]);
  const options = selected && !rows.some(row => row.id === selected.id) ? [selected, ...rows] : rows;
  return <div className="space-y-2">
    <label className="block text-xs font-bold">{label}
      <input type="search" value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder={`ابحث عن ${label}`} className="block mt-1 w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-xs" />
    </label>
    <select aria-label={label} required={required} value={value} onChange={e => { onChange(e.target.value); setSelected(options.find(row => row.id === e.target.value)); }} className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-indigo-950 bg-gray-50 dark:bg-navy-950 text-xs">
      <option value="">اختار {label}</option>
      {options.map(row => <option key={row.id} value={row.id} disabled={row.isActive === false || row.isApproved === false}>{row.title || row.name || row.fullName}</option>)}
    </select>
    <RequestError message={error} onRetry={() => setAttempt(a => a + 1)} />
    <Pagination pagination={pagination} onPage={setPage} label={`صفحات ${label}`} />
  </div>;
}
