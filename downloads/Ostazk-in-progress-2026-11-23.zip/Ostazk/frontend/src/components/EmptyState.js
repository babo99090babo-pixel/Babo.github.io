import Link from 'next/link';
import { HiOutlineSearch } from 'react-icons/hi';

export default function EmptyState({
  title = 'ما في نتائج متوفرة حالياً',
  description = 'جرب غيّر خيارات التصفية أو افتش بكلمات تانية.',
  actionText = '',
  actionHref = '',
}) {
  return (
    <div className="flex flex-col items-center justify-center p-10 text-center rounded-2xl border border-dashed border-gray-300 dark:border-indigo-950/80 bg-gray-50/50 dark:bg-navy-900/30 max-w-lg mx-auto my-6">
      <div className="w-14 h-14 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center mb-3">
        <HiOutlineSearch className="w-7 h-7" />
      </div>
      <h4 className="text-base font-bold text-gray-900 dark:text-white mb-1">
        {title}
      </h4>
      <p className="text-xs text-gray-500 dark:text-gray-400 max-w-sm mb-4 leading-relaxed">
        {description}
      </p>
      {actionText && actionHref && (
        <Link
          href={actionHref}
          className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 transition-colors"
        >
          {actionText}
        </Link>
      )}
    </div>
  );
}
