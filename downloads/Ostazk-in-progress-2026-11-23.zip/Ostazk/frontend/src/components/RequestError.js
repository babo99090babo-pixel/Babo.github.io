'use client';

export default function RequestError({ message, onRetry }) {
  if (!message) return null;
  return <div role="alert" className="my-4 p-4 rounded-2xl border border-amber-500/30 bg-amber-500/10 text-sm text-amber-800 dark:text-amber-200">
    <p>{message}</p>
    {onRetry && <button type="button" onClick={onRetry} className="mt-3 px-4 py-2 rounded-xl bg-orange-600 text-white font-bold">إعادة المحاولة</button>}
  </div>;
}
