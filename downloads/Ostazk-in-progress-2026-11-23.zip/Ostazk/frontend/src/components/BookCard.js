import Link from 'next/link';
import { HiDocumentText, HiDownload, HiEye, HiLockClosed } from 'react-icons/hi';

export default function BookCard({ book }) {
  if (!book) return null;

  const accessBadges = {
    PUBLIC: { label: 'متاح للجميع', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
    REGISTERED: { label: 'للحسابات المسجلة', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400' },
    SUBSCRIBER: { label: 'للمشتركين بالكورس', color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  };

  const badge = accessBadges[book.accessLevel] || accessBadges.PUBLIC;

  return (
    <div className="card-base p-4 bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 hover:border-purple-500/40 hover:shadow-lg transition-all duration-300 flex flex-col justify-between">
      <div>
        {/* Top visual representation */}
        <div className="h-32 rounded-xl bg-gradient-to-br from-indigo-900 via-navy-800 to-purple-950 flex flex-col items-center justify-center text-white mb-3 p-3 text-center relative overflow-hidden">
          <HiDocumentText className="w-10 h-10 text-orange-400 mb-1" />
          <span className="text-xs font-semibold text-gray-200 line-clamp-1">{book.subject?.name || 'مذكرة / كتاب'}</span>
          <span className="text-[10px] text-purple-300">{book.grade?.name}</span>

          <span className={`absolute top-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded-full ${badge.color} bg-navy-950/80`}>
            {badge.label}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-sm font-bold text-gray-900 dark:text-white mb-1 line-clamp-2">
          {book.title}
        </h3>

        {/* Info */}
        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 mb-3">
          {book.year && <span>إصدار {book.year}</span>}
          {book.fileSize > 0 && <span>• {(book.fileSize / (1024 * 1024)).toFixed(1)} ميقا</span>}
        </div>
      </div>

      {/* Action buttons */}
      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-100 dark:border-indigo-950/50">
        <Link
          href={`/library/${book.id}`}
          className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-bold bg-purple-600/10 hover:bg-purple-600/20 text-purple-600 dark:text-purple-400 transition-colors"
        >
          <HiEye className="w-3.5 h-3.5" />
          <span>معاينة</span>
        </Link>
        <Link
          href={`/library/${book.id}#download`}
          className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-bold bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 transition-colors"
        >
          {book.allowDownload ? (
            <>
              <HiDownload className="w-3.5 h-3.5" />
              <span>تحميل</span>
            </>
          ) : (
            <>
              <HiLockClosed className="w-3.5 h-3.5" />
              <span>للقراءة فقط</span>
            </>
          )}
        </Link>
      </div>
    </div>
  );
}
