'use client';
import { useState } from 'react';
import api from '@/lib/api';
import RequestError from './RequestError';
import toast from 'react-hot-toast';

export default function AdminTeacherForm({ onCreated }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ name: '', phone: '', email: '', city: '', qualifications: '', bio: '' });
  const save = async e => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      await api.post('/admin/teachers', Object.fromEntries(Object.entries(form).map(([k,v]) => [k, v.trim() || null])));
      toast.success('تم إنشاء ملف المدرس ونشره في الدليل'); setOpen(false); onCreated();
    } catch (err) { setError(err.friendlyMessage); } finally { setBusy(false); }
  };
  return <div>
    <button className="px-4 py-2 rounded-xl bg-orange-600 text-white font-bold text-sm" onClick={() => setOpen(!open)}>{open ? 'إغلاق النموذج' : '+ إضافة مدرس معتمد'}</button>
    {open && <form onSubmit={save} className="mt-4 p-5 rounded-2xl border border-purple-500/20 bg-white dark:bg-navy-900 space-y-3">
      <div className="grid sm:grid-cols-2 gap-3">{[['name','اسم المدرس','text'],['phone','رقم الهاتف','tel'],['email','البريد (اختياري)','email'],['city','المدينة','text'],['qualifications','المؤهلات','text']].map(([key,label,type]) => <label key={key} className="text-xs font-bold">{label}<input type={type} required={['name','phone','city'].includes(key)} value={form[key]} onChange={e => setForm({...form,[key]: e.target.value})} className="mt-1 block w-full px-3 py-2 rounded-xl border bg-gray-50 dark:bg-navy-950 border-gray-300 dark:border-indigo-950" /></label>)}</div>
      <label className="block text-xs font-bold">نبذة وخبرات<textarea value={form.bio} onChange={e => setForm({...form,bio:e.target.value})} rows={3} className="mt-1 block w-full px-3 py-2 rounded-xl border bg-gray-50 dark:bg-navy-950 border-gray-300 dark:border-indigo-950" /></label>
      <RequestError message={error} /><button disabled={busy} className="px-5 py-2 rounded-xl bg-purple-600 text-white disabled:opacity-50">{busy ? 'جاري الحفظ...' : 'حفظ المدرس'}</button>
    </form>}
  </div>;
}
