import Link from 'next/link';
import { HiUser, HiLocationMarker, HiVideoCamera, HiUsers } from 'react-icons/hi';

export default function CourseCard({ course }) {
  if (!course) return null;

  // Format teaching method label
  const methodLabels = {
    INDIVIDUAL_ONSITE: { label: 'فردي حضوري', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' },
    GROUP_ONSITE: { label: 'جماعي حضوري', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20' },
    INDIVIDUAL_ONLINE: { label: 'فردي أونلاين', color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20' },
    GROUP_ONLINE: { label: 'جماعي أونلاين', color: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20' },
  };

  const methodInfo = methodLabels[course.teachingMethod] || {
    label: 'متاح',
    color: 'bg-gray-500/10 text-gray-500 border-gray-500/20',
  };

  const isOnline = course.teachingMethod?.includes('ONLINE');
  const firstGroup = course.groups?.[0];

  return (
    <div className="card-base group flex flex-col justify-between overflow-hidden p-5 bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 hover:border-purple-500/40 dark:hover:border-purple-500/40 hover:shadow-xl transition-all duration-300">
      <div>
        {/* Top Badges */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold border ${methodInfo.color}`}>
            {isOnline ? <HiVideoCamera className="w-3.5 h-3.5" /> : <HiLocationMarker className="w-3.5 h-3.5" />}
            {methodInfo.label}
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-gray-100 dark:bg-navy-800 text-gray-600 dark:text-gray-300">
            {course.subject?.name || 'مادة عامة'}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-orange-500 transition-colors">
          <Link href={`/courses/${course.id}`}>{course.title}</Link>
        </h3>

        {/* Grade & Stage */}
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
          {course.grade?.name} {course.grade?.stage?.name ? `• ${course.grade.stage.name}` : ''}
        </p>

        {/* Teacher details */}
        {course.teacher && (
          <div className="flex items-center gap-2.5 mb-4 py-2 border-t border-b border-gray-100 dark:border-indigo-950/40">
            <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-300 flex items-center justify-center font-bold text-xs">
              <HiUser className="w-4 h-4" />
            </div>
            <div className="text-xs">
              <p className="font-bold text-gray-800 dark:text-gray-200">{course.teacher.name}</p>
              {course.teacher.city && (
                <p className="text-gray-500 dark:text-gray-400">{course.teacher.city}</p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom price and CTA */}
      <div className="pt-2">
        <div className="flex items-baseline justify-between mb-3">
          <div>
            <span className="text-xs text-gray-500 dark:text-gray-400">السعر: </span>
            {firstGroup ? (
              <span className="text-lg font-black text-orange-500">
                {Number(firstGroup.priceAmount).toLocaleString()} SDG
              </span>
            ) : (
              <span className="text-xs font-medium text-gray-400">يحدد مع الإدارة</span>
            )}
          </div>
          {firstGroup && (
            <span className="text-[11px] text-gray-500 dark:text-gray-400">
              {firstGroup.priceType === 'PER_STUDENT' ? 'للطالب' : 'للمجموعة'}
            </span>
          )}
        </div>

        <Link
          href={`/courses/${course.id}`}
          className="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-sm transition-all"
        >
          تفاصيل الكورس والحجز
        </Link>
      </div>
    </div>
  );
}
