import Link from 'next/link';
import { HiUser, HiLocationMarker, HiAcademicCap } from 'react-icons/hi';

export default function TeacherCard({ teacher }) {
  if (!teacher) return null;

  return (
    <div className="card-base p-5 bg-white dark:bg-navy-900 border border-gray-200 dark:border-indigo-950/70 hover:border-purple-500/40 hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
      <div>
        {/* Avatar & Basic Info */}
        <div className="flex items-center gap-3.5 mb-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-700 to-indigo-600 flex items-center justify-center text-white text-xl font-bold shadow-md shadow-purple-900/20 flex-shrink-0">
            {teacher.name ? teacher.name.charAt(0) : <HiUser />}
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white leading-tight">
              {teacher.name}
            </h3>
            {teacher.city && (
              <p className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                <HiLocationMarker className="w-3.5 h-3.5 text-orange-500" />
                <span>{teacher.city}</span>
              </p>
            )}
          </div>
        </div>

        {/* Bio */}
        {teacher.bio && (
          <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2 mb-3 leading-relaxed">
            {teacher.bio}
          </p>
        )}

        {/* Qualifications */}
        {teacher.qualifications && (
          <div className="flex items-center gap-1.5 text-xs text-purple-600 dark:text-purple-400 mb-4 bg-purple-500/10 px-2.5 py-1.5 rounded-lg">
            <HiAcademicCap className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{teacher.qualifications}</span>
          </div>
        )}
      </div>

      <Link
        href={`/teachers/${teacher.id}`}
        className="w-full inline-flex items-center justify-center py-2 px-3 rounded-xl text-xs font-bold border border-purple-600 text-purple-600 dark:text-purple-400 hover:bg-purple-600 hover:text-white transition-all text-center"
      >
        عرض الملف والكورسات المتاحة
      </Link>
    </div>
  );
}
