'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { HiMenu, HiX, HiAcademicCap, HiUser, HiLogout } from 'react-icons/hi';
import { useAuthStore } from '@/lib/store';
import ThemeToggle from './ThemeToggle';

export default function Header() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const { student, isAuthenticated, checkAuth, logout } = useAuthStore();

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  // Close mobile drawer on route change
  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  const navLinks = [
    { label: 'الرئيسية', href: '/' },
    { label: 'المراحل والصفوف', href: '/stages' },
    { label: 'الكورسات والدروس', href: '/courses' },
    { label: 'المدرسون', href: '/teachers' },
    { label: 'المكتبة', href: '/library' },
    { label: 'انضم كأستاذ', href: '/join-teacher' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 dark:bg-navy-950/90 backdrop-blur-md border-b border-gray-200/80 dark:border-indigo-950/60 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-orange-500 flex items-center justify-center text-white shadow-md shadow-purple-900/20 group-hover:scale-105 transition-transform">
              <HiAcademicCap className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-black tracking-tight text-gray-900 dark:text-white font-cairo">
                أستاذك
              </span>
              <span className="text-[10px] -mt-1 font-semibold text-orange-500 dark:text-orange-400">
                منصة السودان التعليمية
              </span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const isActive =
                link.href === '/'
                  ? pathname === '/'
                  : pathname.startsWith(link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                    isActive
                      ? 'text-orange-500 dark:text-orange-400 bg-orange-500/10'
                      : 'text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-gray-100 dark:hover:bg-navy-800/50'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Actions & Auth */}
          <div className="hidden md:flex items-center gap-3">
            <ThemeToggle />

            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                <Link
                  href="/dashboard"
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600/10 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border border-purple-500/20 text-sm font-bold hover:bg-purple-600/20 transition-all"
                >
                  <HiUser className="w-4 h-4" />
                  <span>{student?.fullName?.split(' ')[0] || 'لوحة الطالب'}</span>
                </Link>
                <button
                  onClick={logout}
                  className="p-2.5 rounded-xl border border-gray-200 dark:border-indigo-900/40 text-gray-500 hover:text-red-500 transition-colors"
                  title="تسجيل الخروج"
                >
                  <HiLogout className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  href="/login"
                  className="px-4 py-2 rounded-xl text-sm font-bold text-gray-700 dark:text-gray-300 hover:text-orange-500 transition-colors"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  href="/register"
                  className="px-4 py-2 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-md shadow-orange-500/25 transition-all"
                >
                  إنشاء حساب
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu trigger */}
          <div className="flex items-center gap-2 md:hidden">
            <ThemeToggle />
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-2.5 rounded-xl border border-gray-200 dark:border-indigo-900/40 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-navy-800"
              aria-label="القائمة"
            >
              {menuOpen ? <HiX className="w-6 h-6" /> : <HiMenu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {menuOpen && (
        <div className="md:hidden border-t border-gray-200 dark:border-indigo-950/60 bg-white dark:bg-navy-950 px-4 pt-3 pb-6 space-y-2 shadow-2xl animate-slide-up">
          {navLinks.map((link) => {
            const isActive =
              link.href === '/' ? pathname === '/' : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`block px-3 py-2.5 rounded-xl text-base font-semibold ${
                  isActive
                    ? 'text-orange-500 bg-orange-500/10'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-navy-800'
                }`}
              >
                {link.label}
              </Link>
            );
          })}

          <div className="pt-4 border-t border-gray-200 dark:border-indigo-900/50 space-y-2">
            {isAuthenticated ? (
              <>
                <Link
                  href="/dashboard"
                  className="flex items-center justify-between w-full px-4 py-3 rounded-xl bg-purple-600/10 text-purple-700 dark:text-purple-300 font-bold"
                >
                  <span>لوحة الطالب ({student?.fullName?.split(' ')[0]})</span>
                  <HiUser className="w-5 h-5" />
                </Link>
                <button
                  onClick={logout}
                  className="flex items-center justify-between w-full px-4 py-3 rounded-xl text-red-600 hover:bg-red-500/10 font-bold"
                >
                  <span>تسجيل الخروج</span>
                  <HiLogout className="w-5 h-5" />
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Link
                  href="/login"
                  className="text-center py-2.5 rounded-xl font-bold border border-gray-200 dark:border-indigo-900 text-gray-800 dark:text-gray-200"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  href="/register"
                  className="text-center py-2.5 rounded-xl font-bold bg-orange-500 text-white"
                >
                  حساب جديد
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
