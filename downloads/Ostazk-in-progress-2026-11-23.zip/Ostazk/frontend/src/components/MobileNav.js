'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { HiHome, HiAcademicCap, HiBookOpen, HiUser } from 'react-icons/hi';
import { useAuthStore } from '@/lib/store';

export default function MobileNav() {
  const pathname = usePathname();
  const { isAuthenticated } = useAuthStore();

  // If in admin dashboard, we can hide or customize, but let's check
  if (pathname.startsWith('/admin')) {
    return null;
  }

  const items = [
    { label: 'الرئيسية', href: '/', icon: HiHome },
    { label: 'الدروس', href: '/courses', icon: HiAcademicCap },
    { label: 'المكتبة', href: '/library', icon: HiBookOpen },
    {
      label: isAuthenticated ? 'حسابي' : 'دخول',
      href: isAuthenticated ? '/dashboard' : '/login',
      icon: HiUser,
    },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-navy-900/95 backdrop-blur-md border-t border-gray-200 dark:border-indigo-950/80 px-2 py-1.5 shadow-xl">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive =
            item.href === '/'
              ? pathname === '/'
              : pathname.startsWith(item.href);

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-orange-500 font-bold scale-105'
                  : 'text-gray-500 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400'
              }`}
            >
              <Icon className="w-5 h-5 mb-0.5" />
              <span className="text-[11px] font-medium tracking-tight">
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
