'use client';

export default function Pagination({ pagination, onPage, disabled = false, label = 'الصفحات' }) {
  if (!pagination || pagination.totalPages < 2) return null;
  const page = Number(pagination.page) || 1;
  return <nav aria-label={label} className="flex flex-wrap items-center justify-center gap-3 py-4 text-sm">
    <button type="button" disabled={disabled || page <= 1} onClick={() => onPage(page - 1)} className="px-4 py-2 rounded-xl border border-purple-500/30 disabled:opacity-40">السابق</button>
    <span aria-live="polite">صفحة {page} من {pagination.totalPages}</span>
    <button type="button" disabled={disabled || page >= pagination.totalPages} onClick={() => onPage(page + 1)} className="px-4 py-2 rounded-xl border border-purple-500/30 disabled:opacity-40">التالي</button>
  </nav>;
}
