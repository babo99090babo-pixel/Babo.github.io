export default function LoadingSpinner({ text = 'جاري التحميل...' }) {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[200px]">
      <div className="relative w-12 h-12 mb-3">
        <div className="w-12 h-12 rounded-full border-4 border-purple-200 dark:border-indigo-950 border-t-orange-500 animate-spin"></div>
      </div>
      <p className="text-sm font-semibold text-gray-600 dark:text-gray-400">
        {text}
      </p>
    </div>
  );
}
