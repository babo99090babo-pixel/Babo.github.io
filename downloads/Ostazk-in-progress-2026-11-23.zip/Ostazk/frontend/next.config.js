/** @type {import('next').NextConfig} */
const apiOrigin = new URL(process.env.API_ORIGIN || 'http://127.0.0.1:5000');
if (!['http:', 'https:'].includes(apiOrigin.protocol) || apiOrigin.username || apiOrigin.password || apiOrigin.pathname !== '/' || apiOrigin.search || apiOrigin.hash) {
  throw new Error('API_ORIGIN must be a plain http(s) origin without a path or credentials.');
}
const nextConfig = {
  poweredByHeader: false,
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: `${apiOrigin.origin}/api/:path*`,
      },
      { source: '/uploads/images/:path*', destination: `${apiOrigin.origin}/uploads/images/:path*` },
    ];
  },
  // Uploaded images use the same-origin proxy; no arbitrary remote image fetches.
  images: { remotePatterns: [] },
};

module.exports = nextConfig;
