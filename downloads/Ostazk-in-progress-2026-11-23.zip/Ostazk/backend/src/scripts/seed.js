// ========== بذرة البيانات الأساسية ==========
// الاستخدام: node src/scripts/seed.js
require('dotenv').config();

const prisma = require('../services/db');

async function main() {
  console.log('🌱 بذرة البيانات الأساسية لمنصة أستاذك...\n');

  // ========== المراحل ==========
  const stages = [
    { name: 'المرحلة الابتدائية', slug: 'primary', order: 1 },
    { name: 'المرحلة المتوسطة', slug: 'middle', order: 2 },
    { name: 'المرحلة الثانوية', slug: 'secondary', order: 3 },
  ];

  for (const stage of stages) {
    await prisma.stage.upsert({
      where: { slug: stage.slug },
      update: {},
      create: stage
    });
  }
  console.log('✅ المراحل الدراسية');

  // ========== الصفوف ==========
  const primaryStage = await prisma.stage.findUnique({ where: { slug: 'primary' } });
  const middleStage = await prisma.stage.findUnique({ where: { slug: 'middle' } });
  const secondaryStage = await prisma.stage.findUnique({ where: { slug: 'secondary' } });

  const grades = [
    // ابتدائي
    { name: 'الأول الابتدائي', slug: 'primary-1', order: 1, stageId: primaryStage.id },
    { name: 'الثاني الابتدائي', slug: 'primary-2', order: 2, stageId: primaryStage.id },
    { name: 'الثالث الابتدائي', slug: 'primary-3', order: 3, stageId: primaryStage.id },
    { name: 'الرابع الابتدائي', slug: 'primary-4', order: 4, stageId: primaryStage.id },
    { name: 'الخامس الابتدائي', slug: 'primary-5', order: 5, stageId: primaryStage.id },
    { name: 'السادس الابتدائي', slug: 'primary-6', order: 6, stageId: primaryStage.id },
    // متوسط
    { name: 'الأول المتوسط', slug: 'middle-1', order: 1, stageId: middleStage.id },
    { name: 'الثاني المتوسط', slug: 'middle-2', order: 2, stageId: middleStage.id },
    { name: 'الثالث المتوسط', slug: 'middle-3', order: 3, stageId: middleStage.id },
    // ثانوي
    { name: 'الأول الثانوي', slug: 'secondary-1', order: 1, stageId: secondaryStage.id },
    { name: 'الثاني الثانوي', slug: 'secondary-2', order: 2, stageId: secondaryStage.id },
    { name: 'الثالث الثانوي', slug: 'secondary-3', order: 3, stageId: secondaryStage.id },
  ];

  for (const grade of grades) {
    await prisma.grade.upsert({
      where: { slug: grade.slug },
      update: {},
      create: grade
    });
  }
  console.log('✅ الصفوف الدراسية');

  // Starter catalogue, not a complete official curriculum. Preserve existing edits.
  for (const subject of [{ name: 'اللغة العربية', slug: 'arabic' }, { name: 'الرياضيات', slug: 'mathematics' }, { name: 'اللغة الإنجليزية', slug: 'english' }]) {
    if (await prisma.subject.findUnique({ where: { slug: subject.slug } })) continue;
    const allGrades = await prisma.grade.findMany({ select: { id: true } });
    await prisma.subject.create({ data: { ...subject, grades: { create: allGrades.map(g => ({ gradeId: g.id })) } } });
  }
  console.log('✅ مواد أولية قابلة للتعديل');

  // ========== الإعدادات الافتراضية ==========
  const settings = [
    { key: 'platform_name', value: 'أستاذك' },
    { key: 'platform_description', value: 'لقى أستاذك، اختار مادتك، واحجز درسك فردي أو مع مجموعة، أونلاين أو حضوري.' },
    { key: 'platform_slogan', value: 'أستاذك معاك… تعلّم بالطريقة البتناسبك' },
    { key: 'contact_phone', value: '0991974489' },
    { key: 'contact_phone_intl', value: '+249991974489' },
    { key: 'contact_whatsapp', value: 'https://wa.me/249991974489' },
    { key: 'contact_tel', value: 'tel:+249991974489' },
    { key: 'show_admin_email_as_support', value: 'false' },
    { key: 'currency', value: 'SDG' },
    { key: 'timezone', value: 'Africa/Khartoum' },
  ];

  for (const setting of settings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting
    });
  }
  console.log('✅ الإعدادات الافتراضية');

  console.log('\n🎉 تمت البذرة بنجاح!\n');
  console.log('الخطوة التالية: أنشئ حساب المدير:');
  console.log('  node src/scripts/setup-admin.js\n');
}

if (require.main === module) main()
  .catch(err => { console.error('Seed failed:', err.code || err.message); process.exitCode = 1; })
  .finally(() => prisma.$disconnect());
module.exports = { main };
