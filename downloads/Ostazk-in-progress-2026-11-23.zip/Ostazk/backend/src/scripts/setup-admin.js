require('dotenv').config();
const bcrypt = require('bcryptjs');
const prisma = require('../services/db');
const { createPrompt } = require('./prompt');
const { isValidPassword } = require('../services/accountValidation');

async function main() {
  const prompt = createPrompt();
  try {
    console.log('\nإعداد مدير منصة أستاذك — كلمة السر لن تظهر أثناء الكتابة.\n');
    const existing = await prisma.admin.findFirst({ where: { role: 'SUPER_ADMIN' } });
    if (existing) {
      console.log('يوجد مدير رئيسي بالفعل. هذه العملية لا تغير حسابه أو كلمة سره.');
      const answer = await prompt.ask('إنشاء مدير رئيسي إضافي؟ اكتب نعم أو yes: ');
      if (!['نعم', 'yes', 'y'].includes(answer.trim().toLowerCase())) return;
    }
    const email = ((await prompt.ask('البريد [babo99090babo@gmail.com]: ')) || 'babo99090babo@gmail.com').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('البريد الإلكتروني غير صالح.');
    const name = ((await prompt.ask('الاسم [مدير المنصة]: ')) || 'مدير المنصة').trim();
    if (!name || name.length > 200) throw new Error('الاسم غير صالح.');
    let password;
    do {
      password = await prompt.ask('كلمة سر قوية (12 حرفاً على الأقل): ', true);
      if (password.length < 12 || !isValidPassword(password)) console.log('استخدم 12 حرفاً على الأقل، وبحد أقصى 72 بايت.');
    } while (password.length < 12 || !isValidPassword(password));
    const confirmation = await prompt.ask('أعد كلمة السر: ', true);
    if (password !== confirmation) throw new Error('كلمتا السر غير متطابقتين.');
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.$transaction(async tx => {
      const admin = await tx.admin.create({ data: { email, name, passwordHash, role: 'SUPER_ADMIN', isActive: true } });
      await tx.auditLog.create({ data: { adminId: admin.id, action: 'BOOTSTRAP_ADMIN', entity: 'Admin', entityId: admin.id } });
    });
    console.log('تم إنشاء المدير. افتح /admin/login في عنوان الموقع وسجّل دخولك.');
  } catch (err) {
    console.error(err.code === 'P2002' ? 'هذا البريد مسجل بالفعل؛ لم يتم تغيير الحساب.' : `تعذر الإعداد: ${err.message}`);
    process.exitCode = 1;
  } finally {
    prompt.close();
    await prisma.$disconnect();
  }
}
main();
