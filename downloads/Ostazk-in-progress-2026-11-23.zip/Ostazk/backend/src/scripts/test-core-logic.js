const {
  convertArabicDigits,
  cleanPhone,
  normalizePhone,
  isValidSudanesePhone,
} = require('../utils/phone');

const {
  generateCode,
  hashCode,
  verifyCode,
  formatCode,
} = require('../utils/activationCode');

console.log('========================================================');
console.log('🧪 بدء اختبارات المنطق الأساسي لمنصة «أستاذك»');
console.log('========================================================\n');

let passed = 0;
let failed = 0;

function assert(condition, testName) {
  if (condition) {
    console.log(`✅ نجح: ${testName}`);
    passed++;
  } else {
    console.error(`❌ فشل: ${testName}`);
    failed++;
  }
}

// 1. اختبار توحيد أرقام الهواتف السودانية
console.log('--- ١. اختبارات معالجة وتوحيد أرقام الهواتف ---');
const localPhone = '0991974489';
const intlPhone = '+249991974489';
const spacedPhone = '099 197 4489';
const dashedPhone = '099-197-4489';
const arabicDigitsPhone = '٠٩٩١٩٧٤٤٨٩';
const arabicIntlPhone = '+٢٤٩٩٩١٩٧٤٤٨٩';

assert(
  normalizePhone(localPhone) === '+249991974489',
  'تحويل الرقم المحلي 0991974489 إلى الصيغة الموحدة +249991974489'
);

assert(
  normalizePhone(intlPhone) === '+249991974489',
  'الاحتفاظ بالصيغة الدولية +249991974489 كما هي'
);

assert(
  normalizePhone(spacedPhone) === '+249991974489',
  'إزالة المسافات من الرقم بنجاح'
);

assert(
  normalizePhone(dashedPhone) === '+249991974489',
  'إزالة الشرطات من الرقم بنجاح'
);

assert(
  normalizePhone(arabicDigitsPhone) === '+249991974489',
  'تحويل الأرقام المكتوبة بالأرقام العربية (٠-٩) إلى أرقام إنجليزية وموحدة'
);

assert(
  normalizePhone(arabicIntlPhone) === '+249991974489',
  'تحويل الرقم الدولي المكتوب بالأرقام العربية إلى الصيغة الموحدة'
);

assert(
  normalizePhone(localPhone) === normalizePhone(intlPhone),
  'الرقم المحلي والدولي يُعاملان كرقم واحد تماماً لمنع إنشاء حسابين مكررين'
);

assert(
  isValidSudanesePhone(localPhone) === true,
  'صحة الرقم المحلي كـرقم سوداني'
);

assert(
  isValidSudanesePhone('123456') === false,
  'رفض الأرقام القصيرة أو غير الصالحة'
);

// 2. اختبار التحقق من الاسم الرباعي
console.log('\n--- ٢. اختبارات الاسم الرباعي للطالب ---');
function validateFullName(name) {
  const parts = name.trim().split(/\s+/).filter((p) => p.length > 0);
  if (parts.length < 4) return false;
  return parts.every((p) => p.length >= 2);
}

assert(
  validateFullName('أحمد محمد عبدالله إبراهيم') === true,
  'قبول الاسم الرباعي الكامل'
);

assert(
  validateFullName('محمد أحمد') === false,
  'رفض الاسم الثنائي'
);

assert(
  validateFullName('محمد أحمد علي') === false,
  'رفض الاسم الثلاثي'
);

// 3. اختبار رموز التفعيل والتشفير
console.log('\n--- ٣. اختبارات رموز التفعيل والبصمة الآمنة ---');
const rawCode = generateCode(12);
assert(rawCode.length === 12, 'طول رمز التفعيل عشوائي ١٢ خانة');
assert(!/[0O1lI]/.test(rawCode), 'خلو الرمز من الأحرف الملتبسة (0/O, 1/l/I)');

const hash1 = hashCode(rawCode);
assert(hash1.length === 64, 'تجزئة الرمز إلى بصمة SHA-256 بطول 64 حرفاً');

assert(
  verifyCode(rawCode, hash1) === true,
  'التحقق الناجح من الرمز ضد البصمة المشفرة'
);

assert(
  verifyCode('WRONG-CODE-12', hash1) === false,
  'رفض الرمز الخاطئ أو غير المطابق للبصمة'
);

const formatted = formatCode(rawCode);
assert(formatted.includes('-'), 'تنسيق الرمز بفواصل للقراءة السهلة (ABCD-EFGH-JKLM)');

// 4. اختبار اشتراك الإخوة في رقم ولي الأمر
console.log('\n--- ٤. اختبار منطق الأشقاء ورقم ولي الأمر ---');
const sibling1 = {
  fullName: 'خالد عمر حسن عثمان',
  phone: normalizePhone('0911111111'),
  parentPhone: normalizePhone('0991974489'),
};
const sibling2 = {
  fullName: 'سارة عمر حسن عثمان',
  phone: normalizePhone('0922222222'),
  parentPhone: normalizePhone('0991974489'),
};

assert(
  sibling1.parentPhone === sibling2.parentPhone,
  'السماح للأشقاء بمشاركة نفس رقم هاتف ولي الأمر'
);

assert(
  sibling1.phone !== sibling2.phone,
  'هواتف الطلاب مختلفة ومميزة برقم فريد (Unique) لكل حساب'
);

console.log('\n========================================================');
console.log(`📊 النتيجة النهائية: ${passed} نجح | ${failed} فشل`);
console.log('========================================================');

if (failed > 0) {
  process.exit(1);
}
