const readline = require('readline');
const { Writable } = require('stream');
function createPrompt() {
  let muted = false;
  const output = new Writable({ write(chunk, encoding, callback) {
    if (!muted) process.stdout.write(chunk, encoding);
    callback();
  } });
  const rl = readline.createInterface({ input: process.stdin, output, terminal: Boolean(process.stdin.isTTY) });
  rl.on('SIGINT', () => rl.close());
  function ask(question, secret = false) {
    if (secret && !process.stdin.isTTY) return Promise.reject(new Error('Run setup-admin in an interactive terminal to enter a hidden password.'));
    return new Promise((resolve, reject) => {
      const onClose = () => { muted = false; reject(new Error('Setup cancelled.')); };
      rl.once('close', onClose);
      rl.question(question, value => {
        rl.removeListener('close', onClose);
        muted = false;
        if (secret) process.stdout.write('\n');
        resolve(value);
      });
      muted = secret;
    });
  }
  return { ask, close: () => { muted = false; rl.close(); } };
}
module.exports = { createPrompt };
