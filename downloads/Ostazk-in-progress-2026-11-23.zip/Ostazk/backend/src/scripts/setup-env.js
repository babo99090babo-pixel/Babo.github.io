const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const target = path.resolve(__dirname, '../../.env');
try {
  let template = fs.readFileSync(path.resolve(__dirname, '../../.env.example'), 'utf8');
  for (const name of ['JWT_SECRET', 'ADMIN_JWT_SECRET', 'TEACHER_JWT_SECRET']) {
    template = template.replace(new RegExp(`^${name}=.*$`, 'm'), `${name}=${crypto.randomBytes(48).toString('hex')}`);
  }
  fs.writeFileSync(target, template, { flag: 'wx', mode: 0o600 });
  console.log('Created backend/.env with random signing keys. Edit DATABASE_URL before continuing.');
} catch (err) {
  if (err.code === 'EEXIST') console.log('Existing .env preserved. Edit its DATABASE_URL and keys only if needed.');
  else { console.error('Could not create .env:', err.code || err.message); process.exitCode = 1; }
}
