// ========== الواجهات العامة - المراحل والصفوف والمواد ==========
const express = require('express');
const router = express.Router();
const prisma = require('../services/db');
const { validatePublicQuery } = require('../utils/query');
const { PUBLIC_SETTING_KEYS } = require('../utils/publicSettings');
const { normalizePhone, isValidSudanesePhone } = require('../utils/phone');
router.use(validatePublicQuery);

// ========== المراحل ==========
router.get('/stages', async (req, res) => {
  try {
    const stages = await prisma.stage.findMany({
      where: { isActive: true },
      orderBy: { order: 'asc' },
      include: {
        grades: {
          where: { isActive: true },
          orderBy: { order: 'asc' },
          select: { id: true, name: true, slug: true, order: true }
        }
      }
    });
    res.json(stages);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

router.get('/stages/:slug', async (req, res) => {
  try {
    const stage = await prisma.stage.findUnique({
      where: { slug: req.params.slug },
      include: {
        grades: {
          where: { isActive: true },
          orderBy: { order: 'asc' },
          include: {
            subjects: {
              include: { subject: true }
            }
          }
        }
      }
    });
    if (!stage || !stage.isActive) return res.status(404).json({ message: 'المرحلة ما موجودة' });
    res.json(stage);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== الصفوف ==========
router.get('/grades/:slug', async (req, res) => {
  try {
    const grade = await prisma.grade.findUnique({
      where: { slug: req.params.slug },
      include: {
        stage: { select: { id: true, name: true, slug: true } },
        subjects: {
          include: {
            subject: { select: { id: true, name: true, slug: true } }
          }
        }
      }
    });
    if (!grade || !grade.isActive) return res.status(404).json({ message: 'الصف ما موجود' });
    res.json(grade);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== المواد ==========
router.get('/subjects', async (req, res) => {
  try {
    const subjects = await prisma.subject.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' }
    });
    res.json(subjects);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== الكورسات ==========
router.get('/courses', async (req, res) => {
  try {
    const { stage, grade, subject, method, teacher, city, search, minPrice, maxPrice, page = 1, limit = 12 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const where = { isActive: true, teacher: { isActive: true, isApproved: true } };
    if (city) where.teacher.city = { contains: city.trim(), mode: 'insensitive' };
    if (search?.trim()) {
      const contains = { contains: search.trim(), mode: 'insensitive' };
      where.OR = [{ title: contains }, { description: contains }, { teacher: { name: contains } }, { subject: { name: contains } }];
    }
    if (minPrice || maxPrice) {
      where.groups = { some: { status: { notIn: ['CANCELLED', 'FINISHED'] }, priceAmount: {
        ...(minPrice ? { gte: minPrice } : {}), ...(maxPrice ? { lte: maxPrice } : {})
      } } };
    }
    if (grade) where.gradeId = parseInt(grade);
    if (subject) where.subjectId = parseInt(subject);
    if (method) where.teachingMethod = method;
    if (teacher) where.teacherId = teacher;
    
    if (stage) {
      where.grade = { stageId: parseInt(stage) };
    }

    const [courses, total] = await Promise.all([
      prisma.course.findMany({
        where,
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' },
        include: {
          subject: { select: { id: true, name: true } },
          grade: { select: { id: true, name: true, stage: { select: { id: true, name: true } } } },
          teacher: { select: { id: true, name: true, photoUrl: true, city: true } },
          groups: {
            where: { status: { not: 'CANCELLED' } },
            select: {
              id: true, name: true, priceAmount: true, priceType: true,
              pricePer: true, maxStudents: true, enrolledCount: true, status: true
            }
          }
        }
      }),
      prisma.course.count({ where })
    ]);

    res.json({
      courses,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

router.get('/courses/:id', async (req, res) => {
  try {
    const course = await prisma.course.findUnique({
      where: { id: req.params.id },
      include: {
        subject: true,
        grade: { include: { stage: true } },
        teacher: {
          select: { id: true, name: true, bio: true, photoUrl: true, city: true, qualifications: true }
        },
        groups: {
          where: { status: { not: 'CANCELLED' } },
          include: {
            sessions: {
              orderBy: { date: 'asc' },
              include: {
                location: {
                  include: {
                    location: {
                      select: { state: true, city: true, area: true, venueName: true }
                      // العنوان التفصيلي فقط للمحجوزين المؤكدين
                    }
                  }
                }
              }
            }
          }
        }
      }
    });
    if (!course || !course.isActive) {
      return res.status(404).json({ message: 'الكورس ما موجود' });
    }
    // Room IDs and tokens are disclosed only by the authorized session join endpoint.
    course.groups = course.groups.map(group => ({ ...group, sessions: group.sessions.map(({ meetingToken, onlineRoomId, ...session }) => session) }));
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== المدرسون ==========
router.get('/teachers', async (req, res) => {
  try {
    const { subject, stage, city, search, page = 1, limit = 12 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const where = { isApproved: true, isActive: true };
    if (city) where.city = { contains: city.trim(), mode: 'insensitive' };
    if (subject || stage) {
      where.subjects = { some: { gradeSubject: {
        ...(subject ? { subjectId: Number(subject) } : {}),
        ...(stage ? { grade: { stageId: Number(stage) } } : {})
      } } };
    }
    if (search?.trim()) {
      const contains = { contains: search.trim(), mode: 'insensitive' };
      where.OR = [{ name: contains }, { bio: contains }, { city: contains },
        { subjects: { some: { gradeSubject: { subject: { name: contains } } } } },
        { courses: { some: { isActive: true, subject: { name: contains } } } }];
    }

    const [teachers, total] = await Promise.all([
      prisma.teacher.findMany({
        where,
        orderBy: [{ name: 'asc' }, { id: 'asc' }],
        skip,
        take: parseInt(limit),
        select: {
          id: true, name: true, bio: true, photoUrl: true,
          city: true, qualifications: true,
          subjects: {
            include: {
              gradeSubject: {
                include: {
                  subject: { select: { name: true } },
                  grade: { select: { name: true, stage: { select: { name: true } } } }
                }
              }
            }
          },
          _count: { select: { courses: true } }
        }
      }),
      prisma.teacher.count({ where })
    ]);

    res.json({
      teachers,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

router.get('/teachers/:id', async (req, res) => {
  try {
    const teacher = await prisma.teacher.findFirst({
      where: { id: req.params.id, isApproved: true, isActive: true },
      select: {
        id: true, name: true, bio: true, photoUrl: true,
        city: true, qualifications: true,
        subjects: {
          include: {
            gradeSubject: {
              include: {
                subject: true,
                grade: { include: { stage: true } }
              }
            }
          }
        },
        courses: {
          where: { isActive: true },
          include: {
            subject: true,
            grade: { include: { stage: true } },
            groups: {
              where: { status: { not: 'CANCELLED' } },
              select: { id: true, name: true, priceAmount: true, priceType: true, pricePer: true, maxStudents: true, enrolledCount: true, status: true }
            }
          }
        }
      }
    });
    if (!teacher) {
      return res.status(404).json({ message: 'المدرس ما موجود' });
    }
    res.json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== الكتب ==========
router.get('/books', async (req, res) => {
  try {
    const { stage, grade, subject, search, page = 1, limit = 12 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const where = { status: 'PUBLISHED' };
    if (grade) where.gradeId = parseInt(grade);
    if (subject) where.subjectId = parseInt(subject);
    if (stage) {
      where.grade = { stageId: parseInt(stage) };
    }
    if (search) {
      where.title = { contains: search, mode: 'insensitive' };
    }

    const [books, total] = await Promise.all([
      prisma.book.findMany({
        where,
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' },
        select: {
          id: true, title: true, description: true, coverUrl: true,
          year: true, edition: true, fileType: true, fileSize: true,
          accessLevel: true, allowDownload: true,
          subject: { select: { id: true, name: true } },
          grade: { select: { id: true, name: true, stage: { select: { name: true } } } }
        }
      }),
      prisma.book.count({ where })
    ]);

    res.json({
      books,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

router.get('/books/:id', async (req, res) => {
  try {
    const book = await prisma.book.findUnique({
      where: { id: req.params.id },
      include: {
        subject: true,
        grade: { include: { stage: true } }
      }
    });
    if (!book || book.status !== 'PUBLISHED') {
      return res.status(404).json({ message: 'الكتاب ما موجود' });
    }
    // لا نرسل مسار الملف
    const { filePath, ...bookData } = book;
    res.json(bookData);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== طلب انضمام مدرس ==========
router.post('/teacher-applications', [
  require('express-validator').body('name').isString().trim().isLength({ min: 2, max: 200 }).withMessage('الاسم مطلوب'),
  require('express-validator').body('phone').isString().custom(isValidSudanesePhone).withMessage('الرقم مطلوب'),
  require('express-validator').body('subject').isString().trim().isLength({ min: 1, max: 200 }).withMessage('المادة مطلوبة'),
  require('express-validator').body('stage').isString().trim().isLength({ min: 1, max: 200 }).withMessage('المرحلة مطلوبة'),
  require('express-validator').body('city').isString().trim().isLength({ min: 1, max: 200 }).withMessage('المدينة مطلوبة'),
  require('express-validator').body('email').optional({ values: 'falsy' }).isEmail().isLength({ max: 254 }),
  require('express-validator').body('message').optional().isString().isLength({ max: 3000 }),
], require('../middleware/validate').validate, async (req, res) => {
  try {
    const { name, phone, email, subject, stage, city, message } = req.body;
    await prisma.teacherApplication.create({
      data: { name, phone: normalizePhone(phone), email: email || null, subject, stage, city, message }
    });
    res.status(201).json({ message: 'تم إرسال طلبك! راح نتواصل معاك قريب إن شاء الله' });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ. حاول تاني.' });
  }
});

// ========== البحث الموحد ==========
router.get('/search', async (req, res) => {
  try {
    const { q, type = 'all', page = 1, limit = 10 } = req.query;
    if (!q || q.length < 2) {
      return res.status(400).json({ message: 'اكتب حرفين على الأقل للبحث' });
    }

    const results = {};
    const skip = (parseInt(page) - 1) * parseInt(limit);

    if (type === 'all' || type === 'courses') {
      results.courses = await prisma.course.findMany({
        where: {
          isActive: true,
          OR: [
            { title: { contains: q, mode: 'insensitive' } },
            { description: { contains: q, mode: 'insensitive' } }
          ]
        },
        take: parseInt(limit),
        skip,
        include: {
          subject: { select: { name: true } },
          grade: { select: { name: true } },
          teacher: { select: { name: true } }
        }
      });
    }

    if (type === 'all' || type === 'teachers') {
      results.teachers = await prisma.teacher.findMany({
        where: {
          isApproved: true, isActive: true,
          name: { contains: q, mode: 'insensitive' }
        },
        take: parseInt(limit),
        skip,
        select: { id: true, name: true, photoUrl: true, city: true }
      });
    }

    if (type === 'all' || type === 'books') {
      results.books = await prisma.book.findMany({
        where: {
          status: 'PUBLISHED',
          title: { contains: q, mode: 'insensitive' }
        },
        take: parseInt(limit),
        skip,
        select: { id: true, title: true, coverUrl: true, subject: { select: { name: true } } }
      });
    }

    res.json(results);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ في البحث' });
  }
});

// ========== الإعلانات ==========
router.get('/announcements', async (req, res) => {
  try {
    const announcements = await prisma.announcement.findMany({
      where: { isActive: true, targetAudience: 'ALL' },
      orderBy: { createdAt: 'desc' },
      take: 10
    });
    res.json(announcements);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== الإعدادات العامة ==========
router.get('/settings', async (req, res) => {
  try {
    const settings = await prisma.setting.findMany({ where: { key: { in: PUBLIC_SETTING_KEYS } } });
    const result = {};
    settings.forEach(s => { result[s.key] = s.value; });
    res.json(result);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

module.exports = router;
