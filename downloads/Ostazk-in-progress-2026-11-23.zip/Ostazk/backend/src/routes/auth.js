const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const prisma = require('../services/db');
const { validate } = require('../middleware/validate');
const { authenticateStudent } = require('../middleware/auth');
const { loginLimiter, registerLimiter } = require('../middleware/rateLimiter');
const { normalizePhone, isValidSudanesePhone } = require('../utils/phone');
const { issueStudentSession, setSessionCookie, clearSessionCookie, tokenHash } = require('../services/authSession');
const { isFullName, isValidPassword } = require('../services/accountValidation');

const publicStudent = { id: true, fullName: true, phone: true, stageId: true, gradeId: true, createdAt: true };
const passwordRule = name => body(name).custom(isValidPassword).withMessage('كلمة السر لازم تكون 8 أحرف على الأقل ولا تزيد عن 72 بايت');
const httpError = (status, message) => Object.assign(new Error(message), { status });
async function recordLogin(req, phone, success) {
  await prisma.loginAttempt.create({ data: { phone, success, ipAddress: req.ip, userAgent: (req.get('user-agent') || '').slice(0, 500) } }).catch(() => {});
}

router.post('/register', registerLimiter, [
  body('fullName').custom(isFullName).withMessage('اكتب اسمك الرباعي كامل، وكل جزء حرفين على الأقل'),
  body('phone').custom(value => typeof value === 'string' && isValidSudanesePhone(value)).withMessage('اكتب رقم هاتف سوداني صالح'),
  body('parentPhone').custom(value => typeof value === 'string' && isValidSudanesePhone(value)).withMessage('رقم هاتف ولي الأمر ما صحيح'),
  passwordRule('password'),
  body('confirmPassword').custom((value, { req }) => value === req.body.password).withMessage('كلمتين السر ما متطابقات'),
], validate, async (req, res, next) => {
  try {
    const { fullName, phone, parentPhone, password } = req.body;
    const passwordHash = await bcrypt.hash(password, 12);
    const { student, token } = await prisma.$transaction(async tx => {
      const student = await tx.student.create({ data: {
        fullName: fullName.trim().replace(/\s+/g, ' '), phone: normalizePhone(phone),
        parentPhone: normalizePhone(parentPhone), passwordHash,
      }, select: publicStudent });
      const token = await issueStudentSession(tx, student, req);
      return { student, token };
    });
    setSessionCookie(res, 'studentToken', token);
    await recordLogin(req, student.phone, true);
    res.status(201).json({ message: 'تم إنشاء حسابك بنجاح! أهلاً بيك في أستاذك', student });
  } catch (err) {
    if (err.code === 'P2002') return res.status(409).json({ message: 'الرقم دا مسجل بيهو حساب قبل كدا' });
    next(err);
  }
});

router.post('/login', loginLimiter, [
  body('phone').isString().isLength({ min: 1, max: 40 }).withMessage('اكتب رقم هاتفك'),
  body('password').isString().isLength({ min: 1, max: 200 }).withMessage('اكتب كلمة السر'),
], validate, async (req, res, next) => {
  try {
    const phone = normalizePhone(req.body.phone);
    const student = await prisma.student.findUnique({ where: { phone } });
    if (!student?.isActive || !(await bcrypt.compare(req.body.password, student.passwordHash))) {
      await recordLogin(req, phone, false);
      return res.status(401).json({ message: 'رقم الهاتف أو كلمة السر غلط' });
    }
    const token = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "Student" WHERE id = ${student.id} FOR UPDATE`;
      const current = await tx.student.findUnique({ where: { id: student.id } });
      if (!current?.isActive || current.passwordHash !== student.passwordHash) throw httpError(401, 'بيانات الدخول تغيّرت. حاول تاني.');
      return issueStudentSession(tx, current, req);
    });
    setSessionCookie(res, 'studentToken', token);
    await recordLogin(req, phone, true);
    res.json({ message: 'أهلاً بيك!', student: {
      id: student.id, fullName: student.fullName, phone: student.phone,
      stageId: student.stageId, gradeId: student.gradeId,
    } });
  } catch (err) { next(err); }
});

router.post('/logout', authenticateStudent, async (req, res, next) => {
  try {
    await prisma.studentSession.updateMany({
      where: { studentId: req.student.id, tokenHash: tokenHash(req.cookies.studentToken), isActive: true },
      data: { isActive: false },
    });
    clearSessionCookie(res, 'studentToken');
    res.json({ message: 'تم تسجيل الخروج' });
  } catch (err) { next(err); }
});

router.get('/me', authenticateStudent, async (req, res, next) => {
  try {
    const student = await prisma.student.findUnique({ where: { id: req.student.id }, select: {
      ...publicStudent, parentPhone: true,
      stage: { select: { id: true, name: true, slug: true } },
      grade: { select: { id: true, name: true, slug: true } },
    } });
    res.json(student);
  } catch (err) { next(err); }
});

function nullableId(value) {
  if (value === undefined) return undefined;
  if (value === null || value === '') return null;
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 1) throw httpError(400, 'اختار مرحلة وصف صالحين');
  return number;
}

router.put('/profile', authenticateStudent, async (req, res, next) => {
  try {
    const data = {};
    if (req.body.fullName !== undefined) {
      if (!isFullName(req.body.fullName)) throw httpError(400, 'اكتب اسمك الرباعي كامل، وكل جزء حرفين على الأقل');
      data.fullName = req.body.fullName.trim().replace(/\s+/g, ' ');
    }
    const stageId = nullableId(req.body.stageId);
    const gradeId = nullableId(req.body.gradeId);
    if (stageId !== undefined) data.stageId = stageId;
    if (gradeId !== undefined) data.gradeId = gradeId;
    const current = await prisma.student.findUnique({ where: { id: req.student.id }, select: { stageId: true, gradeId: true } });
    const effectiveStage = stageId === undefined ? current.stageId : stageId;
    let effectiveGrade = gradeId === undefined ? current.gradeId : gradeId;
    if (stageId !== undefined && stageId !== current.stageId && gradeId === undefined) {
      effectiveGrade = null;
      data.gradeId = null;
    }
    if (effectiveStage !== null) {
      const stage = await prisma.stage.findFirst({ where: { id: effectiveStage, isActive: true } });
      if (!stage) throw httpError(400, 'المرحلة غير متاحة');
    }
    if (effectiveGrade !== null) {
      const grade = await prisma.grade.findFirst({ where: { id: effectiveGrade, stageId: effectiveStage ?? -1, isActive: true } });
      if (!grade) throw httpError(400, 'الصف لازم يتبع المرحلة المختارة');
    }
    const student = await prisma.student.update({ where: { id: req.student.id }, data, select: publicStudent });
    res.json({ message: 'تم تحديث بياناتك', student });
  } catch (err) { next(err); }
});

router.post('/change-password', authenticateStudent, loginLimiter, [
  body('currentPassword').isString().isLength({ min: 1, max: 200 }).withMessage('اكتب كلمة السر الحالية'),
  passwordRule('newPassword'),
  body('confirmNewPassword').custom((value, { req }) => value === req.body.newPassword).withMessage('كلمتين السر ما متطابقات'),
], validate, async (req, res, next) => {
  try {
    const student = await prisma.student.findUnique({ where: { id: req.student.id } });
    if (!(await bcrypt.compare(req.body.currentPassword, student.passwordHash))) throw httpError(400, 'كلمة السر الحالية غلط');
    const passwordHash = await bcrypt.hash(req.body.newPassword, 12);
    const token = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "Student" WHERE id = ${student.id} FOR UPDATE`;
      const current = await tx.student.findUnique({ where: { id: student.id } });
      if (!current?.isActive || current.passwordHash !== student.passwordHash) throw httpError(401, 'بيانات الحساب تغيّرت. سجّل دخولك تاني.');
      const updated = await tx.student.update({ where: { id: student.id }, data: { passwordHash } });
      return issueStudentSession(tx, updated, req);
    });
    setSessionCookie(res, 'studentToken', token);
    res.json({ message: 'تم تغيير كلمة السر وإغلاق الجلسات السابقة' });
  } catch (err) { next(err); }
});

module.exports = router;
