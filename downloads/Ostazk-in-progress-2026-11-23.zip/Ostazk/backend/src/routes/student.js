// ========== واجهات الطالب المحمية ==========
const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { validate } = require('../middleware/validate');
const { authenticateStudent } = require('../middleware/auth');
const { activationLimiter } = require('../middleware/rateLimiter');
const { hashCode } = require('../utils/activationCode');
const { createBooking, redeemCode, closedStatuses } = require('../services/enrollment');
const { sessionWindow, todayDate } = require('../services/sessionTime');

// كل الراوتات تتطلب مصادقة الطالب
router.use(authenticateStudent);

// ========== حجز كورس ==========
router.post('/bookings',
  [body('courseGroupId').notEmpty().withMessage('اختار المجموعة')],
  validate,
  async (req, res) => {
    try {
      const { courseGroupId } = req.body;
      const studentId = req.student.id;

      const booking = await prisma.$transaction(tx => createBooking(tx, studentId, courseGroupId));

      const statusMsg = booking.status === 'WAITLISTED'
        ? 'المجموعة مكتملة حالياً. تم إضافتك في قائمة الانتظار.'
        : 'تم حجزك! اتواصل مع الإدارة على واتساب لتأكيد الحجز.';

      res.status(201).json({ message: statusMsg, booking });
    } catch (err) {
      if (err.status) return res.status(err.status).json({ message: err.message });
      if (err.code === 'P2002') {
        return res.status(409).json({ message: 'أنت محجوز في المجموعة دي قبل كدا' });
      }
      console.error(err);
      res.status(500).json({ message: 'حصل خطأ. حاول تاني.' });
    }
  }
);

// ========== حجوزاتي ==========
router.get('/bookings', async (req, res) => {
  try {
    const bookings = await prisma.booking.findMany({
      where: { studentId: req.student.id },
      orderBy: { createdAt: 'desc' },
      include: {
        courseGroup: {
          include: {
            course: {
              include: {
                subject: { select: { name: true } },
                grade: { select: { name: true } },
                teacher: { select: { name: true } }
              }
            }
          }
        }
      }
    });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

router.get('/bookings/:id', async (req, res) => {
  try {
    const booking = await prisma.booking.findFirst({
      where: { id: req.params.id, studentId: req.student.id },
      include: {
        courseGroup: {
          include: {
            course: {
              include: { subject: true, grade: true, teacher: { select: { name: true, photoUrl: true } } }
            },
            sessions: {
              orderBy: { date: 'asc' },
              include: { location: { include: { location: true } } }
            }
          }
        }
      }
    });
    if (!booking) return res.status(404).json({ message: 'الحجز ما موجود' });

    // إخفاء العنوان التفصيلي إن لم يكن الحجز مؤكد
    if (booking.status !== 'CONFIRMED') {
      booking.courseGroup.sessions.forEach(s => {
        if (s.location?.location) {
          s.location.location.address = undefined;
          s.location.location.mapLat = undefined;
          s.location.location.mapLng = undefined;
        }
      });
    }

    booking.courseGroup.sessions.forEach(s => { delete s.meetingToken; delete s.onlineRoomId; });
    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== تفعيل الرمز ==========
router.post('/activate',
  activationLimiter,
  [body('code').trim().notEmpty().withMessage('اكتب الرمز')],
  validate,
  async (req, res) => {
    try {
      const { code } = req.body;
      const studentId = req.student.id;
      const result = await prisma.$transaction(tx => redeemCode(tx, studentId, code));

      res.json({
        message: 'تم تفعيل اشتراكك بنجاح! دروسك جاهزة 🎉',
        subscription: result
      });
    } catch (err) {
      if (!err.status) console.error('Activation failed:', err.code || err.message);
      res.status(err.status || 503).json({ message: err.status ? err.message : 'تعذر التفعيل حالياً. حاول مرة أخرى.' });
    }
  }
);

// ========== اشتراكاتي ==========
router.get('/subscriptions', async (req, res) => {
  try {
    const subscriptions = await prisma.subscription.findMany({
      where: { studentId: req.student.id },
      orderBy: { createdAt: 'desc' },
      include: {
        courseGroup: {
          include: {
            course: {
              include: {
                subject: { select: { name: true } },
                grade: { select: { name: true } },
                teacher: { select: { id: true, name: true, photoUrl: true } }
              }
            }
          }
        }
      }
    });
    res.json(subscriptions);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== حصصي القادمة ==========
router.get('/sessions', async (req, res) => {
  try {
    const activeSubs = await prisma.subscription.findMany({
      where: { studentId: req.student.id, status: 'ACTIVE', startDate: { lte: new Date() }, endDate: { gt: new Date() }, booking: { status: 'CONFIRMED' }, courseGroup: { status: { notIn: closedStatuses }, course: { isActive: true } } },
      select: { courseGroupId: true }
    });
    const groupIds = activeSubs.map(s => s.courseGroupId);

    if (groupIds.length === 0) return res.json([]);

    const sessions = await prisma.session.findMany({
      where: {
        courseGroupId: { in: groupIds },
        date: { gte: todayDate() },
        status: { in: ['SCHEDULED', 'LIVE'] }
      },
      orderBy: { date: 'asc' },
      take: 20,
      include: {
        courseGroup: {
          include: {
            course: {
              select: { title: true, teachingMethod: true, teacher: { select: { name: true } } }
            }
          }
        },
        location: {
          include: { location: { select: { city: true, area: true, venueName: true, address: true } } }
        }
      }
    });

    res.json(sessions.filter(session => sessionWindow(session).end > new Date()).map(({ meetingToken, onlineRoomId, ...session }) => session));
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== دخول الحصة (أونلاين) ==========
router.post('/sessions/:id/join', async (req, res) => {
  try {
    const session = await prisma.session.findUnique({
      where: { id: req.params.id },
      include: { courseGroup: { include: { course: true } } }
    });

    if (!session) return res.status(404).json({ message: 'الحصة ما موجودة' });
    if (!['SCHEDULED', 'LIVE'].includes(session.status) || closedStatuses.includes(session.courseGroup.status) || !session.courseGroup.course.isActive || !['INDIVIDUAL_ONLINE', 'GROUP_ONLINE'].includes(session.courseGroup.course.teachingMethod)) {
      return res.status(403).json({ message: 'الحصة غير متاحة للدخول الآن' });
    }

    // التحقق من الاشتراك
    const subscription = await prisma.subscription.findFirst({
      where: {
        studentId: req.student.id,
        courseGroupId: session.courseGroupId,
        status: 'ACTIVE',
        startDate: { lte: new Date() },
        endDate: { gt: new Date() },
        booking: { status: 'CONFIRMED' }
      }
    });

    if (!subscription) {
      return res.status(403).json({ message: 'ما عندك اشتراك فعّال في الكورس دا' });
    }

    // التحقق من الوقت
    const now = new Date();
    const { start: sessionDate, end: endDate, early: earlyEntry } = sessionWindow(session);

    if (now < earlyEntry) {
      return res.status(400).json({ 
        message: 'الحصة لسه ما بدت. ممكن تدخل قبل الموعد بـ 10 دقائق.',
        startsAt: sessionDate
      });
    }

    if (now >= endDate) {
      return res.status(400).json({ message: 'الحصة انتهت' });
    }

    // إنشاء رمز دخول للبث
    if (!process.env.JITSI_APP_ID || !process.env.JITSI_API_KEY || !process.env.JITSI_DOMAIN || process.env.JITSI_DOMAIN === 'meet.jit.si' || process.env.JITSI_DOMAIN === '8x8.vc') {
      return res.json({
        message: 'خدمة البث غير مُعدّة حالياً. اتواصل مع الإدارة.',
        streamConfigured: false,
        sessionInfo: {
          title: session.courseGroup.course.title,
          startTime: session.startTime,
          endTime: session.endTime
        }
      });
    }

    // توليد رمز Jitsi (يحتاج إعداد JITSI_APP_ID و JITSI_API_KEY)
    const roomName = `ostazk-${session.id}`;
    const jwt = require('jsonwebtoken');
    const meetingToken = jwt.sign({
      aud: 'jitsi',
      iss: process.env.JITSI_APP_ID,
      sub: process.env.JITSI_DOMAIN || 'meet.jit.si',
      room: roomName,
      context: {
        user: {
          name: (await prisma.student.findUnique({ where: { id: req.student.id }, select: { fullName: true } }))?.fullName || 'طالب',
          id: req.student.id
        }
      },
      exp: Math.floor(endDate.getTime() / 1000) + 300 // 5 دقائق بعد انتهاء الحصة
    }, process.env.JITSI_API_KEY, { algorithm: 'HS256', jwtid: require('crypto').randomUUID() });

    res.json({
      message: 'جاهز! ادخل الحصة',
      streamConfigured: true,
      meetingToken,
      roomName,
      domain: process.env.JITSI_DOMAIN || 'meet.jit.si',
      sessionInfo: {
        title: session.courseGroup.course.title,
        startTime: session.startTime,
        endTime: session.endTime
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

// ========== المفضلة ==========
router.get('/bookmarks', async (req, res) => {
  try {
    const bookmarks = await prisma.studentBookmark.findMany({
      where: { studentId: req.student.id },
      include: {
        book: {
          select: {
            id: true, title: true, coverUrl: true,
            subject: { select: { name: true } },
            grade: { select: { name: true } }
          }
        }
      }
    });
    res.json(bookmarks);
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

router.post('/bookmarks/:bookId', async (req, res) => {
  try {
    const { bookId } = req.params;
    const existing = await prisma.studentBookmark.findUnique({
      where: { studentId_bookId: { studentId: req.student.id, bookId } }
    });

    if (existing) {
      await prisma.studentBookmark.delete({ where: { id: existing.id } });
      return res.json({ message: 'تم إزالته من المحفوظات', bookmarked: false });
    }

    await prisma.studentBookmark.create({
      data: { studentId: req.student.id, bookId }
    });
    res.json({ message: 'تم حفظه', bookmarked: true });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ' });
  }
});

module.exports = router;
