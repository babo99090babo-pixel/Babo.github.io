// ========== لوحة الإدارة - كل الواجهات ==========
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, query } = require('express-validator');
const prisma = require('../services/db');
const { Prisma } = require('@prisma/client');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { randomUUID: uuidv4 } = require('crypto');
const { validate } = require('../middleware/validate');
const { authenticateAdmin, requireRole } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/rateLimiter');
const { logAction } = require('../services/auditService');
const { generateCode, hashCode, formatCode } = require('../utils/activationCode');
const { normalizePhone, isValidSudanesePhone } = require('../utils/phone');
const { issueAdminSession, setSessionCookie, clearSessionCookie, revokeAdminSession } = require('../services/authSession');
const { getUploadDirectory, resolveBookPath } = require('../services/bookAccess');
const { SETTINGS_KEYS, normalizeSiteSettings, csvCell, sumPayments, fileSignatureMatches } = require('../services/adminSafety');
const { DomainError, closedStatuses, lockGroup, syncSeats, confirmBooking, cancelBooking, issueCodes } = require('../services/enrollment');
const { sessionWindow, TIME_PATTERN } = require('../services/sessionTime');
const pick = (value, keys) => Object.fromEntries(keys.filter(k => value[k] !== undefined).map(k => [k, value[k]]));
const auditFor = req => ({ adminId: req.admin.id, ipAddress: req.ip });
function sendError(res, err) {
  const status = err.status || ({ P2002: 409, P2003: 400, P2025: 404, P2024: 503 })[err.code] || 500;
  const message = err.status ? err.message : ({ 409: 'البيانات موجودة بالفعل', 400: 'راجع البيانات المرتبطة بالطلب', 404: 'البيانات غير موجودة', 503: 'الخدمة مشغولة. حاول بعد قليل.' })[status] || 'حصل خطأ. حاول تاني.';
  return res.status(status).json({ message });
}
function integer(value, min = 1, max = 1000000) {
  if (!/^[0-9]+$/.test(String(value)) || !Number.isSafeInteger(Number(value)) || Number(value) < min || Number(value) > max) throw new DomainError('أدخل عدداً صحيحاً صالحاً');
  return Number(value);
}
function money(value) {
  const text = String(value);
  if (!/^[0-9]{1,10}(\.[0-9]{1,2})?$/.test(text)) throw new DomainError('أدخل مبلغاً صالحاً غير سالب بمنزلتين عشريتين كحد أقصى');
  return text;
}
function textField(value, max = 200, required = false) {
  if (typeof value !== 'string' || value.length > max || (required && !value.trim())) throw new DomainError('راجع الحقول النصية المطلوبة');
  return value.trim();
}
function enumValue(value, values) { if (!values.includes(value)) throw new DomainError('الخيار غير صالح'); return value; }
function booleanValue(value) {
  if (![true, false, 'true', 'false'].includes(value)) throw new DomainError('الخيار غير صالح');
  return value === true || value === 'true';
}
router.use((req, res, next) => {
  for (const [key, value] of Object.entries(req.query)) {
    if (typeof value !== 'string' || value.length > 200) return res.status(400).json({ message: 'خيارات البحث غير صالحة' });
    if (['page', 'limit'].includes(key) && (!/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value)) || (key === 'limit' && Number(value) > 100))) return res.status(400).json({ message: 'رقم الصفحة أو حد النتائج غير صالح' });
    if (['from', 'to'].includes(key) && !Number.isFinite(new Date(value).getTime())) return res.status(400).json({ message: 'التاريخ غير صالح' });
  }
  next();
});


// ========== إعداد رفع الملفات ==========
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = file.fieldname === 'bookFile'
      ? getUploadDirectory('books')
      : getUploadDirectory('images');
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = file.fieldname === 'bookFile' ? '.pdf' : ({ 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }[file.mimetype] || '.invalid');
    cb(null, `${uuidv4()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: (parseInt(process.env.MAX_FILE_SIZE_MB) || 50) * 1024 * 1024, files: 2, fields: 20, fieldSize: 20000 },
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'bookFile') {
      if (file.mimetype === 'application/pdf') cb(null, true);
      else cb(new DomainError('الملف لازم يكون PDF'));
    } else if (file.fieldname === 'image' || file.fieldname === 'cover') {
      if (['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) cb(null, true);
      else cb(new DomainError('الصورة لازم تكون JPEG أو PNG أو WebP'));
    } else {
      cb(new DomainError('نوع الملف غير مدعوم'));
    }
  }
});

// ========== دخول المدير ==========
router.post('/auth/login', loginLimiter, [
  body('email').isString().trim().isEmail().isLength({ max: 254 }).withMessage('البريد ما صحيح'),
  body('password').isString().isLength({ min: 1, max: 200 }).withMessage('كلمة السر مطلوبة'),
], validate, async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await prisma.admin.findUnique({ where: { email: email.trim().toLowerCase() } });

    if (!admin || !admin.isActive) {
      await prisma.loginAttempt.create({
        data: { email: email.trim().toLowerCase(), success: false, ipAddress: req.ip, userAgent: req.get('user-agent') }
      }).catch(() => {});
      return res.status(401).json({ message: 'البريد أو كلمة السر غلط' });
    }

    const valid = await bcrypt.compare(password, admin.passwordHash);
    if (!valid) {
      await prisma.loginAttempt.create({
        data: { email: email.trim().toLowerCase(), success: false, ipAddress: req.ip, userAgent: req.get('user-agent') }
      }).catch(() => {});
      return res.status(401).json({ message: 'البريد أو كلمة السر غلط' });
    }

    const token = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "Admin" WHERE id = ${admin.id} FOR UPDATE`;
      const current = await tx.admin.findUnique({ where: { id: admin.id } });
      if (!current?.isActive || current.passwordHash !== admin.passwordHash) throw new DomainError('بيانات الدخول تغيرت. حاول مجدداً.', 401);
      const token = await issueAdminSession(tx, current, req);
      await logAction({ adminId: admin.id, action: 'LOGIN', entity: 'Admin', entityId: admin.id, ipAddress: req.ip }, tx);
      return token;
    });
    setSessionCookie(res, 'adminToken', token);

    res.json({ message: 'تم الدخول', admin: { id: admin.id, name: admin.name, email: admin.email, role: admin.role } });
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/auth/logout', authenticateAdmin, async (req, res) => {
  try {
    await revokeAdminSession(prisma, req.cookies.adminToken);
    clearSessionCookie(res, 'adminToken');
    res.json({ message: 'تم الخروج' });
  } catch (err) { sendError(res, err); }
});

router.get('/auth/me', authenticateAdmin, async (req, res) => {
  const admin = await prisma.admin.findUnique({
    where: { id: req.admin.id },
    select: { id: true, name: true, email: true, role: true }
  });
  res.json(admin);
});

// ========== كل الراوتات التالية تتطلب مصادقة المدير ==========
router.use(authenticateAdmin);

// ========== لوحة المعلومات ==========
router.get('/dashboard', async (req, res) => {
  try {
    const [students, teachers, bookings, subscriptions, pendingApps, recentBookings] = await Promise.all([
      prisma.student.count(),
      prisma.teacher.count({ where: { isApproved: true } }),
      prisma.booking.count(),
      prisma.subscription.count({ where: { status: 'ACTIVE', startDate: { lte: new Date() }, endDate: { gt: new Date() }, booking: { status: 'CONFIRMED' }, courseGroup: { status: { notIn: closedStatuses }, course: { isActive: true } } } }),
      prisma.teacherApplication.count({ where: { status: 'PENDING' } }),
      prisma.booking.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          student: { select: { fullName: true, phone: true } },
          courseGroup: { include: { course: { select: { title: true } } } }
        }
      })
    ]);

    res.json({ stats: { students, teachers, bookings, activeSubscriptions: subscriptions, pendingApplications: pendingApps }, recentBookings });
  } catch (err) {
    sendError(res, err);
  }
});

// ========== إدارة الطلاب ==========
router.get('/students', async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = {};

    if (search) {
      const normalizedSearch = normalizePhone(search);
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { phone: { contains: normalizedSearch } },
        { id: search }
      ];
    }

    const [students, total] = await Promise.all([
      prisma.student.findMany({
        where, skip, take: parseInt(limit),
        orderBy: { createdAt: 'desc' },
        select: {
          id: true, fullName: true, phone: true, parentPhone: true,
          isActive: true, stageId: true, gradeId: true, createdAt: true,
          stage: { select: { name: true } },
          grade: { select: { name: true } },
          _count: { select: { bookings: true, subscriptions: true } }
        }
      }),
      prisma.student.count({ where })
    ]);

    res.json({ students, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

router.get('/students/:id', async (req, res) => {
  try {
    const student = await prisma.student.findUnique({
      where: { id: req.params.id },
      select: {
        id: true, fullName: true, phone: true, parentPhone: true,
        isActive: true, stageId: true, gradeId: true, createdAt: true,
        stage: { select: { name: true } },
        grade: { select: { name: true } },
        bookings: {
          include: { courseGroup: { include: { course: { select: { title: true } } } } },
          orderBy: { createdAt: 'desc' }
        },
        subscriptions: {
          include: { courseGroup: { include: { course: { select: { title: true } } } } },
          orderBy: { createdAt: 'desc' }
        }
      }
    });
    if (!student) return res.status(404).json({ message: 'الطالب ما موجود' });
    res.json(student);
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/students/:id/toggle-active', async (req, res) => {
  try {
    const student = await prisma.student.findUnique({ where: { id: req.params.id } });
    if (!student) return res.status(404).json({ message: 'الطالب ما موجود' });

    const updated = await prisma.student.update({
      where: { id: req.params.id },
      data: { isActive: !student.isActive },
      select: { id: true, isActive: true }
    });

    await logAction({ adminId: req.admin.id, action: student.isActive ? 'DEACTIVATE' : 'ACTIVATE', entity: 'Student', entityId: req.params.id, ipAddress: req.ip });
    res.json({ message: updated.isActive ? 'تم تفعيل الحساب' : 'تم تعطيل الحساب', student: updated });
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/students/:id/reset-password-link', async (req, res) => {
  try {
    const student = await prisma.student.findUnique({ where: { id: req.params.id } });
    if (!student) return res.status(404).json({ message: 'الطالب ما موجود' });

    // توليد رمز استعادة مؤقت
    const crypto = require('crypto');
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetHash = crypto.createHash('sha256').update(resetToken).digest('hex');

    // حفظه كإعداد مؤقت (يمكن استخدام جدول منفصل)
    await prisma.setting.upsert({
      where: { key: `reset_${req.params.id}` },
      update: { value: JSON.stringify({ hash: resetHash, expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString() }) },
      create: { key: `reset_${req.params.id}`, value: JSON.stringify({ hash: resetHash, expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString() }) }
    });

    await logAction({ adminId: req.admin.id, action: 'RESET_PASSWORD_LINK', entity: 'Student', entityId: req.params.id, ipAddress: req.ip });

    res.json({
      message: 'تم إنشاء رابط الاستعادة (صالح لـ 30 دقيقة)',
      resetUrl: `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}&id=${req.params.id}`,
      whatsappMessage: `السلام عليكم\nرابط استعادة كلمة السر:\n${process.env.FRONTEND_URL}/reset-password?token=${resetToken}&id=${req.params.id}\nصالح لـ 30 دقيقة فقط.`
    });
  } catch (err) {
    sendError(res, err);
  }
});

// ========== إدارة المراحل ==========
router.get('/stages', async (req, res) => {
  const stages = await prisma.stage.findMany({ orderBy: { order: 'asc' }, include: { grades: { orderBy: { order: 'asc' } } } });
  res.json(stages);
});

router.post('/stages', [body('name').notEmpty(), body('slug').notEmpty()], validate, async (req, res) => {
  try {
    const stage = await prisma.stage.create({ data: { name: req.body.name, slug: req.body.slug, order: req.body.order || 0 } });
    await logAction({ adminId: req.admin.id, action: 'CREATE', entity: 'Stage', entityId: stage.id.toString(), ipAddress: req.ip });
    res.status(201).json(stage);
  } catch (err) {
    if (err.code === 'P2002') return res.status(409).json({ message: 'المرحلة موجودة' });
    sendError(res, err);
  }
});

router.put('/stages/:id', async (req, res) => {
  try {
    const stage = await prisma.stage.update({ where: { id: parseInt(req.params.id) }, data: pick(req.body, ['name', 'slug', 'order', 'isActive']) });
    await logAction({ adminId: req.admin.id, action: 'UPDATE', entity: 'Stage', entityId: req.params.id, ipAddress: req.ip });
    res.json(stage);
  } catch (err) {
    sendError(res, err);
  }
});

// ========== إدارة الصفوف ==========
router.get('/grades', async (req, res) => {
  const { stageId } = req.query;
  const where = stageId ? { stageId: parseInt(stageId) } : {};
  const grades = await prisma.grade.findMany({ where, orderBy: { order: 'asc' }, include: { stage: { select: { name: true } } } });
  res.json(grades);
});

router.post('/grades', [body('name').notEmpty(), body('slug').notEmpty(), body('stageId').isInt()], validate, async (req, res) => {
  try {
    const grade = await prisma.grade.create({ data: { name: req.body.name, slug: req.body.slug, stageId: parseInt(req.body.stageId), order: req.body.order || 0 } });
    await logAction({ adminId: req.admin.id, action: 'CREATE', entity: 'Grade', entityId: grade.id.toString(), ipAddress: req.ip });
    res.status(201).json(grade);
  } catch (err) {
    if (err.code === 'P2002') return res.status(409).json({ message: 'الصف موجود' });
    sendError(res, err);
  }
});

router.put('/grades/:id', async (req, res) => {
  try {
    const data = pick(req.body, ['name', 'slug', 'order', 'isActive', 'stageId']);
    if (data.stageId) data.stageId = parseInt(data.stageId);
    const grade = await prisma.grade.update({ where: { id: parseInt(req.params.id) }, data });
    res.json(grade);
  } catch (err) {
    sendError(res, err);
  }
});

// ========== إدارة المواد ==========
router.get('/subjects', async (req, res) => {
  const subjects = await prisma.subject.findMany({ orderBy: { name: 'asc' } });
  res.json(subjects);
});

router.post('/subjects', [body('name').notEmpty(), body('slug').notEmpty()], validate, async (req, res) => {
  try {
    const subject = await prisma.subject.create({ data: { name: req.body.name, slug: req.body.slug } });
    await logAction({ adminId: req.admin.id, action: 'CREATE', entity: 'Subject', entityId: subject.id.toString(), ipAddress: req.ip });
    res.status(201).json(subject);
  } catch (err) {
    if (err.code === 'P2002') return res.status(409).json({ message: 'المادة موجودة' });
    sendError(res, err);
  }
});

router.put('/subjects/:id', async (req, res) => {
  try {
    const subject = await prisma.subject.update({ where: { id: integer(req.params.id) }, data: pick(req.body, ['name', 'slug', 'isActive']) });
    res.json(subject);
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/subjects/:id/grades', [body('gradeIds').isArray()], validate, async (req, res) => {
  try {
    const subjectId = parseInt(req.params.id);
    // حذف الروابط القديمة
    await prisma.gradeSubject.deleteMany({ where: { subjectId } });
    // إنشاء الروابط الجديدة
    const data = req.body.gradeIds.map(gId => ({ gradeId: parseInt(gId), subjectId }));
    await prisma.gradeSubject.createMany({ data, skipDuplicates: true });
    res.json({ message: 'تم ربط المادة بالصفوف' });
  } catch (err) {
    sendError(res, err);
  }
});

// ========== إدارة المدرسين ==========
router.get('/teachers', async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = {};
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } }
      ];
    }
    const [teachers, total] = await Promise.all([
      prisma.teacher.findMany({ where, skip, take: parseInt(limit), orderBy: { createdAt: 'desc' } }),
      prisma.teacher.count({ where })
    ]);
    res.json({ teachers, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/teachers', [body('name').notEmpty()], validate, async (req, res) => {
  try {
    const { name, phone, email, bio, qualifications, city, photoUrl } = req.body;
    let passwordHash = null;
    if (req.body.password) {
      passwordHash = await bcrypt.hash(req.body.password, 12);
    }
    const teacher = await prisma.teacher.create({
      data: { name, phone, email, bio, qualifications, city, photoUrl, passwordHash, isApproved: true }
    });
    await logAction({ adminId: req.admin.id, action: 'CREATE', entity: 'Teacher', entityId: teacher.id, ipAddress: req.ip });
    res.status(201).json(teacher);
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/teachers/:id', async (req, res) => {
  try {
    const { name, phone, email, bio, qualifications, city, photoUrl, isApproved, isActive } = req.body;
    const teacher = await prisma.teacher.update({
      where: { id: req.params.id },
      data: { name, phone, email, bio, qualifications, city, photoUrl, isApproved, isActive }
    });
    await logAction({ adminId: req.admin.id, action: 'UPDATE', entity: 'Teacher', entityId: req.params.id, ipAddress: req.ip });
    res.json(teacher);
  } catch (err) {
    sendError(res, err);
  }
});

// طلبات الانضمام
router.get('/teacher-applications', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const where = status ? { status } : {};
    const [apps, total] = await Promise.all([
      prisma.teacherApplication.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (parseInt(page) - 1) * parseInt(limit), take: parseInt(limit) }),
      prisma.teacherApplication.count({ where })
    ]);
    res.json({ applications: apps, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/teacher-applications/:id/approve', async (req, res) => {
  try {
    const app = await prisma.teacherApplication.update({
      where: { id: req.params.id },
      data: { status: 'APPROVED', reviewedBy: req.admin.id, reviewedAt: new Date() }
    });
    await logAction({ adminId: req.admin.id, action: 'APPROVE', entity: 'TeacherApplication', entityId: req.params.id, ipAddress: req.ip });
    res.json({ message: 'تم قبول الطلب', application: app });
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/teacher-applications/:id/reject', async (req, res) => {
  try {
    const app = await prisma.teacherApplication.update({
      where: { id: req.params.id },
      data: { status: 'REJECTED', reviewedBy: req.admin.id, reviewedAt: new Date() }
    });
    await logAction({ adminId: req.admin.id, action: 'REJECT', entity: 'TeacherApplication', entityId: req.params.id, ipAddress: req.ip });
    res.json({ message: 'تم رفض الطلب', application: app });
  } catch (err) {
    sendError(res, err);
  }
});

// ========== إدارة الكورسات ==========
router.get('/courses', async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = {};
    if (search) where.title = { contains: search, mode: 'insensitive' };
    const [courses, total] = await Promise.all([
      prisma.course.findMany({
        where, skip, take: parseInt(limit), orderBy: { createdAt: 'desc' },
        include: {
          subject: { select: { name: true } },
          grade: { select: { name: true, stage: { select: { name: true } } } },
          teacher: { select: { name: true } },
          _count: { select: { groups: true } }
        }
      }),
      prisma.course.count({ where })
    ]);
    res.json({ courses, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/courses', [
  body('title').notEmpty().withMessage('العنوان مطلوب'),
  body('subjectId').isInt().withMessage('المادة مطلوبة'),
  body('gradeId').isInt().withMessage('الصف مطلوب'),
  body('teacherId').notEmpty().withMessage('المدرس مطلوب'),
  body('teachingMethod').isIn(['INDIVIDUAL_ONSITE', 'GROUP_ONSITE', 'INDIVIDUAL_ONLINE', 'GROUP_ONLINE']).withMessage('نوع التدريس ما صحيح'),
], validate, async (req, res) => {
  try {
    const course = await prisma.course.create({
      data: {
        title: req.body.title,
        description: req.body.description,
        subjectId: parseInt(req.body.subjectId),
        gradeId: parseInt(req.body.gradeId),
        teacherId: req.body.teacherId,
        teachingMethod: req.body.teachingMethod,
        totalSessions: parseInt(req.body.totalSessions) || 1,
        sessionDurationMinutes: parseInt(req.body.sessionDurationMinutes) || 60
      }
    });
    await logAction({ adminId: req.admin.id, action: 'CREATE', entity: 'Course', entityId: course.id, ipAddress: req.ip });
    res.status(201).json(course);
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/courses/:id', async (req, res) => {
  try {
    const data = pick(req.body, ['title', 'description', 'imageUrl', 'subjectId', 'gradeId', 'teacherId', 'teachingMethod', 'totalSessions', 'sessionDurationMinutes', 'isActive']);
    if (data.subjectId) data.subjectId = parseInt(data.subjectId);
    if (data.gradeId) data.gradeId = parseInt(data.gradeId);
    if (data.totalSessions) data.totalSessions = parseInt(data.totalSessions);
    if (data.sessionDurationMinutes) data.sessionDurationMinutes = parseInt(data.sessionDurationMinutes);
    const course = await prisma.course.update({ where: { id: req.params.id }, data });
    await logAction({ adminId: req.admin.id, action: 'UPDATE', entity: 'Course', entityId: req.params.id, ipAddress: req.ip });
    res.json(course);
  } catch (err) {
    sendError(res, err);
  }
});

// ========== المجموعات ==========
router.get('/courses/:courseId/groups', async (req, res) => {
  try {
    const groups = await prisma.courseGroup.findMany({ where: { courseId: req.params.courseId }, orderBy: { createdAt: 'asc' }, include: { sessions: { orderBy: [{ date: 'asc' }, { startTime: 'asc' }], include: { location: { include: { location: true } } } } } });
    res.json(groups);
  } catch (err) { sendError(res, err); }
});
function groupData(body, partial = false) {
  const data = pick(body, ['name', 'minStudents', 'maxStudents', 'priceAmount', 'priceType', 'pricePer', 'status']);
  if (!partial || data.name !== undefined) data.name = textField(data.name, 200, true);
  if (!partial || data.minStudents !== undefined) data.minStudents = integer(data.minStudents ?? 1);
  if (!partial || data.maxStudents !== undefined) data.maxStudents = integer(data.maxStudents);
  if (!partial || data.priceAmount !== undefined) data.priceAmount = money(data.priceAmount);
  if (data.priceType !== undefined) data.priceType = enumValue(data.priceType, ['PER_STUDENT', 'PER_GROUP']);
  if (data.pricePer !== undefined) data.pricePer = enumValue(data.pricePer, ['PER_SESSION', 'PER_COURSE']);
  if (data.status !== undefined) data.status = enumValue(data.status, ['WAITING_ENROLLMENT', 'CONFIRMED', 'FULL', 'POSTPONED', 'CANCELLED', 'FINISHED']);
  return data;
}
router.post('/courses/:courseId/groups', async (req, res) => {
  try {
    const data = groupData(req.body);
    if (data.minStudents > data.maxStudents) throw new DomainError('العدد الأدنى يجب ألا يتجاوز العدد الأقصى');
    delete data.status;
    const group = await prisma.$transaction(async tx => {
      const group = await tx.courseGroup.create({ data: { ...data, courseId: req.params.courseId } });
      await logAction({ ...auditFor(req), action: 'CREATE', entity: 'CourseGroup', entityId: group.id }, tx);
      return group;
    });
    res.status(201).json(group);
  } catch (err) { sendError(res, err); }
});
router.put('/groups/:id', async (req, res) => {
  try {
    const data = groupData(req.body, true);
    const updated = await prisma.$transaction(async tx => {
      const group = await lockGroup(tx, req.params.id);
      if (group.status === 'CANCELLED' && data.status && data.status !== 'CANCELLED') throw new DomainError('أنشئ مجموعة جديدة بدلاً من إعادة فتح مجموعة ألغيت حجوزاتها');
      const max = data.maxStudents ?? group.maxStudents;
      if ((data.minStudents ?? group.minStudents) > max) throw new DomainError('العدد الأدنى يجب ألا يتجاوز العدد الأقصى');
      const count = await tx.booking.count({ where: { courseGroupId: group.id, status: 'CONFIRMED' } });
      if (max < count) throw new DomainError('السعة أقل من عدد المقاعد المحجوزة بالفعل');
      await tx.courseGroup.update({ where: { id: group.id }, data });
      if (data.status === 'CANCELLED') {
        const bookings = await tx.booking.findMany({ where: { courseGroupId: group.id, status: { not: 'CANCELLED' } }, select: { id: true } });
        for (const booking of bookings) await cancelBooking(tx, booking.id, 'إلغاء المجموعة', auditFor(req));
        await tx.session.updateMany({ where: { courseGroupId: group.id, status: { in: ['SCHEDULED', 'LIVE'] } }, data: { status: 'CANCELLED' } });
      }
      const fresh = await tx.courseGroup.findUnique({ where: { id: group.id } });
      const result = await syncSeats(tx, fresh);
      await logAction({ ...auditFor(req), action: 'UPDATE', entity: 'CourseGroup', entityId: group.id }, tx);
      return result;
    }, { timeout: 20000 });
    res.json(updated);
  } catch (err) { sendError(res, err); }
});

// ========== الحصص ==========
router.post('/groups/:groupId/sessions', async (req, res) => {
  try {
    if (!Array.isArray(req.body.sessions) || !req.body.sessions.length || req.body.sessions.length > 100) throw new DomainError('أضف من 1 إلى 100 حصة');
    const sessions = req.body.sessions.map(s => {
      if (!s || typeof s.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s.date)) throw new DomainError('تاريخ الحصة غير صالح');
      const date = new Date(`${s.date}T00:00:00Z`);
      if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== s.date || !TIME_PATTERN.test(s.startTime) || !TIME_PATTERN.test(s.endTime) || s.endTime <= s.startTime) throw new DomainError('راجع تاريخ الحصة ووقتي البداية والنهاية بتوقيت السودان');
      return { sessionNumber: integer(s.sessionNumber), date, startTime: s.startTime, endTime: s.endTime, ...(s.locationId ? { location: { create: { locationId: integer(s.locationId) } } } : {}) };
    });
    if (new Set(sessions.map(s => s.sessionNumber)).size !== sessions.length) throw new DomainError('رقم الحصة مكرر في القائمة');
    const created = await prisma.$transaction(async tx => {
      const group = await lockGroup(tx, req.params.groupId);
      if (['CANCELLED', 'FINISHED'].includes(group.status)) throw new DomainError('المجموعة مغلقة');
      if (group.course.teachingMethod.endsWith('_ONSITE') && sessions.some(s => !s.location)) throw new DomainError('اختر مكاناً لكل حصة حضورية');
      const created = [];
      for (const s of sessions) created.push(await tx.session.create({ data: { ...s, courseGroupId: group.id } }));
      await logAction({ ...auditFor(req), action: 'CREATE_SESSIONS', entity: 'CourseGroup', entityId: group.id, details: { count: created.length } }, tx);
      return created;
    }, { timeout: 20000 });
    res.status(201).json(created);
  } catch (err) { sendError(res, err); }
});
router.put('/sessions/:id', async (req, res) => {
  try {
    const status = enumValue(req.body.status, ['SCHEDULED', 'LIVE', 'COMPLETED', 'CANCELLED']);
    const result = await prisma.$transaction(async tx => {
      const session = await tx.session.findUnique({ where: { id: req.params.id } });
      if (!session) throw new DomainError('الحصة ما موجودة', 404);
      const group = await lockGroup(tx, session.courseGroupId);
      if (closedStatuses.includes(group.status) && status !== 'CANCELLED') throw new DomainError('المجموعة غير متاحة');
      const updated = await tx.session.update({ where: { id: session.id }, data: { status } });
      await logAction({ ...auditFor(req), action: 'UPDATE', entity: 'Session', entityId: session.id, details: { status } }, tx);
      return updated;
    });
    res.json(result);
  } catch (err) { sendError(res, err); }
});

// ========== الحجوزات ==========
router.get('/bookings', async (req, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = {};
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { student: { fullName: { contains: search, mode: 'insensitive' } } },
        { student: { phone: { contains: search } } }
      ];
    }
    const [bookings, total] = await Promise.all([
      prisma.booking.findMany({
        where, skip, take: parseInt(limit), orderBy: { createdAt: 'desc' },
        include: {
          student: { select: { id: true, fullName: true, phone: true } },
          courseGroup: { include: { course: { select: { title: true, teachingMethod: true } } } }
        }
      }),
      prisma.booking.count({ where })
    ]);
    res.json({ bookings, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/bookings/:id/confirm', async (req, res) => {
  try {
    const booking = await prisma.$transaction(tx => confirmBooking(tx, req.params.id, auditFor(req)));
    res.json({ message: 'تم تأكيد الحجز وحجز المقعد', booking });
  } catch (err) { sendError(res, err); }
});
router.put('/bookings/:id/cancel', async (req, res) => {
  try {
    const reason = req.body.reason === undefined ? null : textField(req.body.reason, 1000);
    const booking = await prisma.$transaction(tx => cancelBooking(tx, req.params.id, reason, auditFor(req)));
    res.json({ message: 'تم إلغاء الحجز ورموزه واشتراكه', booking });
  } catch (err) { sendError(res, err); }
});


router.post('/bookings/:id/payment', async (req, res) => {
  try {
    const amount = money(req.body.amount);
    const currency = req.body.currency || 'SDG';
    if (!/^[A-Z]{3}$/.test(currency) || Number(amount) <= 0) throw new DomainError('راجع المبلغ ورمز العملة');
    const method = textField(req.body.method, 100, true);
    const reference = req.body.reference === undefined ? null : textField(req.body.reference, 200);
    const notes = req.body.notes === undefined ? null : textField(req.body.notes, 2000);
    const payment = await prisma.$transaction(async tx => {
      const payment = await tx.paymentRecord.create({ data: { bookingId: req.params.id, amount, currency, method, reference, notes, recordedBy: req.admin.id } });
      await logAction({ ...auditFor(req), action: 'RECORD_PAYMENT', entity: 'Booking', entityId: req.params.id, details: { amount, currency } }, tx);
      return payment;
    });
    res.status(201).json({ message: 'تم تسجيل الدفع', payment });
  } catch (err) { sendError(res, err); }
});


// ========== رموز التفعيل ==========
router.get('/activation-codes', async (req, res) => {
  try {
    const { status, studentId, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = {};
    if (status) where.status = status;
    if (studentId) where.studentId = studentId;
    const [codes, total] = await Promise.all([
      prisma.activationCode.findMany({
        where, skip, take: parseInt(limit), orderBy: { createdAt: 'desc' },
        select: {
          id: true, status: true, expiresAt: true, usedAt: true, createdAt: true,
          student: { select: { id: true, fullName: true, phone: true } },
          booking: { include: { courseGroup: { include: { course: { select: { title: true } } } } } }
        }
      }),
      prisma.activationCode.count({ where })
    ]);
    res.json({ codes, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/activation-codes', async (req, res) => {
  try {
    const results = await prisma.$transaction(tx => issueCodes(tx, req.body.items, auditFor(req)), { timeout: 20000 });
    res.status(201).json({ message: `تم إنشاء ${results.length} رمز`, results });
  } catch (err) { sendError(res, err); }
});
router.put('/activation-codes/:id/cancel', async (req, res) => {
  try {
    await prisma.$transaction(async tx => {
      const code = await tx.activationCode.findUnique({ where: { id: req.params.id }, include: { booking: true } });
      if (!code) throw new DomainError('الرمز ما موجود', 404);
      await lockGroup(tx, code.booking.courseGroupId);
      const updated = await tx.activationCode.updateMany({ where: { id: code.id, status: 'ACTIVE' }, data: { status: 'CANCELLED' } });
      if (updated.count !== 1) throw new DomainError('الرمز مستخدم أو غير نشط');
      await logAction({ ...auditFor(req), action: 'CANCEL', entity: 'ActivationCode', entityId: code.id }, tx);
    });
    res.json({ message: 'تم إلغاء الرمز' });
  } catch (err) { sendError(res, err); }
});


// ========== الاشتراكات ==========
router.get('/subscriptions', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const where = status ? { status } : {};
    const [subs, total] = await Promise.all([
      prisma.subscription.findMany({
        where, orderBy: { createdAt: 'desc' }, skip: (parseInt(page) - 1) * parseInt(limit), take: parseInt(limit),
        include: {
          student: { select: { fullName: true, phone: true } },
          courseGroup: { include: { course: { select: { title: true } } } }
        }
      }),
      prisma.subscription.count({ where })
    ]);
    res.json({ subscriptions: subs, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

for (const action of ['suspend', 'reactivate']) {
  router.put(`/subscriptions/:id/${action}`, async (req, res) => {
    try {
      await prisma.$transaction(async tx => {
        const sub = await tx.subscription.findUnique({ where: { id: req.params.id }, include: { booking: true } });
        if (!sub) throw new DomainError('الاشتراك ما موجود', 404);
        const group = await lockGroup(tx, sub.courseGroupId);
        if (action === 'reactivate' && (sub.booking.status !== 'CONFIRMED' || sub.endDate <= new Date() || closedStatuses.includes(group.status) || !group.course.isActive)) throw new DomainError('لا يمكن إعادة تفعيل اشتراك منتهٍ أو حجز ملغي');
        await tx.subscription.update({ where: { id: sub.id }, data: { status: action === 'suspend' ? 'SUSPENDED' : 'ACTIVE' } });
        await logAction({ ...auditFor(req), action: action === 'suspend' ? 'SUSPEND' : 'REACTIVATE', entity: 'Subscription', entityId: sub.id }, tx);
      });
      res.json({ message: action === 'suspend' ? 'تم إيقاف الاشتراك' : 'تم إعادة تفعيل الاشتراك' });
    } catch (err) { sendError(res, err); }
  });
}


// ========== الكتب ==========
router.get('/books', async (req, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const where = {};
    if (status) where.status = status;
    if (search) where.title = { contains: search, mode: 'insensitive' };
    const [books, total] = await Promise.all([
      prisma.book.findMany({
        where, orderBy: { createdAt: 'desc' }, skip: (parseInt(page) - 1) * parseInt(limit), take: parseInt(limit),
        include: { subject: { select: { name: true } }, grade: { select: { name: true } } }
      }),
      prisma.book.count({ where })
    ]);
    res.json({ books, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

function uploadedFiles(req) {
  return req.file ? [req.file] : Object.values(req.files || {}).flat();
}
async function safeRemoveUpload(file) {
  if (!file?.path) return;
  const root = getUploadDirectory(file.fieldname === 'bookFile' ? 'books' : 'images');
  try {
    const [realRoot, realFile] = await Promise.all([fs.promises.realpath(root), fs.promises.realpath(file.path)]);
    const relative = path.relative(realRoot, realFile);
    if (!relative || relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) return;
    await fs.promises.unlink(realFile);
  } catch (err) { if (!['ENOENT', 'ENOTDIR'].includes(err.code)) console.error('Upload cleanup failed:', err.code); }
}
async function validateUpload(file) {
  if (!file || file.size < 1) throw new DomainError('الملف فارغ أو غير صالح');
  const handle = await fs.promises.open(file.path, 'r');
  try {
    const header = Buffer.alloc(Math.min(file.size, 16));
    const tail = Buffer.alloc(Math.min(file.size, 1024));
    await handle.read(header, 0, header.length, 0);
    await handle.read(tail, 0, tail.length, Math.max(0, file.size - tail.length));
    if (!fileSignatureMatches(file, header, tail)) throw new DomainError('محتوى الملف لا يطابق نوعه أو الملف غير مكتمل');
  } finally { await handle.close(); }
}
function bookData(input, existing) {
  const allowed = ['title', 'description', 'subjectId', 'gradeId', 'year', 'edition', 'accessLevel', 'courseId', 'allowDownload', 'status'];
  if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).some(key => !allowed.includes(key))) throw new DomainError('حقول الكتاب غير صالحة');
  const data = pick(input, allowed);
  if (!existing || data.title !== undefined) data.title = textField(data.title, 300, true);
  for (const key of ['description', 'year', 'edition']) if (data[key] !== undefined) data[key] = data[key] === null ? null : textField(data[key], key === 'description' ? 10000 : 100);
  for (const key of ['subjectId', 'gradeId']) if (!existing || data[key] !== undefined) data[key] = integer(data[key]);
  if (data.accessLevel !== undefined) data.accessLevel = enumValue(data.accessLevel, ['PUBLIC', 'REGISTERED', 'SUBSCRIBER']);
  if (data.status !== undefined) data.status = enumValue(data.status, ['DRAFT', 'PUBLISHED', 'ARCHIVED']);
  if (data.allowDownload !== undefined) data.allowDownload = booleanValue(data.allowDownload);
  if (data.courseId !== undefined) data.courseId = data.courseId === null || data.courseId === '' ? null : textField(data.courseId, 100, true);
  if ((data.accessLevel ?? existing?.accessLevel) === 'SUBSCRIBER' && !(data.courseId === undefined ? existing?.courseId : data.courseId)) throw new DomainError('اختار الكورس المرتبط بكتاب المشتركين');
  return data;
}
router.post('/books', upload.fields([{ name: 'bookFile', maxCount: 1 }, { name: 'cover', maxCount: 1 }]), async (req, res) => {
  let committed = false;
  try {
    const bookFile = req.files?.bookFile?.[0];
    if (!bookFile) throw new DomainError('ملف الكتاب مطلوب (PDF)');
    await Promise.all(uploadedFiles(req).map(validateUpload));
    const data = bookData(req.body);
    const cover = req.files?.cover?.[0];
    const book = await prisma.$transaction(async tx => {
      const book = await tx.book.create({ data: { ...data, fileType: 'pdf', filePath: bookFile.path, fileSize: bookFile.size, coverUrl: cover ? `/uploads/images/${cover.filename}` : null } });
      await logAction({ ...auditFor(req), action: 'CREATE', entity: 'Book', entityId: book.id }, tx);
      return book;
    });
    committed = true;
    res.status(201).json({ message: 'تم رفع الكتاب', book });
  } catch (err) {
    if (!committed) await Promise.all(uploadedFiles(req).map(safeRemoveUpload));
    sendError(res, err);
  }
});
router.put('/books/:id', async (req, res) => {
  try {
    const book = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "Book" WHERE id = ${req.params.id} FOR UPDATE`;
      const existing = await tx.book.findUnique({ where: { id: req.params.id } });
      if (!existing) throw new DomainError('الكتاب ما موجود', 404);
      const book = await tx.book.update({ where: { id: existing.id }, data: bookData(req.body, existing) });
      await logAction({ ...auditFor(req), action: 'UPDATE', entity: 'Book', entityId: book.id }, tx);
      return book;
    });
    res.json(book);
  } catch (err) { sendError(res, err); }
});
router.put('/books/:id/file', upload.single('bookFile'), async (req, res) => {
  let committed = false;
  try {
    await validateUpload(req.file);
    const { book, oldPath } = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "Book" WHERE id = ${req.params.id} FOR UPDATE`;
      const existing = await tx.book.findUnique({ where: { id: req.params.id } });
      if (!existing) throw new DomainError('الكتاب ما موجود', 404);
      const book = await tx.book.update({ where: { id: existing.id }, data: { filePath: req.file.path, fileSize: req.file.size, fileType: 'pdf' } });
      await logAction({ ...auditFor(req), action: 'UPDATE_FILE', entity: 'Book', entityId: book.id }, tx);
      return { book, oldPath: existing.filePath };
    });
    committed = true;
    // Only after a successful commit; never unlink an untrusted stored path.
    const oldFile = await resolveBookPath(oldPath);
    if (oldFile && oldFile !== req.file.path && !(await prisma.book.count({ where: { filePath: oldPath } }))) await safeRemoveUpload({ path: oldFile, fieldname: 'bookFile' });
    res.json({ message: 'تم استبدال الملف', book });
  } catch (err) {
    if (!committed) await safeRemoveUpload(req.file);
    sendError(res, err);
  }
});

// ========== الأماكن ==========
router.get('/locations', async (req, res) => {
  const locations = await prisma.location.findMany({ orderBy: { city: 'asc' } });
  res.json(locations);
});

router.post('/locations', [
  body('state').notEmpty(), body('city').notEmpty(), body('area').notEmpty(),
  body('venueName').notEmpty(), body('address').notEmpty()
], validate, async (req, res) => {
  try {
    const location = await prisma.location.create({
      data: {
        state: req.body.state, city: req.body.city, area: req.body.area,
        venueName: req.body.venueName, address: req.body.address,
        mapLat: req.body.mapLat ? parseFloat(req.body.mapLat) : null,
        mapLng: req.body.mapLng ? parseFloat(req.body.mapLng) : null
      }
    });
    res.status(201).json(location);
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/locations/:id', async (req, res) => {
  try {
    const data = pick(req.body, ['state', 'city', 'area', 'venueName', 'address', 'mapLat', 'mapLng', 'isActive']);
    if (data.mapLat) data.mapLat = parseFloat(data.mapLat);
    if (data.mapLng) data.mapLng = parseFloat(data.mapLng);
    const location = await prisma.location.update({ where: { id: parseInt(req.params.id) }, data });
    res.json(location);
  } catch (err) {
    sendError(res, err);
  }
});

// ========== الإعدادات ==========
router.get('/settings', async (req, res) => {
  try {
    const settings = await prisma.setting.findMany({ where: { key: { in: SETTINGS_KEYS } } });
    res.json(Object.fromEntries(settings.map(setting => [setting.key, setting.value])));
  } catch (err) { sendError(res, err); }
});
router.put('/settings', async (req, res) => {
  try {
    const entries = Object.entries(normalizeSiteSettings(req.body));
    await prisma.$transaction(async tx => {
      for (const [key, value] of entries) await tx.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
      await logAction({ ...auditFor(req), action: 'UPDATE', entity: 'Settings', details: { keys: entries.map(([key]) => key) } }, tx);
    });
    res.json({ message: 'تم تحديث الإعدادات' });
  } catch (err) { sendError(res, err); }
});

// ========== الإعلانات ==========
router.get('/announcements', async (req, res) => {
  const announcements = await prisma.announcement.findMany({ orderBy: { createdAt: 'desc' } });
  res.json(announcements);
});

router.post('/announcements', [body('title').notEmpty(), body('content').notEmpty()], validate, async (req, res) => {
  try {
    const ann = await prisma.announcement.create({
      data: { title: req.body.title, content: req.body.content, targetAudience: req.body.targetAudience || 'ALL' }
    });
    res.status(201).json(ann);
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/announcements/:id', async (req, res) => {
  try {
    const ann = await prisma.announcement.update({ where: { id: req.params.id }, data: pick(req.body, ['title', 'content', 'targetAudience', 'isActive']) });
    res.json(ann);
  } catch (err) {
    sendError(res, err);
  }
});

// ========== التقارير ==========
router.get('/reports/bookings', async (req, res) => {
  try {
    const { from, to, status } = req.query;
    const where = {};
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(to);
    }
    if (status) where.status = status;

    const bookings = await prisma.booking.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: {
        student: { select: { fullName: true, phone: true } },
        courseGroup: { include: { course: { select: { title: true } } } },
        payments: true
      }
    });

    // CSV export
    if (req.query.format === 'csv') {
      const csv = [['الطالب', 'الهاتف', 'الكورس', 'الحالة', 'التاريخ', 'المبلغ المدفوع', 'العملة'].map(csvCell).join(',')];
      bookings.forEach(b => {
        const totals = sumPayments(b.payments);
        for (const item of totals.length ? totals : [{ total: '0.00', currency: 'SDG' }]) {
          csv.push([b.student.fullName, b.student.phone, b.courseGroup.course.title, b.status, b.createdAt.toISOString(), item.total, item.currency].map(csvCell).join(','));
        }
      });
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename=bookings-report.csv');
      return res.send('\uFEFF' + csv.join('\n'));
    }

    res.json({ bookings, total: bookings.length });
  } catch (err) {
    sendError(res, err);
  }
});

router.get('/reports/revenue', async (req, res) => {
  try {
    const { from, to } = req.query;
    const where = {};
    if (from || to) {
      where.recordedAt = {};
      if (from) where.recordedAt.gte = new Date(from);
      if (to) where.recordedAt.lte = new Date(to);
    }

    const payments = await prisma.paymentRecord.findMany({
      where, orderBy: { recordedAt: 'desc' },
      include: {
        booking: {
          include: {
            student: { select: { fullName: true } },
            courseGroup: { include: { course: { select: { title: true } } } }
          }
        }
      }
    });

    const totalsByCurrency = sumPayments(payments);
    // Keep the legacy SDG display accurate; other currencies remain separate.
    const totalRevenue = totalsByCurrency.find(item => item.currency === 'SDG')?.total || '0.00';
    res.json({ payments, totalRevenue, currency: 'SDG', totalsByCurrency });
  } catch (err) {
    sendError(res, err);
  }
});

// ========== سجل التدقيق ==========
router.get('/audit-log', requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const { entity, adminId, page = 1, limit = 50 } = req.query;
    const where = {};
    if (entity) where.entity = entity;
    if (adminId) where.adminId = adminId;

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where, orderBy: { createdAt: 'desc' }, skip: (parseInt(page) - 1) * parseInt(limit), take: parseInt(limit),
        include: { admin: { select: { name: true, email: true } } }
      }),
      prisma.auditLog.count({ where })
    ]);
    res.json({ logs, pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    sendError(res, err);
  }
});

module.exports = router;
