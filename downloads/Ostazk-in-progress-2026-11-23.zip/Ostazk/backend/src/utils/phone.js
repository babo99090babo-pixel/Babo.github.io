// ========== أدوات توحيد أرقام الهاتف السوداني ==========

/**
 * تحويل الأرقام العربية إلى إنجليزية
 */
function convertArabicDigits(str) {
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  return str.replace(/[٠-٩]/g, (d) => arabicDigits.indexOf(d).toString());
}

/**
 * تنظيف الرقم من المسافات والرموز غير اللازمة
 */
function cleanPhone(phone) {
  if (!phone) return '';
  // تحويل الأرقام العربية
  let cleaned = convertArabicDigits(phone.toString());
  // إزالة المسافات والفواصل والأقواس والشرطات
  cleaned = cleaned.replace(/[\s\-\(\)\.\,]/g, '');
  return cleaned;
}

/**
 * توحيد صيغة رقم الهاتف السوداني
 * يحوّل أي صيغة إلى +249XXXXXXXXX
 */
function normalizePhone(phone) {
  let cleaned = cleanPhone(phone);
  
  // إذا بدأ بـ 00249
  if (cleaned.startsWith('00249')) {
    cleaned = '+249' + cleaned.slice(5);
  }
  // إذا بدأ بـ +249
  else if (cleaned.startsWith('+249')) {
    // بالفعل في الصيغة الصحيحة
  }
  // إذا بدأ بـ 249
  else if (cleaned.startsWith('249') && cleaned.length >= 12) {
    cleaned = '+' + cleaned;
  }
  // إذا بدأ بـ 0 (رقم محلي)
  else if (cleaned.startsWith('0')) {
    cleaned = '+249' + cleaned.slice(1);
  }
  // أرقام بدون بادئة
  else if (cleaned.length === 9) {
    cleaned = '+249' + cleaned;
  }

  return cleaned;
}

/**
 * التحقق من صحة رقم الهاتف السوداني
 */
function isValidSudanesePhone(phone) {
  const normalized = normalizePhone(phone);
  // الصيغة: +249 ثم 9 أرقام
  // أرقام الموبايل السودانية تبدأ بـ 9
  return /^\+249[0-9]{9}$/.test(normalized);
}

/**
 * إخفاء جزء من الرقم للعرض العام
 * مثال: +249991***489
 */
function maskPhone(phone) {
  const normalized = normalizePhone(phone);
  if (normalized.length < 10) return '***';
  return normalized.slice(0, 7) + '***' + normalized.slice(-3);
}

module.exports = {
  convertArabicDigits,
  cleanPhone,
  normalizePhone,
  isValidSudanesePhone,
  maskPhone
};
