// Only these site settings may be returned without authentication.
const PUBLIC_SETTING_KEYS = [
  'platform_name', 'platform_description', 'platform_slogan',
  'contact_phone', 'contact_phone_intl', 'contact_whatsapp', 'contact_tel',
  'currency', 'timezone'
];
module.exports = { PUBLIC_SETTING_KEYS };
