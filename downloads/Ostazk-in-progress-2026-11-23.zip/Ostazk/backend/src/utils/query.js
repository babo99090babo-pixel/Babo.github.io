function validatePublicQuery(req, res, next) {
  const integerKeys = ['page', 'limit', 'stage', 'grade', 'subject'];
  for (const [key, value] of Object.entries(req.query)) {
    if (typeof value !== 'string' || value.length > 200) {
      return res.status(400).json({ message: 'خيارات البحث غير صالحة' });
    }
    if (integerKeys.includes(key) && (!/^\d+$/.test(value) || !Number.isSafeInteger(Number(value)) || Number(value) < 1)) {
      return res.status(400).json({ message: 'رقم الصفحة أو التصفية غير صالح' });
    }
    if (key === 'limit' && Number(value) > 100) {
      return res.status(400).json({ message: 'الحد الأقصى 100 نتيجة في الصفحة' });
    }
    if (['minPrice', 'maxPrice'].includes(key) && (!/^\d+(\.\d{1,2})?$/.test(value) || Number(value) > 9999999999)) {
      return res.status(400).json({ message: 'السعر غير صالح' });
    }
    if (key === 'method' && !['INDIVIDUAL_ONSITE', 'GROUP_ONSITE', 'INDIVIDUAL_ONLINE', 'GROUP_ONLINE'].includes(value)) {
      return res.status(400).json({ message: 'نوع الدرس غير صالح' });
    }
  }
  if (req.query.minPrice && req.query.maxPrice && Number(req.query.minPrice) > Number(req.query.maxPrice)) {
    return res.status(400).json({ message: 'راجع الحد الأدنى والأقصى للسعر' });
  }
  next();
}
module.exports = { validatePublicQuery };
