// ========== أدوات رموز التفعيل ==========
const crypto = require('crypto');

// أحرف آمنة بدون أحرف ملتبسة (0/O, 1/l/I)
const SAFE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

/**
 * توليد رمز عشوائي قوي
 */
function generateCode(length = 12) {
  if (!Number.isInteger(length) || length < 12 || length > 32) throw new Error('INVALID_CODE_LENGTH');
  let code = '';
  for (let i = 0; i < length; i++) {
    code += SAFE_CHARS[crypto.randomInt(SAFE_CHARS.length)];
  }
  return code;
}

/**
 * تجزئة الرمز للتخزين الآمن
 */
function hashCode(code) {
  return crypto.createHash('sha256').update(normalizeCode(code)).digest('hex');
}

function normalizeCode(code) {
  return String(code ?? '').toUpperCase().replace(/[\s-]/g, '');
}

/**
 * التحقق من الرمز ضد البصمة المخزنة
 */
function verifyCode(inputCode, storedHash) {
  if (!/^[a-f0-9]{64}$/i.test(String(storedHash))) return false;
  const inputHash = hashCode(inputCode);
  return crypto.timingSafeEqual(
    Buffer.from(inputHash, 'hex'),
    Buffer.from(storedHash, 'hex')
  );
}

/**
 * تنسيق الرمز للعرض (مع فواصل)
 * مثال: ABCD-EFGH-JKLM
 */
function formatCode(code) {
  return normalizeCode(code).match(/.{1,4}/g)?.join('-') || '';
}

module.exports = {
  generateCode,
  hashCode,
  verifyCode,
  formatCode
  ,normalizeCode
};
