const jwt = require('jsonwebtoken');

function validateSecurityConfig() {
  const secrets = ['JWT_SECRET', 'ADMIN_JWT_SECRET'];
  for (const key of secrets) {
    const value = process.env[key];
    if (!value || Buffer.byteLength(value) < 32 || /^(change|your[_-]|example|secret)/i.test(value)) {
      throw new Error(`${key} must be an independent random secret of at least 32 bytes. Run the setup script or see README.`);
    }
  }
  if (process.env.JWT_SECRET === process.env.ADMIN_JWT_SECRET) throw new Error('Student and administrator JWT secrets must be different.');
  const url = new URL(process.env.FRONTEND_URL || 'http://localhost:3000');
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new Error('FRONTEND_URL must contain only the frontend origin.');
  if (process.env.NODE_ENV === 'production' && url.protocol !== 'https:') throw new Error('Production FRONTEND_URL must use HTTPS.');
  for (const [key, fallback] of [['JWT_EXPIRES_IN', '7d'], ['ADMIN_JWT_EXPIRES_IN', '8h']]) {
    const value = jwt.decode(jwt.sign({}, process.env.JWT_SECRET, { expiresIn: process.env[key] || fallback }));
    if (!value.exp || value.exp <= value.iat || value.exp - value.iat > 30 * 86400) throw new Error(`${key} must be between 1 second and 30 days.`);
  }
  return { frontendOrigin: url.origin };
}

function sameOriginMutations(frontendOrigin) {
  return (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origin = req.get('origin');
    if ((origin && origin !== frontendOrigin) || req.get('sec-fetch-site') === 'cross-site') {
      return res.status(403).json({ message: 'افتح الموقع مباشرة ثم حاول من جديد.' });
    }
    // API requests are JSON; multipart uploads must come from the configured frontend.
    // Requests without Origin are allowed for JSON API clients, not cross-site HTML forms.
    if (!origin && req.is('multipart/form-data')) return res.status(403).json({ message: 'ارفع الملف من لوحة الإدارة.' });
    if (req.is('application/x-www-form-urlencoded') || req.is('text/plain')) return res.status(415).json({ message: 'صيغة الطلب غير مدعومة.' });
    next();
  };
}

module.exports = { validateSecurityConfig, sameOriginMutations };
