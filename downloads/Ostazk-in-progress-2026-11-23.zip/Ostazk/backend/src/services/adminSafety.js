const { normalizePhone, isValidSudanesePhone } = require('../utils/phone');
const { PUBLIC_SETTING_KEYS } = require('../utils/publicSettings');
const SETTINGS_KEYS = [...PUBLIC_SETTING_KEYS, 'show_admin_email_as_support'];
const bad = message => Object.assign(new Error(message), { status: 400 });

function normalizeSiteSettings(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw bad('الإعدادات غير صالحة');
  const result = {};
  for (const [key, value] of Object.entries(input)) {
    if (!SETTINGS_KEYS.includes(key)) throw bad('لا يمكن تعديل هذا الإعداد');
    if (typeof value !== 'string' || value.length > 2000) throw bad('قيمة الإعداد غير صالحة');
    result[key] = value.trim();
  }
  const phoneKeys = ['contact_phone', 'contact_phone_intl', 'contact_tel'];
  const phones = phoneKeys.filter(key => key in result).map(key => {
    const value = key === 'contact_tel' ? result[key].replace(/^tel:/i, '') : result[key];
    if (!isValidSudanesePhone(value)) throw bad('رقم التواصل غير صالح');
    return normalizePhone(value);
  });
  if (new Set(phones).size > 1) throw bad('رقما الاتصال المحلي والدولي غير متطابقين');
  if (phones.length) {
    result.contact_phone = `0${phones[0].slice(4)}`;
    result.contact_phone_intl = phones[0];
    result.contact_tel = `tel:${phones[0]}`;
  }
  if ('contact_whatsapp' in result) {
    let number = result.contact_whatsapp;
    if (number.includes('://')) {
      let url;
      try { url = new URL(number); } catch { throw bad('رابط واتساب غير صالح'); }
      if (url.protocol !== 'https:' || url.hostname !== 'wa.me' || url.port || url.username || url.password || url.hash || url.search || !/^\/\d+$/.test(url.pathname)) throw bad('استخدم رابط https://wa.me/ متبوعاً بالرقم الدولي فقط');
      number = url.pathname.slice(1);
    }
    if (!isValidSudanesePhone(number)) throw bad('رقم واتساب غير صالح');
    result.contact_whatsapp = `https://wa.me/${normalizePhone(number).slice(1)}`;
  }
  if ('show_admin_email_as_support' in result && !['true', 'false'].includes(result.show_admin_email_as_support)) throw bad('خيار عرض البريد غير صالح');
  if ('timezone' in result && result.timezone !== 'Africa/Khartoum') throw bad('توقيت المنصة الحالي هو Africa/Khartoum');
  if ('currency' in result && result.currency !== 'SDG') throw bad('أسعار الكورسات الحالية بالجنيه السوداني SDG');
  if ('platform_name' in result && !result.platform_name) throw bad('اسم المنصة مطلوب');
  return result;
}

function csvCell(value) {
  let text = String(value ?? '');
  // Quoting alone does not prevent spreadsheet formulas, including a leading + phone.
  if (/^[\s\u0000-\u001f]*[=+\-@]/.test(text) || /^[\t\r\n]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}
function sumPayments(payments) {
  const cents = new Map();
  for (const payment of payments) {
    const value = String(payment.amount);
    if (!/^-?\d+(\.\d{1,2})?$/.test(value)) throw new Error('Invalid stored payment amount');
    const negative = value.startsWith('-');
    const [whole, fraction = ''] = value.replace(/^-/, '').split('.');
    const amount = (BigInt(whole) * 100n + BigInt(fraction.padEnd(2, '0'))) * (negative ? -1n : 1n);
    const currency = payment.currency;
    if (typeof currency !== 'string' || !/^[A-Z]{3}$/.test(currency)) throw new Error('Invalid stored payment currency');
    cents.set(currency, (cents.get(currency) || 0n) + amount);
  }
  return [...cents].sort(([a], [b]) => a.localeCompare(b)).map(([currency, value]) => {
    const magnitude = value < 0n ? -value : value;
    return { currency, total: `${value < 0n ? '-' : ''}${magnitude / 100n}.${String(magnitude % 100n).padStart(2, '0')}` };
  });
}
function fileSignatureMatches(file, header, tail) {
  if (file.fieldname === 'bookFile') return /^%PDF-(1\.[0-7]|2\.0)[\r\n\s]/.test(header.toString('latin1')) && tail.includes(Buffer.from('%%EOF'));
  if (file.mimetype === 'image/png') return header.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if (file.mimetype === 'image/jpeg') return header[0] === 255 && header[1] === 216 && header[2] === 255;
  if (file.mimetype === 'image/webp') return header.subarray(0,4).toString() === 'RIFF' && header.subarray(8,12).toString() === 'WEBP';
  return false;
}
module.exports = { SETTINGS_KEYS, normalizeSiteSettings, csvCell, sumPayments, fileSignatureMatches };
