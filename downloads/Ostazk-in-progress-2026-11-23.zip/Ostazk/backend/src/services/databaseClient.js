const { PrismaPg } = require('@prisma/adapter-pg');

function databaseOptions(connectionString = process.env.DATABASE_URL) {
  if (!connectionString) throw new Error('DATABASE_URL is required. Run npm run setup-env and configure PostgreSQL.');
  const url = new URL(connectionString);
  if (!['postgres:', 'postgresql:'].includes(url.protocol)) throw new Error('DATABASE_URL must use PostgreSQL.');
  const schema = url.searchParams.get('schema') || 'public';
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(schema)) throw new Error('Invalid PostgreSQL schema name.');
  url.searchParams.delete('schema');
  const max = Number(process.env.DB_POOL_SIZE || 10);
  if (!Number.isInteger(max) || max < 1 || max > 50) throw new Error('DB_POOL_SIZE must be between 1 and 50.');
  return { schema, config: { connectionString: url.toString(), max, connectionTimeoutMillis: 5000, options: `-c search_path=${schema}` } };
}
function createAdapter(connectionString) {
  const { config, schema } = databaseOptions(connectionString);
  return new PrismaPg(config, { schema });
}
function createClient(connectionString) {
  const { PrismaClient } = require('@prisma/client');
  return new PrismaClient({ adapter: createAdapter(connectionString) });
}
module.exports = { createClient, createAdapter, databaseOptions };
