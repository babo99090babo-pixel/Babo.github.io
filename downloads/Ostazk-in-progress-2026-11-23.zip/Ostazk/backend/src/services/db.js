const { createClient } = require('./databaseClient');

// One pool per server process. Routes and services share the same client.
module.exports = createClient();
