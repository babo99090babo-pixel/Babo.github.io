// ========== خدمة سجل التدقيق ==========
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

/**
 * تسجيل إجراء إداري
 */
async function logAction({ adminId, action, entity, entityId, details, ipAddress }, tx = prisma) {
    return tx.auditLog.create({
      data: {
        adminId,
        action,
        entity,
        entityId: entityId?.toString(),
        details: details || {},
        ipAddress
      }
    });
}

module.exports = { logAction };
