const dayjs = require('dayjs');
dayjs.extend(require('dayjs/plugin/utc'));
dayjs.extend(require('dayjs/plugin/timezone'));
const TIME_ZONE = 'Africa/Khartoum';
const TIME_PATTERN = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
function sessionTime(date, time) {
  if (!TIME_PATTERN.test(time)) throw new Error('INVALID_TIME');
  const calendarDate = new Date(date).toISOString().slice(0, 10);
  return dayjs.tz(`${calendarDate} ${time}`, TIME_ZONE).toDate();
}
function todayDate(now = new Date()) {
  return new Date(`${dayjs(now).tz(TIME_ZONE).format('YYYY-MM-DD')}T00:00:00Z`);
}
function sessionWindow(session) {
  const start = sessionTime(session.date, session.startTime);
  const end = sessionTime(session.date, session.endTime);
  if (end <= start) throw new Error('INVALID_TIME_RANGE');
  return { start, end, early: new Date(start.getTime() - 600000) };
}
module.exports = { TIME_ZONE, TIME_PATTERN, sessionTime, todayDate, sessionWindow };
