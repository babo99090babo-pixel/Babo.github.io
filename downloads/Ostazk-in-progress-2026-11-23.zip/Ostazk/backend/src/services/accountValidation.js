function isFullName(value) {
  if (typeof value !== 'string' || value.trim().length > 200) return false;
  const parts = value.trim().split(/\s+/);
  return parts.length >= 4 && parts.every(part => part.length >= 2 && /^[\p{L}\p{M}'’ـ-]+$/u.test(part));
}
function isValidPassword(value) {
  return typeof value === 'string' && value.length >= 8 && Buffer.byteLength(value, 'utf8') <= 72;
}
module.exports = { isFullName, isValidPassword };
