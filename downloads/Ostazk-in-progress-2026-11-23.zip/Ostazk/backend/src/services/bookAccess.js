const path = require('path');
const fs = require('fs/promises');
const prisma = require('./db');

function getUploadDirectory(kind) {
  if (!['books', 'images'].includes(kind)) throw new Error('Invalid upload kind');
  return path.resolve(process.env.UPLOAD_DIR || './uploads', kind);
}

// Resolve symlinks too: a stored path must never expose a file outside the book directory.
async function resolveBookPath(filePath) {
  if (typeof filePath !== 'string' || !filePath) return null;
  try {
    const [root, file] = await Promise.all([
      fs.realpath(getUploadDirectory('books')), fs.realpath(path.resolve(filePath)),
    ]);
    const relative = path.relative(root, file);
    if (!relative || relative.startsWith(`..${path.sep}`) || relative === '..' || path.isAbsolute(relative)) return null;
    return (await fs.stat(file)).isFile() ? file : null;
  } catch (err) {
    if (['ENOENT', 'ENOTDIR', 'EACCES'].includes(err.code)) return null;
    throw err;
  }
}

function accessError(status, message) { return Object.assign(new Error(message), { status }); }

async function assertBookAccess(book, student, download = false) {
  if (!book || book.status !== 'PUBLISHED') throw accessError(404, 'الكتاب ما موجود');
  if (download && !book.allowDownload) throw accessError(403, 'التنزيل غير متاح لهذا الكتاب');
  if (book.accessLevel === 'PUBLIC') return;
  if (!student) throw accessError(401, 'سجّل دخولك لفتح الكتاب');
  if (book.accessLevel === 'REGISTERED') return;
  if (book.accessLevel !== 'SUBSCRIBER' || !book.courseId) throw accessError(403, 'الكتاب غير متاح لحسابك حاليًا. تواصل مع الإدارة.');
  const now = new Date();
  const subscription = await prisma.subscription.findFirst({ where: {
    studentId: student.id, status: 'ACTIVE', startDate: { lte: now }, endDate: { gt: now },
    booking: { status: 'CONFIRMED' },
    courseGroup: {
      courseId: book.courseId,
      status: { notIn: ['CANCELLED', 'FINISHED'] }, course: { isActive: true },
    },
  }, select: { id: true } });
  if (!subscription) throw accessError(403, 'الكتاب دا للمشتركين في الكورس باشتراك ساري');
}

module.exports = { getUploadDirectory, resolveBookPath, assertBookAccess };
