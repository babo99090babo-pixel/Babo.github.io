const { logAction } = require('./auditService');
const { generateCode, hashCode, formatCode } = require('../utils/activationCode');

class DomainError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const closedStatuses = ['CANCELLED', 'FINISHED', 'POSTPONED'];
function assertOpen(group) {
  if (!group || !group.course.isActive || closedStatuses.includes(group.status)) {
    throw new DomainError('المجموعة غير متاحة حالياً');
  }
}
async function lockGroup(tx, id) {
  const rows = await tx.$queryRaw`SELECT id FROM "CourseGroup" WHERE id = ${id} FOR UPDATE`;
  if (!rows.length) throw new DomainError('المجموعة ما موجودة', 404);
  return tx.courseGroup.findUnique({ where: { id }, include: { course: true } });
}
async function syncSeats(tx, group) {
  const count = await tx.booking.count({ where: { courseGroupId: group.id, status: 'CONFIRMED' } });
  const status = closedStatuses.includes(group.status) ? group.status
    : count >= group.maxStudents ? 'FULL' : count >= group.minStudents ? 'CONFIRMED' : 'WAITING_ENROLLMENT';
  return tx.courseGroup.update({ where: { id: group.id }, data: { enrolledCount: count, status } });
}
async function getLockedBooking(tx, id) {
  const initial = await tx.booking.findUnique({ where: { id } });
  if (!initial) throw new DomainError('الحجز ما موجود', 404);
  const group = await lockGroup(tx, initial.courseGroupId);
  const booking = await tx.booking.findUnique({ where: { id }, include: { subscription: true, student: true } });
  return { booking, group };
}
async function createBooking(tx, studentId, courseGroupId) {
  const group = await lockGroup(tx, courseGroupId);
  assertOpen(group);
  if (await tx.booking.findUnique({ where: { studentId_courseGroupId: { studentId, courseGroupId } } })) {
    throw new DomainError('لديك حجز سابق في هذه المجموعة. تواصل مع الإدارة للمساعدة.', 409);
  }
  const fresh = await syncSeats(tx, group);
  const waiting = fresh.enrolledCount >= fresh.maxStudents;
  const booking = await tx.booking.create({ data: { studentId, courseGroupId, status: waiting ? 'WAITLISTED' : 'PENDING_CONTACT' } });
  if (waiting) {
    const last = await tx.waitingList.findFirst({ where: { courseGroupId }, orderBy: { position: 'desc' } });
    await tx.waitingList.create({ data: { studentId, courseGroupId, position: (last?.position || 0) + 1 } });
  }
  return booking;
}
async function confirmBooking(tx, id, audit) {
  const { booking, group } = await getLockedBooking(tx, id);
  assertOpen(group);
  if (!booking.student.isActive || booking.status === 'CANCELLED') throw new DomainError('لا يمكن تأكيد هذا الحجز');
  if (booking.status === 'CONFIRMED') { await syncSeats(tx, group); return booking; }
  const confirmed = await tx.booking.count({ where: { courseGroupId: group.id, status: 'CONFIRMED' } });
  if (confirmed >= group.maxStudents) throw new DomainError('المجموعة مكتملة', 409);
  const updated = await tx.booking.update({ where: { id }, data: { status: 'CONFIRMED', confirmedAt: new Date() } });
  await tx.waitingList.deleteMany({ where: { studentId: booking.studentId, courseGroupId: group.id } });
  await syncSeats(tx, group);
  await logAction({ ...audit, action: 'CONFIRM', entity: 'Booking', entityId: id }, tx);
  return updated;
}
async function cancelBooking(tx, id, reason, audit) {
  const { booking, group } = await getLockedBooking(tx, id);
  const updated = await tx.booking.update({ where: { id }, data: { status: 'CANCELLED', cancelledAt: new Date(), cancellationReason: reason || null } });
  await tx.activationCode.updateMany({ where: { bookingId: id, status: 'ACTIVE' }, data: { status: 'CANCELLED' } });
  await tx.subscription.updateMany({ where: { bookingId: id }, data: { status: 'SUSPENDED' } });
  await tx.waitingList.deleteMany({ where: { studentId: booking.studentId, courseGroupId: group.id } });
  await syncSeats(tx, group);
  await logAction({ ...audit, action: 'CANCEL', entity: 'Booking', entityId: id }, tx);
  return updated;
}
async function issueCodes(tx, items, audit) {
  if (!Array.isArray(items) || !items.length || items.length > 100 || items.some(item => !item || typeof item.studentId !== 'string' || typeof item.bookingId !== 'string')) {
    throw new DomainError('حدد حجوزات صحيحة (حتى 100 حجز في المرة)');
  }
  if (new Set(items.map(i => i.bookingId)).size !== items.length) throw new DomainError('الحجز مكرر في القائمة');
  // Consistent group ordering avoids deadlocks for concurrent batches.
  const bookings = await tx.booking.findMany({ where: { id: { in: items.map(i => i.bookingId) } } });
  for (const groupId of [...new Set(bookings.map(b => b.courseGroupId))].sort()) await lockGroup(tx, groupId);
  const results = [];
  const expiryDays = Math.min(Math.max(Number(process.env.ACTIVATION_CODE_EXPIRY_DAYS) || 30, 1), 365);
  for (const item of items) {
    const booking = await tx.booking.findUnique({ where: { id: item.bookingId }, include: { student: true, subscription: true, courseGroup: { include: { course: true } } } });
    if (!booking || booking.studentId !== item.studentId || booking.status !== 'CONFIRMED' || !booking.student.isActive) {
      throw new DomainError('كل رمز يحتاج حجزاً مؤكداً للطالب المحدد');
    }
    assertOpen(booking.courseGroup);
    if (booking.subscription) throw new DomainError('هذا الحجز لديه اشتراك بالفعل');
    // Issuing a replacement invalidates any earlier unused code.
    await tx.activationCode.updateMany({ where: { bookingId: item.bookingId, status: 'ACTIVE' }, data: { status: 'CANCELLED' } });
    const plainCode = generateCode(12);
    const code = await tx.activationCode.create({ data: { codeHash: hashCode(plainCode), studentId: item.studentId, bookingId: item.bookingId, expiresAt: new Date(Date.now() + expiryDays * 86400000), createdBy: audit.adminId } });
    const formatted = formatCode(plainCode);
    results.push({ id: code.id, code: formatted, studentName: booking.student.fullName, studentPhone: booking.student.phone, courseName: booking.courseGroup.course.title, expiresAt: code.expiresAt,
      whatsappLink: `https://wa.me/${booking.student.phone.replace('+', '')}?text=${encodeURIComponent(`السلام عليكم ${booking.student.fullName}\nرمز تفعيل اشتراكك في "${booking.courseGroup.course.title}":\n${formatted}\nسجّل دخولك في أستاذك وفعّل الرمز من حسابك.`)}` });
  }
  await logAction({ ...audit, action: 'CREATE_CODES', entity: 'ActivationCode', details: { count: results.length } }, tx);
  return results;
}
async function redeemCode(tx, studentId, input) {
  const initial = await tx.activationCode.findUnique({ where: { codeHash: hashCode(input) } });
  if (!initial || initial.studentId !== studentId) throw new DomainError('الرمز ما صالح للحساب دا');
  const { booking, group } = await getLockedBooking(tx, initial.bookingId);
  assertOpen(group);
  const code = await tx.activationCode.findUnique({ where: { id: initial.id } });
  const now = new Date();
  if (code.status !== 'ACTIVE' || code.expiresAt <= now) throw new DomainError('الرمز مستخدم أو ملغي أو انتهت صلاحيته');
  if (booking.studentId !== studentId || !booking.student.isActive || booking.status !== 'CONFIRMED' || booking.subscription) {
    throw new DomainError('الحجز غير متاح للتفعيل. تواصل مع الإدارة.');
  }
  const count = await tx.booking.count({ where: { courseGroupId: group.id, status: 'CONFIRMED' } });
  if (count > group.maxStudents) throw new DomainError('تحتاج الإدارة مراجعة سعة المجموعة');
  const claimed = await tx.activationCode.updateMany({ where: { id: code.id, status: 'ACTIVE', expiresAt: { gt: now } }, data: { status: 'USED', usedAt: now } });
  if (claimed.count !== 1) throw new DomainError('الرمز مستخدم أو انتهت صلاحيته');
  const subscription = await tx.subscription.create({ data: { studentId, courseGroupId: group.id, bookingId: booking.id, activationCodeId: code.id, startDate: now, endDate: new Date(now.getTime() + 90 * 86400000) } });
  await tx.activationCode.update({ where: { id: code.id }, data: { subscriptionId: subscription.id } });
  await syncSeats(tx, group);
  await logAction({ action: 'REDEEM_CODE', entity: 'Subscription', entityId: subscription.id, details: { studentId, bookingId: booking.id } }, tx);
  return subscription;
}
module.exports = { DomainError, closedStatuses, assertOpen, lockGroup, syncSeats, getLockedBooking, createBooking, confirmBooking, cancelBooking, issueCodes, redeemCode };
