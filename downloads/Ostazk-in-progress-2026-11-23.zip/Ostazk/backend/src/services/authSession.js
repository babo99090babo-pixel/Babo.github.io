const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const tokenHash = token => crypto.createHash('sha256').update(token).digest('hex');
const cookieOptions = () => ({
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  path: '/',
});

function signSession(user, type) {
  const admin = type === 'admin';
  return jwt.sign(
    { id: user.id, ...(admin ? { email: user.email, role: user.role } : { phone: user.phone }) },
    process.env[admin ? 'ADMIN_JWT_SECRET' : 'JWT_SECRET'],
    {
      algorithm: 'HS256', issuer: 'ostazk', audience: `ostazk-${type}`,
      jwtid: crypto.randomUUID(),
      expiresIn: process.env[admin ? 'ADMIN_JWT_EXPIRES_IN' : 'JWT_EXPIRES_IN'] || (admin ? '8h' : '7d'),
    }
  );
}

async function issueStudentSession(tx, student, req, { replace = true } = {}) {
  // Serialize login/password changes for the same account, including simultaneous logins.
  await tx.$queryRaw`SELECT id FROM "Student" WHERE id = ${student.id} FOR UPDATE`;
  if (replace) await tx.studentSession.updateMany({ where: { studentId: student.id, isActive: true }, data: { isActive: false } });
  const token = signSession(student, 'student');
  await tx.studentSession.create({ data: {
    studentId: student.id, tokenHash: tokenHash(token),
    deviceInfo: (req.get('user-agent') || '').slice(0, 500), ipAddress: req.ip,
    expiresAt: new Date(jwt.decode(token).exp * 1000),
  } });
  return token;
}

async function issueAdminSession(tx, admin, req, { replace = true } = {}) {
  await tx.$queryRaw`SELECT id FROM "Admin" WHERE id = ${admin.id} FOR UPDATE`;
  if (replace) await tx.adminSession.updateMany({ where: { adminId: admin.id, isActive: true }, data: { isActive: false } });
  const token = signSession(admin, 'admin');
  await tx.adminSession.create({ data: {
    adminId: admin.id, tokenHash: tokenHash(token), expiresAt: new Date(jwt.decode(token).exp * 1000),
  } });
  return token;
}

function setSessionCookie(res, name, token) {
  res.cookie(name, token, { ...cookieOptions(), maxAge: Math.max(0, jwt.decode(token).exp * 1000 - Date.now()) });
}

function clearSessionCookie(res, name) { res.clearCookie(name, cookieOptions()); }

async function revokeAdminSession(tx, token) {
  if (token) await tx.adminSession.updateMany({ where: { tokenHash: tokenHash(token), isActive: true }, data: { isActive: false } });
}

module.exports = { tokenHash, cookieOptions, setSessionCookie, clearSessionCookie, issueStudentSession, issueAdminSession, revokeAdminSession };
