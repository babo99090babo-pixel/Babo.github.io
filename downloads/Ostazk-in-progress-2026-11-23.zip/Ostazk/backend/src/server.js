require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const prisma = require('./services/db');
const { generalLimiter, resetLimiter } = require('./middleware/rateLimiter');
const { optionalAuth } = require('./middleware/auth');
const { assertBookAccess, resolveBookPath, getUploadDirectory } = require('./services/bookAccess');
const { validateSecurityConfig, sameOriginMutations } = require('./services/securityConfig');
const { isValidPassword } = require('./services/accountValidation');
const { clearSessionCookie } = require('./services/authSession');

const { frontendOrigin } = validateSecurityConfig();
const app = express();
app.disable('x-powered-by');
// Set only when the API is reachable exclusively through a trusted reverse proxy.
const proxyHops = Number(process.env.TRUST_PROXY || 0);
if (!Number.isInteger(proxyHops) || proxyHops < 0 || proxyHops > 3) throw new Error('TRUST_PROXY must be 0, 1, 2 or 3.');
app.set('trust proxy', proxyHops);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-origin' } }));
app.use(cors({ origin: frontendOrigin, credentials: true }));
app.use(compression());
// Do not write reset codes or other query parameters to request logs.
if (process.env.NODE_ENV !== 'test') app.use(morgan((tokens, req, res) => `${tokens.method(req, res)} ${req.path} ${tokens.status(req, res)} ${tokens['response-time'](req, res)} ms`));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(sameOriginMutations(frontendOrigin));
app.use('/api', generalLimiter);
app.use(['/api/auth', '/api/admin', '/api/student', '/api/reset-password'], (req, res, next) => {
  res.set('Cache-Control', 'private, no-store');
  next();
});
app.use('/uploads/images', express.static(getUploadDirectory('images'), { dotfiles: 'deny', index: false }));

for (const mode of ['preview', 'download']) {
  app.get(`/api/books/:id/${mode}`, optionalAuth, async (req, res, next) => {
    try {
      res.set('Cache-Control', 'private, no-store');
      const book = await prisma.book.findUnique({ where: { id: req.params.id } });
      await assertBookAccess(book, req.student, mode === 'download');
      const file = await resolveBookPath(book.filePath);
      if (!file) return res.status(404).json({ message: 'ملف الكتاب غير متوفر. تواصل مع الإدارة.' });
      const done = err => { if (err) next(err); };
      if (mode === 'download') return res.download(file, `${book.title}.pdf`, { cacheControl: false }, done);
      res.type('application/pdf');
      res.set('Content-Disposition', 'inline');
      res.sendFile(file, { cacheControl: false }, done);
    } catch (err) { next(err); }
  });
}

app.get('/api/health', async (req, res, next) => {
  try { await prisma.$queryRaw`SELECT 1`; res.json({ status: 'ok' }); } catch (err) { next(err); }
});
app.use('/api/auth', require('./routes/auth'));
app.use('/api', require('./routes/public'));
app.use('/api/student', require('./routes/student'));
app.use('/api/admin', require('./routes/admin'));

app.post('/api/reset-password', resetLimiter, async (req, res, next) => {
  try {
    const { token, id, newPassword } = req.body || {};
    if (typeof token !== 'string' || !/^[a-f0-9]{64}$/i.test(token) || typeof id !== 'string' || !/^[a-f0-9-]{36}$/i.test(id) || !isValidPassword(newPassword)) {
      return res.status(400).json({ message: 'البيانات غير صالحة. كلمة السر تحتاج 8 أحرف على الأقل.' });
    }
    const passwordHash = await bcrypt.hash(newPassword, 12);
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const invalid = () => Object.assign(new Error('الرابط ما صالح أو انتهت صلاحيته'), { status: 400 });
    await prisma.$transaction(async tx => {
      // Lock in the same order as login/change-password, then consume the reset once.
      await tx.$queryRaw`SELECT id FROM "Student" WHERE id = ${id} FOR UPDATE`;
      const student = await tx.student.findUnique({ where: { id }, select: { isActive: true } });
      const setting = await tx.setting.findUnique({ where: { key: `reset_${id}` } });
      if (!student?.isActive || !setting) throw invalid();
      let data;
      try { data = JSON.parse(setting.value); } catch { throw invalid(); }
      if (!/^[a-f0-9]{64}$/.test(data.hash || '') || !crypto.timingSafeEqual(Buffer.from(tokenHash, 'hex'), Buffer.from(data.hash, 'hex')) || !(new Date(data.expiresAt) > new Date())) throw invalid();
      const consumed = await tx.setting.deleteMany({ where: { key: setting.key, value: setting.value } });
      if (consumed.count !== 1) throw invalid();
      await tx.student.update({ where: { id }, data: { passwordHash } });
      await tx.studentSession.updateMany({ where: { studentId: id, isActive: true }, data: { isActive: false } });
    });
    clearSessionCookie(res, 'studentToken');
    res.json({ message: 'تم تغيير كلمة السر وإغلاق الجلسات السابقة. سجّل دخولك بالكلمة الجديدة.' });
  } catch (err) { next(err); }
});

app.use((req, res) => res.status(404).json({ message: 'الصفحة ما موجودة' }));
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (err instanceof require('multer').MulterError) {
    return res.status(400).json({ message: err.code === 'LIMIT_FILE_SIZE' ? `الملف كبير جداً. الحد الأقصى ${process.env.MAX_FILE_SIZE_MB || 50} ميقا` : 'خطأ في رفع الملف' });
  }
  if (err.status >= 400 && err.status < 500) return res.status(err.status).json({ message: err.status === 400 && err.type === 'entity.parse.failed' ? 'صيغة الطلب غير صالحة' : err.message });
  if (['P1001', 'P1002', 'P1008', 'P1017', 'P2024'].includes(err.code)) return res.status(503).json({ message: 'الخدمة غير متاحة مؤقتًا. حاول بعد قليل.' });
  console.error('Server error:', err.code || err.name);
  res.status(500).json({ message: 'حصل خطأ في الخادم. حاول بعد قليل.' });
});

if (require.main === module) {
  const port = Number(process.env.PORT || 5000);
  prisma.$connect().then(() => {
    const server = app.listen(port, process.env.HOST || '127.0.0.1', () => console.log(`Ostazk API: http://${process.env.HOST || '127.0.0.1'}:${port}`));
    const shutdown = () => server.close(() => prisma.$disconnect().finally(() => process.exit(0)));
    process.once('SIGTERM', shutdown);
    process.once('SIGINT', shutdown);
  }).catch(err => { console.error('Database connection failed:', err.code || err.name); process.exitCode = 1; });
}
module.exports = app;
