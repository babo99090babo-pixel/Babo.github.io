const jwt = require('jsonwebtoken');
const prisma = require('../services/db');
const { tokenHash, clearSessionCookie } = require('../services/authSession');

function decodeToken(token, type) {
  if (!token) return null;
  try {
    return jwt.verify(token, process.env[type === 'admin' ? 'ADMIN_JWT_SECRET' : type === 'teacher' ? 'TEACHER_JWT_SECRET' : 'JWT_SECRET'], {
      algorithms: ['HS256'], issuer: 'ostazk', audience: `ostazk-${type}`,
    });
  } catch (err) {
    if (['JsonWebTokenError', 'TokenExpiredError', 'NotBeforeError'].includes(err.name)) return null;
    throw err;
  }
}

async function currentStudent(token) {
  const decoded = decodeToken(token, 'student');
  if (!decoded || typeof decoded.id !== 'string' || !decoded.jti) return null;
  const session = await prisma.studentSession.findUnique({
    where: { tokenHash: tokenHash(token) },
    include: { student: { select: { id: true, phone: true, fullName: true, isActive: true } } },
  });
  if (!session || !session.isActive || session.expiresAt <= new Date() || !session.student.isActive || session.studentId !== decoded.id) return null;
  return session.student;
}

async function authenticateStudent(req, res, next) {
  try {
    req.student = await currentStudent(req.cookies?.studentToken);
    if (!req.student) {
      clearSessionCookie(res, 'studentToken');
      return res.status(401).json({ message: 'الجلسة انتهت أو الحساب غير متاح، سجّل دخولك تاني' });
    }
    next();
  } catch (err) { next(err); }
}

async function authenticateAdmin(req, res, next) {
  try {
    const token = req.cookies?.adminToken;
    const decoded = decodeToken(token, 'admin');
    const session = decoded?.id && decoded.jti ? await prisma.adminSession.findUnique({
      where: { tokenHash: tokenHash(token) }, include: { admin: true },
    }) : null;
    if (!session || !session.isActive || session.expiresAt <= new Date() || !session.admin.isActive || session.adminId !== decoded.id) {
      clearSessionCookie(res, 'adminToken');
      return res.status(401).json({ message: 'الجلسة انتهت، سجّل دخولك تاني' });
    }
    // Read the current role rather than trusting old JWT claims.
    req.admin = { id: session.admin.id, email: session.admin.email, name: session.admin.name, role: session.admin.role };
    next();
  } catch (err) { next(err); }
}

async function authenticateTeacher(req, res, next) {
  try {
    const decoded = decodeToken(req.cookies?.teacherToken, 'teacher');
    const teacher = decoded?.id ? await prisma.teacher.findUnique({ where: { id: decoded.id } }) : null;
    if (!teacher || !teacher.isActive || !teacher.isApproved) return res.status(401).json({ message: 'الدخول مطلوب' });
    req.teacher = { id: teacher.id, name: teacher.name };
    next();
  } catch (err) { next(err); }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.admin || !roles.includes(req.admin.role)) return res.status(403).json({ message: 'ما عندك صلاحية لدا' });
    next();
  };
}

async function optionalAuth(req, res, next) {
  try {
    req.student = await currentStudent(req.cookies?.studentToken);
    if (req.cookies?.studentToken && !req.student) clearSessionCookie(res, 'studentToken');
    next();
  } catch (err) { next(err); }
}

module.exports = { authenticateStudent, authenticateAdmin, authenticateTeacher, requireRole, optionalAuth };
