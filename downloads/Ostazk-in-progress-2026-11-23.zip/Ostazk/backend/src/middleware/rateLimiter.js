const rateLimit = require('express-rate-limit');
const { normalizePhone } = require('../utils/phone');

const common = { standardHeaders: true, legacyHeaders: false };
const generalLimiter = rateLimit({
  ...common, windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: Number(process.env.RATE_LIMIT_MAX) || 500,
  message: { message: 'طلبات كتيرة. استنى شوية وحاول تاني.' },
});
const loginIpLimiter = rateLimit({
  ...common, windowMs: 15 * 60 * 1000, max: Number(process.env.LOGIN_IP_RATE_LIMIT_MAX) || 30,
  message: { message: 'محاولات دخول كتيرة. استنى 15 دقيقة وحاول تاني.' },
});
// Normalizing phone formats closes the local/international spelling bypass.
const loginAccountLimiter = rateLimit({
  ...common, windowMs: 15 * 60 * 1000, max: Number(process.env.LOGIN_RATE_LIMIT_MAX) || 5,
  message: { message: 'محاولات دخول كتيرة. استنى 15 دقيقة وحاول تاني.' },
  skipSuccessfulRequests: true,
  keyGenerator: req => typeof req.body?.email === 'string'
    ? `email:${req.body.email.trim().toLowerCase()}`
    : `phone:${normalizePhone(String(req.body?.phone || ''))}`,
});
const loginLimiter = [loginIpLimiter, loginAccountLimiter];
const activationLimiter = rateLimit({
  ...common, windowMs: 15 * 60 * 1000, max: Number(process.env.ACTIVATION_RATE_LIMIT_MAX) || 5,
  skipSuccessfulRequests: true,
  keyGenerator: req => req.student?.id || req.ip,
  message: { message: 'محاولات تفعيل كتيرة. استنى 15 دقيقة وحاول تاني.' },
});
const registerLimiter = rateLimit({
  ...common, windowMs: 60 * 60 * 1000, max: Number(process.env.REGISTER_RATE_LIMIT_MAX) || 10,
  message: { message: 'تم إنشاء حسابات كتيرة. حاول بعد ساعة.' },
});
const resetLimiter = rateLimit({
  ...common, windowMs: 15 * 60 * 1000, max: Number(process.env.RESET_RATE_LIMIT_MAX) || 10,
  message: { message: 'محاولات كتيرة. استنى 15 دقيقة وحاول تاني.' },
});
module.exports = { generalLimiter, loginLimiter, activationLimiter, registerLimiter, resetLimiter };
