require('dotenv').config();
const { defineConfig } = require('prisma/config');
const { createAdapter } = require('./src/services/databaseClient');

// Prisma's JavaScript/WASM engine uses the normal PostgreSQL driver on Windows and Linux.
module.exports = defineConfig({
  schema: './prisma/schema.prisma',
  engine: 'js',
  experimental: { adapter: true },
  adapter: async () => createAdapter(),
  migrations: { path: './prisma/migrations', seed: 'node src/scripts/seed.js' },
});
